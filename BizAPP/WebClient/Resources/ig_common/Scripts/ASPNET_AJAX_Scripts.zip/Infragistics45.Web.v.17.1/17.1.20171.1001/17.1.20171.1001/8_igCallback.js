/*
* 8_igCallback.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");


$IG.CallbackRequestHandler = function (manager, callbackObject, async)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CallbackRequestHandler">
	/// Handles a CallbackObject's request and resposne.
	/// </summary>
	var me = this;
	this._callbackObject = callbackObject;
	this._manager = manager;
	this._async = async;

	this._responseComplete = function ()
	{
		if (me._request.readyState === 4 && me._request.status == "200")
		{
			window.clearTimeout(me._timerId);
			var response = me._request.responseText;
			if (response != null && response.length > 0)
			{
				var obj;
				var failed = false;
				try
				{
					obj = Sys.Serialization.JavaScriptSerializer.deserialize(response)
				}
				catch (e)
				{					
					

					if (response.indexOf("[") != 0 && (response.indexOf("<HTML") > -1 || response.indexOf("<html") > -1))
					{
						document.write(response);
						return;
					}
					failed = true;
					me._manager._requestFailed(me, me._callbackObject, false, "Deserialization failure: Invalid response.");
				}
				if (!failed)
				{
					
					var vs = me._callbackObject;
					if (vs)
						vs = vs._control;
					if (!vs)
						if (vs = obj[2])
							vs = $find(vs.id);
					
					if (vs && vs._get_clientOnlyValue && vs._get_clientOnlyValue('vscb') == 1)
						vs = false;
					else
						vs = true;

					var viewState = document.getElementById("__VIEWSTATE");
					
					var compressedViewState = document.getElementById("__COMPRESSEDVIEWSTATE");
					
					if (vs && obj[0] && obj[0].length > 3)
					{
						if (viewState)
							viewState.value = obj[0];
						else if (compressedViewState)
							compressedViewState.value = obj[0];
					}
					var eventValidation = document.getElementById("__EVENTVALIDATION");
					if (eventValidation && vs && obj[1] && obj[1].length > 3)
						eventValidation.value = obj[1];
					me._manager._requestCompleted(me, me._callbackObject, obj[2]);
					for (var i in obj[3])
					{
						var item = obj[3][i];
						if (typeof item != 'object')
							continue;
						var id = item[0];
						var ctrlObj = $find(id);
						if (ctrlObj && ctrlObj.dispose)
							ctrlObj.dispose();
						if (item[1])
							var x = eval(item[1]);
					}
				}
			}
			else
			{
				me._timedOut();
			}

			me._callbackObject = null;
			me._manager = null;
			me._request = null;
		}
		else if (me._request.readyState === 4)
		{
			me._manager._requestFailed(me, me._callbackObject, false, "Async request failed " + me._request.responseText.substr(me._request.responseText.indexOf("</html>") + 7).replace("<!--", "").replace("-->", ""));
		}
	}
}

$IG.CallbackRequestHandler.prototype =
{
	execute: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackRequestHandler.execute">
		/// Executes a XmlHttpRequest to the server
		/// </summary>
		this._request = null;
		if (typeof XMLHttpRequest != "undefined")
			this._request = new XMLHttpRequest();
		else if (typeof ActiveXObject != "undefined")
		{
			try { this._request = ig_createActiveXFromProgIDs(["MSXML2.XMLHTTP", "Microsoft.XMLHTTP"]); } catch (e) { }
		}

		if (this._request)
		{
			var ctl = this._manager._control;
			if (ctl)
			{
				
				
				var pi = this._noPI ? null : ctl.get_ajaxIndicator;
				if (pi)
					pi = ctl.get_ajaxIndicator();
				
				if (pi)
					pi.show(ctl);
				
				
				ctl._posted = new Date().getTime();
			}
			this._request.open(this._manager.getHttpVerb(), this._manager.getUrl(), this._async);
			
			this._request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=utf-8');
			// This header will inform the server to compress the response, if browser supports compression
			this._request.setRequestHeader("X-AJAX", "true");
			this._request.onreadystatechange = this._responseComplete;
			this._timerId = window.setTimeout(Function.createDelegate(this, this._timedOut), this._manager.getTimeout());
			
			$util._asyncCtl = ctl;
			this._request.send(this._getArgs());
			delete $util._asyncCtl;
		}
	},

	_getArgs: function()
	{
		var form = this._manager._getForm();
		if (!form) return;

		
		if (typeof ig_controls == 'object')
			for (var id in ig_controls)
				ig_controls[id]._onIgSubmit();

		var count = form.elements.length;
		var element;
		for (var i = 0; i < count; i++)
		{
			element = form.elements[i];
			if (element.tagName.toLowerCase() == "input" && (element.type == "hidden" || element.type == 'password' || element.type == 'text' || ((element.type == "checkbox" || element.type == 'radio') && element.checked)))
				this._addCallbackField(element.name, element.value);
			else if (element.tagName.toLowerCase() == "textarea")
				this._addCallbackField(element.name, element.value);
			else if (element.tagName.toLowerCase() == "select")
			{
				var o = element.options.length;
				while (o-- > 0)
				{
					if (element.options[o].selected)
						this._addCallbackField(element.name, element.options[o].value);
				}
			}
		}

		var args = this._postdata + "__EVENTTARGET=&__EVENTARGUMENT=&__IGCallback_" + this._manager._control._id + "=";
		args += Sys.Serialization.JavaScriptSerializer.serialize(this._callbackObject._getServerData());
		return args;
	},

	_addCallbackField: function(name, value)
	{
		if (!this._postdata)
			this._postdata = "";
		this._postdata += name + "=" + this._encodeValue(value) + "&";
	},

	_encodeValue: function(uri)
	{
		if (encodeURIComponent != null)
			return encodeURIComponent(uri);
		else
			return escape(parameter);
	},

	_timedOut: function()
	{
		this._manager._requestFailed(this, this._callbackObject, true, "Async response time out.");
	}
};
$IG.CallbackRequestHandler.registerClass("Infragistics.Web.UI.CallbackRequestHandler");



$IG.ControlCallbackManager = function (control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ControlCallbackManager">
	/// An object in charge of managin all Callbacks for an Infragistics.Web.UI.Control.
	/// </summary>
	this._control = control;
	this._httpVerb = "POST"
	this._async = true;
	this._timeout = 20000;
	this._url = this._getForm().action;
	
	if ($util.IsIE7 && this._url == "")
		this._url = this._getForm().document.location.href;


	this._currentRequests = 0;
	this._callbackQueue = [];
}

$IG.ControlCallbackManager.prototype =
{
	createCallbackObject: function(control)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.createCallbackObject">
		/// Creates a new CallbackObject for the control.
		/// </summary>
		///<param type="Object" name="control"> IG control </param>
		///<returns type="Infragistics.Web.UI.CallbackObject" mayBeNull="false"></returns>
		if (!control)
			control = this._control;
		return new $IG.CallbackObject(control);
	},

	execute: function(callback, queue, async, noIndicator)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.execute">
		/// Initiates an XmlHTTPRequest for the specified CallbackObject.
		/// </summary>
		///<param type="Infragistics.Web.UI.CallbackObject" name="callback"> callback </param>
		///<param type="Boolean" name="queue"> queue the request or not</param>
		///<param type="Boolean" name="async"> whether the request will be Async (AJAX) or full </param>
		///<param type="Boolean" name="noIndicator"> indicates if AjaxIndicator should be shown </param>
		
		this._timeOut = null;
		if (callback)
		{
			if (async == null)
				async = this.getAsync();
			var requestHandler = new $IG.CallbackRequestHandler(this, callback, async);
			requestHandler._noPI = noIndicator;
			if (queue && this._currentRequests > 0)
				this._pushCallback(requestHandler)
			else
			{
				this._currentRequests++;
				requestHandler.execute();
			}
		}
	},

	_pushCallback: function(callback)
	{
		this._callbackQueue.push(callback);
	},

	_popCallback: function()
	{
		for (var i = 0; i < this._callbackQueue.length; i++)
		{
			var requestHandler = this._callbackQueue[i];
			if (requestHandler != null)
			{
				delete this._callbackQueue[i];
				this._currentRequests++;
				requestHandler.execute();
			}
		}
	},

	getAsync: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.getAsync">
		/// Get/Sets whether or not the Callback should be Async.
		/// The Default is true.
		/// </summary>
		///<returns type="Boolean"> indicates if callback is async </returns>
		return this._async;
	},
	setAsync: function(val) { return this._async; },

	getHttpVerb: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.getHttpVerb">
		/// Get/Sets the HTTP Verb for the Callback.
		/// The Default is "Post"
		/// </summary>
		///<returns type="String">HTTP Verb </returns>
		return this._httpVerb;
	},
	setHttpVerb: function(verb) { this._httpVerb = verb; },

	getUrl: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.getUrl">
		/// Get/Sets the url for the Callback. 
		/// The default is the current form's action.
		/// </summary>
		return this._url;
	},
	setUrl: function(url) { this._url = url; },

	getTimeout: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.getTimeout">
		/// Get/Sets the amount of time (in ms) that is allowed to pass before failing the Callback.
		/// The default is 20000
		/// </summary>
		///<returns type="Integer"> timeout for the request </returns>
		return this._timeout;
	},
	setTimeout: function(val) { this._timeout = val; },

	_getForm: function()
	{
		if (!this._form)
		{
			if (document.forms.length > 1)
			{
				for (var i = 0; i < document.forms.length; i++)
				{
					if (document.forms[i].method == "post" && document.forms[i].action != "")
					{
						this._form = document.forms[i];
						break;
					}
				}
				if (!this._form)
					this._form = document.forms[0];
			}
			else
				this._form = document.forms[0];
			if (!this._form)
				this._form = document.form1;
		}
		return this._form
	},

	_endRequest: function()
	{
		this._currentRequests--;
		if (this._callbackQueue.length > 0)
			this._popCallback();
		
		
		var pi = this._control;
		pi = (pi && pi.get_ajaxIndicator) ? pi.get_ajaxIndicator() : null;
		
		if (pi)
			pi.hide();
	},

	setResponseComplete: function(func, context)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.setResponseComplete">
		/// Sets the method that should be called when the Callback has returned from the server. 
		/// </summary>
		///<param name="func" type="Object"> function to call after response is complete </param>
		/// param name="context" type="Object"> context </param>
		this._responseCompleteFunction = func;
		if (!context)
			context = this._control;
		this._responseCompleteContext = context;
	},

	_requestFailed: function(requestHandler, callbackObject, timedOut, message)
	{
		window.clearTimeout(requestHandler._timerId);
		if (requestHandler._request.readyState == 4)
			callbackObject._responseCompleteError(requestHandler._request, timedOut || this._timeOut, message);
		else
			
			
			this._timeOut = true;
		this._endRequest();
		requestHandler._request.abort();
		requestHandler._request = null;
		
		if (this._control)
			this._control._posted = false;
	},

	_requestCompleted: function(requestHandler, callbackObject, responseObject)
	{
		
		this._endRequest();
		
		
		var ctl = this._control;
		if (!ctl)
			return;
		var id = ctl._id, pi = ctl._pi, elem = ctl._element;
		
		$util._skip_pi = true;
		
		ctl._pi = null;
		this._recursiveResponseCompleted(callbackObject, responseObject, requestHandler._request);
		
		$util._skip_pi = null;
		
		if (ctl._element != elem)
			ctl = ig_controls[id];
		
		if (ctl)
		{
			ctl._pi = pi;
			ctl._posted = false;
		}
	},

	_recursiveResponseCompleted: function(callbackObject, responseObject, browserResponseObject)
	{
		this._responseComplete(callbackObject, responseObject, browserResponseObject);
		for (var i = 0; i < callbackObject._childCallbacks.length; i++)
			this._recursiveResponseCompleted(callbackObject._childCallbacks[i], responseObject.children[i], browserResponseObject);
	},

	_responseComplete: function(callbackObject, responseObject, browserResponseObject)
	{
		if (!callbackObject._responseComplete(responseObject, browserResponseObject))
		{
			if (this._responseCompleteFunction)
				this._responseCompleteFunction.apply(this._responseCompleteContext, [callbackObject, responseObject, browserResponseObject]);
		}
		callbackObject.dispose();
	},

	dispose: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.ControlCallbackManager.dispose">
	/// for internal use only
	///</summary>
		this._control = null;
		this._form = null;
		this._responseCompleteContext = null;
	}

};
$IG.ControlCallbackManager.registerClass("Infragistics.Web.UI.ControlCallbackManager");



$IG.CallbackObject = function(control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.CallbackObject">
	/// An object that contains information about a Callback that should be made to the server.
	/// </summary>
	this._control = control;
	this.serverContext = {};
	this.clientContext = {};
	this._childCallbacks = [];
}

$IG.CallbackObject.prototype =
{
	createCallbackObject: function(control)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackObject.createCallbackObject">
		/// Creates a child CallbackObject of the current CallbackObject
		/// </summary>
		///<param name="control" type="Object">IG control </param>
		if (!control)
			control = this._control;
		var callbackObject = new $IG.CallbackObject(control);
		this._childCallbacks.push(callbackObject);
		return callbackObject;
	},

	getId: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackObject.getId">
		/// Returns the id of the control that is attached to the callback.
		/// </summary>
		///<returns type="String"> id of the control attached to the callback </returns>
		return this._control._id;
	},

	getServerContext: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackObject.getServerContext">
		/// Returns the JSON object that will be used to pass infomration to the server about the specific Callback
		/// </summary>    
		///<returns type="Object"> JSON object </returns>
		return this.serverContext;
	},
	getClientContext: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackObject.getClientContext">
		/// Returns the JSON object that will be used to pass infomration to the ResponseComplete event of the Callback.
		/// </summary>    
		///<returns type="Object"> JSON object</returns>
		return this.clientContext;
	},

	setResponseComplete: function(func, context, funcError)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CallbackObject.setResponseComplete">
		/// Sets an event listener for the ResponseComplete event of the CallbackObject
		/// </summary>    
		///<param name="func" type="Object"> function to call after response is complete </param>
		/// param name="context" type="Object"> context </param>
		/// param name="funcError" type="Object"> function to call when there is error </param>
		this._responseCompleteFunction = func;
		this._responseCompleteErrorFunction = funcError;
		if (!context)
			context = this._control;
		this._responseCompleteContext = context;
	},

	_responseComplete: function(responseObj, browserResponseObject)
	{
		if (this._responseCompleteFunction)
		{
			this._responseCompleteFunction.apply(this._responseCompleteContext, [this, responseObj, browserResponseObject]);
			return true;
		}
		else if (this._control && this._control.__responseCompleteInternal)
		{
			this._control.__responseCompleteInternal(this, responseObj, browserResponseObject);
			return true;
		}
		return false;
	},

	_responseCompleteError: function(responseObj, timedOut, message)
	{
		if (this._responseCompleteErrorFunction)
		{
			this._responseCompleteErrorFunction.apply(this._responseCompleteContext, [this, responseObj, timedOut, message]);
			return true;
		}
		else if (this._control && this._control._responseCompleteError)
		{
			this._control._responseCompleteError(this, responseObj, timedOut, message);
			return true;
		}
		return false;
	},

	_parseErrorMessage: function(browserResponseObject)
	{
		var errorMessage = browserResponseObject.responseText;
		if (errorMessage.substr(0, 6) == "<html>")
		{
			var indexStart = errorMessage.indexOf("<!--");
			var indexEnd;
			if (indexStart > 0)
			{
				indexStart += 4;
				indexEnd = errorMessage.indexOf("-->", indexStart);
				if (indexEnd < 0)
					indexEnd = errorMessage.length;
				errorMessage = errorMessage.substr(indexStart, indexEnd - indexStart);
			}
		}
		return errorMessage;
	},
	_getServerData: function()
	{
		var data = { id: this._control ? this._control.get_uniqueID() : '', context: this.serverContext, children: [] };
		for (var i = 0; i < this._childCallbacks.length; i++)
			data.children[i] = this._childCallbacks[i]._getServerData();
		return data;
	},

	dispose: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.CallbackObject.dispose">
	/// for internal use only
	///</summary>
		this._control = null;
		this.serverContext = null;
		this.clientContext = null;
	}

};
$IG.CallbackObject.registerClass("Infragistics.Web.UI.CallbackObject");


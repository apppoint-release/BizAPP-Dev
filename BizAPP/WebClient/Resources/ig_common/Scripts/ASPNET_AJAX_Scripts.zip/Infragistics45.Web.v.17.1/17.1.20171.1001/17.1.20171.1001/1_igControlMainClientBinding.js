/*
* 1_igControlMainClientBinding.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


$IG.ControlMain.prototype.get_clientbindingprops = function ()
{
return this._props;
}
	
// note that we shouldn't do this for the WDG ! 
$IG.ControlMain.prototype.set_clientbindingprops = function(value)
{
    if (this._usesCollectionsClientState && this._supportsClientRendering && this._thisType !== 'tree')
	{
		this._dataStore = value;
		this._props = value[0];
		this._clientStateManager = new $IG.ObjectClientStateManager(this._props);
		this._objectsManager = new $IG.ObjectsManager(this, value[1]);
		// instantiate the new $IG.MSAjaxCollectionManager
		this._collectionsManager = new $IG.MSAjaxCollectionsManager(this, value[4], this._bindings, this._parentBinding);
		this._initClientEvents(value[3]);

	} else
	{
		this.set_props(value);
	}
}

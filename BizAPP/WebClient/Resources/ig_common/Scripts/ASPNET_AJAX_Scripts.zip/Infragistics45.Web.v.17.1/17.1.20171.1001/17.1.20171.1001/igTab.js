/*
* igTab.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


//vs 12/12/13
Type.registerNamespace('Infragistics.Web.UI');


$IG.TabProps = new function()
{
	var count = $IG.LayoutControlProps.Count;
	this.TabItemSize = [count++, ''];
	this.TextOverflow = [count++, 0];
	this.SelectedIndex = [count++, 0];
	this.TabsOverflow = [count++, 1];
	this.EnableValidation = [count++, 1];
	this.ScrollPosition = [count++, 0];
	this.VisibleHeader = [count++, 1];
	this.VisibleContent = [count++, 1];
	this.Count = count;
};


$IG.WebTab = function(elem)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebTab">Class which implements client side functionality of WebTab.</summary>
	/// <param name="elem" domElement="true" mayBeNull="false">Reference to html element.</param>
	$IG.WebTab.initializeBase(this, [elem]);

	$IG.WebTab.find = $find;
	$IG.WebTab.from = $IG._from;
}
$IG.WebTab.prototype =
{
	_thisType: 'tab',
	// M.P.: Tolerace between expected size and actual i.e. the tab won't resize if the difference is less than this value
	_offsetRatio: 4,
	_responseComplete: function(cb, response, obj)
	{
	    $IG.WebTab.callBaseMethod(this, '_responseComplete', [cb, response, obj]);
	    this._clientStateManager ? this._clientStateManager.override_value($IG.TabProps.SelectedIndex, this.get_selectedIndex()) : "";
	},

	initialize: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.initialize">Initializes instance of WebTab.</summary>
		$IG.WebTab.callBaseMethod(this, 'initialize');
		
		this.set_tabItemSize(this.get_tabItemSize(), 1);
		this._input = $get(this._id + '.i');
		
		this._cssT = this._get_clientOnlyValue('tc').split('|');
		
		this._cssOverlap = this._get_clientOnlyValue('to');
		
		var p = this._get_clientOnlyValue('p').split('|');
		
		this._mode = parseInt(p[0]);
		
		var loc = this._location = parseInt(p[1]);
		
		this._LR = loc > 3;
		
		this._RIGHT = loc > 5;
		
		this._TOP = loc < 2;
		
		this._RIGHT_BOT = (loc & 1) == 1;
		
		this._horiz = p[2] == '0';
		this._textBreak = p[2] == '2';
		
		
		this._6spans = this._LR == this._horiz;
		
		this._enabled = p[3] != '2';
		
		this._activation = p[3] == '1';
		
		
		this._active_if = this._active_i = -1;
		
		this._postClick = p[4] == '1';
		
		this._postUnsel = p[5] == '1';
		
		this._lod = p[6];
		
		this._lodUrl = p[7] == '1';
		
		this._autoHide = p[8] == '1';
		
		this._addDur = parseInt(p[9]);
		
		this._editOnAdd = p[10] == '1';
		
		this._editOnDbl = p[11] == '1';
		
		this._addSelect = p[12] == '1';
		
		this._hasClose = p[13] == '1';
		
		this._closeDur = parseInt(p[14]);
		
		this._cssCloseSize = p[15];
		
		this._cbHovImg = p[16];
		
		this._addHovImg = p[17];
		
		
		var cp = this._get_clientOnlyValue('cp').split('|');
		
		this._minWidth = parseInt(cp[0]);
		
		this._maxWidth = parseInt(cp[1]);
		
		this._minHeight = parseInt(cp[2]);
		
		this._maxHeight = parseInt(cp[3]);
		
		this._autoSize = parseInt(cp[4]);
		
		this._rbPadHoriz = (cp.length > 5) ? parseInt(cp[5]) : 0;
		
		this._rbPadVert = (cp.length > 5) ? parseInt(cp[6]) : 0;
		this._tabs = this._itemCollection._items;
		var tabs = this._tabs;
		var vi = 0, i = tabs.length, elems = this._elements;
		
		var add = elems.ads;
		if (add)
		{
			add._i = add._vi = i;
			add._add = 1;
			add._lastInRow = true;
			add = this._addTab = {_elem: add, _enabled: 1, _hidden: false, _tabSize: 0, _i: i, _vi: i, _add: 1, _img: elems.adi};
		}
		
		this._scroll = -this._get_value($IG.TabProps.ScrollPosition);
		
		var sb = this._get_clientOnlyValue('sb'), sb1 = elems.sb1;
		if (sb && sb1)
		{
			if (this._LR)
				this._sbHolder = sb1.parentNode;
			this._sbImgs = sb = sb.split('|');
			
			this._scrollStart = parseInt(sb[0]);
			this._scrollEnd = parseInt(sb[4]);
			sb[0] = sb1.src;
			sb[4] = elems.sb2.src;
		}
		
		var ti = elems.ti0;
		if (!ti)
			ti = elems.nts;
		
		if (ti)
			this._holder = ti = ti.parentNode;
		if (ti)
			ti = ti.firstChild;
		
		var tiPrev = null, nextRow = false;
		
		while (ti)
		{
			if ($util._isXAttrContains(ti, 'mkr:ti'))
			{
				ti._vi = vi++;
				
				if (nextRow)
				{
					ti._nextRow = true;
					nextRow = false;
				}
				tiPrev = ti;
			}
			
			else if (ti.nodeName == 'SPAN' && ti.style.clear == 'left' && tiPrev)
			{
				
				tiPrev._lastInRow = true;
				nextRow = true;
			}
			ti = ti.nextSibling;
		}
		
		
		
		this._cssTi = new Object();
		p = this._get_clientOnlyValue('tic');
		if (p)
		{
			p = p.split('|');
			for (ti = 0; ti < p.length + 1; ti += 2)
				this._cssTi[p[ti]] = p[ti + 1];
		}
		var selIndex = this._get_value($IG.TabProps.SelectedIndex);
		this._map = new Array();
		
		while (i-- > 0)
		{
			var tab = tabs[i];
			if (i == selIndex)
			{
				tab._loaded = true;
				this._tab = tab;
				tab.set_scrollLeft(tab.get_scrollLeft());
				tab.set_scrollTop(tab.get_scrollTop());
			}
			tab._hidden = tab.get_hidden();
			tab.set_tabSize(tab.get_tabSize(), 1);
			tab._enabled = tab.get_enabled();
			tab._i = i;
			tab._elem = elems['ti' + i];
			vi = tab._vi = tab._elem._vi;
			tab._elem._i = i;
			this._map[vi] = i;
			
			vi = tab.get_enableCloseButton();
			tab._hasClose = vi == 1 || (vi == 0 && this._hasClose);
			
			this._textSpan(tab);
			
			
			if (tab._img && (!tab._enabled || i == selIndex))
				this._cssTi[i + (tab._enabled ? ',52' : ',54')] = tab._img.src;
		}
		
		p = this._get_clientOnlyValue('tm');
		if (p && p.length > 10)
			this._moving = p.split('|');
		
		p = this._element.style;
		this._width0 = p.width;
		this._height0 = p.height;
		
		this._onTimer(true);
		
		ig_ui_timer(this);
		this._timerOn = 1;
		if (!this._enabled)
		{
			this._fixScrollImg(0, 3);
			this._fixScrollImg(1, 3);
		}
		if (!this.get_visibleHeader())
			this._fixVisHead(elems);
		
		if (!this._wasPainted)
			this._raiseClientEvent('Initialize');
		
		if (!(tab = this._tab))
			return;
		
		if (!this._loadUrl(tab, true))
			return;
		
		var doc = this._getFrameDoc(tab, 1);
		var docE = doc ? doc.documentElement : null;
		if (docE)
		{
			if (doc.readyState == 'complete' || (!doc.readyState && docE.offsetHeight > 20))
				return;
			this._fixUrlSize = 1;
			this._initUrlEvt(tab);
		}
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.dispose">Disposes object and event handlers.</summary>
		
		if (this._timerOn)
			ig_ui_timer(this, true);
		var elems = this._elements;
		if (elems && this._enabled && this._wasPainted)
		{
			$clearHandlers(elems.head);
			if (this._sbHolder)
				$clearHandlers(this._sbHolder);
		}
		if (this._activation && this._input)
			$clearHandlers(this._input);
		this.endEditing();
		this._onMouseUp();
		if (this._ajaxID)
			this._clearAjax();
		this._sbHolder = this._map = this._addTab = this._holder = this._tab = this._input = this._editor = null;
		$IG.WebTab.callBaseMethod(this, 'dispose');
	},
	getVisibleSibling: function(tab, next, skipDisabled)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getVisibleSibling">Gets reference to visible TabItem located in front or after tab.</summary>
		/// <param name="tab" type="Infragistics.Web.UI.TabItem" optional="true" mayBeNull="true">Reference to TabItem or null.</param>
		/// <param name="next" type="Boolean">True: next sibling tab, false: previous sibling tab.</param>
		/// <param name="skipDisabled" type="Boolean" optional="true" mayBeNull="true">True: skip disabled TabItems.</param>
		/// <returns type="Infragistics.Web.UI.TabItem" mayBeNull="true">Reference to TabItem or null.</returns>
		var holder = this._holder;
		if (!holder)
			return null;
		var elem = null, nodes = holder.childNodes;
		if (tab)
		{
			elem = tab._elem;
			if (elem && elem.parentNode != holder)
				tab = elem = null;
		}
		if (!elem)
			elem = nodes[next ? 0 : nodes.length - 1];
		while (elem)
		{
			
			var i = (elem._add || elem._mark) ? null : elem._i;
			var ti = (i == null) ? null : this._tabs[i];
			
			if (!tab && ti && !ti._hidden && (!skipDisabled || ti._enabled))
				return ti;
			tab = null;
			if (next)
				elem = elem.nextSibling;
			else
				elem = elem.previousSibling;
		}
		return null;
	},
	addCopy: function(tab, text, url, select)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.addCopy">Adds a copy of TabItem.</summary>
		/// <param name="tab" type="Infragistics.Web.UI.TabItem">Reference to the source TabItem.</param>
		/// <param name="text" type="String" optional="true" mayBeNull="true">Text for new TabItem.</param>
		/// <param name="text" type="String" optional="true" mayBeNull="true">Url for ContentPane associated with new TabItem.</param>
		/// <param name="select" type="Boolean" optional="true" mayBeNull="true">Option to select new TabItem.</param>
		/// <returns type="Infragistics.Web.UI.TabItem" mayBeNull="true">Reference to TabItem or null.</returns>
		return tab ? this._doAdd(null, tab, text, url, select) : null;
	},
	addTab: function(text, url, select)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.addTab">Adds new TabItem.</summary>
		/// <param name="text" type="String" optional="true" mayBeNull="true">Text for new TabItem.</param>
		/// <param name="text" type="String" optional="true" mayBeNull="true">Url for ContentPane associated with new TabItem.</param>
		/// <param name="select" type="Boolean" optional="true" mayBeNull="true">Option to select new TabItem.</param>
		/// <returns type="Infragistics.Web.UI.TabItem" mayBeNull="true">Reference to TabItem or null.</returns>
		return this._doAdd(null, null, text, url, select);
	},
	moveTab: function(tab, index, noMove)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.moveTab">Move tab to new location.</summary>
		/// <param name="tab" type="Infragistics.Web.UI.TabItem">Reference to TabItem to be moved.</param>
		/// <param name="index" type="Number" integer="true">Visible index.</param>
		/// <param name="noMove">Internal use only: request to keep html elements where they are.</param>
		var tabs = this._tabs, map = this._map;
		var i, iLen = tabs.length, elem = tab._elem, vi = tab._vi;
		var holder = this._holder;
		index = Math.max(Math.min(index, iLen - 1), 0);
		
		if (index == vi || !holder || (this._hasRows && this._mode == 2))
			return;
		if (!noMove)
		{
			holder.removeChild(elem);
			if (index > vi)
				index++;
			var next = tabs[map[index]];
			if (next)
				next = next._elem;
			else if (next = tabs[map[iLen - 1]])
				next = next._elem.nextSibling;
			if (next)
				holder.insertBefore(elem, next);
			else
				holder.appendChild(elem);
		}
		var nodes = holder.childNodes;
		vi = -1;
		for (var n = 0; n < nodes.length; n++)
		{
			elem = nodes[n];
			
			i = elem._i;
			
			if (i == null || elem._add || elem._mark)
				continue;
			map[++vi] = i;
			tab = tabs[i];
			tab.set_visibleIndex(tab._vi = elem._vi = vi, 1);
		}
		this._calcLabels(false, true);
	},
	findTabFromKey: function(key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.findTabFromKey">Find TabItem by key.</summary>
		/// <param name="key" type="String">Key of TabItem.</param>
		/// <returns type="Infragistics.Web.UI.TabItem" mayBeNull="true">First found TabItem or null.</returns>
		var i = -1, tabs = this._tabs;
		while (++i < tabs.length)
			if (tabs[i].get_key() == key)
				return tabs[i];
		return null;
	},
	getHeaderSpan: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getHeaderSpan">Returns html element which is used as the header of control.</summary>
		/// <returns domElement="true">Reference to SPAN html element.</returns>
		return this._elements.head;
	},
	getContentDiv: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getContentDiv">Returns html element which is used as container of all content panes.</summary>
		/// <returns domElement="true">Reference to DIV html element.</returns>
		return this._elements.cph;
	},
	getAddNewTabSpan: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getAddNewTabSpan">Returns html element which is used as add-new-tab button.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to SPAN or null.</returns>
		var tab = this._addTab;
		return tab ? tab._elem : null;
	},
	getAddNewTabImg: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getAddNewTabImg">Returns html element which is used as image on add-new-tab button.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to IMG or null.</returns>
		var tab = this._addTab;
		return tab ? tab._img : null;
	},
	getEditingInput: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getEditingInput">Returns html element which is used to edit text in TabItem.</summary>
		/// <returns domElement="true">Reference to INPUT.</returns>
		var input = this._editor;
		if (!input)
		{
			this._editor = input = document.createElement('INPUT');
			input.alt = 'tab editor';
			var style = input.style;
			style.position = 'absolute';
			style.padding = '0px';
			style.zIndex = 99999;
			style.fontSize = '12px';
			if (this._LR && this._horiz)
				style.marginLeft = '4px';
		}
		return input;
	},
	startEditing: function(tab, e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.startEditing">Start editing of TabItem's text.</summary>
		/// <param name="tab" type="Infragistics.Web.UI.TabItem">Reference to the TabItem.</param>
		/// <param name="e" optional="true" mayBeNull="true">Reference to browser event. Internal use only.</param>
		var txt = this._textSpan(tab);
		var elem = txt ? tab._elem : null;
		if (!elem)
			return;
		this.endEditing();
		
		var args = this._fireEvt('StartEditing', tab._i, null, e);
		if (!this._element || (args && args.get_cancel()))
			return;
		var input = this.getEditingInput();
		input.value = tab.get_text();
		$addHandlers(input, {'focus':this._onInput, 'blur':this._onInput, 'keydown':this._onInput}, this);
		this._editing = (new Date()).getTime();
		input._i = tab._i;
		input.style.width = Math.max(txt.parentNode.offsetWidth - 2, 20) + 'px';
		elem.insertBefore(input, elem.firstChild);
		
		if (tab._cent)
			elem = tab._cent;
		input.style.marginTop = Math.floor(Math.max((elem.offsetHeight - input.offsetHeight) / 2 - 1, 0)) + 'px';
		setTimeout(Function.createDelegate(this, this._editFocus), 0);
	},
	_editFocus: function()
	{
		try
		{
			this._editor.focus();
		}
		catch(ex){}
	},
	endEditing: function(update, e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.endEditing">End editing of TabItem's text.</summary>
		/// <param name="update" type="Boolean" optional="true" mayBeNull="true">True: update text of TabItem.</param>
		/// <param name="e" optional="true" mayBeNull="true">Reference to browser event. Internal use only.</param>
		var input = this._editor;
		var par = (this._editing && input) ? input.parentNode : null;
		if (!par)
			return;
		$clearHandlers(input);
		this._editing = null;
		par.removeChild(input);
		var tab = this._tabs[input._i], val = input.value;
		if (!tab)
			return;
		
		var args = this._raiseClientEvent('EndEditing', new $IG.TabItemEndEditingEventArgs(e, tab._i, val, !update));
		if (!this._element)
			return;
		if (args)
		{
			if (args.get_cancel())
				return;
			val = args.get_text();
		}
		tab.set_text(val);
	},
	scrollIntoView: function(index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.scrollIntoView">Scroll tabs header to make TabItem visible.</summary>
		/// <param name="index" type="Number" integer="true">Index of TabItem. Note: if index is equal or larger than get_tabs().length, then that is request to scroll add-new-tab button into view.</param>
		var tab = null, size = this._scrollSize, tabs = this._tabs;
		if (index < 0 || (size && !this._sbImgs))
			return;
		if (index >= tabs.length)
		{
			index = tabs.length - 1;
			if (tab = this._addTab)
				index++;
		}
		if (!tab) if (!(tab = tabs[index]))
			return;
		var elem = tab._elem;
		var scroll = -this._scroll, edge = this._LR ?  elem.offsetTop : elem.offsetLeft;
		
		if (edge > scroll)
		{
			if ((edge += (this._LR ? elem.offsetHeight : elem.offsetWidth)) <= size + scroll)
				
				return;
			edge += 5 - size;
		}
		else if (edge == scroll)
			
			return;
		this._doScroll(-edge, null, 1);
	},
	setSize: function(width, height)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.setSize">Gets size of control.</summary>
		/// <param name="width" type="String">Width of control as percentage or pixel unit value.</param>
		/// <param name="height" type="String">Height of control as percentage or pixel unit value.</param>
		var elem = this._element;
		if (width != null)
		{
			this._width0 = width;
			elem.style.width = width;
		}
		if (height != null)
		{
			this._height0 = height;
			elem.style.height = height;
		}
		this._set_occasionalProperty('size', this._width0 + ',' + this._height0);
		this.repaint();
	},
	get_width: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.width">Gets sets width of control as string. Value should be percentage or pixel unit value.</summary>
		/// <value type="String">Width in units</value>
		return this._width0;
	},
	set_width: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.width">Sets width of control.</summary>
		/// <param name="val" type="String">Width of control as percentage or pixel unit value.</param>
		this.setSize(val);
	},
	get_height: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.height">Gets sets height of control as string. Value should be percentage or pixel unit value.</summary>
		/// <value type="String">Height in units</value>
		return this._height0;
	},
	set_height: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.height">Sets height of control.</summary>
		/// <param name="val" type="String">Height of control as percentage or pixel unit value.</param>
		this.setSize(null, val);
	},
	get_activeIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.activeIndex">
		/// Gets sets index of active TabItem as integer.
		/// That property has effect only when activation is enabled and control is visible.
		/// If the get returns -1, then control does not have focus and there is no active item.
		/// If the get returns get_tabs().length, then add-new-tab button is active.
		/// If control does not have focus, then the set will set focus to control and activate TabItem.
		/// </summary>
		/// <value type="Number" integer="true">Index of active tab</value>
		return this._active_i;
	},
	set_activeIndex: function(val, delay)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.activeIndex">Sets index of active TabItem as integer.</summary>
		/// <param name="val" type="Number" integer="true">Index of active tab</param>
		/// <param name="delay" type="Boolean">True: call input.focus() using setTimeout</param>
		if (!this._activation || val == null || val < 0 || val > this._tabs.length)
			return;
		
		if (this._active_i < 0)
		{
			
			this._active_if = val;
			var foc = this._input;
			if(delay)
				window.setTimeout(function()
				{
					try
					{
						foc.focus();
					}catch(ex){}
				}, 0);
			else try
			{
				foc.focus();
			}catch(ex){}
		}
		
		else
			this._onInput(null, val);
	},
	get_scrollPosition: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.scrollPosition">Gets sets scroll of tabs as integer.</summary>
		/// <value type="Number" integer="true">Scroll position</value>
		var val = this._scroll;
		return val ? -val : 0;
	},
	set_scrollPosition: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.scrollPosition">Sets scroll of tabs.</summary>
		/// <param name="val" type="Number" integer="true">Scroll in pixels</param>
		this._doScroll(-val);
	},
	get_tabs: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.tabs">Gets reference to collection of tab items. Returns array of Infragistics.Web.UI.TabItem objects.</summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.TabItem">Array of tab items</value>
		return this._tabs;
	},
	getTabAt: function(index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getTabAt">Gets reference to TabItem at particular index.</summary>
		/// <param name="index" type="Number" integer="true">Index of tab item within collection.</param>
		/// <returns type="Infragistics.Web.UI.TabItem">Reference to tab item or null.</returns>
		return this._tabs[index];
	},
	get_enabled: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.enabled">Checks if control is enabled.</summary>
		/// <value type="Boolean">True: control is enabled</value>
		return this._enabled;
	},
	getLayoutManager: function(index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.getLayoutManager">Gets reference to LayoutManager located at index (TabItem which defines bounds of its children).</summary>
		/// <param name="index" type="Number" integer="true">Index of pane within collection.</param>
		/// <returns type="Infragistics.Web.UI.TabItem">Reference to layout manager or null.</returns>
		return this.getTabAt(index);
	},
	get_tabItemSize: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.tabItemSize">Gets sets size of tab item in % or px units as string.</summary>
		/// <value type="String">Size in units</value>
		return this._get_value($IG.TabProps.TabItemSize);
	},
	set_tabItemSize: function(val, noFix)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.tabItemSize">Sets size of tab item.</summary>
		/// <param name="val" type="String">Size of tab item in % or px units as string</param>
		/// <param name="noFix" type="Boolean" optional="true" mayBeNull="true">True: skip adjustment of labels and size of control</param>
		if (!val || val.indexOf('-') >= 0)
			val = '';
		this._perc = val.indexOf('%') > 0;
		if (!this._perc && val.indexOf('px') < 1)
			val = '';
		this._tabSize = $util.toInt(val, 0);
		if (noFix)
			return;
		this._set_value($IG.TabProps.TabItemSize, val);
		if (this._LR && this._horiz && val.indexOf('px') > 0)
		{
			var elems = this._elements;
			var style = elems.head.style;
			style.width = val;
			elems.cph.style.marginLeft = val;
			
			if (this._RIGHT)
			{
				style.marginLeft = '-' + val;
				elems.cph.parentNode.style.marginLeft = '-' + val;
			}
			style = this._sbHolder;
			if (style)
			{
				
				if (this._RIGHT)
					style.style.marginLeft = '-' + val;
				else
					style.style.left = val;
			}
		}
		this._calcLabels();
	},
	get_textOverflow: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.textOverflow">Gets sets option to add ... if text does not fit in tab item element. Integer value of 1 means that ... is used.</summary>
		/// <value type="Number" integer="true">Possible values: 0 or 1</value>
		return this._get_value($IG.TabProps.TextOverflow);
	},
	set_textOverflow: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.textOverflow">Sets option to add ... if text does not fit in tab item element.</summary>
		/// <param name="val" type="Number" integer="true">Possible values: 0 or 1</param>
		this._set_value($IG.TabProps.TextOverflow, val);
		this._calcLabels();
	},
	get_tabsOverflow: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.tabsOverflow">
		/// Gets sets option to reduce sizes of tabs when their overall
		/// size does not fit in size of control. Integer value of 1 means that
		/// size of tabs can be reduced to keep them in bounds of control.
		/// Value of 0 means that size of tabs is preserved and size of
		/// control can be larger than value set on server.
		/// </summary>
		/// <value type="Number" integer="true">Possible values: 0 or 1</value>
		return this._get_value($IG.TabProps.TabsOverflow);
	},
	set_tabsOverflow: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.tabsOverflow">Sets option to reduce sizes of tabs when their overall size does not fit in size of control.</summary>
		/// <param name="val" type="Number" integer="true">Possible values: 0 or 1</param>
		this._set_value($IG.TabProps.TabsOverflow, val);
		this._calcLabels();
	},
	get_enableValidation: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.enableValidation">Gets sets option to enable validation when selected tab is changed or its content is reloaded. Value should be boolean.</summary>
		/// <value type="Boolean">True: validation is enabled</value>
		return this._get_value($IG.TabProps.EnableValidation) == 1;
	},
	set_enableValidation: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.enableValidation">Sets option to enable validation when selected tab is changed or its content is reloaded.</summary>
		/// <param name="val" type="Boolean">True: validation is enabled</param>
		this._set_value($IG.TabProps.EnableValidation, val ? 1 : 0);
	},
	get_visibleHeader: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.visibleHeader">Gets sets visibility of header as boolean.</summary>
		/// <value type="Boolean">True: header is visible</value>
		return this._get_value($IG.TabProps.VisibleHeader) == 1;
	},
	set_visibleHeader: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.visibleHeader">Sets visibility of header.</summary>
		/// <param name="val" type="Boolean">True: header is visible</param>
		this._set_value($IG.TabProps.VisibleHeader, val ? 1 : 0);
		var elems = this._elements;
		$util.display(elems.head, !val);
		this._fixVisHead(elems, val);
		this.repaint();
	},
	get_visibleContent: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.visibleContent">Gets sets visibility of content as boolean.</summary>
		/// <value type="Boolean">True: content is visible</value>
		return this._get_value($IG.TabProps.VisibleContent) == 1;
	},
	set_visibleContent: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.visibleContent">Sets visibility of content.</summary>
		/// <param name="val" type="Boolean">True: content is visible</param>
		this._set_value($IG.TabProps.VisibleContent, val ? 1 : 0);
		$util.display(this._elements.cph, !val);
		this.repaint();
	},
	get_selectedIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.selectedIndex">Gets sets index of selected tab as integer.</summary>
		/// <value type="Number" integer="true">Index of tab item</value>
		return this._get_value($IG.TabProps.SelectedIndex);
	},
	set_selectedIndex: function(val, reload, e)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebTab.selectedIndex">Sets index of selected tab item.</summary>
		/// <param name="val" type="String">Index of tab item</param>
		/// <param name="reload" type="Boolean" optional="true" mayBeNull="true">True: reload content of already selected tab item</param>
		/// <param name="e" optional="true" mayBeNull="true">Referece of event of browser. Internal use only.</param>
		var tab = this._tab, old = this._get_value($IG.TabProps.SelectedIndex);
		if (this._validate(tab))
			return;
		if (old == val)
		{
			
			if (val >= 0 && (reload === true || (this._postClick && reload == 1)))
			{
				var doc = this._getFrameDoc(tab, 1);
				
				if (doc)
					
					this._submitUrl(doc, tab, true);
				
				else if (!$util.isEmpty(tab.get_contentUrl()))
					
					this._loadUrl(tab, null, 1);
				
				else if (this._doAjax(val) < 1)
					
					this._postAction(1, '');
			}
			return;
		}
		var args = e ? this._raiseClientEvent('SelectedIndexChanging', 'TabSelectedIndexChanging', e, 0, val, old) : null;
		if (!this._element || (args && args.get_cancel()))
			return;
		this._clearUrlEvt();
		
		this._doIndicator();
		
		
		var input = this._input, loaded = false;
		if (input)
		{
			var ids = input.value.split(':');
			var i = ids ? ids.length : 0, str = val + ':' + old;
			while (i-- > 0)
			{
				var index = parseInt(ids[i]);
				if (index == val)
					loaded = true;
				else if (index != old)
					str += ':' + index;
			}
			input.value = str;
		}
		var url, posted = null;
		this._set_value($IG.TabProps.SelectedIndex, val);
		if (old >= 0)
		{
			tab = this._tabs[old];
			if (tab)
			{
				
				tab._onSubmit();
				
				if (this._postUnsel && this._wasPainted)
				{
					var doc = this._getFrameDoc(tab, 1);
					if (doc)
						
						this._submitUrl(doc, tab);
					else if (!this._lod)
						
						posted = this._doAjax(old) == 2;
				}
				
				this._setVis(tab._element);
			}
		}
		this._fixUrlSize = this._tab = null;
		
		reload = 0;
		if (val >= 0)
		{
			this._tab = tab = this._tabs[val];
			if (tab)
			{
				if (this._lod && (loaded || this._isLoaded(tab)))
					posted = true;
				
				if (!posted && this._wasPainted && this._lod == '2')
				{
					posted = this._doAjax(val) > 0;
				}
				url = !$util.isEmpty(tab.get_contentUrl());
				if (this._lod && !posted && !url)
					reload = 1;
				else
				{
					if (!posted)
						tab._loaded = true;
					
					tab._element.style.display = '';
					
					
					
					tab.set_scrollLeft(tab.get_scrollLeft());
					tab.set_scrollTop(tab.get_scrollTop());
					this._fixSelSize();
				}
				this._layout();
			}
		}
		args = this._fireEvt('SelectedIndexChanged', val, 2, e, reload);
		if (!this._element)
		    return;
		//if (args)
		//	reload = args.get_postBack();
		
		if (reload == 1)
			this._postAction(1, '');
		else
		{
			if (old >= 0)
				this._fixTabCss(old);
			if (val >= 0)
				this._fixTabCss(val);
			
			this._fixSelMulti();
			
			this._fixLine();
		}
		if (url && !this._posted)
			this._loadUrl(tab, true);
	},
	repaint: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebTab.repaint">Repaints control.</summary>
		this._calcLabels();
	},
	
	
	
	_fixVisHead: function(elems, vis)
	{
		var prop = this._headProp, cph = elems.cph;
		if (prop == null)
		{
			
			this._headProp = prop = $util.getStyleValue(null, this._LR ? 'marginLeft' : (this._TOP ? 'borderBottomWidth' : 'borderTopWidth'), cph);
			
			if (!this._LR)
				this._headOld = $util.getStyleValue(null, this._TOP ? 'borderTopWidth' : 'borderBottomWidth', cph);
		}
		if (prop)
		{
			
			if (this._TOP)
			{
				
				cph.style.borderTopWidth = vis ? this._headOld : prop;
				return;
			}
			
			if (!this._LR)
			{
				
				cph.style.borderBottomWidth = vis ? this._headOld : prop;
				return;
			}
			
			cph.style.marginLeft = vis ? prop : ((this._RIGHT || this._horiz) ? '1px' : '0px');
			
			if (this._RIGHT)
				cph.parentNode.style.marginLeft = vis ? '-' + prop : '-1px';
		}
		
		if (this._LR && elems.sb1)
			$util.display(elems.sb1.parentNode, !vis);
	},
	
	
	_validate: function(tab)
	{
		if (!tab || !this.get_enableValidation() || !this._wasPainted)
			return false;
		var vi, win = this._getFrameDoc(tab, 2), elem = tab._element;
		
		if (win)
		{
			
			elem = null;
			win = win.contentWindow;
		}
		else
			win = window;
		var vals = null;
		if (win) try
		{
			vals = win.Page_Validators;
		}
		catch(ex){}
		var i = vals ? vals.length : 0;
		if (i < 1)
			return false;
		var foc = win.$util;
		if (foc)
			foc = foc._focusedCtl;
		if (foc && foc._onValidate && (!elem || $util.isChild(elem, foc._element)))
			foc._onValidate();
		// foc: invalid flag
		foc = false;
		while (i-- > 0)
		{
			vi = vals[i];
			if (vi.validationGroup || (elem && !$util.isChild(elem, vi)))
				continue;
			if (win.ValidatorValidate)
				win.ValidatorValidate(vi);
			if (vi.isvalid === false)
				foc = true;
		}
		if (!foc)
			return false;
		try
		{
			vals = win.Page_ValidationSummaries;
			i = vals ? vals.length : 0;
			while (i-- > 0)
			{
				vi = vals[i];
				if (vi.validationGroup || (elem && !$util.isChild(elem, vi)))
					continue;
				win.Page_IsValid = false;
				win.ValidationSummaryOnSubmit();
				break;
			}
		}
		catch(ex){}
		return true;
	},
	
	_setVis: function(elem, show)
	{
		
		if (!show)
			$util.display(elem, true);
		else if (elem)
		{
			elem.style.visibility = 'visible';
			elem.style.display = (show == 2 && !this._LR) ? 'inline' : 'block';
		}
	},
	
	



	
	_doAdd: function(e, copy, text, url, select)
	{
		var tabs = this._tabs, elems = this._elements;
		var len = tabs.length, holder = this._holder, add = this._addTab;
		if (e) if (this._fireEvt('TabAdding', len, null, e))
			return;
		if (!this._element)
			return;
		if (!copy && !elems.nts && len > 0)
		{
			copy = tabs[0];
			if (!text)
				text = '';
			if (!url)
				url = '';
		}
		var span = copy ? copy._elem : elems.nts, div = copy ? copy._element : elems.ntc;
		if (!span || !div || !holder)
			return null;
		if (e)
			select = this._addSelect;
		
		var id = copy ? ('ti' + copy._i) : 'nts';
		id = $util._getXAttr(span).replace('mkr:' + id, '');
		div = div.cloneNode(false);
		div.id = '';
		this._setVis(div);
		span = span.cloneNode(true);
		$util._setXAttr(span, id + 'mkr:ti' + len);
		span.setAttribute('mkr', 'ti' + len);
		
		var cb = span.childNodes;
		for (var i = 0; i < cb.length; i++) if (cb[i].nodeName == 'IMG')
		{
			$util._setXAttr(cb[i], id + 'mkr:cb' + len);
			cb[i].setAttribute('mkr', 'cb' + len);
		}
		this._setVis(span, 2);
		var tab = this._createItem(div, '' + len);
		
		if (tab._csm)
			tab._csm.set_itemProps(len, [{}]);
		
		if (add)
			add._i = add._vi = add._elem._i = add._elem._vi = len + 1;
		tab._i = tab._vi = span._i = span._vi = len;
		tab._elem = span;
		tab._enabled = true;
		tab._tabSize = 0;
		tab._hasClose = this._hasClose;
		
		var last = null;
		
		if (len < 1)
			last = elems.nts;
		
		else if (last = tabs[this._map[len - 1]])
			last = last._elem.nextSibling;
		
		if (!last)
			last = elems.ads;
		if (last && last.parentNode == holder)
			holder.insertBefore(span, last);
		else
			holder.appendChild(span);
		this._map[len] = len;
		elems.cph.appendChild(div);
		if (text == null)
		{
			if (copy)
				text = copy.get_text();
			
			else if (text = this._getText(tab))
				text = text.replace(/<br><br>/gi, ' ').replace(/<br>/gi, '').replace(/</g, '').replace(/>/g, '');
		}
		
		if (text != null)
			tab.set_text(text);
		if (url != null)
			tab.set_contentUrl(url, this._lodUrl);
		var dur = this._addDur > 1;
		if (this._element.offsetWidth > 1)
		{
			this._calcLabels();
			
			if (dur)
				this._tickHandler(3, this, tab);
		}
		
		if (!dur)
			this.scrollIntoView(9999);
		if (this._active_i == len)
			this._active_i++;
		if (e)
		{
			this._fireEvt('TabAdded', len, 2, e);
			if (!this._element)
				return;
		}
		if (select)
			this.set_selectedIndex(tab._i);
		if (this._editOnAdd && !dur)
			this.startEditing(tab, e);
		return tab;
	},
	
	
	
	
	_submitUrl: function(doc, tab, evt)
	{
		try
		{
			if (this._fireEvt('UrlSubmitting', tab._i))
				return;
			if (!this._element)
				return;
			doc.forms[0].submit();
			this._fireEvt('UrlSubmitted', tab._i, 1);
			if (!this._element)
				return;
			if (evt)
				this._initUrlEvt(tab);
		}
		catch(doc){}
	},
	_createItem: function(elem, adr)
	{
		return this._itemCollection._addObject($IG.TabItem, elem, adr);
	},
	
	_onSubmitOtherHandler: function(e)
	{
		
		if (this._tab)
			this._tab._onSubmit();
		$IG.WebTab.callBaseMethod(this, '_onSubmitOtherHandler', [e]);
	},
	
	_onUrlLoad: function(evt)
	{
		this._clearUrlEvt();
		this._doIndicator();
		if (this._fixUrlSize)
		{
			this._fixUrlSize = null;
			this._fixSelSize();
		}
		
		
		this._fireEvt('UrlLoaded', this._loadUrl_i, 1);
	},
	
	_clearUrlEvt: function()
	{
		var frame = this._frameEvt;
		this._frameEvt = null;
		if (frame)
			$removeHandler(frame, 'load', this._onUrlLoadFn);
	},
	
	
	
	
	
	_loadUrl: function(tab, fixSize, reset)
	{
		var url = tab.get_contentUrl(), frame = tab.get_iframe();
		if (!frame)
			return;
		if (reset)
			frame.src = '';
		var old = frame.src, u = url, len = u.length;
		while (len > 0 && u.charAt(0) == '.')
			u = u.substring(1, len--);
		var len0 = old.length, index = old.indexOf(u);
		
		if (this._ieBug1 && !tab._ieBug1 && len > 0)
			len = -2;
		if (len0 - index == len && (index == 0 || u.charAt(0) == '/' || (index > 0 && old.charAt(index - 1) == '/')))
			return true;
		
		tab._ieBug1 = 1;
		if (len > 0)
		{
			this._fireEvt('UrlLoadRequest', tab._i, 1);
			if (!this._element)
				return;
		}
		this._fixUrlSize = fixSize;
		this._initUrlEvt(tab, url);
	},
	
	
	
	_initUrlEvt: function(tab, url)
	{
		
		if (!this._onUrlLoadFn)
			this._onUrlLoadFn = Function.createDelegate(this, this._onUrlLoad);
		var frame = tab.get_iframe();
		this._frameEvt = frame;
		this._loadUrl_i = tab._i;
		$addHandler(frame, 'load', this._onUrlLoadFn);
		this._doIndicator(true, tab._i);
		if (url)
			frame.src = url;
	},
	
	
	
	_doIndicator: function(show, index)
	{
		var ai = this.get_ajaxIndicator();
		if (!ai)
			return;
		if (this._hasAI)
		{
			this._fireEvt('IndicatorHide', this._hasAI - 1, 1);
			if (!this._element)
				return;
			this._hasAI = null;
			ai.hide();
		}
		if (show)
		{
			if (this._fireEvt('IndicatorShow', index))
				return;
			if (!this._element)
				return;
			this._hasAI = index + 1;
			ai.setRelativeContainer(this._elements.cph);
			ai.show();
		}
	},
	
	
	
	_doAjax: function(index)
	{
		var rm = Sys.WebForms.PageRequestManager.getInstance();
		var id = this._id + ':ajax.' + index;
		if (!rm || !$get(id))
			return 0;
		if (this._fireEvt('AjaxSubmitting', index))
			return 1;
		if (!this._element)
			return 1;
		this._clearAjax(rm);
		
		this._ajaxID = id;
		$util._ig_tab_ajax = this;
		
		$util._ig_tab_i = index;
		
		rm.add_beginRequest(this._beginAjax);
		rm.add_endRequest(this._endAjax);
		
		__doPostBack(id, '');
		return 2;
	},
	
	_beginAjax: function(rm, args)
	{
		var me = $util._ig_tab_ajax, elem = args.get_postBackElement();
		if (!me)
			return;
		
		if (me && (!elem || elem.id != me._ajaxID))
		{
			me._clearAjax(rm);
			return;
		}
		var index = $util._ig_tab_i;
		me._fireEvt('AjaxSubmitted', index, 1);
		if (!me._element)
			return;
		
		me._doIndicator(true, index);
	},
	
	_endAjax: function(rm, args)
	{
		var me = $util._ig_tab_ajax, index = $util._ig_tab_i;
		if (!me || !me._fireEvt)
			return;
		var tab = me._tab;
		
		if (tab && tab._i == index)
			tab._loaded = true;
		me._clearAjax(rm);
		me._fireEvt('AjaxLoaded', index, 1);
		if (!me._element)
			return;
		me._fixSelSize();
		me._layout();
	},
	
	_clearAjax: function(rm)
	{
		var me = $util._ig_tab_ajax;
		if (!me)
			return;
		if (!rm)
			rm = Sys.WebForms.PageRequestManager.getInstance();
		if (!rm)
			return;
		
		me._doIndicator();
		
		me._ajaxID = $util._ig_tab_ajax = $util._ig_tab_i = null;
		
		rm.remove_beginRequest(me._beginAjax);
		rm.remove_endRequest(me._endAjax);
	},
	
	_isLoaded: function(tab)
	{
		if (tab._loaded)
			return true;
		if (this._lod == '1')
			return false;
		
		var nodes, i = 4, elem = $get(this._id + ':ajax.' + tab._i);
		
		
		if (elem)
		{
			nodes = elem.parentNode.childNodes;
			i = nodes.length;
			if (i < 4) while (i-- > 0)
			{
				var val = nodes[i];
				if (val == elem)
					continue;
				
				if (val.nodeName != '#text')
					break;
				val = val.nodeValue;
				var j = val ? val.length : 0;
				
				while(j-- > 0) if (val.charCodeAt(j) > 33)
					break;
			}
			if (i < 0)
				return false;
		}
		return tab._loaded = true;
	},
	_fixSelSize: function()
	{
		var auto = this._tab;
		if (auto)
			auto = auto._getAutoSize();
		if (auto == 0)
			auto = this._autoSize;
		if (auto != 0)
			this._calcLabels(true);
		else
			this._fixSize();
	},
	
	
	_fixSize: function(check)
	{
		var elem = this._element;
		if (!elem || !elem.offsetWidth || !elem.offsetHeight)
			return false;
		if (check !== true)
		{
			if (this._LR)
				this._doSizeLR();
			else
				this._doSize();
		}
		var size = this._size;
		var width = elem ? elem.offsetWidth : 0, height = elem ? elem.offsetHeight : 0;
		if (width < 2 || height < 2)
			return false;
		if (!size)
			this._size = size = {width: width, height: height};
		if (Math.abs(size.width - width) < 2 && Math.abs(size.height - height) < this._offsetRatio)
			return false;
		
		if (!check)
		{
			size.width = width;
			size.height = height;
		}
		this._layout();
		return true;
	},
	
	
	_doSize: function()
	{
		var tab = this._tab, elem = this._element, vis = this.get_visibleContent();
		var v, height = vis ? this._height0 : '', width = this._width0, minSize = this._tabsSize;
		
		if ($util.isEmpty(width) && minSize)
			width = (minSize + 6) + 'px';
		
		if (elem.style.width != width)
			elem.style.width = width;
		
		if (elem.style.height != height)
			elem.style.height = height;
		
		if ((v = this._minHeight0) != null)
			elem.style.minHeight = v;
		
		if ((v = this._minWidth0) != null)
			elem.style.minWidth = v;
		var val, size, elems = this._elements;
		var cph = elems.cph, rb = elems.rb;
		
		cph.style.height = '80%';
		
		if (!vis)
			return;
		var padVert = this._rbPadVert, padHoriz = this._rbPadHoriz;
		var head = elems.head.offsetHeight;
		var div = tab ? tab._element : null, auto = tab ? tab._getAutoSize() : 0;
		if (auto == 0)
			auto = this._autoSize;
		
		if (!height && auto == 0)
			auto = 2;
		
		if (auto > 0 && div)
		{
			div.style.height = '';
			
			if (auto == 1)
				div.style.width = '';
			var url = tab.get_contentUrl();
			var width0 = elem.offsetWidth, height0 = elem.offsetHeight;
			size = this._frameSize(tab);
			var max = this._maxHeight;
			if (size)
			{
				if (max < 1 || size[1] >= max)
					
					div.style.overflowY = 'hidden';
			}
			else
			{
				
				div.style.position = 'absolute';
				size = [div.scrollWidth + 2, div.scrollHeight + 2];
				
				div.style.position = 'relative';
			}
			
			if (size[0] < (v = this._minWidth))
				size[0] = v;
			if ((v = this._maxWidth) > 0) if (size[0] > v)
				size[0] = v;
			if (size[1] < (v = this._minHeight))
				size[1] = v;
			if (max > 0 && size[1] > max)
				size[1] = max;
			size[0] += padHoriz + 1;
			size[1] += padVert + 1;
			
			if (auto == 1 && width0 < size[0])
			{
				
				if (this._minWidth0 == null)
					this._minWidth0 = elem.style.minWidth;
				elem.style.minWidth = size[0] + 'px';
				
				if(elem.offsetWidth < size[0])
					elem.style.width = size[0] + 'px';
				width0 = elem.offsetWidth;
			}
			size[0] = width0;
			val = size[1] + head;
			if (height0 < val)
			{
				
				if (this._minHeight0 == null)
					this._minHeight0 = elem.style.minHeight;
				elem.style.minHeight = val + 'px';
				
				if(elem.offsetHeight < val)
					elem.style.height = val + 'px';
			}
			else
				size[1] = (val = height0) - head;
			size[1] = Math.max(size[1] - 2, 1);
			
			v = size[1] + 'px';
			if (cph.style.height != v)
				cph.style.height = v;
			
			if (rb)
			{
				val = size[0] - padHoriz;
				if (val < 0)
					val = 0;
				size[0] = val * 100 / size[0];
				val = size[1] - padVert;
				if (val < 0)
					val = 0;
				size[1] = val * 100 / size[1];
			}
			else
				size[0] = size[1] = 100;
		}
		else
		{
			var width0 = elem.offsetWidth, height0 = elem.offsetHeight;
			if (height0 < head + padVert)
				height0 = head + padVert;
			
			val = height0;
			height0 = Math.max(height0 - head - 2, 1);
			if (cph.style.height != (v = height0 * 100 / val + '%'))
				cph.style.height = v;
			size = [100, 100];
			
			if (rb)
			{
				val = width0 - padHoriz;
				if (val < 0)
					val = 0;
				size[0] = val * 100 / width0;
				val = height0 - padVert;
				if (val < 0)
					val = 0;
				size[1] = val * 100 / height0;
			}
		}
		if (!div)
			return;
		if (div.style.width != (v = size[0] + '%'))
			div.style.width = v;
		if (div.style.height != (v = size[1] + '%'))
			div.style.height = v;
		div.style.visibility = 'visible';
	},
	
	
	_doSizeLR: function()
	{
		var tab = this._tab, elem = this._element, vis = this.get_visibleContent();
		var val, elems = this._elements;
		var rb = elems.rb, padVert = this._rbPadVert, padHoriz = this._rbPadHoriz;
		
		var cph = elems.cph, header = elems.head;
		var head = header.offsetWidth;
		var v, height = this._height0, width = vis ? this._width0 : head + 'px', minSize = this._tabsSize;
		
		if ($util.isEmpty(height) && minSize)
			height = (minSize + 6) + 'px';
		
		if (elem.style.width != width)
			elem.style.width = width;
		
		if (elem.style.height != height)
			elem.style.height = height;
		
		if ((v = this._minHeight0) != null)
			elem.style.minHeight = v;
		
		if ((v = this._minWidth0) != null)
			elem.style.minWidth = v;
		
		if (!vis)
			return;
		
		if (this._RIGHT)
			cph = cph.parentNode;
		
		if (this._cphPad == null)
			this._cphPad = $util.getOffset($util.getRuntimeStyle(cph));
		
		if (!tab)
		{
			height = elem.offsetHeight;
			
			cph.style.height = (height - this._cphPad) + 'px';
			
			
			if ($util.IsIEStandards)
				header.style.height = height + 'px';
			return;
		}
		cph.style.height = '99.5%';
		
		
		if ($util.IsIEStandards)
			header.style.height = '100%';
		var div = tab._element, auto = tab._getAutoSize();
		if (auto == 0)
			auto = this._autoSize;
		
		if ($util.isEmpty(width) && auto == 0)
			auto = 2;
		var style = div.style, width0 = elem.offsetWidth, height0 = elem.offsetHeight;
		
		if (auto > 0)
		{
			style.width = style.height = '';
			var size = this._frameSize(tab);
			var max = this._maxHeight;
			if (size)
			{
				if (max < 1 || size[1] >= max)
					
					div.style.overflowY = 'hidden';
			}
			else
			{
				
				style.position = 'absolute';
				size = [div.scrollWidth + 2, div.scrollHeight + 2];
				
				style.position = 'relative';
			}
			style.height = '100%';
			
			if (size[0] < (v = this._minWidth))
				size[0] = v;
			if ((v = this._maxWidth) > 0) if (size[0] > v)
				size[0] = v;
			if (size[1] < (v = this._minHeight))
				size[1] = v;
			if (max > 0 && size[1] > max)
				size[1] = max;
			size[0] += padHoriz + 1;
			size[1] += padVert + 1;
			
			if (auto == 1 && height0 < size[1])
			{
				
				if (this._minHeight0 == null)
					this._minHeight0 = elem.style.minHeight;
				elem.style.minHeight = size[1] + 'px';
				
				if(elem.offsetHeight < size[1])
					elem.style.height = size[1] + 'px';
			}
			val = size[0] + head;
			if (width0 < val)
			{
				
				if (this._minWidth0 == null)
					this._minWidth0 = elem.style.minWidth;
				elem.style.minWidth = val + 'px';
				
				if(elem.offsetWidth < val)
					elem.style.width = val + 'px';
			}
		}
		height = elem.offsetHeight;
		
		if (rb)
		{
			width = Math.max(elem.offsetWidth - head - 2, 1);
			style.width = Math.max(width - padHoriz, 1) * 100 / width + '%';
			style.height = Math.max(height - padVert, 1) * 100 / height + '%';
		}
		
		cph.style.height = (height - this._cphPad) + 'px';
		
		
		if ($util.IsIEStandards)
			header.style.height = height + 'px';
		div.style.visibility = 'visible';
	},
	
	
	
	_getFrameDoc: function(tab, doc)
	{
		var url = tab ? tab.get_contentUrl() : null;
		if (!url || url.length < 3)
			return null;
		var fDoc = null, frame = tab.get_iframe();
		if (!frame || doc == 2)
			return frame;
		try
		{
			fDoc = frame.contentWindow.document;
			return (doc || !fDoc) ? fDoc : {frame:frame, doc:fDoc};
		}
		catch(url){}
		return null;
	},
	
	_frameSize: function(tab)
	{
		var doc = this._getFrameDoc(tab);
		if (!doc)
			return null;
		var frame = doc.frame;
		if (!(doc = doc.doc.documentElement))
			return null;
		var width = doc.scrollWidth + 3, height = doc.scrollHeight + 3;
		frame.width = width + 'px';
		frame.height = height + 'px';
		return [width, height];
	},
	
	
	
	
	
	
	_fireEvt:function(name, arg, type, evt, post)
	{
		arg = this._raiseClientEvent(name, 'TabItem' + ((type == 1) ? '' : ((type == 2) ? 'PostBack' : 'Cancel')), evt, post, arg);
		return !type && arg && arg.get_cancel();
	},
	
	_onMouse: function(e)
	{
		if (!e)
			return;
		var tabs = this._tabs;
		var delay = false, iLen = tabs.length, elems = this._elements, type = e.type, src = e.target;
		if (!type || !src)
			return;
		type = type.substring(5);
		var down = type == 'down', over = type == 'over', old = this._mouse_i;
		if (type == 'out' && this._MSpointer)
			return;
		
		if (this._editing)
		{
			if (down && src != this._editor)
				this.endEditing(false, e);
			else
				return;
		}
		
		if (this._drag && type == 'out' && $util.isOut(e, this._holder))
		{
			this._onMouseUp();
			return;
		}
		if (src.nodeName == 'INPUT' || src.nodeName == 'SELECT')
			return;
		
		if (over && src.unselectable != 'on')
			src.unselectable = 'on';
		if (type == 'move' || down)
		{
			
			if (!(delay = down && document.hasFocus && !document.hasFocus()))
				$util.cancelEvent(e);
			if (!down)
			{
				this._doDrag(e);
				return;
			}
		}
		
		var scroll = (src == elems.sb1) ? 1 : ((src == elems.sb2) ? -1 : 0);
		
		var v, mkr = null, elem = src;
		
		while (src)
		{
			if (src.getAttribute)
				mkr = src.getAttribute('mkr');
			if (mkr && mkr.length > 0)
				break;
			src = src.parentNode;
		}
		if (!mkr)
			return;
		
		var ti = (mkr.indexOf('ti') == 0) ? parseInt(mkr.substring(2)) : -2;
		
		if (type == 'ick')
		{
			if (ti >= 0 && this._editOnDbl)
				this.startEditing(tabs[ti], e);
			return;
		}
		
		var cbi = (mkr.indexOf('cb') == 0) ? parseInt(mkr.substring(2)) : -1;
		
		var add = mkr.indexOf('ad') == 0;
		var iSel = this.get_selectedIndex();
		var tab = Math.max(cbi, ti);
		if (down)
			type = 'Down';
		else
			type = over ? 'Over' : 'Out';
		var args = this._raiseClientEvent('Mouse' + type, 'TabMouse', e, 0, tab, (scroll == 0) ? -1 : ((scroll < 0) ? 0 : 1), cbi >= 0, add);
		if (!this._element || (args && args.get_cancel()))
			return;
		
		var enabled = true;
		if (tab >= 0)
		{
			tab = tabs[tab];
			if (tab)
				enabled = tab._enabled;
		}
		
		if (down)
		{
			if (add)
				this._doAdd(e);
			
			if (scroll != 0)
				
				this._tickHandler(scroll, this);
			
			if (cbi >= 0)
			{
				if (tab && enabled) if (!this._fireEvt('TabClosing', cbi, null, e))
					if (this._element)
						tab.set_hidden(true);
				return;
			}
			
			if (ti >= 0)
			{
				if (enabled)
				{
					
					this.set_selectedIndex(ti, 1, e);
					this.set_activeIndex(ti, delay);
				}
				
				if (this._moving)
				{
					
					
					
					
					
					
					
					
					this._drag = {i:ti, vi:tab._vi, src: src, x:e.clientX, y:e.clientY, left: src.offsetLeft, top: src.offsetTop, size: this._LR ? src.offsetHeight : src.offsetWidth, scroll: this._scroll, shift: 0};
					
					this._doUp(true);
				}
			}
			return;
		}
		if (this._drag)
			return;
		
		if (scroll != 0)
		{
			
			if (!over)
				this._onMouseUp();
			elem._mouse = over;
			this._fixScrollImg(1 - (scroll + 1) / 2);
			return;
		}
		
		if (cbi >= 0)
		{
			var url = src._src;
			if (!url && over)
				url = src._src = src.src;
			if (url && enabled)
				src.src = over ? this._cbHovImg : url;
			return;
		}
		if (add)
			ti = -1;
		
		if (ti < -1 || !enabled)
			return;
		if (over)
		{
			if (ti == old)
				return;
		}
		else if (!$util.isOut(e, src))
			return;
		
		this._mouse_i = over ? ti : -2;
		this._fixTabCss(old);
		this._fixTabCss(ti);
		
		this._fixLine();
	},
	
	_doDrag: function(e)
	{
		var drag = this._drag, x = e.clientX, y = e.clientY;
		if (!drag)
			return;
		var evtLoc = this._LR ? y : x;
		
		x -= drag.x;
		y -= drag.y;
		
		
		
		var args, on = drag.on, mark = drag.mark, drop = drag.drop;
		var i, elem, ni = -1, tabs = this._tabs, holder = this._holder;
		
		if (!on)
		{
			
			if (Math.abs(x) < 3 && Math.abs(y) < 3)
				return;
			args = this._raiseClientEvent('TabMovingStart', 'TabMoving', e, 0, drag.i, drag.vi);
			if (!this._element || (args && args.get_cancel()))
				return;
			
			drag.nextElem = tabs[drag.i]._elem.nextSibling;
		}
		
		
		
		var last = null, next = 0, len = -1;
		
		if (on != 1)
		{
			
			drag.next = -1;
			drag.drop = drop = new Array();
			var nodes = holder.childNodes;
			
			while (++ni < nodes.length)
			{
				elem = nodes[ni];
				
				
				i = (elem._add || elem._mark) ? null : elem._i;
				
				if (i == null || elem.offsetWidth < 2)
					continue;
				var top = elem.offsetTop, left = elem.offsetLeft;
				if ((this._LR && left != drag.left) || (!this._LR && top != drag.top))
					continue;
				
				last = elem;
				if (next == 1)
				{
					
					drag.next = i;
					next++;
				}
				
				if (i == drag.i)
					next++;
				else
					drop[++len] = {i: i, x: left, y: top};
			}
			
			if (len < 0)
				return;
			
			drag.last = null;
			
			if (last && last._i != drag.i)
			{
				
				drop[++len] = {i: -1, x: last.offsetLeft + last.offsetWidth, y: last.offsetTop + last.offsetHeight};
				
				drag.last = last.nextSibling;
			}
			
			if (!mark)
			{
				
				elem = drag.src;
				mark = drag.mark = elem.cloneNode(true);
				mark._i = mark._vi = mark.mkr = null;
				
				mark._mark = 1;
				var style = mark.style;
				style.position = 'absolute';
				style.zIndex = 10000;
				style.marginLeft = style.marginTop = '0px';
				if (this._LR)
				{
					style.left = drag.left + 'px';
					style.width = elem.offsetWidth + 'px';
				}
				else
					style.top = drag.top + 'px';
				mark.className += ' ' + this._moving[1];
				holder.insertBefore(mark, holder.firstChild);
				elem.className += ' ' + this._moving[0];
			}
			drag.on = 1;
		}
		if (!mark)
			return;
		
		var loc = this._LR ? y + drag.top : x + drag.left;
		
		if (!(last = drag.lastLoc))
			last = this._LR ? drag.y : drag.x;
		drag.lastLoc = evtLoc;
		
		if (i = this._scrollSize)
		{
			
			var dir = (evtLoc < last) ? -1 : 1;
			if (!drag.dir)
				drag.dir = dir * 4;
			
			if ((drag.dir > 0) != (dir > 0)) if ((drag.dir += dir) == 0)
				drag.dir = dir * 4;
			
			var delta = loc + this._scroll + drag.shift;
			
			if(delta < 0 && drag.dir < 0)
				
				delta = 5;
			
			else if(i - delta - drag.size < 0 && drag.dir > 0)
				
				delta = -5;
			else
				
				delta = 0;
			if (delta != 0)
			{
				this._doScroll(0, delta, true, 1);
				drag.shift = drag.scroll - this._scroll;
			}
		}
		
		loc += drag.shift;
		
		if (this._LR)
			mark.style.top = loc + 'px';
		else
			mark.style.left = loc + 'px';
		i = len = drop.length;
		elem = drag.src;
		
		while (i-- > 0)
		{
			var dropi = drop[i];
			
			var shift = (this._LR ? dropi.y : dropi.x) - loc;
			if (Math.abs(shift) > 5 && Math.abs(shift - drag.size) > 5)
				continue;
			
			
			dropi = dropi.i;
			
			if (dropi == drag.i || dropi == drag.next)
				return;
			
			
			i = tabs.length - 1;
			
			last = drag.last;
			
			if (dropi >= 0)
			{
				last = tabs[dropi]._elem;
				
				i = last._vi;
				
				if (i > drag.vi)
					i--;
			}
			if (last == elem)
				return;
			
			args = this._raiseClientEvent('TabMoving', 'TabMoving', e, 0, drag.i, i);
			if (!this._element || (args && args.get_cancel()))
				return;
			
			holder.removeChild(elem);
			if (last)
				holder.insertBefore(elem, last);
			else
				holder.appendChild(elem);
			
			drag.move_i = i;
			
			drag.on = 2;
			
			this._raiseClientEvent('TabMoved', 'TabMoved', e, 0, drag.i, i);
			
			return;
		}
	},
	_onT:function(e)
	{
		$util.cancelEvent(e);
		var t = e.rawEvent.touches;
		if(t && t[0])
		{
			e.clientX = t[0].pageX;
			e.clientY = t[0].pageY;
		}
		e.button = 0;
	},
	_onTStart:function(e)
	{
		this._onT(e);
		e.type = 'mouseover';
		this._onMouse(e);
		e.type = 'mousedown';
		this._onMouse(e);
	},
	_onTMove:function(e)
	{
		this._onT(e);
		e.type = 'mousemove';
		this._onMouse(e);
	},
	_onTEnd:function(e)
	{
		this._onT(e);
		e.type = 'mouseup';
		this._onMouse(e);
		e.type = 'mouseout';
		this._onMouse(e);
	},
	_onMST:function(e, re)
	{
		e.clientX = re.pageX;
		e.clientY = re.pageY;
		$util.cancelEvent(e);
		e.button = 0;
	},
	_onMSStart:function(e)
	{
		var re = e.rawEvent;
		this._onMST(e, re);
		var src = this._MSsrc = e.target;
		
		if (this._ie11pointer && src.setPointerCapture)
			src.setPointerCapture(this._MSpointer = re.pointerId);
		else if (src.msSetPointerCapture)
			src.msSetPointerCapture(this._MSpointer = re.pointerId);
		this._MSupHandler = this._MSupHandler || Function.createDelegate(this, this._onMSEnd);
		if (!this._MSupOn)
			$addHandler(document, this._pointerUpName, this._MSupHandler);
		this._MSupOn = true;
		// fake events expected on mousedown to prepare for drag
		e.type = 'mouseover';
		this._onMouse(e);
		e.type = 'mousedown';
		this._onMouse(e);
	},
	_onMSMove:function(e)
	{
		if(!this._MSpointer)
			return;
		var re = e.rawEvent;
		this._onMST(e, re);
		// fake events expected on mousemove while drag
		e.type = 'mousemove';
		this._onMouse(e);
	},
	_onMSEnd:function(e)
	{
		var p = this._MSpointer, src = this._MSsrc, re = e.rawEvent;
		if (this._MSupOn)
			$removeHandler(document, this._pointerUpName, this._MSupHandler);
		delete this._MSupOn;
		delete this._MSpointer;
		delete this._MSsrc;
		if(!p)
			return;
		
		if (this._ie11pointer && src.releasePointerCapture)
			src.releasePointerCapture(p);
		else if (src.msReleasePointerCapture)
			src.msReleasePointerCapture(p);
		this._onMST(e, re);
		// fake events expected on mouseup after drag
		e.type = 'mouseup';
		this._onMouse(e);
		e.type = 'mouseout';
		this._onMouse(e);
	},
	
	
	
	_fixScrollImg: function(i, state)
	{
		var elem = this._elements['sb' + (i + 1)];
		if (!elem)
			return;
		if (!state || state < 3)
		{
			
			
			if ((i == 0 && this._scroll == 0) || (i == 1 && this._scrollEdge))
				state = 3;
			else if (state != 2)
				state = elem._mouse ? 1 : 0;
		}
		if (elem._src != (state += i * 4))
			elem.src = this._sbImgs[elem._src = state];
	},
	
	
	_fixTabCss: function(i)
	{
		if (i < -1)
			return;
		
		
		var s1 = 0, s2 = -1;
		var img = null, tab = null;
		if (i >= 0)
			tab = this._tabs[i];
		else if (tab = this._addTab)
			img = tab._img;
		if (!tab)
			return;
		if (!tab._enabled || !this._enabled)
			s1 = 4;
		else if (i == this.get_selectedIndex())
		{
			s1 = 2;
			if (i == this._mouse_i)
				s2 = 1;
		}
		else if (i == this._mouse_i)
			s1 = 1;
		
		var elem = tab._elem, over = this._cssOverlap;
		
		if (img)
		{
			var hov = this._addHovImg, src = img.src;
			if (!img._src)
				img._src = src;
			if (hov && (s1 == 0) != (img._src == src))
				img.src = (s1 == 0) ? img._src : hov;
		}
		
		if (img = tab._img)
		{
			
			
			var url = null, urls = this._cssTi;
			
			if (!tab._src)
				tab._src = img.src;
			
			if (s1 == 4)
				url = urls[i + ',54'];
			else
			{
				
				if (s1 == 1 || s2 == 1)
					url = urls[i + ',51'];
				
				if (!url && i == this._activeCss)
					url = urls[i + ',53'];
				
				if (!url && (s1 == 2 || s2 == 2))
					url = urls[i + ',52'];
			}
			
			if (!urls[i + ',50'])
				urls[i + ',50'] = tab._src;
			if (!url)
				url = urls[i + ',50'];
			if (tab._src != url)
				img.src = tab._src = url;
		}
		
		var extra = (!tab._first && over) ? over : null;
		





































		
		elem = this._fixElemI(elem, 0, i, tab._vi, s1, s2, over ? 1 : 0, extra);
		
		if (!this._LR || this._horiz)
		{
			
			elem = this._fixElemI(elem, 1, i, tab._vi, s1, s2);
			
			if (this._6spans && !this._LR)
				elem = this._findSpan(tab._elem, 2);
		}
		
		elem = this._fixElemI(elem, 2, i, tab._vi, s1, s2, 0, tab._hasClose ? this._cssCloseSize : null);
		
		this._fixElemI(elem, 3, i, tab._vi, s1, s2, 2);
		
		if (this._LR && !this._horiz)
			
			return this._fixElemI(this._findSpan(tab._elem, 1), 1, i, tab._vi, s1, s2, 2);
		if (!this._6spans)
			return;
		
		elem = this._fixElemI(this._findSpan(tab._elem, 1), 4, i, tab._vi, s1, s2);
		
		this._fixElemI(elem, 5, i, tab._vi, s1, s2, 2);
	},
	
	
	
	
	
	
	
	
	_fixElemI: function(elem, id, i, vi, s1, s2, over, extra)
	{
		if (!elem)
			return;
		var css = this._cssT[id];
		
		if (over == 1)
		{
			var zi = (s1 == 2) ? 999 : (500 - vi);
			if (elem.style.zIndex != zi)
				elem.style.zIndex = zi;
		}
		
		if (extra)
			css += ' ' + extra;
		
		extra = this._cssTi[i + ',' + id];
		if (extra)
			css += ' ' + extra;
		if (s1 > 0)
		{
			css += ' ' + this._cssT[s1 * 6 + id];
			
			extra = this._cssTi[i + ',' + (s1 * 6 + id)];
			if (extra)
				css += ' ' + extra;
		}
		if (s2 > 0)
		{
			css += ' ' + this._cssT[s2 * 6 + id];
			
			extra = this._cssTi[i + ',' + (s2 * 6 + id)];
			if (extra)
				css += ' ' + extra;
		}
		if (i == this._activeCss)
		{
			css += ' ' + this._cssT[3 * 6 + id];
			
			extra = this._cssTi[i + ',' + (3 * 6 + id)];
			if (extra)
				css += ' ' + extra;
		}
		if (elem.className != css)
			elem.className = css;
		if (over != 2)
			return this._findSpan(elem, 0);
	},
	
	
	_animate: function(size)
	{
		
		
		var tab = this._tickTab, add = this._tickAct == 3;
		var elem = tab ? tab._elem : null;
		if (!elem)
			return;
		
		var px = tab._tickSize, min = tab._tickMin;
		var style = elem.style;
		
		if (!px)
		{
			if (!min)
				min = $util.getOffset($util.getRuntimeStyle(elem), !this._LR) + 2;
			
			tab._tickSize = px = (this._LR ? elem.offsetHeight : elem.offsetWidth) - min;
			
			tab._tickMin = min;
			
			if (this._LR)
				
				tab._doHeight(-1);
			else
				tab._sizeStyle = style.width;
		}
		
		if ((px = Math.floor(px * (1 - size * size))) < min)
			size = 1;
		
		if (size < 0.98)
		{
			if (add)
				px = tab._tickSize + min - px;
			else
				size = 1 - size;
			$util.setOpacity(elem, 80 * size);
			if (this._LR)
				tab._doHeight(px);
			else
				style.width = px + 'px';
			return;
		}
		
		if (!add)
			this._closeTab(tab);
		
		px = null;
		try
		{
			if(style.removeAttribute)
				style.removeAttribute(px = 'filter');
			else if(style.removeProperty)
				style.removeProperty(px = 'opacity');
		}
		catch(e){}
		if (!px)
			$util.setOpacity(elem, 100);
		
		if (tab._tickSize)
		{
			if (this._LR)
				
				tab._doHeight(-2);
			else
				style.width = tab._sizeStyle;
		}
		
		this._tickTab = tab._tickSize = tab._sizeStyle = null;
		
		this._clearTick();
		if (add)
		{
			this._fireEvt('TabAddAnimationEnded', tab._i, 1);
			if (!this._element)
				return;
			
			this.scrollIntoView(9999);
			
			if (this._editOnAdd)
				this.startEditing(tab);
		}
	},
	_closeTab: function(tab)
	{
		
		if (tab._i == this.get_selectedIndex())
			this.set_selectedIndex(-1);
		
		this._setVis(tab._elem);
		
		this._calcLabels();
		this._fireEvt('TabClosed', tab._i, 2);
	},
	_showTab: function(tab, show)
	{
		
		this._mouse_i = -2;
		
		if (show)
		{
			this._setVis(tab._elem, 2);
			this._calcLabels();
		}
		
		else if (this._closeDur > 1 && this._element.offsetWidth > 1)
			this._tickHandler(2, this, tab);
		
		else
			this._closeTab(tab);
	},
	
	_findSpan: function(elem, index)
	{
		if (!elem)
			return null;
		elem = elem.childNodes;
		for (var i = 0; i < elem.length; i++)
			if (elem[i].nodeName == 'SPAN')
				if (index-- <= 0)
					return elem[i];
		return null;
	},
	
	_setText: function(tab, txt)
	{
		var elem = this._textSpan(tab);
		if (!elem)
			return;
		tab._span = tab._txt = null;
		txt = '' + txt;
		var c, tag = false, i = this._textBreak ? txt.length : 0;
		while (i-- > 1)
		{
			if ((c = txt.charCodeAt(i)) == 60)
				tag = false;
			if (c == 62)
				tag = true;
			if (!tag)
				txt = txt.substring(0, i) + '<br />' + txt.substring(i);
		}
		elem.innerHTML = txt;
		this._calcLabels(true);
	},
	
	_getText: function(tab)
	{
		var elem = this._textSpan(tab);
		return elem ? elem.innerHTML : null;
	},
	
	
	_setTabSize: function(tab)
	{
		var elem = tab._elem;
		if (!elem || this._6spans)
			return;
		var val = tab._tabSize;
		var perc = tab._perc;
		if (val == 0)
		{
			val = this._tabSize;
			perc = this._perc;
		}
		val = (val == 0 || perc) ? '' : val + 'px';
		if (this._LR)
			elem.style.height = val;
		else
			elem.style.width = val;
		if (!noCalc)
			this._calcLabels(true);
	},
	
	
	_textSpan: function(tab)
	{
		if (!tab)
			return null;
		var i = -1, elem = tab._span;
		if (elem)
			return elem;
		
		if (this._LR)
		{
			if (!this._horiz)
				
				elem = tab._cent = this._findSpan(tab._elem, 0);
		}
		else if (this._6spans)
			
			elem = this._findSpan(tab._elem, 2);
		
		if (!elem)
			if (!(elem = this._findSpan(this._findSpan(tab._elem, 0), 0)))
				return null;
		
		elem = elem.childNodes;
		while (++i < elem.length)
		{
			var name = elem[i].nodeName;
			if (name == 'SPAN' && !tab._span)
				tab._span = elem[i];
			else if (name == 'IMG' && !tab._img)
				tab._img = elem[i];
		}
		return tab._span;
	},
	
	
	
	_textOver: function(tab, fix)
	{
		
		var vert = !this._horiz, span = this._textSpan(tab);
		
		var ie6 = !vert && this._LR && ($util.IsQuirks || $util.IsIE6);
		if (this.get_textOverflow() != 1)
		{
			if (ie6)
				
				ie6 = 1;
			else
				return;
		}
		if (this._textBreak)
			return this._textOverBR(tab);
		if (!span || (!vert && !this._LR && $util.isEmpty(tab._elem.style.width)))
			return;
		var avail, txt = span.firstChild, cont = span.parentNode;
		if (!txt || txt != span.lastChild || txt.nodeName != '#text')
			return;
		
		if (vert)
			avail = this._LR ? cont.offsetHeight : tab._elem.offsetHeight;
		else
		{
			avail = cont.offsetWidth;
			if (ie6)
			{
				var width = this._elements.head.offsetWidth - $util.getOffset($util.getRuntimeStyle(cont), true) - $util.getOffset($util.getRuntimeStyle(cont.parentNode), true);
				if (avail > width)
					avail = width + ((ie6 === 1) ? 10 : 0);
				
				else if (ie6 === 1)
					return;
			}
		}
		var i, str = txt.nodeValue, old = tab._txt;
		if (!str || avail == 0)
		{
			tab._txt = null;
			return;
		}
		var size = vert ? span.scrollHeight : span.offsetWidth, margin = tab._txtMargin;
		var pad = tab._txtPad;
		if (!pad)
		{
			pad = $util.toIntPX(null, vert ? 'paddingTop' : 'paddingLeft', 0, span) + $util.toIntPX(null, vert ? 'paddingBottom' : 'paddingRight', 0, span);
			if (vert)
				pad += $util.toIntPX(null, 'marginTop', 0, span) + $util.toIntPX(null, 'marginBottom', 0, span) + $util.toIntPX(null, 'paddingTop', 0, cont);
			
			if (tab._hasClose)
				pad += $util.toIntPX(null, vert ? 'paddingBottom' : 'paddingRight', 0, cont);
			tab._txtPad = pad;
		}
		if (margin == null || fix)
		{
			margin = 0;
			
			var img = tab._img;
			if (img && img.style.position != 'absolute') if ((margin = vert ? img.offsetHeight : img.offsetWidth) == 0)
			{
				
				margin = 20;
				if (!tab._fixOver)
					tab._fixOver = 1;
				if (tab._fixOver++ < 4)
					setTimeout($util.createDelegate(this, this._textOver, [tab, true]), 300);
			}
			margin += pad;
		}
		
		tab._txtMargin = margin;
		avail -= margin;
		if (old && (size <= avail || fix))
		{
			txt.nodeValue = str = old;
			tab._txt = null;
		}
		
		
		var j = 1, dots = (ie6 === 1) ? '' : '...';
		
		while ((size = vert ? span.scrollHeight : span.offsetWidth) > avail + 1 && j++ < 4)
		{
			if (!tab._txt)
				tab._txt = str;
			if ((i = Math.floor(avail / size * str.length - j)) < 2)
			{
				
				if (size - avail > 5 && ie6 !== 1)
					dots = dots.substring(0, Math.floor(avail * 3 / size));
				i = 1;
				j = 9;
			}
			txt.nodeValue = str = str.substring(0, i) + dots;
		}
	},
	
	
	
	_textOverBR: function(tab, fix)
	{
		var span = this._textSpan(tab);
		if (!span)
			return;
		var cont = span.parentNode;
		var avail = this._LR ? cont.offsetHeight : tab._elem.offsetHeight;
		var i, str = span.innerHTML, old = tab._txt;
		if (str.length == 0 || avail == 0)
		{
			tab._txt = null;
			return;
		}
		var height = span.offsetHeight, margin = tab._txtMargin;
		var pad = tab._txtPad;
		if (!pad)
		{
			pad = $util.toIntPX(null, 'paddingTop', 0, span) + $util.toIntPX(null, 'paddingBottom', 0, span);
			
			if (tab._hasClose)
				pad += $util.toIntPX(null, 'paddingBottom', 0, cont);
			tab._txtPad = pad;
		}
		if (margin == null || fix)
		{
			margin = 0;
			
			var img = tab._img;
			if (img && img.style.position != 'absolute') if ((margin = img.offsetHeight) == 0)
			{
				
				margin = 20;
				if (!tab._fixOver)
					tab._fixOver = 1;
				if (tab._fixOver++ < 4)
					setTimeout($util.createDelegate(this, this._textOverBR, [tab, true]), 300);
			}
			margin += pad;
		}
		
		tab._txtMargin = margin;
		avail -= margin;
		if (old && (height <= avail || fix))
		{
			span.innerHTML = str = old;
			tab._txt = null;
		}
		var br = '<BR>';
		if (str.indexOf(br) < 0) if (str.indexOf(br = '<br>') < 0)
			if (str.indexOf(br = '<BR/>') < 0) if (str.indexOf(br = '<BR />') < 0)
				if (str.indexOf(br = '<br/>') < 0) if (str.indexOf(br = '<br />') < 0)
					return;
		
		while ((height = span.offsetHeight) > avail + 1)
		{
			if (!tab._txt)
				tab._txt = str;
			if ((i = str.lastIndexOf(br)) < 1)
				break;
			span.innerHTML = str = str.substring(0, i);
		}
	},
	_clearTick: function()
	{
		this._animate(1);
		this._tickAct = 0;
		if (!$util._tab_f)
			return;
		window.clearInterval($util._tab_f);
		$util._tab_f = $util._tab_o = null;
	},
	
	_doUp: function(start)
	{
		if (!this._upHandler)
			this._upHandler = Function.createDelegate(this, this._onMouseUp);
		if (start)
		{
			if (!this._upOn)
				$addHandler(document, 'mouseup', this._upHandler);
			this._upOn = true;
			return;
		}
		if (this._upOn)
			$removeHandler(document, 'mouseup', this._upHandler);
		this._upOn = false;
	},
	_onMouseUp: function(e)
	{
		
		var act = this._tickAct;
		if (e && (act == 1 || act == -1))
			this._fixScrollImg((1 - act) / 2);
		
		this._doUp();
		
		var drag = this._drag;
		if (drag)
		{
			this._drag = null;
			
			var mark = drag.mark, mi = drag.move_i, next = drag.nextElem;
			drag.nextElem = null;
			if (mark)
			{
				
				mark.parentNode.removeChild(mark);
				drag.mark = null;
				
				drag.src.className = drag.src.className.replace(' ' + this._moving[0], '');
				drag.drop = drag.src = null;
			}
			
			if (mi != null && drag.vi != mi)
			{
				var tab = this._tabs[drag.i];
				
				var args = this._raiseClientEvent('TabMovingEnd', 'TabMoving', e, 0, drag.i, mi);
				if (!this._element)
					return;
				if (args && args.get_cancel())
				{
					var elem = tab._elem, holder = this._holder;
					if (holder && elem.nextSibling != next)
					{
						holder.removeChild(elem);
						if (next)
							holder.insertBefore(elem, next);
						else
							holder.appendChild(elem);
					}
					return;
				}
				this.moveTab(tab, mi, 1);
				this._fireEvt('TabMovedEnd', tab._i, 2, e);
				if (!this._element)
					return;
			}
		}
		this._clearTick();
		this._tickAct = 0;
	},
	
	
	
	
	_tickHandler: function(act, me, tab)
	{
		//var delta;
		
		if (me != null)
		{
			me._clearTick();
			
			
			if (act < 2)
				me._doUp(true);
			me._tickTab = tab;
			
			me._tickAct = act;
			
			//delta = me._scrollStart;
			me._tick = 0;
			$util._tab_o = me;
			$util._tab_f = window.setInterval(me._tickHandler, 30);
		}
		else
		{
			if ((me = $util._tab_o) == null)
				return;
			act = me._tickAct;
			
			
			var delta = 0.02;
			
			if (act > 1)
				delta = Math.max(1 / (((act == 2) ? me._closeDur : me._addDur) + 1), 0.02);
			if ((me._tick += delta) > 1)
				me._tick = 1;
		}
		if (act < 2)
			
			me._doScroll(0, act * (me._scrollStart + Math.round((me._scrollEnd - me._scrollStart) * me._tick)), true);
		else
			me._animate(me._tick);
	},
	
	
	
	
	
	_doScroll: function(val, delta, fire, auto)
	{
		var args = null, elems = this._elements;
		var holder = this._holder, size = this._scrollSize;
		if (!holder || !size || !this._enabled)
		{
			
			this._set_value($IG.TabProps.ScrollPosition, -(this._scroll = val));
			return;
		}
		var hide = this._tabsSize <= size && this._autoHide;
		
		this._scrollEdge = hide;
		
		var old = this._scroll;
		if (!old)
			old = 0;
		if (delta != null)
			val = old + delta;
		if (val > 0 || hide)
			val = 0;
		
		var sb = elems.sb1, max = 10, nodes = holder.childNodes;
		
		var i = hide ? 0 : nodes.length;
		while (i-- > 0)
		{
			var n = nodes[i];
			
			if ((n._add && auto) || n._mark)
				continue;
			if (this._LR)
				n = n.offsetHeight + n.offsetTop;
			else
				n = n.offsetWidth + n.offsetLeft;
			if (n > max)
				max = n;
		}
		if (!hide && (max += 5) + val <= size)
		{
			
			this._scrollEdge = true;
			this._fixScrollImg(1, 3);
			if ((val = size - max) > 0)
				val = 0;
		}
		
		if (this._autoHide)
		{
			var vis = (hide || (val == 0 && this._scrollEdge)) ? 'hidden' : 'visible';
			sb = sb.parentNode.style;
			if (vis != sb.visibility)
				sb.visibility = vis;
		}
		
		if (val == old)
			fire = false;
		if (fire)
			args = this._raiseClientEvent('Scrolling', 'TabScrolling', null, 0, -val, -old);
		if (!this._element || (args && args.get_cancel()))
			return;
		
		this._scroll = val;
		
		this._set_value($IG.TabProps.ScrollPosition, -val);
		
		this._fixScrollImg((val > old) ? 0 : 1, (val == old) ? 0 : 2);
		this._fixScrollImg((val > old) ? 1 : 0);
		
		sb = elems.scroll.style;
		if (this._LR)
			sb.marginTop = val + 'px';
		else
			sb.marginLeft = val + 'px';
		if (fire)
			this._raiseClientEvent('Scrolled', 'TabScrolled', null, 0, -val, -old);
	},
	
	_fixSelMulti: function()
	{
		var elem, holder = this._holder;
		var iSel = this.get_selectedIndex(), tabs = this._tabs;
		if (!holder || this._mode < 2 || iSel < 0 || iSel >= tabs.length || tabs[iSel]._hidden)
			return;
		
		var nodes = holder.childNodes;
		var iLen = nodes.length;
		
		
		var outStart = -1, outEnd = -1, selStart = -1, selEnd = -1;
		
		var selFound = -1;
		
		var outDone = false, i = iLen;
		
		while (i-- > 0)
		{
			elem = nodes[i];
			
			if (elem.nodeName != 'SPAN' || elem._add || elem._mark)
				continue;
			
			if (elem._i != null)
			{
				if (elem._i == iSel)
					selFound = 0;
				if (selFound == 0)
					selStart = i;
				if (selEnd < 0)
					selEnd = i;
				if (!outDone)
				{
					if (outEnd < 0)
						outEnd = i;
					outStart = i;
				}
			}
			
			if (elem.style.clear == 'left')
			{
				if (selFound >= 0)
					selFound = 1;
				else
					selStart = selEnd = -1;
				
				if (this._TOP)
					outDone = true;
				
				else
					outEnd = -1;
			}
		}
		if (outStart == selStart || selStart < 0 || outStart < 0)
			return;
		
		var aOut = new Array(), aSel = new Array();
		for (i = outStart; i <= outEnd; i++)
			aOut[i - outStart] = nodes[i];
		for (i = selStart; i <= selEnd; i++)
			aSel[i - selStart] = nodes[i];
		
		var afterSel = (selEnd + 1 < iLen) ? nodes[selEnd + 1] : null;
		var afterOut = (outEnd + 1 < iLen) ? nodes[outEnd + 1] : null;
		
		i = aOut.length;
		while (i-- > 0)
			holder.removeChild(aOut[i]);
		i = aSel.length;
		while (i-- > 0)
			holder.removeChild(aSel[i]);
		
		for (i = 0; i < aOut.length; i++)
		{
			if (afterSel)
				holder.insertBefore(aOut[i], afterSel);
			else
				holder.appendChild(aOut[i]);
		}
		for (i = 0; i < aSel.length; i++)
		{
			if (afterOut)
				holder.insertBefore(aSel[i], afterOut);
			else
				holder.appendChild(aSel[i]);
		}
		
		if (this._mode != 3)
			return;
		var vi = 0;
		for (i = 0; i < iLen; i++)
		{
			elem = nodes[i];
			var index = elem._i;
			var tab = (index == null) ? null : tabs[index];
			if (!tab)
				continue;
			
			
			tab._vi = elem._vi = vi;
			this._map[vi++] = index;
		}
	},
	
	_clearMulti: function()
	{
		var holder = this._holder;
		this._hasRows = false;
		if (this._mode != 3 || !holder)
			return;
		
		var nodes = holder.childNodes;
		var i = nodes.length;
		while (i-- > 0)
		{
			var elem = nodes[i];
			
			if (elem.nodeName != 'SPAN' || elem._add || elem._mark)
				continue;
			if (elem.style.clear == 'left')
				holder.removeChild(elem);
			else
				elem._nextRow = elem._lastInRow = null;
		}
	},
	
	_chromeBug: function(on)
	{
		var b = document.body, e = this._chromeE;
		if (e)
			b.removeChild(e);
		delete this._chromeE;
		// Chrome returns wrong value for holder.offsetWidth, when its width was set to 99999px
		// Change to document seems to trick Chrome to do its layout and update holder.offsetWidth
		// Changes to other elements or their attributes do have effect and Chrome keeps old/wrong layout
		if (on)
		{
			on = this._chromeE = document.createElement('SPAN');
			on.style.position = 'absolute';
			b.appendChild(on);
		}
	},
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	_calcLabels: function(noCss, noSize, multi)
	{
		
		this._chromeBug();
		if (this._LR)
			return this._calcLabelsLR(noCss, noSize);
		var elem0 = this._element, holder = this._holder, tabs = this._tabs, elems = this._elements, mode = this._mode;
		if (!holder || !tabs || !elems)
			return;
		if (!this.get_visibleHeader())
		{
			if (!noSize)
				this._fixSize();
			return;
		}
		var hasWidth = !$util.isEmpty(this._width0);
		
		if (!hasWidth && mode == 3)
			mode = 0;
		
		if (!multi)
		{
			if (this._calcWait || elem0.offsetWidth < 2)
				return;
			this._calcWait = true;
			
			if (mode != 1)
			{
				
				if (!this._perc || !hasWidth)
					elem0.style.minWidth = this._minWidth ? this._minWidth + 'px' : '';
				
				holder.style.width = '99999px';
				
				this._chromeBug(1);
				// note: if temporary SPAN is removed at once, like in line below, then that has no effect
				//this._chromeBug();
			}
			
			
			this._wrapTabs = (mode & 1) == 0 && hasWidth && this._horiz && this.get_tabsOverflow() == 1;
			this._clearMulti();
		}
		var width = elem0.offsetWidth;
		var height = null, maxHeight = this._6spans ? 1 : 0;
		var v, elem, tab, i, vi = -1, size = 0, iLen = tabs.length;
		this._lastElem = null;
		
		var pad = this._rbPadHoriz;
		var last = true, first = true;
		var addTab = this._addTab;
		var add = addTab ? 1 : 0;
		var percWidth = Math.max(5, width - pad - 5);
		
		while (++vi < iLen + add)
		{
			tab = (vi == iLen) ? addTab : tabs[i = this._map[vi]];
			tab._first = tab._last = false;
			elem = tab._elem;
			
			if (elem._nextRow)
				this._hasRows = first = true;
			if (tab._hidden)
				continue;
			
			if (tab._tempOver && tab._txt)
			{
				if (this._textBreak)
					tab._span.innerHTML = tab._txt;
				else
					tab._span.firstChild.nodeValue = tab._txt;
			}
			
			if (!multi && this._horiz)
			{
				
				v = tab._perc;
				
				size = (!v || hasWidth) ? tab._tabSize : 0;
				if (size == 0)
				{
					
					v = this._perc;
					
					if (!v || hasWidth)
						size = this._tabSize;
				}
				
				if (size > 0 && v)
					if ((size = Math.floor(size * percWidth / 100)) < 1)
						size = 1;
				
				elem.style.width = (size > 0) ? size + 'px' : 'auto';
			}
			if (first)
				tab._first = true;
			first = false;
			if (maxHeight > 0 && (v = elem.offsetHeight) > maxHeight)
			{
				maxHeight = v;
				height = elem.style.height;
			}
		}
		if (maxHeight > 0 && $util.isEmpty(height))
			height = maxHeight + 'px';
		
		vi = iLen + add;
		while (vi-- > 0)
		{
			tab = (vi == iLen) ? addTab : tabs[this._map[vi]];
			elem = tab._elem;
			
			if (elem._lastInRow)
				last = true;
			if (tab._hidden)
				continue;
			if (last)
				tab._last = true;
			last = false;
			if (maxHeight > 0)
				elem.style.height = height;
		}
		
		if (!noCss)
			for (i = -add; i < iLen; i++)
				this._fixTabCss(i);
		
		var max = (!multi && mode == 3) ? (width - pad - 10) : 99999;
		
		
		multi = last = null;
		var parentWidth, rowWidth = 0, rowOverlap = 0, rowMargin = 0, rowPlus = 0, visNum = 0, padPlus = 0;
		vi = -1;
		size = 0;
		while (++vi < iLen + add)
		{
			tab = (vi == iLen) ? addTab : tabs[i = this._map[vi]];
			if (tab._hidden)
				continue;
			elem = tab._elem;
			
			if (tab._first)
				rowWidth = rowOverlap = rowPlus = rowMargin = 0;
			
			var tw = elem.offsetWidth;
			v = elem.scrollWidth;
			
			// get around bug in IE6: it may stretch tab to whole width of container
			if (!parentWidth)
				if ((parentWidth = Math.min(3000, elem.parentNode.offsetWidth - 20)) < 100)
					parentWidth = 3000;
			if (tw > parentWidth || v > parentWidth)
			{
				tw = elem.childNodes;
				v = tw.length;
				while (v-- > 0) if (tw[v].nodeName == 'SPAN')
					tw[v].style.display = 'inline-block';
				tw = elem.offsetWidth;
				v = elem.scrollWidth;
			}
			// end of IE6 bug
			var tl = elem.offsetLeft + rowPlus;
			if (v > tw && v < tw + 20)
				tw = v;
			var img = tab._img;
			if (img && img.style.position != 'absolute' && img.offsetWidth == 0)
			{
				tw += 20;
				rowPlus += 20;
			}
			
			if (tab._marginR == null)
			{
				v = elem.style.marginRight;
				tab._marginR = (v.indexOf('px') > 0) ? $util.toInt(v, 0) : 0;
			}
			if (tab._marginL == null)
			{
				v = elem.style.marginLeft;
				tab._marginL = (v.indexOf('px') > 0) ? $util.toInt(v, 0) : 0;
			}
			rowMargin += (padPlus = tab._marginR) + tab._marginL;
			if (tw < 1)
				continue;
			visNum++;
			
			rowWidth += tw;
			
			if (mode > 1 || (this._wrapTabs && mode == 0))
			{
				var style = $util.getRuntimeStyle(elem);
				
				tab._padding = $util.getOffset(style, true);
				
				rowOverlap += $util.toIntPX(style, 'marginLeft', 0);
			}
			
			tab._widthPX = tw;
			if (tab._last)
			{
				
				tab._rowWidth = rowWidth;
				tab._rowOverlap = rowOverlap;
			}
			
			if (tw + tl > max && last)
			{
				this._hasRows = true;
				last._lastInRow = true;
				elem._nextRow = true;
				multi = document.createElement('SPAN');
				multi.style.clear = 'left';
				multi.style.width = '0px';
				if (!$util.IsIE || $util.IsIEStandards)
					multi.style.display = 'block';
				holder.insertBefore(multi, elem);
				rowWidth = 0;
			}
			
			last = elem;
			if (tw + tl > size)
				size = tw + tl;
			
			if (mode < 2 && !this._wrapTabs)
			{
				tab._fixOver = null;
				this._textOver(tab);
			}
		}
		if (multi)
			return this._calcLabels(noCss, noSize, true);
		
		
		if (mode == 0 && last)
		{
			if (elems.rs)
			{
				size += 10;
				last = elems.rs;
			}
			this._lastElem = last;
			last._top = last.offsetTop;
		}
		pad += padPlus;
		size += pad;
		this._tabsSize = size;
		
		
		var perc = null, right = this._RIGHT_BOT;
		
		if (mode != 1)
		{
			if (!hasWidth)
				width = size;
			
			if (width < size + 5 && this._wrapTabs)
				perc = 99.5;
			
			
			if (right && !perc)
				v = 'auto';
			
			else if (mode == 3)
				v = '100%';
			
			else if (perc || (mode == 2 && width > size))
				v = (width - pad) + 'px';
			else if (right || mode > 0)
				v = size + 'px';
			else
				v = null;
			if (mode > 1)
				perc = 99.5;
			if (v)
				holder.style.width = v;
			if (!this._perc || !hasWidth)
				elem0.style.minWidth = this._wrapTabs ? '' : (size + 6) + 'px';
		}
		
		if (perc)
		{
			
			if (addTab)
				perc -= addTab._elem.offsetWidth / width;
			
			rowPlus = rowMargin;
			
			if (mode == 0 && visNum > 5)
				perc -= 0.01 * (visNum - 4);
			
			if (width < 500)
				perc -= (500 + width) / width;
			
			size = holder.offsetWidth;
			if (size < 10)
				size = 10;
			
			last = this._lastElem;
			i = 0;
			while (i++ < 5)
			{
				vi = iLen;
				while (vi-- > 0)
				{
					tab = tabs[this._map[vi]];
					if (tab._hidden)
						continue;
					
					if (tab._last)
					{
						rowWidth = tab._rowWidth;
						
						
						rowWidth += tab._rowOverlap * rowWidth / (size + rowWidth / 10);
					}
					
					if ((v = tab._widthPX / (rowWidth + rowPlus) - tab._padding / size) < 0.01)
						v = 0.01;
					tab._elem.style.width = v * perc + '%';
					
					if (i == 1)
					{
						tab._fixOver = null;
						
						tab._tempOver = 1;
						this._textOver(tab);
					}
				}
				if (!last)
					break;
				if (last.offsetTop < last._top + 5 && last.offsetLeft + last.offsetWidth + 5 < width)
					
					if (!addTab || addTab._elem.offsetTop < last._top + 5)
						break;
				rowPlus += i * i * Math.floor((1000 + 20 * rowMargin) / width);
				perc *= 0.96;
				if (mode == 0 && visNum > 6 && i > 1)
					perc -= 0.05 * (visNum - 6);
			}
			this._fixSelMulti();
		}
		
		else if (mode < 2 && this._wrapTabs)
		{
			for (i = 0; i < iLen; i++)
			{
				tab = tabs[i];
				if (!tab._hidden)
				{
					tab._fixOver = null;
					
					tab._tempOver = 1;
					this._textOver(tab);
				}
			}
		}
		
		if ((v = elem0.offsetWidth) > 8000 && v > (this._tabsSize + 100))
			holder.style.width = '1000%';
		
		this._chromeBug();
		if (!noSize)
		{
			this._fixSize();
			
			if ((v = elem0.offsetWidth) > 8000 && v > (this._tabsSize + 100))
			{
				holder.style.width = '1000%';
				this._fixSize();
			}
		}
		
		this._scrollSize = (elems.scroll && elems.sb1) ? holder.parentNode.offsetWidth - elems.sb1.parentNode.offsetWidth - pad : null;
		
		this._doScroll(0, 0, true);
		this._calcWait = null;
	},
	
	
	
	
	
	
	
	
	
	_calcLabelsLR: function(noCss, noSize)
	{
		var elem0 = this._element, holder = this._holder, tabs = this._tabs, elems = this._elements, mode = this._mode;
		if (!holder || !tabs || !elems)
			return;
		if (!this.get_visibleHeader())
		{
			if (!noSize)
				this._fixSize();
			return;
		}
		
		var bot = this._RIGHT_BOT;
		var hasHeight = !$util.isEmpty(this._height0);
		if (this._calcWait || elem0.offsetHeight < 2)
			return;
		this._calcWait = true;
		
		if (mode != 1)
		{
			
			if (!this._perc || !hasHeight)
				elem0.style.minHeight = this._minHeight ? this._minHeight + 'px' : '';
			if (bot)
				holder.parentNode.style.paddingTop = '';
			
			this._wrapTabs = hasHeight && !this._horiz && (this.get_tabsOverflow() == 1 || mode > 1);
		}
		var height = elem0.offsetHeight;
		var v, elem, tab, i, vi = -1, size = 0, iLen = tabs.length;
		
		var pad = this._rbPadVert, last = null, first = true;
		var addTab = this._addTab;
		var add = addTab ? 1 : 0;
		var percHeight = Math.max(5, height - pad - 5);
		
		while (++vi < iLen + add)
		{
			tab = (vi == iLen) ? addTab : tabs[i = this._map[vi]];
			tab._first = tab._last = false;
			elem = tab._elem;
			if (tab._hidden)
				continue;
			
			if (tab._txt)
			{
				if (this._textBreak)
					tab._span.innerHTML = tab._txt;
				else
					tab._span.firstChild.nodeValue = tab._txt;
			}
			
			last = tab;
			
			if (!this._horiz && vi < iLen)
			{
				
				v = tab._perc;
				
				size = (!v || hasHeight) ? tab._tabSize : 0;
				if (size == 0)
				{
					
					v = this._perc;
					
					if (!v || hasHeight)
						size = this._tabSize;
				}
				
				if (size > 0 && v)
					if ((size = Math.floor(size * percHeight / 100)) < 1)
						size = 1;
				
				tab._doHeight(size, this);
			}
			if (first)
				tab._first = true;
			first = false;
			
			if (this._horiz)
			{
				tab._fixOver = null;
				this._textOver(tab);
			}
		}
		
		if (last)
			tab._last = true;
		
		if (!noCss)
			for (i = -add; i < iLen; i++)
				this._fixTabCss(i);
		size = holder.offsetHeight;
		
		var rowOverlap = 0, rowMargin = 0, rowPlus = 0, padPlus = 0, padTop = -1;
		vi = -1;
		while (++vi < iLen + add)
		{
			tab = (vi == iLen) ? addTab : tabs[this._map[vi]];
			if (tab._hidden)
				continue;
			elem = tab._elem;
			
			var th = elem.offsetHeight, top = elem.offsetTop + rowPlus;
			if ((v = elem.scrollHeight) > th)
				th = v;
			var img = tab._img;
			if (img && img.style.position != 'absolute' && img.offsetHeight == 0)
			{
				th += 20;
				
				rowPlus += 20;
			}
			
			tab._heightPX = th;
			
			if (tab._marginB == null)
			{
				v = elem.style.marginBottom;
				tab._marginB = (v.indexOf('px') > 0) ? $util.toInt(v, 0) : 0;
			}
			if (tab._marginT == null)
			{
				v = elem.style.marginTop;
				tab._marginT = (v.indexOf('px') > 0) ? $util.toInt(v, 0) : 0;
			}
			if (padTop < 0)
				padTop = tab._marginT;
			
			
			rowMargin += (v = Math.max(padPlus, tab._marginT));
			
			if (this._wrapTabs && v == 0)
				rowOverlap += $util.toIntPX($util.getRuntimeStyle(elem), 'marginTop', 0);
			padPlus = tab._marginB;
		}
		
		size += pad + padPlus + padTop;
		this._tabsSize = size;
		
		
		if (mode != 1)
		{
			if (!hasHeight)
				height = size;
			
			if (mode > 1 || (height < size && this._wrapTabs))
				
				percHeight = null;
			if (!this._perc || !hasHeight)
			{
				elem0.style.minHeight = this._wrapTabs ? '' : size + 'px';
				
				if (!this._wrapTabs)
					this._minHeight0 = null;
			}
		}
		
		if (!percHeight)
		{
			
			v = addTab ? addTab._elem.offsetHeight : 0;
			v += rowMargin + pad + rowOverlap + padPlus;
			
			if ((height -= v) < 2)
				height = 2;
			if ((size -= v) < 2)
				size = 2;
			
			v = height / size;
			i = iLen;
			while (i-- > 0)
			{
				tab = tabs[i];
				if (!tab._hidden)
					tab._doHeight(Math.max(1, Math.floor(tab._heightPX * v)), this);
			}
		}
		if (!noSize)
			this._fixSize();
		
		if (bot) if ((bot = elem0.offsetHeight - this._tabsSize - pad - 2) > 0)
			holder.parentNode.style.paddingTop = bot + 'px';
		
		this._scrollSize = (elems.scroll && elems.sb1) ? holder.parentNode.offsetHeight - elems.sb1.parentNode.offsetHeight - pad : null;
		
		this._doScroll(0, 0, true);
		this._calcWait = null;
	},
	
	
	_onInput: function(e, index)
	{
		var active_i = this._active_i, tab = this._tab, edit = this._editing, tabs = this._tabs;
		if (index == null)
			index = active_i;
		if (!e)
		{
			e = active_i;
			active_i = index;
			index = e;
		}
		else if (e.type == 'focus')
		{
			if (active_i < 0)
				
				if ((active_i = this._active_if) < 0)
					
					active_i = tab ? tab._i : 0;
			
			this._active_if = -1;
			
			this._raiseClientEvent('Focus', null, e);
			if (!this._element)
				return;
		}
		else if (e.type == 'blur')
		{
			if (edit && edit + 50 > (new Date()).getTime())
				return;
			active_i = -1;
			
			this._raiseClientEvent('Blur', null, e);
			if (!this._element)
				return;
			if (edit)
				this.endEditing(false, e);
		}
		else
		{
			if (this._fireEvt('KeyDown', index, null, e))
				return;
			if (!this._element)
				return;
			var next, key = e.keyCode, keys = Sys.UI.Key;
			tab = (index < 0) ? null : tabs[index];
			if ((this._LR && (key == keys.up || key == keys.down)) || (!this._LR && (key == keys.left || key == keys.right)))
				next = key == keys.right || key == keys.down;
			else if (key == keys.end || key == keys.home)
			{
				tab = null;
				next = key == keys.home;
			}
			else
			{
				if (edit)
				{
					if (key == keys.esc || key == keys.enter || key == keys.tab)
					{
						$util.preventDefaults(e);
						//$util.cancelEvent(e);
						this.endEditing(key != keys.esc, e);
					}
					return;
				}
				if (key == keys.space || key == keys.enter)
				{
					$util.preventDefaults(e);
					//$util.cancelEvent(e);
					if (tab)
						this.set_selectedIndex(index);
					else if (active_i == tabs.length)
						this._doAdd(e);
				}
				return;
			}
			if (next && active_i == tabs.length)
				return;
			tab = this.getVisibleSibling(tab, next, 1);
			if (!tab && next)
				tab = this._addTab;
			if (!tab)
				return;
			active_i = tab._i;
		}
		if (edit || index == active_i)
			return;
		if (this._fireEvt('ActiveTabChange', active_i))
			return;
		if (!this._element)
			return;
		this._active_i = active_i;
		
		this._activeCss = (active_i < 0) ? -2 : ((active_i == tabs.length) ? -1 : active_i);
		this._fixTabCss(index);
		this._fixTabCss(active_i);
		
		this._fixLine();
		this.scrollIntoView(active_i);
	},
	
	
	_fixLine: function()
	{
		
		if (!this._lastElem || this._lastElem._top + 4 > this._lastElem.offsetTop)
			return false;
		this.repaint();
		return true;
	},
	_layout: function()
	{
	    
        
	    $util.raiseLayoutEvent(this);
		if (this._tab)
			$util.raiseLayoutEvent(this._tab);
	},
	
	
	
	_onTimer: function(init)
	{
		
		if (this._timer && this._holder)
		{
			if (this._timer++ > 9)
			{
				this._timer = 9;
				if (!this._resize)
				{
					
					ig_ui_timer(this, true);
					delete this._timerOn;
					return;
				}
			}
			
			if (this._timer < 9)
				if (this._fixLine())
					return;

			
			
			if (this._fixAutoSize(this._tab)) {
				this._doAutoSize();
			} else {
				
				if (this._fixSize(true))
					this.repaint();
			}
			return;
		}
		
		var back = (init === true) ? this._get_CS() : null, input = this._input;
		if (back && back.value.length > 10 && input)
		{
			
			this._ieBug1 = $util.IsIE;
			
			var old = input.value.split(':');
			if (old.length > 1)
				if ((old = parseInt(old[0])) != (this._tab ? this._tab._i : -1))
					this.set_selectedIndex(old);
		}
		var elem = this._element;
		if (!elem)
			return;
		var w = elem.offsetWidth;
		
		if (!w || w == 0)
			return;
		
		this._mouse_i = -2;
		var elems = this._elements;
		var head = elems.head;
		this._calcLabels(this._enabled);
		elem.style.visibility = 'visible';
		
		if (init === true)
			this._raiseClientEvent('Initialize');
		this._wasPainted = true;
		if (this._enabled)
		{
			
			var evts, ie = $util.ieTouchType();
			if (!ie)
			{
				evts = {mousedown:this._onMouse, mouseover:this._onMouse, mouseout:this._onMouse, mousemove:this._onMouse, touchstart:this._onTStart, touchmove:this._onTMove, touchend:this._onTEnd};
			}
			else if (ie == 'pointer')
			{
				evts = {pointerdown:this._onMSStart, pointermove:this._onMSMove, pointerup:this._onMSEnd};
				this._ie11pointer = true;
				this._pointerUpName = 'pointerup';
				head.style.touchAction = 'none';
				if (this._sbHolder)
					this._sbHolder.style.touchAction = 'none';
			}
			else
			{
				evts = {MSPointerDown:this._onMSStart, MSPointerMove:this._onMSMove, MSPointerUp:this._onMSEnd};
				this._pointerUpName = 'MSPointerUp';
				head.style.msTouchAction = 'none';
				if (this._sbHolder)
					this._sbHolder.style.msTouchAction = 'none';
			}
			if (this._sbHolder)
				$addHandlers(this._sbHolder, evts, this);
			if (this._editOnDbl)
				evts.dblclick = this._onMouse;
			$addHandlers(head, evts, this);
		}
		
		this._resize = (this._width0 && this._width0.indexOf('%') > 0) || (this._height0 && this._height0.indexOf('%') > 0);
		
		this._timer = 1;
		if (input) if (this._activation)
			$addHandlers(input, {focus:this._onInput, blur:this._onInput, keydown:this._onInput}, this);
		else
			input.tabIndex = -1;
		this._layout();
		this._raiseClientEvent('Loaded');
	},
	



	_fixAutoSize: function (tab)
	{
		var auto = tab;
		if (auto)
		{
			auto = auto._getAutoSize();
		} else {
			return false;
		}
			
		if (auto == 0)
			auto = this._autoSize;
		if (auto === 0)
		{
			return false;
		}

		var frameSize = this._frameSize(tab), elem = this._element, tabHeaderHeight = this._LR ? 0 : tab._elem.offsetHeight;
		if (frameSize)
		{
			if (Math.abs((frameSize[1] + tabHeaderHeight + this._rbPadVert) - elem.offsetHeight) > this._offsetRatio)
			{
				return true;
			}
		} else {
			if (Math.abs((tab._element.scrollHeight + tabHeaderHeight + this._rbPadVert) - elem.offsetHeight) > this._offsetRatio) {
				return true;
			}
		}
		return false;
	},
	
	
	_doAutoSize: function()
	{
		var tab = this._tab, elem = this._element, vis = this.get_visibleContent();
		var v, height = vis ? this._height0 : '', width = this._width0, minSize = this._tabsSize;
		
		if ($util.isEmpty(width) && minSize)
			width = (minSize + 6) + 'px';
		
		if (elem.style.width != width)
			elem.style.width = width;
		
		if (elem.style.height != height)
			elem.style.height = height;
		
		if ((v = this._minHeight0) != null)
			elem.style.minHeight = v;
		
		if ((v = this._minWidth0) != null)
			elem.style.minWidth = v;
		var val, size, elems = this._elements;
		var cph = elems.cph, rb = elems.rb;
		
		if (!vis)
			return;
		var padVert = this._rbPadVert, padHoriz = this._rbPadHoriz;
		var head = elems.head.offsetHeight;
		var div = tab ? tab._element : null, auto = tab ? tab._getAutoSize() : 0;
		if (auto == 0)
			auto = this._autoSize;
		
		if (!height && auto == 0)
			auto = 2;
		
		if (auto > 0 && div)
		{
			div.style.height = '';
			
			if (auto == 1)
				div.style.width = '';
			var url = tab.get_contentUrl();
			var width0 = elem.offsetWidth, height0 = elem.offsetHeight;
			size = this._frameSize(tab);
			var max = this._maxHeight;
			if (size)
			{
				if (max < 1 || size[1] >= max)
					
					div.style.overflowY = 'hidden';
			}
			else
			{
				
				div.style.position = 'absolute';
				size = [div.scrollWidth + 2, div.scrollHeight + 2];
				
				div.style.position = 'relative';
			}
			
			if (size[0] < (v = this._minWidth))
				size[0] = v;
			if ((v = this._maxWidth) > 0) if (size[0] > v)
				size[0] = v;
			if (size[1] < (v = this._minHeight))
				size[1] = v;
			if (max > 0 && size[1] > max)
				size[1] = max;
			size[0] += padHoriz + 1;
			size[1] += padVert + 1;
			
			if (auto == 1 && width0 < size[0])
			{
				
				if (this._minWidth0 == null)
					this._minWidth0 = elem.style.minWidth;
				elem.style.minWidth = size[0] + 'px';
				
				if(elem.offsetWidth < size[0])
					elem.style.width = size[0] + 'px';
				width0 = elem.offsetWidth;
			}
			size[0] = width0;
			val = size[1] + head;
			this._size = { width: size[0], height: val };
			size[1] = Math.max(size[1] - 2, 1);
			
			v = size[1] + 'px';
			if (cph.style.height != v)
				cph.style.height = v;
			
			if (rb)
			{
				val = size[0] - padHoriz;
				if (val < 0)
					val = 0;
				size[0] = val * 100 / size[0];
				val = size[1] - padVert;
				if (val < 0)
					val = 0;
				size[1] = val * 100 / size[1];
			}
			else
				size[0] = size[1] = 100;
		}
		else
		{
			var width0 = elem.offsetWidth, height0 = elem.offsetHeight;
			if (height0 < head + padVert)
				height0 = head + padVert;
			
			val = height0;
			height0 = Math.max(height0 - head - 2, 1);
			if (cph.style.height != (v = height0 * 100 / val + '%'))
				cph.style.height = v;
			size = [100, 100];
			
			if (rb)
			{
				val = width0 - padHoriz;
				if (val < 0)
					val = 0;
				size[0] = val * 100 / width0;
				val = height0 - padVert;
				if (val < 0)
					val = 0;
				size[1] = val * 100 / height0;
			}
		}
		if (!div)
			return;
		if (div.style.width != (v = size[0] + '%'))
			div.style.width = v;
		if (div.style.height != (v = size[1] + '%'))
			div.style.height = v;
		div.style.visibility = 'visible';
	}
}
$IG.WebTab.registerClass('Infragistics.Web.UI.WebTab', $IG.ControlMain);

$IG.WebTab.find = function (clientID)
{
	///<summary>Finds WebTab by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebTab">Reference to the WebTab control object that corresponds to specified client ID.</returns>
};

$IG.WebTab.from = function (obj)
{
	///<summary>Casts passed in object to the WebTab type.</summary>
	///<param name="obj">Object to convert to the WebTab type.</param>
	///<returns type="Infragistics.Web.UI.WebTab">Reference to the same object that is passed in, only type converted to the WebTab type.</returns>
};


$IG.TabItemProps = new function()
{
	var count = $IG.ContentPaneProps.Count;
	this.TabSize = [count++, ''];
	this.Text = [count++, ''];
	this.AutoSize = [count++, 0];
	this.Enabled = [count++, 1];
	this.Hidden = [count++, 0];
	this.VisibleIndex = [count++, -1];
	this.EnableCloseButton = [count++, 0];
	this.Key = [count++, ''];
	this.Count = count;
};


$IG.TabItem = function(adr, elem, props, ctl, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabItem">Class used by WebTab for its content panes and tabs.</summary>
	/// <param name="adr" type="String">Address. Internal use only.</param>
	/// <param name="element" domElement="true">Html element. Internal use only.</param>
	/// <param name="props" type="Array">Properties. Internal use only.</param>
	/// <param name="ctl">Reference to control. Internal use only.</param>
	/// <param name="csm">Client state manager. Internal use only.</param>
	$IG.TabItem.initializeBase(this, [adr, elem, props, ctl, csm]);
}

$IG.TabItem.prototype =
{
	getDisplayedText: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabItem.getDisplayedText">Gets text displayed on tab.</summary>
		/// <returns type="String" mayBeNull="true">Actual text (innerHTML) on tab. If owner WebTab is not defined, then null is returned.</returns>
		return this._owner ? this._owner._getText(this) : null;
	},
	get_enableCloseButton: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.enableCloseButton">Checks if close button is enabled.</summary>
		/// <value type="Number" integer="true">If returned value is 0, then WebTab.CloseButton.Enabled property is used. If returned value is 1, then close button is enabled. If returned value is 2, then close button is disabled.</value>
		return this._get_value($IG.TabItemProps.EnableCloseButton);
	},
	get_text: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.text">
		/// Gets sets text displayed on tab as string.
		/// Note: when vertical text is enabled, then the set may fail if value contains html tags.
		/// </summary>
		/// <value type="String">Text in tab label</value>
		var v = this._get_value($IG.TabItemProps.Text);
		return v ? v.replace(/%3C/gi, '<') : '';
	},
	set_text: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.text">Sets text of tab item.</summary>
		/// <param name="val" type="String">Text of tab item.</param>
		if (!val)
			val = '';
		this._set_value($IG.TabItemProps.Text, val.replace(/</gi, '%3C'));
		if (this._owner)
			this._owner._setText(this, val);
	},
	get_key: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.key">Gets sets key of tab item.</summary>
		/// <value type="String">String associated with tab item</value>
		return this._get_value($IG.TabItemProps.Key);
	},
	set_key: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.key">Sets key of tab item.</summary>
		/// <param name="val" type="String">String associated with tab item</param>
		this._set_value($IG.TabItemProps.Key, val ? val.replace(/[><&\n\r\'\"]/g, '') : val);
	},
	get_tabSize: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.tabSize">Gets sets size of tab in % or px units as string.</summary>
		/// <value type="String">Size in units</value>
		return this._get_value($IG.TabItemProps.TabSize);
	},
	set_tabSize: function(val, noFix)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.tabSize">Sets size of tab item.</summary>
		/// <param name="val" type="String">Size of tab item in % or px units as string</param>
		/// <param name="noFix" type="Boolean" optional="true" mayBeNull="true">True: skip adjustment of labels and size of control</param>
		if (!val || val.indexOf('-') >= 0)
			val = '';
		this._perc = val.indexOf('%') > 0;
		if (!this._perc && val.indexOf('px') < 1)
			val = '';
		this._tabSize = $util.toInt(val, 0);
		if (noFix)
			return;
		this._set_value($IG.TabItemProps.TabSize, val);
		if (this._owner)
			this._owner._setTabSize(this);
	},
	get_hidden: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.hidden">Gets sets hidden state of tab as boolean.</summary>
		/// <value type="Boolean">True: tab item is hidden</value>
		return this._get_value($IG.TabItemProps.Hidden) == 1;
	},
	set_hidden: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.hidden">Sets hidden state of tab item.</summary>
		/// <param name="val" type="Boolean">True: tab is hidden</param>
		this._set_value($IG.TabItemProps.Hidden, val ? 1 : 0);
		this._hidden = val;
		if (this._owner)
			this._owner._showTab(this, !val);
	},
	get_enabled: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.enabled">Gets sets enabled state of tab as boolean.</summary>
		/// <value type="Boolean">True: tab item is enabled</value>
		return this._get_value($IG.TabItemProps.Enabled) == 1;
	},
	set_enabled: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.enabled">Sets enable state of tab item.</summary>
		/// <param name="val" type="Boolean">True: tab is enabled</param>
		this._set_value($IG.TabItemProps.Enabled, (this._enabled = val) ? 1 : 0);
		var div = this.getBody();
		if (div)
			div.disabled = val ? '' : 'disabled';
		if (this._owner)
			this._owner._fixTabCss(this._i);
	},
	get_visibleIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.visibleIndex">Gets sets visible index of tab as integer.</summary>
		/// <value type="Number" integer="true">Visible index.</value>
		var i = this._get_value($IG.TabItemProps.VisibleIndex);
		return (i < 0) ? this._vi : i;
	},
	set_visibleIndex: function(val, noFix)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.visibleIndex">Sets visible index.</summary>
		/// <param name="val" type="Number" integer="true">Visible index</param>
		/// <param name="noFix" type="Boolean" optional="true" mayBeNull="true">True: skip adjustment and repainting. Internal use only.</param>
		this._set_value($IG.TabItemProps.VisibleIndex, val);
		var owner = this._owner;
		if (owner && !noFix)
			owner.moveTab(this, val);
	},
	getImageElem: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabItem.getImageElem">Gets reference to html element which renders image.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to IMG or null.</returns>
		return this._img;
	},
	getTextElem: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabItem.getTextElem">Gets reference to html element which contains text.</summary>
		/// <returns domElement="true" mayBeNull="true">Reference to SPAN or null.</returns>
		return this._span;
	},
	get_index: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItem.index">Gets index of pane within collection of panes in WebTab as integer.</summary>
		/// <value type="Number" integer="true">Index in collection of tabs.</value>
		return this._i;
	},
	_getAutoSize: function()
	{
		return this._get_value($IG.TabItemProps.AutoSize);
	},
	
	
	
	
	
	_doHeight: function(val, fixTxt)
	{
		var elem = this._elem, cent = this._cent;
		
		if (val < 0)
		{
			if (val == -1)
				this._sizeStyle = elem.style.height;
			else
				elem.style.height = this._sizeStyle;
			if (cent)
				if (val == -1)
					this._sizeStyleC = cent.style.height;
				else
					cent.style.height = this._sizeStyleC;
			return;
		}
		
		if (!cent)
		{
			elem.style.height = val + 'px';
			return;
		}
		
		elem.style.height = cent.style.height = 'auto';
		
		var dif = this._dif;
		if (dif == null)
			
			this._dif = dif = elem.offsetHeight - cent.offsetHeight + $util.getOffset($util.getRuntimeStyle(cent));
		
		if (val < 1)
			return;
		
		if ((dif = val - dif) < 1)
		{
			
			if (this._dif0 == null)
				this._dif0 = $util.getOffset($util.getRuntimeStyle(elem));
			elem.style.height = Math.max(val - this._dif0, 1) + 'px';
			dif = 1;
		}
		cent.style.height = dif + 'px';
		
		if (fixTxt)
		{
			this._fixOver = null;
			
			this._tempOver = 1;
			fixTxt._textOver(this);
		}
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabItem.dispose">Disposes object and event handlers.</summary>
		$IG.TabItem.callBaseMethod(this, 'dispose');
		for (var p in this) if (this.hasOwnProperty(p))
			delete this[p];
	}
}

$IG.TabItem.registerClass('Infragistics.Web.UI.TabItem', $IG.LayoutPane);


$IG.TabSelectedIndexChangingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabSelectedIndexChangingEventArgs">Class used as EventArgs while raising events before selected tab change in WebTab.</summary>
	$IG.TabSelectedIndexChangingEventArgs.initializeBase(this);
}
$IG.TabSelectedIndexChangingEventArgs.prototype =
{
	
	get_tabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabSelectedIndexChangingEventArgs.tabIndex">Gets sets index of new selected tab as integer.</summary>
		/// <value type="Number" integer="true">Index of tab item.</value>
		return this._props[2];
	},
	get_oldTabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabSelectedIndexChangingEventArgs.oldTabIndex">Gets index of old selected tab as integer.</summary>
		/// <value type="Number" integer="true">Old index of tab item.</value>
		return this._props[3];
	},
	set_tabIndex:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabSelectedIndexChangingEventArgs.tabIndex">Sets index of selected tab item.</summary>
		/// <param name="val" type="Number" integer="true">Index of selected tab</param>
		this._props[2] = val;
	}
}
$IG.TabSelectedIndexChangingEventArgs.registerClass('Infragistics.Web.UI.TabSelectedIndexChangingEventArgs', $IG.CancelEventArgs);


$IG.TabMouseEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabMouseEventArgs">Class used as EventArgs while raising mouse events in WebTab.</summary>
	$IG.TabMouseEventArgs.initializeBase(this);
}
$IG.TabMouseEventArgs.prototype =
{
	
	get_tabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabMouseEventArgs.tabIndex">Gets index of tab item involved in mouse event as integer. If returned value is -1, then it is event over scroll buttons or add-new-tab button.</summary>
		/// <value type="Number" integer="true">Index of tab item.</value>
		return this._props[2];
	},
	isCloseButton:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabMouseEventArgs.isCloseButton">Returns true if it is event over close button in tab item.</summary>
		/// <returns type="Boolean">True: event is over close button.</returns>
		return this._props[4];
	},
	isAddNewTabButton:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TabMouseEventArgs.isAddNewTabButton">Return true if it is event over add-new-tab button.</summary>
		/// <returns type="Boolean">True: event is over add-new-tab button.</returns>
		return this._props[5];
	},
	get_scrollButtonIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabMouseEventArgs.scrollButtonIndex">Gets index of scroll button involved in mouse event. Possible values: 0 - right or top scroll button, 1 - left or bottom scroll button, -1 - it is event over tab item or add-new-tab button.</summary>
		/// <value type="Number" integer="true">Index of scroll button.</value>
		return this._props[3];
	}
}
$IG.TabMouseEventArgs.registerClass('Infragistics.Web.UI.TabMouseEventArgs', $IG.CancelEventArgs);


$IG.TabItemCancelEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabItemCancelEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabItemCancelEventArgs.initializeBase(this);
}
$IG.TabItemCancelEventArgs.prototype =
{
	
	get_tabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItemCancelEventArgs.tabIndex">Gets index of tab item involved in event as integer.</summary>
		/// <value type="Number" integer="true">Index of tab item.</value>
		return this._props[2];
	}
}
$IG.TabItemCancelEventArgs.registerClass('Infragistics.Web.UI.TabItemCancelEventArgs', $IG.CancelEventArgs);


$IG.TabItemEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabItemEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabItemEventArgs.initializeBase(this);
}
$IG.TabItemEventArgs.prototype =
{
	
	get_tabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItemEventArgs.tabIndex">Gets index of tab item involved in event as integer.</summary>
		/// <value type="Number" integer="true">Index of tab item.</value>
		return this._props[2];
	}
}
$IG.TabItemEventArgs.registerClass('Infragistics.Web.UI.TabItemEventArgs', $IG.EventArgs);


$IG.TabItemPostBackEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabItemPostBackEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabItemPostBackEventArgs.initializeBase(this);
}
$IG.TabItemPostBackEventArgs.prototype =
{
	
	get_tabIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItemPostBackEventArgs.tabIndex">Gets index of tab item involved in event as integer.</summary>
		/// <value type="Number" integer="true">Index of tab item.</value>
		return this._props[2];
	}
}
$IG.TabItemPostBackEventArgs.registerClass('Infragistics.Web.UI.TabItemPostBackEventArgs', $IG.PostBackEventArgs);


$IG.TabScrollingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabScrollingEventArgs">Class used as EventArgs while raising events before scroll action in WebTab.</summary>
	$IG.TabScrollingEventArgs.initializeBase(this);
}
$IG.TabScrollingEventArgs.prototype =
{
	
	get_scroll:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabScrollingEventArgs.scroll">Gets new scroll position in pixels as integer.</summary>
		/// <value type="Number" integer="true">New scroll.</value>
		return this._props[2];
	},
	
	get_oldScroll:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabScrollingEventArgs.oldScroll">Gets old scroll position in pixels as integer.</summary>
		/// <value type="Number" integer="true">Old scroll.</value>
		return this._props[3];
	}
}
$IG.TabScrollingEventArgs.registerClass('Infragistics.Web.UI.TabScrollingEventArgs', $IG.CancelEventArgs);


$IG.TabScrolledEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabScrolledEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabScrolledEventArgs.initializeBase(this);
}
$IG.TabScrolledEventArgs.prototype =
{
	
	get_scroll:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabScrolledEventArgs.scroll">Gets new scroll position in pixels as integer.</summary>
		/// <value type="Number" integer="true">New scroll.</value>
		return this._props[2];
	},
	
	get_oldScroll:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabScrolledEventArgs.oldScroll">Gets old scroll position in pixels as integer.</summary>
		/// <value type="Number" integer="true">Old scroll.</value>
		return this._props[3];
	}
}
$IG.TabScrolledEventArgs.registerClass('Infragistics.Web.UI.TabScrolledEventArgs', $IG.EventArgs);


$IG.TabMovingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabMovingEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabMovingEventArgs.initializeBase(this);
}
$IG.TabMovingEventArgs.prototype =
{
	
	get_tabVisibleIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabMovingEventArgs.tabVisibleIndex">Gets visible index of moving tab item as integer.</summary>
		/// <value type="Number" integer="true">Visible index of tab item.</value>
		return this._props[3];
	}
}
$IG.TabMovingEventArgs.registerClass('Infragistics.Web.UI.TabMovingEventArgs', $IG.TabItemCancelEventArgs);


$IG.TabMovedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabMovedEventArgs">Class used as EventArgs while raising events before tab-item close, add or submit action in WebTab.</summary>
	$IG.TabMovedEventArgs.initializeBase(this);
}
$IG.TabMovedEventArgs.prototype =
{
	
	get_tabVisibleIndex:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabMovedEventArgs.tabVisibleIndex">Gets index of tab item involved in event as integer.</summary>
		/// <value type="Number" integer="true">Visible index of tab item.</value>
		return this._props[3];
	}
}
$IG.TabMovedEventArgs.registerClass('Infragistics.Web.UI.TabMovedEventArgs', $IG.TabItemEventArgs);


$IG.TabItemEndEditingEventArgs = function(e, i, txt, cancel)
{
	/// <summary locid="T:J#Infragistics.Web.UI.TabItemEndEditingEventArgs">Class used as EventArgs while raising events before end TabItem text-editing in WebTab.</summary>
	$IG.TabItemEndEditingEventArgs.initializeBase(this);
	this._props = [e, 0, i, txt];
	this._cancel = cancel;
}
$IG.TabItemEndEditingEventArgs.prototype =
{
	
	get_text:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItemEndEditingEventArgs.text">Gets sets new text for TabItem as string.</summary>
		/// <value type="String">Text for label of tab item.</value>
		return this._props[3];
	},
	
	set_text:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TabItemEndEditingEventArgs.text">Sets text of tab item.</summary>
		/// <param name="val" type="String">Text of tab item.</param>
		this._props[3] = val;
	}
}
$IG.TabItemEndEditingEventArgs.registerClass('Infragistics.Web.UI.TabItemEndEditingEventArgs', $IG.TabItemCancelEventArgs);

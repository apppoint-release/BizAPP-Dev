/*
* igWebDataMenu.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


/// <reference name="MicrosoftAjax.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/0_igControlMain.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/2_igCollections.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/3_igUIBehaviors.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/4_igEnums.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/5_igObjects.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/7_igClientStateManager.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/8_igCallback.js" />
/// <reference path="../../../../Infragistics.Web.UI/Scripts/9_igPropertyManagers.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igAnimation.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igDragDrop.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igDropDown.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igLayoutPane.js" />
/// <reference path="../../../../Infragistics.Web.UI/SharedScripts/igResizeBehavior.js" />
/// <reference path="igDataMenuItem.js" />
/// <reference path="igWebDataMenu.js" />

Type.registerNamespace('Infragistics.Web.UI');
var $IG = Infragistics.Web.UI;




 

$IG.DataMenuProps = new function()
{
    this.Enabled = [$IG.NavControlProps.Count + 1, 0];
    this.EnableExpandOnClick = [$IG.NavControlProps.Count + 2, 0];
    this.IsContextMenu = [$IG.NavControlProps.Count + 3, false];
    this.ScrollingSpeed = [$IG.NavControlProps.Count + 4, 2]; // Normal Speed
    this.Count = $IG.NavControlProps.Count + 5;
};



$IG.DataMenuItemProps = new function()
{
    this.Expanded = [$IG.NavItemProps.Count + 0, 0];
    this.ClientLevel = [$IG.NavItemProps.Count + 1, 0];
    this.HoverCssClass = [$IG.NavItemProps.Count + 2, ''];
    this.IsSeparator = [$IG.NavItemProps.Count + 3, false];
    this.Clicked = [$IG.NavItemProps.Count + 4, 0];
    this.Count = $IG.NavItemProps.Count + 5;
};



$IG.DataMenuGroupSettingsProps = new function()
{
    this.OffsetX = [$IG.DataMenuItemProps.Count + 0, 0];
    this.OffsetY = [$IG.DataMenuItemProps.Count + 1, 0];
    this.Height = [$IG.DataMenuItemProps.Count + 2, 0];
    this.Width = [$IG.DataMenuItemProps.Count + 3, 0];
    this.Orientation = [$IG.DataMenuItemProps.Count + 4, 1];
    this.ExpandDirection = [$IG.DataMenuItemProps.Count + 5, 0];
    this.EnableAnimation = [$IG.DataMenuItemProps.Count + 6, 1];
    this.AnimationType = [$IG.DataMenuItemProps.Count + 7, 0];
    this.AnimationDuration = [$IG.DataMenuItemProps.Count + 8, 500];
    this.AnimationEquationType = [$IG.DataMenuItemProps.Count + 9, 3];
    this.ItemsFullAddress = [$IG.DataMenuItemProps.Count + 10, 0];
    this.Count = $IG.DataMenuItemProps.Count + 11;
};

$IG.DataMenuItemSettingsProps = new function()
{
    this.CssClass = [$IG.DataMenuGroupSettingsProps.Count + 0, ""];
    this.DisabledCssClass = [$IG.DataMenuGroupSettingsProps.Count + 1, ""];
    this.HoverCssClass = [$IG.DataMenuGroupSettingsProps.Count + 2, ""];
    this.ImageUrl = [$IG.DataMenuGroupSettingsProps.Count + 3, ""];
    this.Target = [$IG.DataMenuGroupSettingsProps.Count + 4, ""];
    this.NavigateUrl = [$IG.DataMenuGroupSettingsProps.Count + 5, ""];
    this.SelectedCssClass = [$IG.DataMenuGroupSettingsProps.Count + 6, ""];
    this.ImageToolTip = [$IG.DataMenuGroupSettingsProps.Count + 7, ""];
    this.Count = $IG.DataMenuGroupSettingsProps.Count + 8;
};


$IG.DataMenuAnimationtype = new function()
{
    /// <summary>Defines the types of animation that can be applied to the menu.</summary>
    /// <field name="OpacityAnimation" type="Number" integer="true" static="true">If used the menu turns its opacity from semi transparent to opaque.</field>
    /// <field name="ExpandAnimation" type="Number" integer="true" static="true">If used the menu slides itself according to the expand direction.</field>
    this.OpacityAnimation = 0;
    this.ExpandAnimation = 1;
}


$IG.DataMenuScrollingSpeed = new function()
{
    /// <summary>Defines the scrolling speed values that can be used for the menu.</summary>
    /// <field name="VerySlow" type="Number" integer="true" static="true"></field>
    /// <field name="Slow" type="Number" integer="true" static="true"></field>
    /// <field name="Normal" type="Number" integer="true" static="true"></field>
    /// <field name="Fast" type="Number" integer="true" static="true"></field>
    /// <field name="VeryFast" type="Number" integer="true" static="true"></field>
    this.VerySlow = 0;
    this.Slow = 1;
    this.Normal = 2;
    this.Fast = 3;
    this.VeryFast = 4;
}

$IG.DataMenuScrollingSpeedFormula = new function()
{
    /// <summary>Defines the scrolling speed values that can be used for the menu.</summary>   
    this.VerySlow = [1, 100];
    this.Slow = [3, 80];
    this.Normal = [6, 30];
    this.Fast = [9, 20];
    this.VeryFast = [12, 5];
}

$IG.DataMenuScrollingItemsFactor = new function()
{
    this.Slow = [0, 100, 1];
    this.Normal = [100, 1000, 1.2];
    this.Fast = [1000, 10000, 2];
}


$IG.MenuExpandDirection = new function()
{
    /// <summary>Defines the expand directions that menu follows when oppening.</summary>
    /// <field name="Auto" type="Number" integer="true" static="true">Defaults to the Left value when the menu is vertically aligned. If horizontally aligned defaults to the Down value.</field>
    /// <field name="Up" type="Number" integer="true" static="true">The menu will open upwards. Applies only when the orientation is horizontal.</field>
    /// <field name="Down" type="Number" integer="true" static="true">The menu will open downwards. Applies only when the orientation is horizontal.</field>
    /// <field name="Left" type="Number" integer="true" static="true">The menu will open leftwards. Applies only when the orientation is vertical.</field>
    /// <field name="Right" type="Number" integer="true" static="true">The menu will open rightwards. Applies only when the orientation is vertical.</field>
    this.Auto = 0;
    this.Up = 1;
    this.Down = 2;
    this.Left = 3;
    this.Right = 4;
}


$IG.DataMenuItemSettings = function(element, props, control)
{
    /// <summary locid="T:J#Infragistics.Web.UI.DataMenuItemSettings">
    /// A DataMenuItemSettings object that represents the common item settings
    /// </summary>
    var csm = new $IG.ObjectClientStateManager(props[0]);
    $IG.DataMenuItemSettings.initializeBase(this, ["itemSettings", element, props, control, csm]);
    this.initialize();   
}

$IG.DataMenuItemSettings.prototype = 
{
    initialize:function()
	{	    
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemSettings.initialize">
        /// Initializes the DataMenuItemSettings object
        ///</summary>
		$IG.DataMenuItemSettings.callBaseMethod(this, 'initialize');
	},
	
    get_CssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.CssClass">Get the CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.CssClass);
    },
    
    get_DisabledCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.DisabledCssClass">Get the disabled CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.DisabledCssClass);
    },
    
    get_HoverCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.HoverCssClass">Get the hover CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.HoverCssClass);
    },
    
    get_SelectedCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.SelectedCssClass">Get the selected CSS class of the object.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.SelectedCssClass);
    },
    
    
    get_ImageUrl: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.ImageUrl">Get the image URL.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.ImageUrl);
    },
    
    get_NavigateUrl: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.NavigateUrl">Get the navigate URL.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.NavigateUrl);
    },
    
    get_Target: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemSettings.Target">Get the navigate URL target.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuItemSettingsProps.Target);
    }
}

$IG.DataMenuItemSettings.registerClass('Infragistics.Web.UI.DataMenuItemSettings', $IG.ObjectBase);

$IG.DataMenuGroupSettings = function(element, props, control)
{
    /// <summary locid="T:J#Infragistics.Web.UI.DataMenuGroupSettings">
    /// A DataMenuGroupSettings object that represents the group settings
    /// </summary>
    var csm = new $IG.ObjectClientStateManager(props[0]);
    $IG.DataMenuGroupSettings.initializeBase(this, ["groupSettings", element, props, control, csm]);
    this.initialize();
}

$IG.DataMenuGroupSettings.prototype =
{
    initialize:function()
	{	    
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.initialize">
        ///Initializes the DataMenuGroupSettings object 
        ///</summary>
		$IG.DataMenuGroupSettings.callBaseMethod(this, 'initialize');
        this._menuItem = null;
        this._settingsCache = new Array(); // contains cached values by prop id.
	},

    get_offsetX: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.offsetX">Get the offset X appearance in pixels for the menu or sub-menu group.</summary>
        ///<value type="int"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.OffsetX);
    },
    get_offsetY: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.offsetY">Get the offset Y appearance in pixels for the menu or sub-menu group.</summary>
        ///<value type="int"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.OffsetY);
    },
    get_height: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.height">Get the height of the menu or sub-menu group in pixels.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Height);
    },
    get_width: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.width">Get the width of the menu or sub-menu group in pixels.</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Width);
    },
    get_orientation: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.orientation">Get the orientation of the menu or sub-menu group.</summary>
        ///<value type="Infragistics.Web.UI.Orientation"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.Orientation);
    },    
    get_expandDirection: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.expandDirection">Get the expand direction of the menu items.</summary>
        ///<value type="Infragistics.Web.UI.MenuExpandDirection"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.ExpandDirection);
    },
    
    get_enableAnimation: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.enableAnimation">Get whether animation is enabled.</summary>
        ///<value type="Boolean"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.EnableAnimation, true);
    },
    
    get_animationDuration: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationDuration">Get the duration in milliseconds of the animation effect.</summary>
        ///<value type="int"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationDuration);        
    },
    
    get_animationType: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationType">Get the animation type.</summary>
        ///<value type="Infragistics.Web.UI.DataMenuAnimationtype"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationType);
    },
    
    get_animationEquationType: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.animationEquationType">Get the animation equation type.</summary>
        ///<value type="Infragistics.Web.UI.AnimationEquationType"></value>
        return this._get_inheritedValue($IG.DataMenuGroupSettingsProps.AnimationEquationType);
    },

    get_itemsFullAddress: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.itemsFullAddress">Get the address of a menu item. Format: ItemLevel.ItemLevel.ItemLevel</summary>
        ///<value type="String"></value>
        return this._get_value($IG.DataMenuGroupSettingsProps.ItemsFullAddress);
    },

    isEmpty: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.isEmpty">Get whether the object contains default values for all of its properties.</summary>
        ///<value type="Boolean"></value>
        var defaultVal = this.get_offsetX() == $IG.DataMenuGroupSettingsProps.OffsetX[1];
        defaultVal = defaultVal && this.get_offsetY() == $IG.DataMenuGroupSettingsProps.OffsetY[1];
        defaultVal = defaultVal && this.get_height() == $IG.DataMenuGroupSettingsProps.Height[1];
        defaultVal = defaultVal && this.get_width() == $IG.DataMenuGroupSettingsProps.Width[1];
        defaultVal = defaultVal && this.get_orientation() == $IG.DataMenuGroupSettingsProps.Orientation[1];
        defaultVal = defaultVal && this.get_expandDirection() == $IG.DataMenuGroupSettingsProps.ExpandDirection[1];
        defaultVal = defaultVal && this.get_enableAnimation() == $IG.DataMenuGroupSettingsProps.EnableAnimation[1];
        defaultVal = defaultVal && this.get_animationDuration() == $IG.DataMenuGroupSettingsProps.AnimationDuration[1];
        defaultVal = defaultVal && this.get_animationType() == $IG.DataMenuGroupSettingsProps.AnimationType[1];
        defaultVal = defaultVal && this.get_animationEquationType() == $IG.DataMenuGroupSettingsProps.AnimationEquationType[1];
        return defaultVal;
    },

    _set_item: function(item)
    {
        this._menuItem = item;
    },

	get_item: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.item">Get reference to menu item.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItem"></value>
		return this._menuItem;
	},

    _get_inheritedValue: function(propId, isBool)
    {
		///<summary>If the current instance has a default value for the concreet property
		/// the function will go up the stack and return the value that is set by the user.
		/// If the user set somewhere the default value we will know that it is explicitly
		/// set and will return it.
		///</summary>
        if(!$util.isNullOrUndefined(this._settingsCache[propId[0]]))
            return this._settingsCache[propId[0]];

        var val = this._get_value(propId, isBool);

        if(val == propId[1] &&
           $util.isNullOrUndefined(this._csm._items[0][propId[0]]) && // value has not come from the server about this
           this.get_itemsFullAddress() != "-1")
        {
            // the value is default, search up the stack until the root level.
            var settings;
            var parentItem = this._menuItem.get_parentItem();
            if(parentItem)
            {
                settings = parentItem.get_itemsGroupSettings();
            }
            else
            {
                settings = this._menuItem._get_owner().get_menuGroupSettings();
            }

            if(settings)
            {
                var val1 = settings._get_inheritedValue(propId, isBool);
                this._settingsCache[propId[0]] = val1;
                return val1;
            }
        }
        else
        {
            this._settingsCache[propId[0]] = val;
        }
        return val;
    }
}
$IG.DataMenuGroupSettings.registerClass('Infragistics.Web.UI.DataMenuGroupSettings', $IG.ObjectBase);



$IG.WebDataMenu = function(element)
{
	$IG.WebDataMenu.initializeBase(this, [element]);

	$IG.WebDataMenu.find = $find;
	$IG.WebDataMenu.from = $IG._from;
}

$IG.WebDataMenu.prototype =
{
	_thisType: 'menu',
	initialize: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.initialize">Initializes the WebDataMenu object.</summary>
		this.__enabled = this._get_clientOnlyValue("enabled");
		this.__resizedId = 0;
		this.__expandedItems = [];
		this.__itemBoundsHash = [];
		$IG.WebDataMenu.callBaseMethod(this, 'initialize');
		this._visibleItems = [];
		this.__currentFocusedItem = null;
		this._selectedItem = null;
		this._activeItem = null;
		this._hoveredItem = null;
		this._itemSettings = new $IG.DataMenuItemSettings(this._element, this._objectsManager.get_objectProps(0), this);
		this._objectsManager.register_object(0, this._itemSettings);
		this._menuGroupSettings = this._groupSettingsCollection.getGroupSettingsObjectByAdr("-1");
		this.__subMenuClosingDelay = parseInt(this._get_clientOnlyValue("subMenuClosingDelay"));
		this.__subMenuOpeningDelay = parseInt(this._get_clientOnlyValue("subMenuOpeningDelay"));
		this.__enableScrolling = this._get_clientOnlyValue("enableScrolling");
		this.__activateOnHover = this._get_clientOnlyValue("aoh");
		this.__closeOnClick = this._get_clientOnlyValue("cmonc");
		var selItemAdr = this._get_clientOnlyValue("selectedItemAdr");
		if(!$util.isNullOrUndefined(selItemAdr))
		{
			this._selectedItem = this.getItems()._getObjectByAdr(selItemAdr);
		}
		var el = this._element;

		if (this.get_isContextMenu())
		{
			// L.T. 12/11/2010, 59844, When WDM is in UpdatePanel, when some other control causes the panel
			// to do an async postback, the update panel disposes its child controls by enumerating its child
			// DOM elements and calling el.control.dispose(). We have to leave an empty DIV in the update panel
			// so that we are notified about the dispose.
			var pseudoControlDiv = document.createElement("DIV");
			pseudoControlDiv.style.display = "none";
			pseudoControlDiv.style.visibility = "hidden";
			pseudoControlDiv.control = this;
			el.parentNode.appendChild(pseudoControlDiv);
			this._pseudoControlDiv = pseudoControlDiv;

			el.parentNode.removeChild(el);
			document.body.appendChild(el);
		}
		else
		{
			// A.Y. 18/01/2011, 59951, WDM is incorrectly rendered on WebKit browsers(Safari, Chrome)
			// The problem arises from the fact that DOMContentLoaded event fires before
			// all images and css files are loaded and when measured the size of the menu is incorrect.
			// Moving the resize in window.onload solves the problem.
			// K.D. January 26, 2011 The below fix needs to be applied only in Webkit browsers, otherwise it breaks
			// functionality for all other browsers
			if($util.IsChrome || $util.IsSafari)
			{
				this.onResizeFn = Function.createDelegate(this, this.__resizeTopLevelItems);
				$addHandler(window, 'load', this.onResizeFn);
				//I.I. 90688: window.load is not called when part of the page is posted back by UpdatePanel
				var prm = Sys.WebForms.PageRequestManager.getInstance();
				if (prm) prm.add_endRequest(this.onResizeFn);
			}
			else
				this.__resizeTopLevelItems();
			
			if (this.get_enableScrolling())
			{
				var size = this._menuGroupSettings.get_orientation() == $IG.Orientation.Horizontal ? el.style.width : el.style.height;
				if (size && size.indexOf("%") > 0)
				{
					size = this;
					setTimeout(function()
					{
						// add menu as listener for LayoutManager events
						$util.addLayoutTarget(size);
						// menu is inside of LayoutManager: trigger resizing on menu in initialization
						// this.layout() will notify about further resize events
						if (size._layoutManager)
							size.fixSize(null, true);
					}, 10);
				}
			}
		}
		
		












		var ie;
		if ($util.IsIE6)
			el.className += " ie6";
		else if ($util.IsIE)
		{
			ie = parseFloat(document.documentMode);
			if (!ie || ie < 7.5)
			{
				el.className += " ie7_DisplayInlineFix";
				ie = 7;
			}
		}
		el.style.display = ie == 7 ? "" : "inline-block";
		if(this.get_enabled())
		{
			this.__createFocusEl();
			$addHandler(el, 'keydown', Function.createDelegate(this, this._onKeydownHandler));
			$addHandler(el, 'mouseout', Function.createDelegate(this, this._onMouseOutHandler));
			if (this.get_enableScrolling())
			{
				$addHandler(el, 'mousemove', Function.createDelegate(this, this._onMouseOverHandler));
				$addHandler(el, 'touchstart', Function.createDelegate(this, this._onTouchStart));
				$addHandler(el, 'touchmove', Function.createDelegate(this, this._onTouchMove));
				$addHandler(el, 'touchend', Function.createDelegate(this, this._onTouchEnd));
				//A.T. 5 October 2010 - fix for bug #50032 - The menu is not resized when the splitter is resized under IE7
				this._onResizeFn = Function.createDelegate(this, this._onWindowResizeHandler);
				this._resizeTimerID = setInterval(this._onResizeFn, 200);
				$addHandler(el, $util.IsFireFox ? "DOMMouseScroll" : "mousewheel", Function.createDelegate(this, this._onMouseWheel));
			}
		}
		this.__getPageDimensions(true);
	    //this._resizeTopLevelSeparators();

		if(!this.preventInitEvent)
			this._raiseClientEvent('Initialize', 'DataMenuItemCancel', null, null, null);
		this.__isInitialized = true;
	},
	
	layout: function ()
	{
		this.fixSize();
	},
	
	_stopTimer: function ()
	{
		if (this._timerOn == 1)
			ig_ui_timer(this, true);
		// prevent restarting timer more than once
		this._timerOn = 2;
	},
	
	
	_onTimer: function(init)
	{
		// test for visibility
		if (!this._element.offsetWidth && !this._element.offsetHeight)
		{
			// start timer only once on initial rendering
			if (init && !this._timerOn)
			{
				// start timer-interval to wait when control will be visible and ready for calculations
				ig_ui_timer(this);
				this._timerOn = 1;
			}
			return;
		}
		if (!init)
			this.__resizeTopLevelItems();
		this.__topLevelItemsResized = true;
		this._stopTimer();
	},
	
	
	fixSize: function (item, layout)
	{
		///<summary>Recalculate layout and repaint top level items for menu with enabled scrolling.</summary>
		///<param type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true">Optional reference to any top-level item</param>
		if (this._noFix || (item && item.get_level()) || !this.get_enableScrolling() || (!layout && !this.__topLevelItemsResized))
			return;
		// prevent dead loop from _zoomCheck
		this._noFix = true;
		var ul = this._get_subgroup();
		ul.style.height = ul.style.width = "";
		this.__resizeItems(this.getItems().getItem(0), this._menuGroupSettings, ul);
		delete this._noFix;
	},
	__resizeTopLevelItems: function()
	{
		if (this.__topLevelItemsResized) return;
		
		if (document.body.offsetWidth)
			this.__resizeItems(this.getItems().getItem(0), this._menuGroupSettings, this._get_subgroup());
		
		var me = this;
		setTimeout(function() { me._onTimer(true); }, 1);
	},

	_onIgSubmit: function()
	{
		if (this._hoveredItem)
		{
			
			this._hoveredItem._getFlags().setHovered(false);
		}

        //A.T. Fix for #48430
        for(var i=0; i < this.__expandedItems.length; i++)
        {
            if (this.__expandedItems[i])
            {
                this.__expandedItems[i].set_expanded(false);
            }
        }

		$IG.WebDataMenu.callBaseMethod(this, '_onIgSubmit');
	},

	__resizeListItems: function(item)
	{
		if (item)
			this.__resizeItems(item.get_childItem(0), item.get_itemsGroupSettings(), item._get_subgroup());
	},
	
	_child: function (elem, tag, index)
	{
		var i = -1, kids = elem ? elem.childNodes : null, len = kids ? kids.length : 0;
		while (++i < len)
			if (kids[i].nodeName == tag)
				if (index-- == 0)
					return kids[i];
	},
	
	_zoomCheck: function (size)
	{
		var ul = this._zoomUL;
		if (!ul || ul.childNodes.length < 2 || ul.offsetWidth < 10)
			return;
		var v, w = 0, kids = $adrutil.getImmediateElementsByTagName(ul, "LI"), j = kids.length, i = j - 1;
		if (j < 2)
			return;
		
		if (size)
		{
			
			while (j-- > 0)
				w += kids[j].offsetWidth;
			
			v = ul.style.width;
			v = v ? parseFloat(v) : 0;
			if (!v || isNaN(v) || v < w)
				ul.style.width = w + "px";
			
			this._zoomPlus = 0;
		}
		this._zoomIE9 += this._zoomIE9;
		
		if (kids[0].offsetTop + 5 < kids[i].offsetTop)
		{
			if (this._zoomIE9)
			{
				// flag to stop interval
				this._zoomIE9 = 20;
				this.fixSize();
			}
			else
			{
				
				while (j-- > 0)
					w += kids[j].offsetWidth;
				w += (this._zoomPlus = (this._zoomPlus || 0) + 2);
				ul.style.width = w + "px";
			}
		}
		// stop interval: do not process zoom under IE9
		if (this._zoomIE9 > 16)
		{
			clearInterval(this._zoomFn);
			delete this._zoomFn;
			this._zoomIE9 = 0;
		}
	},
	
	__resizeItems: function(childItem, grpSettings, group, repeat)
	{
	    
	    if (childItem.get_element().className.indexOf('igdm_MenuItemHorizontalRoot') !== -1)
	    {
	        var _parent = childItem.get_element().parentNode,
                _menuOrientation = grpSettings.get_orientation() == $IG.Orientation.Horizontal;
	        if (_menuOrientation)
	        {
	            var children = _parent.children;
	            for (var i = 0; i < children.length; i++) {
	                children[i].style['font-weight'] = 'inherit';
	            }
                // Exit after initialization of horizontal root items
	            return;
	        }
	    }

		if (!childItem || !grpSettings || !group)
			return;
		var width, ulBounds, childItemElem = childItem.get_element(), scroll = this.get_enableScrolling(), hor = grpSettings.get_orientation() == $IG.Orientation.Horizontal, me = this;
		if (scroll)
		{
			if (repeat)
				group.style.width = group.style.height = "";
			ulBounds = this.__getElementBoundsEx(group);
			this.__resizeScrollArea(ulBounds, group.parentNode, grpSettings);
			
			if (!repeat && group._ht && group._ht > 4) // if we have set the size once, then return.
				return;
			
			if (hor && !this._zoomUL)
			{
				me._zoomUL = group;
				// do not process zoom under IE9+, only verify initial layout (possible images in items)
				me._zoomIE9 = $util.IsIE9Plus ? 1 : 0;
				me._zoomFn = setInterval(function() { me._zoomCheck(); }, 250);
			}
			group.style.width = (ulBounds.width + 1) + "px";
			
			group.style.height = (group._ht = ulBounds.height) + "px";
		}
		var button = group.previousSibling;
		if (!hor && scroll && button && !button.style.width)
		{
			
			//var width = $util.toIntPX(null, 'width', 0, group);
			width = ulBounds.width;
			if (width > 0)
			{
				
				button.style.width = Math.max(width - $util.toIntPX(null, 'borderLeftWidth', 0, button) - $util.toIntPX(null, 'borderRightWidth', 0, button), 1) + 'px';
				button = group.nextSibling;
				if (button)
					button.style.width = Math.max(width - $util.toIntPX(null, 'borderLeftWidth', 0, button) - $util.toIntPX(null, 'borderRightWidth', 0, button), 1) + 'px';
			}
		}
		else if (hor && !childItemElem.style.height)
		{
			var maxHeight = 0;
			while (childItemElem)
			{
				if (!this._isSeparatorElement(childItemElem))
				{
					
					maxHeight = Math.max(maxHeight, this.__getElementBoundsEx(childItemElem).height);
				} else {
					//B.C. January 24th, 2012, Bug #99926 In IE last item is droped from the menu list because of insufficient menu width when we have separators.
					//group.style.width = ($util.toIntPX(null, 'width', 0, group) + 1) + "px";
					//I.I. Feb 17, 2012, Bug #101047 No horizontal orientation of the control if  there are separator items
					group.style.width = (this.__getElementBoundsEx(group).width + 2) + 'px';
				}
				childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
			}
			
			if (maxHeight < 5)
			{
				repeat = repeat || 0;
				
				if (repeat++ < 4 && scroll)
					setTimeout(function () { me.__resizeItems(childItem, grpSettings, group, repeat)}, repeat * 100);
				return;
			}
			childItemElem = childItem.get_element();			
			var maxHeightSeparator = maxHeight, style = $util.getRuntimeStyle(group);
			if (scroll)
			{
				group.parentNode.style.height = maxHeight + "px";
				
				if (button)
					button.style.height = Math.max(maxHeight - $util.toIntPX(null, 'borderTopWidth', 0, button) - $util.toIntPX(null, 'borderBottomWidth', 0, button), 1) + 'px';
				button = group.nextSibling;
				if (button)
					button.style.height = Math.max(maxHeight - $util.toIntPX(null, 'borderTopWidth', 0, button) - $util.toIntPX(null, 'borderBottomWidth', 0, button), 1) + 'px';
			}
			
			maxHeight -= $util.getOffset(style) + $util.getMargin(style);
			if(scroll)
				group.style.height = maxHeight + "px";
			
			group._ht = maxHeight;
			style = $util.getRuntimeStyle(childItemElem);
			maxHeight -= $util.getOffset(style) + $util.getMargin(style);
			
			while (childItemElem)
			{
				childItemElem.style.height = (this._isSeparatorElement(childItemElem) ? maxHeightSeparator : maxHeight) + 'px';
				childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
			}
		}
	},
	__resizeScrollArea: function(ulBounds, scrollContainer, grpSettings)
	{
		var orientation = grpSettings.get_orientation();
		
		if (this._get_scrollContainer() == scrollContainer)
			this._zoomCheck(1);

		if (this.get_enableScrolling() && (this.__needsResize(scrollContainer.parentNode.resizeId) ||
		                                  (scrollContainer.style.height == "" && orientation == $IG.Orientation.Vertical) ||
										  (scrollContainer.style.width == "" && orientation == $IG.Orientation.Horizontal)))
		{
            // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
            // in the commented lines below
			//var firstScrollButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[0];
			//var secondScrollButton = $adrutil.getImmediateElementsByTagName(scrollContainer, "A")[1];
			var pageDims = this.__getPageDimensions();

			if (orientation == $IG.Orientation.Vertical && grpSettings.get_height() == 0)
			{
                // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
                // in the commented lines below
				//var firstScrollButtonHeight = this.__getElementBoundsEx(firstScrollButton).height;
				//var secondScrollButtonHeight = this.__getElementBoundsEx(secondScrollButton).height;
                //A.T. Fix for bug #37249 (this code is not needed ) 
				//var height = firstScrollButtonHeight + ulBounds.height + secondScrollButtonHeight;
                var height = ulBounds.height;
				
				if (height > pageDims.MaxY)
				{
					height = Math.floor((pageDims.MaxY * 99) / 100);
				}

				if(grpSettings.get_itemsFullAddress() == "-1")
				{
					// when the root context menu is positioned its size should be calculated respective to the opening position.
					var top = $util.toIntPX(null, 'top', 0, this._element);
					if(height + top > pageDims.MaxY)
					{
						height = height - top;
					}
					// L.T. 8/11/2010 59328. If you change this code make sure to test 57382 and 48174 as well!
					var marginTop = $util.toIntPX(null, 'marginTop', 0, this._element);
					if(height + marginTop > pageDims.MaxY)
					{
						height = height - marginTop;
					}

					var marginTopVal = $util.getStyleValue(null, 'marginTop', this._element);
					if(marginTopVal == "auto")
					{
						var controlBounds = this.__getElementBounds(this._element);
						if(height + controlBounds.y > pageDims.MaxY)
						{
							height = height - controlBounds.y;
						}
					}
				}

                if(height > 0)
				{
                    scrollContainer.style.height = height + "px";

					if(scrollContainer.realParent)
					{
						scrollContainer.parentNode.style.height = height + "px";
					}
				}

				if($util.IsIE7 && scrollContainer.parentNode.id == this._id && height > 0)
				{
					scrollContainer.parentNode.style.height = height + "px";
				}
			}
            // Bug #67035 K.D. March 19, 2011 We need to set the scrollercontainer width according to the
            // parent container when the parent container's width is in percentages
			else if (orientation == $IG.Orientation.Horizontal && (grpSettings.get_width() == 0 || grpSettings.get_width()[grpSettings.get_width().length - 1] == '%'))
			{
                // K.D. April 4th, 2011 The Caching below is also not needed because it is used only 
                // in the commented lines below
				//var firstScrollButtonWidth = this.__getElementBoundsEx(firstScrollButton).width;
				//var secondScrollButtonWidth = this.__getElementBoundsEx(secondScrollButton).width;
                //A.T. Fix for bug #37249 (this code is not needed ) 
				//var width = firstScrollButtonWidth + ulBounds.width + secondScrollButtonWidth;
                var width = ulBounds.width;

				if (width > pageDims.MaxX)
				{
					width = Math.floor((pageDims.MaxX * 99) / 100);
				}

				if(grpSettings.get_itemsFullAddress() == "-1")
				{
					// when the root context menu is positioned its size should be calculated respective to the opening position.
					var left = $util.toIntPX(null, 'left', 0, this._element);
					if(width + left > pageDims.MaxX)
					{
						width = width - left;
					}
					// L.T. 8/11/2010 59328. If you change this code make sure to test 57382 and 48174 as well!
					var marginLeft = $util.toIntPX(null, 'marginLeft', 0, this._element);
					if(width + marginLeft > pageDims.MaxX)
					{
						width = width - marginLeft;
					}

					var marginLeftVal = $util.getStyleValue(null, 'marginLeft', this._element);
					if(marginLeftVal == "auto")
					{
						var controlBounds = this.__getElementBounds(this._element);
						if(width + controlBounds.x > pageDims.MaxX)
						{
							width = width - controlBounds.x;
						}
					}
				}

				if(width > 0)
				{
					scrollContainer.style.width = width + "px";
					if(scrollContainer.realParent)
					{
						scrollContainer.parentNode.style.width = width + "px";
					}
				}

				if($util.IsIE7 && scrollContainer.parentNode.id == this._id && width > 0)
				{
					scrollContainer.parentNode.style.width = width + "px";
				}

                // Bug #67035 K.D. March 19, 2011 We need to set the scrollercontainer width according to the
                // parent container when the parent container's width is in percentages
                var scrollParent = scrollContainer.parentNode;
                if(scrollParent.id == this._id && width > 0 && scrollParent.style.width[scrollParent.style.width.length - 1] == '%')
                {
                    var containerWidth = this.__getElementBounds(scrollParent).width + 'px';
                    scrollContainer.style.width = containerWidth;
                }
			}

			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			var scrollContainerBounds = this.__getElementBoundsEx(scrollContainer);
			var it = grpSettings.get_item();

			if (orientation == $IG.Orientation.Vertical)
			{
				if (it)
				{
					if (ulBounds.height < scrollContainerBounds.height)
					{
						it._displayScrollButton(0, false);
					}
					it._displayScrollButton(1, ulBounds.height > scrollContainerBounds.height);
				}
				else
				{
					var mainMenuScrollContainer = this._get_scrollContainer();
					if (ulBounds.height < scrollContainerBounds.height)
					{
						this._displayScrollButton(mainMenuScrollContainer, 0, false);
					}
					this._displayScrollButton(mainMenuScrollContainer, 1, ulBounds.height > scrollContainerBounds.height);
				}

				// if the user resized, scrolled up and resized so that no buttons are need we should reset the top of the scroll container.
				var ul = this._child(scrollContainer, "UL", 0);
				if (ulBounds.height < scrollContainerBounds.height && $util.toIntPX(null, 'top', 0, ul) != 0)
				{
					ul.style.top = "0px";
				}
			}
			else
			{
				// show the second scroll button, when contents are bigger than scroll area.
				if (it)
				{
					if (ulBounds.width < scrollContainerBounds.width)
					{
						it._displayScrollButton(0, false);
					}
					it._displayScrollButton(1, ulBounds.width > scrollContainerBounds.width);
				}
				else
				{
					var mainMenuScrollContainer = this._get_scrollContainer();
					if (ulBounds.width < scrollContainerBounds.width)
					{
						this._displayScrollButton(mainMenuScrollContainer, 0, false);
					}
					this._displayScrollButton(mainMenuScrollContainer, 1, ulBounds.width > scrollContainerBounds.width);
				}

				// if the user resized, scrolled left and resized so that no buttons are need we should reset the left of the scroll container.
				var ul = this._child(scrollContainer, "UL", 0);
				if (ulBounds.width < scrollContainerBounds.width && $util.toIntPX(null, 'left', 0, ul) != 0)
				{
					ul.style.left = "0px";
				}
			}
		}

		if (scrollContainer.style.width == "" && ulBounds.width > 0)
			scrollContainer.style.width = ulBounds.width + "px";

		if (scrollContainer.style.height == "" && ulBounds.height > 0)
			scrollContainer.style.height = ulBounds.height + "px";
		
		this._fixFocusPos();
	},

	_isSeparatorElement: function(domElement)
	{
		return domElement ? $util._isXAttrContains(domElement, "mkr:sep") : false;
	},

	//    _resizeTopLevelSeparators: function()
	//    {
	//        var item0 = this.getItems().getItem(0);
	//        var item0Elem = item0.get_element();
	//        if(this._menuGroupSettings.get_orientation() == $IG.Orientation.Vertical)
	//            this._resizeSeparators(item0, this._menuGroupSettings, item0Elem.offsetWidth, 1);
	//        else
	//            this._resizeSeparators(item0, this._menuGroupSettings, 1, item0Elem.offsetHeight);
	//    },

	//    _resizeSubLevelSeparators: function(item, width, height)
	//    {
	//        this._resizeSeparators(item.get_childItem(0), item.get_itemsGroupSettings(), width, height);
	//    },

	//    _resizeSeparators: function(childItem, grpSettings, width, height)
	//    {
	//        var childItemElem = childItem.get_element();
	//	    var orientation = grpSettings.get_orientation();

	//        while(childItemElem)
	//        {
	//            if(this._isSeparatorElement(childItemElem))
	//            {
	//                if(orientation == $IG.Orientation.Vertical)
	//                {
	//                    childItemElem.style.width = width + 'px';
	//                    var nextItemElem = $util.skipTextNodes(childItemElem.nextSibling);
	//                    /* dirty hack to make separators work */
	//                    if(nextItemElem &&
	//                       !this._isSeparatorElement(nextItemElem) &&
	//                       nextItemElem.style.marginTop == "")
	//                    {
	//                        nextItemElem.style.marginTop = "1px";
	//                    }
	//                }
	//                else
	//                {
	//                    childItemElem.style.height = height + 'px';
	//                }
	//            }
	//            childItemElem = $util.skipTextNodes(childItemElem.nextSibling);
	//        }
	//    },
	// adjust position of focus-element to the center of menu
	_fixFocusPos: function (me)
	{
		if (!me)
		{
			me = this;
			return setTimeout(function() { me._fixFocusPos(me); }, 100);
		}
		var fe = me._focusElement, e = me._element;
		if (!fe || !e) return;
		var w = e.offsetWidth, h = e.offsetHeight;
		if (w && h)
		{
			fe.style.marginTop = Math.round(h / 2) + "px";
			fe.style.marginLeft = Math.round(w / 2) + "px";
		}
	},
	__createFocusEl: function()
	{
		var inputEl = document.createElement("INPUT"), style = inputEl.style;
		style.position = "absolute";
		
		style.background = "transparent";
		style.padding = style.border = "0px";
		style.outline = "none";
		style.width = style.height = "1px";
		style.zIndex = -1;
		inputEl.setAttribute("type", "button");
		// marker for focus element to skip it while returning focus to last focused element
		inputEl._menu_fe = 1;
		// inputEl.setAttribute("tabindex", "-1");
		// A.T. 2009-10-08 Fix for bug #22847
		inputEl.setAttribute("tabIndex", this._get_clientOnlyValue("tabIndex"));
		// this._element.setAttribute("tabIndex", "-1"); L.T. !! never! Breaks kb navigation on FF, Chrome, Safari.
		inputEl.value = "";
		
		this._element.insertBefore(inputEl, this._element.firstChild);
		this._focusElement = inputEl;
		
		this._fixFocusPos();
		$addHandler(inputEl, 'focus', Function.createDelegate(this, this._onFocusHandler));
		$addHandler(inputEl, 'blur', Function.createDelegate(this, this._onBlurHandler));
	},

	_onFocusHandler: function(browserEvent)
	{
		if (this.__controlActive)
		    return;
		this._timeOutClose();
		this.__controlActive = true;
	    // K.D. September 12th, 2013 Bug #150775 The keyboard navigation does not account for disabled items at all
		if (!this._activeItem || !this._activeItem.get_enabled())
		{
			this.__setActiveItem(this._getFirstEnabled(), false);
		}
		else
		{
		    // K.D. September 12th, 2013 Bug #150775 The keyboard navigation does not account for disabled items at all
		    var parent = this._activeItem.get_parentItem();
		    if (parent && !parent.get_enabled()) {
		        this.__setActiveItem(this._getFirstEnabled(), false);
		    } else {
		        this._activeItem.set_active(true);
		    }
		}
	},
	_timeOutSub: function (on)
	{
		if (this._timeoutID)
		{
			clearTimeout(this._timeoutID);
			delete this._timeoutID;
		}
		if (on)
			this._timeoutID = setTimeout(Function.createDelegate(this, this.__hideAll), this.__subMenuClosingDelay);
	},
	_timeOutClose: function (on)
	{
		if (this._contextClosingTimeOut)
		{
			clearTimeout(this._contextClosingTimeOut);
			delete this._contextClosingTimeOut;
		}
		if (on)
			// M.H. 25 Jul 2011 - fix bug 76404 - for setTimeout should be used 100ms for delay - otherwise the bug is reproduced in IE9
			this._contextClosingTimeOut = setTimeout(Function.createDelegate(this, on == 1 ? this.__hideAll : this.hide), on == 1 ? 100 : this.__subMenuClosingDelay);
	},
	_timeOutOpen: function (on)
	{
		if (this._openingDelayTimeoutID)
		{
			clearTimeout(this._openingDelayTimeoutID);
			delete this._openingDelayTimeoutID;
		}
		if (on)
			this._openingDelayTimeoutID = setTimeout(Function.createDelegate(this, this._expandOnHoverHelper), this.__subMenuOpeningDelay);
	},
	_timeOutScroll: function ()
	{
		if (this.__scrollingTimeoutID)
		{
			clearTimeout(this.__scrollingTimeoutID);
			delete this.__scrollingTimeoutID;
			return true;
		}
	},
	_onBlurHandler: function(event)
	{
	    
		if (this._focInTempl())
		    return;
		
		if (this.__cancelBlur && !(this._outsideClickTime && this._outsideClickTime + 30 > new Date().getTime()))
		{
			var me = this;
			
			// 2nd param - validate if focus belongs to INPUT in template
			setTimeout(function() { me._focusEventElement(null, 1); }, 50);
		}
		else if (this.__controlActive)
		{
			this.__controlActive = false;
			if (this._activeItem != null)
			{
				this._activeItem.set_active(false);
			}
			if (this.get_isContextMenu())
				this._timeOutClose(1);
			else
			    this._timeOutSub(true);
		}

	    // Z.K. February 2, 2016 Fixing Bug #212349 - MenuItem previously selected is highlighted after postback 
		if (this.get_isContextMenu()) {
	        this.__unselectAll();
	    }

		this.__cancelBlur = false;
	},

	dispose: function()
	{
	    ///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.dispose">Disposes the object.</summary>
	    this._stopTimer();
	    
	    this._focInTempl('end');
	    if (this._zoomFn)
	        clearInterval(this._zoomFn);
	    delete this._zoomFn;
	    this._disposeMenu();
	    if(this._pseudoControlDiv)
	    {
	        this._pseudoControlDiv.parentNode.removeChild(this._pseudoControlDiv);
	        this._pseudoControlDiv = null;
	    }
	    
	    if(this.get_isContextMenu() && this._element.parentNode == document.body)
	        document.body.removeChild(this._element);
	    if (this.onResizeFn) {
	        var prm = Sys.WebForms.PageRequestManager.getInstance();
	        if (prm) prm.remove_endRequest(this.onResizeFn);
	    }
		$IG.WebDataMenu.callBaseMethod(this, 'dispose');
	},

	_disposeMenu: function()
	{
		// clear timeouts, they could be fired after the dispose and be a potential source of exceptions.
		this._timeOutSub();
		this._timeOutClose();
		this._timeOutOpen();
		this._timeOutScroll();
		$clearHandlers(this.get_element());
		
		if (this._focusElement)
			$clearHandlers(this._focusElement);
		if (this.get_enableScrolling())
			//A.T. 5 October 2010 - fix for bug #50032 - The menu is not resized when the splitter is resized under IE7
			clearInterval(this._resizeTimerID);
	},

	_soft_dispose: function()
	{
		
		
	    this._disposeMenu();
		this._elements = []; // clear markers
		// K.D. May 19, 2011 Bug #74373 If AjaxControlToolkit is referenced it has disposed of _events already
		// so check for the existence of _events should be made first before reseting the list
		if (this._events)
			this._events._list = []; // it's very important to clear the events !
		this.__clearOtherEvents();
		if (this._objectsManager)
			this._objectsManager.dispose();
		if (this._collectionsManager)
			this._collectionsManager.dispose();
	},

	// check - validate if focus belongs to INPUT in template
	// item - called from mouse hover to set focus to menu if activation on hover is on
	_focusEventElement: function(item, check)
	{
		var e, vert, v, shift = 0, fe = this._focusElement;
		
		if (fe && (!check || !this._focInTempl()))
		{
			try
			{
				
				if (item)
				{
					e = this._element;
					v = e.offsetWidth;
					vert = e.offsetHeight;
					if (v < vert)
						v = vert;
					else
						vert = null;
					item = v ? item._element : null;
					while (item && item != e && item.nodeName != "DIV")
					{
						shift += vert ? item.offsetTop : item.offsetLeft;
						item = item.parentNode;
					}
					if (item)
						fe.style["margin" + (vert ? "Top" : "Left")] = Math.max(50, Math.min(shift, v - 50)) + "px";
					
					e = document.activeElement;
					// not another menu!
					if (e && !e._menu_fe)
						$util.__lastFocusedElement = e;
				}
				
				this._focus(fe);
			} catch (ex) { }
		}
	},

	showAt: function(x, y, browserEvent)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.showAt">
		/// Shows the menu at specified position
		///</summary>
		///<param name="x" type="int">The value for X-Axis where to show the menu</param>
		///<param name="y" type="int">The value for Y-Axis where to show the menu</param>
		///<param name="browserEvent" type="BrowserEvent">The borwser event object, to calculate position, if X,Y or both are empty</param>
		this._timeOutClose();
		this.__hideAll();
		
		this._oldHandlers = {menu: document.oncontextmenu, up: document.body.onmouseup};
		document.oncontextmenu = document.body.onmouseup = function() { return false; };
		//
		browserEvent = browserEvent || window.event || window.Event;
		if (isNaN(x) || (x != 0 && !x))
			x = 2 + (browserEvent ? (browserEvent.clientX || 0) : 0);
		if (isNaN(y) || (y != 0 && !y))
			y = 2 + (browserEvent ? (browserEvent.clientY || 0) : 0);
		var pageDims = this.__getPageDimensions(true), elem = this._element, style = elem.style, r = this.__getElementBounds(elem);
		
		var v0 = pageDims.Height, v1 = r.height;
		if (v0 && v1)
		{
			if (y + v1 > v0)
			{
				if (y > v1)
					y -= v1 + 4;
				else
				{
					y = Math.max(v0 - v1, 2);
					x += 2;
				}
			}
			v0 = pageDims.Width;
			v1 = r.width;
			if (x + v1 > v0)
			{
				if (x > v1)
					x -= v1 + 4;
				else
					x = Math.max(v0 - v1, 0);
			}
		}
		
		y += pageDims.ScrollTop;
		x += pageDims.ScrollLeft;
		style.position = "absolute";
		style.zIndex = "12000";
		//
		if(this.get_enableScrolling())
		{
			if($util.toIntPX(null, 'top', 0, elem) != y || $util.toIntPX(null, 'left', 0, elem) != x)
				this.__resizedId++;
		}
		else if (this._menuGroupSettings.get_orientation() == $IG.Orientation.Horizontal)
			style.width = r.width + 'px';
		style.top = y + "px";
		style.left = x + "px";
		//
		this.__clearActiveItem();
		this.__topLevelItemsResized = false;
		this.__resizeTopLevelItems();
		style.display = "block";
		style.visibility = "visible";
		
		style.overflow = "visible";
		var me = this;
		setTimeout(function() { me._focusEventElement(); }, 1);
	},

	hide: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.hide">
		/// Hides the menu if IsContextMenu is enabled
		///</summary>
		if (this.get_isContextMenu())
		{
			
			var old = this._oldHandlers;
			delete this._oldHandlers;
			if (old)
			{
				document.oncontextmenu = old.menu;
				document.body.onmouseup = old.up;
			}
			this._element.style.display = "none";
			this._element.style.visibility = "hidden";
		}
	},
	_onDocMouse: function(e)
	{
		e = e.target;
		delete this._outsideClickTime;
		while (e)
		{
			if (e == this.element)
				return;
			e = e.parentNode;
		}
		
		this._outsideClickTime = new Date().getTime();
	},
	_addHandlers: function()
	{
		$IG.WebDataMenu.callBaseMethod(this, '_addHandlers');
		if(this.get_enabled())
		{
			// K.D. March 22nd, 2012 Bug #104974 WebDataMenu�s Server side ItemClick event fires when post back is caused by template asp button.
			// Moving a lot of the item interaction logic on click instead of on mousedown
			this._registerHandlers(["mousedown", "mouseup", "click", "mousewheel"]);
			
			if (!this._docMouseFn)
				$addHandler(document, 'mousedown', this._docMouseFn = Function.createDelegate(this, this._onDocMouse));
		}
	},

	getItems: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.getItems">Get the collection of menu items in the WebDataMenu.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItemCollection"></value>
		return this._itemCollection;
	},

	get_isContextMenu: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_isContextMenu">Get whether the menu is displayed as context menu.</summary>
		///<value type="Boolean"></value>
		if (this._get_value($IG.DataMenuProps.IsContextMenu) < 1)
			return false;
		return true;
	},

	get_enableExpandOnClick: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_enableExpandOnClick">Get whether the menu items expand when they are clicked with the mouse.</summary>
		///<value type="Boolean"></value>
		if (this._get_value($IG.DataMenuProps.EnableExpandOnClick) < 1)
			return false;
		return true;
	},

	get_selectedItem: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_selectedItem">Get the currently selected item.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
		return this._selectedItem;
	},

	get_activeItem: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_activeItem">Get the currently active item.</summary>
		///<value type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true"></value>
		return this._activeItem;
	},

	get_scrollingSpeed: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.scrollingSpeed">Get the menu scrolling speed.</summary>
		///<value type="Infragistics.Web.UI.ScrollingSpeed"></value>
		return this._get_value($IG.DataMenuProps.ScrollingSpeed);
	},

	set_scrollingSpeed: function(value)
	{
		///<summary>Specify scrolling speed of the items during scrolling.</summary>
		///<param type="Infragistics.Web.UI.DataMenuScrollingSpeed"></param>
		this._set_value($IG.DataMenuProps.ScrollingSpeed, value);
	},

	get_enableScrolling: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.enableScrolling">Get whether the scrolling feature is enabled.</summary>
		///<value type="Boolean"></value>
		return this.__enableScrolling;
	},

	get_enabled: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataMenu.enabled">Get whether the menu is enabled.</summary>
		///<value type="Boolean"></value>
		return this.__enabled;
	},

	__clearActiveItem: function()
	{
		if (this._activeItem != null)
		{
			this._activeItem.set_active(false);
			this._selectItem(this._activeItem, false);
			this._activeItem = null;
		}
	},

	__setActiveItem: function(item, force)
	{
		if (this._activeItem != null)
		{
			this._activeItem.set_active(false);
		}
		
		if (item == null) return;
		item.set_active(true, force);
		this._activeItem = item;
	},
	// check for custom "active" control
	_isUserElem: function (e)
	{
	    var name = e ? e.nodeName : null;
	    if (!name && e && e.target)
	        name = e.target.nodeName;
	    return name == "INPUT" || name == "TEXTAREA" || name == "SELECT" || name == "BUTTON";
	},
	_shouldCancelBrowserEvent: function (e)
	{
				
		var args = this._raiseClientEventStart(['CancelBrowserEventOverride', 'Cancel', e]);
		
		
		return args ? !args.get_cancel() : !this._isUserElem(e ? e.target : null);
	},
	// called by the Aikido behaviors 
	_selectItem: function(item, val)
	{
		if (!item.get_isSeparator())
			this.__selectItem(item, val);
	},

	__selectItem: function(item, val, force)
	{
		var selAddr = (this._selectedItem != null) ? this._selectedItem._address : "";
		var args, realForce = (force != null && typeof (force) != "undefined") ? force : false;
		if (val && (item._address != selAddr || realForce))
		{
			

			if (this.__isInitialized)
				args = this._raiseClientEvent('ItemSelecting', 'DataMenuItemCancel', null, null, item);
			if (!args || !args.get_cancel())
			{
				if (this.__isInitialized)
					this._raiseClientEventEx('ItemSelected', $IG.DataMenuItemCancelEventArgs, [item]);
				this.__unselectAll(this.getItems());
				item.set_selected(true);
				this._selectedItem = item;
			}
			


			else
			{
				item.set_selected(false);
			}
		}
		else if (!val)
		{
			item.set_selected(false);
		}
	},

	_raiseClientEventEx: function(clientEventName, evntArgs, eventArgsParams)
	{
		var args = null;
		var clientEvent = this._clientEvents[clientEventName];
		if (clientEvent != null)
		{
			if (evntArgs == null)
				args = new $IG.EventArgs();
			else
				args = new evntArgs(clientEventName, eventArgsParams); // L.T. 4/11/2010 59265 all eventArgs receive the eventName first!
			args = this._raiseSenderClientEvent(this, clientEvent, args);
		}
		return args;
	},

	__unselectAll: function(items)
	{
		
		//	    for (var i = 0, len = items.getChildrenCount(); i < len; i++)
		//	    {
		//            var item = items.getItem(i);
		//	        item.set_selected(false);
		//	        if(item.hasChildren())
		//	        {
		//	            this.__unselectAll(item.getItems());
		//	        }
		//	    }
		if (this._selectedItem && this._selectedItem.get_selected())
		{
			this._selectedItem.set_selected(false);
			this._selectedItem = null;
		}
	},

	__hideItem: function(item)
	{
		if (!item)
			return;
		var args = this._raiseClientEvent('ItemCollapsing', 'DataMenuItemCancel', null, null, item);
		if (args && args.get_cancel())
			return false;
		
		
	    // hide iframe for item
	    // D.A. Bug #176716 Removing showHideIframe used to support IE6.
		// It was causing huge performance impact.
		//this._showHideIframe(item);
		item.__clearAnimation(false);
		if (this.get_enableScrolling())
		{
			var div = $get(this._id + "_" + item._get_address());
			if (div && div.nodeName == "DIV")
			{
				div.style.display = 'none';
				div.style.visibility = 'hidden';
				if ($util.IsIE7)
				{
					div.firstChild.style.display = 'none';
					div.firstChild.style.visibility = 'hidden';
				}
			}
		}
		else
		{
			var subgroup = item._get_subgroup();
			if (subgroup)
			{
				subgroup.style.display = 'none';
				subgroup.style.visibility = 'hidden';
			}
		}
		
		item.set_expanded(false);
	    
		item.set_hover(false);
	    //D.U. 22th of January 2014 Remove items from _visibleItems
		for (var i = 0; i < this._visibleItems.length; ++i) {
		    if (item === this._visibleItems[i]) {
		        this._visibleItems.splice(i, 1);
		    }
		}
		item.set_active(false);
        // D.A 18th December 2013 Update __expandedItems when hiding item
		for (var i = 0; i < this.__expandedItems.length; i++) {
		    if (this.__expandedItems[i]._get_address() == item._get_address()) {
		        this.__expandedItems.splice(i, 1);
		    }
		}
		this._raiseClientEvent('ItemCollapsed', 'DataMenuItemCancel', null, null, item);
		return true;
	},

	__getPageDimensions: function(force)
	{
		


		if ($util.isNullOrUndefined(this.__pageSize) || force)
		{
			var pageHeight = 0;
			var pageScrollTop = 0;
			var pageWidth = 0;
			var pageScrollLeft = 0;
			var pageScrollWidth = document.body.scrollWidth;
			var pageScrollHeight = document.body.scrollHeight;
			if (document.compatMode == "BackCompat")
			{
				pageHeight = document.body.clientHeight;
				pageScrollTop = document.body.scrollTop + document.body.parentNode.scrollTop;
				pageWidth = document.body.clientWidth;
				pageScrollLeft = document.body.scrollLeft + document.body.parentNode.scrollLeft;
			} else
			{
				
				pageHeight = window.innerHeight;
				pageScrollTop = window.pageYOffset;
				pageWidth = window.innerWidth;
				pageScrollLeft = window.pageXOffset;
				if ($util.IsIE)
				{
					
					pageScrollTop = document.documentElement.scrollTop;
					pageScrollLeft = document.documentElement.scrollLeft;
					if($util.IsIE7)
					{
						
						document.body.style.overflow = 'hidden'; // will hide the scrollbars on IE7
						this.__scrollbarWidth = document.documentElement.clientWidth - document.body.offsetWidth;
						document.body.style.overflow = '';
						
						document.documentElement.scrollTop = pageScrollTop;
						document.documentElement.scrollLeft = pageScrollLeft;
					}					
					pageHeight = document.documentElement.clientHeight;
					pageWidth = document.documentElement.clientWidth;
					pageScrollHeight = document.documentElement.scrollHeight;
					pageScrollWidth = document.documentElement.scrollWidth;
				}
			}
			var scrollBarWidth = this.__get_scrollbarWidth();
			var dims = new Object();
			dims.Width = pageWidth;
			dims.Height = pageHeight;
			dims.ScrollLeft = pageScrollLeft;
			dims.ScrollTop = pageScrollTop;
			dims.ScrollWidth = pageScrollWidth;
			dims.ScrollHeight = pageScrollHeight;
			dims.X = pageScrollWidth - pageScrollLeft;
			dims.Y = pageScrollHeight - pageScrollTop;
			dims.MaxX = dims.ScrollLeft + dims.Width - scrollBarWidth;
			dims.MaxY = dims.ScrollTop + dims.Height - scrollBarWidth;

			this.__pageSize = dims;
		}
		return this.__pageSize;
	},

	__focusLink: function(item, fromParent)
	{
		this._timeOutSub();
		var isChild = false;
		if (!$util.isNullOrUndefined(fromParent))
		{
			if (fromParent) isChild = true;
		}
		if (item && !item.get_isSeparator())
		{
			if (this._activeItem != null && !isChild)
			{
				$util.removeCompoundClass(this._activeItem.get_element(),
                                          this._activeItem.get_stateCssClass("Active"));
			}

			this.__hideUpLevelItems(item);
			this._activeItem = item; // 44165: Needed so that parent items remain active.
			this.__setActiveItem(item);
		}
	},
	
	_onMousewheelHandler: function()
	{
		if (this._IEWheelClick)
			this._IEWheelClick = 2;
	},

	// K.D. March 22nd, 2012 Bug #104974 WebDataMenu�s Server side ItemClick event fires when post back is caused by template asp button.
	// Moving a lot of the item interaction logic on click instead of on mousedown
	_onClickHandler: function (elem, adr, event) {
	    if (!event || this._isUserElem(event))
		    return;
		
		var wheel = this._IEWheelClick == 2;
		delete this._IEWheelClick;
		var item = this.getItems()._getObjectByAdr(adr);

	    //D.U. December 12th, 2013 Bug 159191 Submenus are not closing when selecting items when ItemSelected is async
	    //Problem was that we never set _visibleItems for click event
	    //D.U. Decemer 18th, 2013 Bug 160082 ItemCollapsing event fires with incorrect parameters
        //We initialize this variable when we click on root but we should not
		if (item !== null && !item.hasChildren()) {
		    this._visibleItems.push(item.get_parentItem());
		} else if (item !== null && item.get_level() === 0) {
		    //This means that we are in root item
		    this._visibleItems.length = 0;
		    this._visibleItems.push(item);
		}

		if (item && !item.get_enabled())
		{
			if ($util.IsIE)
			{
				this.__cancelBlur = true;
			}
			$util.cancelEvent(event);
			return false;
		}
		if (!this.__activateOnHover && !this.__controlActive)
		{
			if (item) { this.__setActiveItem(item); }
			//B.C 12th, April 2012. We force the focus back to the menu on click.
			this._onFocusHandler(event);
			this._focusEventElement();
			if (item) { item.open(); }
		}
		else
		{
			
			// ensure focus on menu
			if (this._focInTempl())
				this._focusEventElement();
			if(item && !item.get_expanded() && item.hasChildren())
			{
				if (this.__showItem(item))
					this.__hideUpLevelItems(item);
			}
			else if (!this._touchNoHide)
			{
				this.__closeMenuOnClick(item);
			}
		}
		if (item && item._getFlags().getEnabled(this))
		{
			// L.T. 2/11/2010 58814 focus is not properly handled.
            // K.D. 20/12/2010 61566 We have to add the condition of closeOnClick being false, because otherwise the menu
            // closes when clicked on submenu item
			if (($util.IsIE && this.__activateOnHover) || ($util.IsIE && !this.__closeOnClick))
				this.__cancelBlur = true;
			item._toggleClicked();
			item.set_hover(false);
			
			this._posted = false;
			var args = this._raiseClientEventEx("ItemClick", $IG.DataMenuItemCancelEventArgs, [item]);
			this.__focusLink(item);
			if (args && args.get_cancel())
			{
				item._toggleClicked(); // return the old value, since the click is cancelled.
				return false;
			}
			if(this._posted)
			    item._clearTransactions();

			if (event.button == '0')
			{
				
				
				var newTab = wheel || event.ctrlKey;
				var modal = event.shiftKey;
				// Navigate if the events is not cancelled, and only on left button click.
				item._navigateOnClick(newTab, modal);
			} 
			
			else if (event.button == '1')
			{
				item._navigateOnClick(true);
			} else if (event.type === 'touchend') {
			    // K.D. June 19th, 2013 Bug #144771 NavigateUrl does not open the page in mobile devices.
			    item._navigateOnClick(false);
			}
		}
	},

	_onMouseupHandler: function()
	{
		this.__accelerateScrolling = false;
	},
	
	// prevent focus when window is not active (another browser or application)
	// e: optional reference to html element to set focus
	// returns true if window is active or focus was set
	_focus: function(e)
	{
		try
		{
			if ($util.isDocActive())
			{
				if (e)
					e.focus();
				return true;
			}
		} catch (ex) { }
	},
	
	// return true if (!e) and if focus is currently in INPUT of template
	_focInTempl: function (e)
	{
		var me = this, o = me._nbObj;
		if (!e)
		    return o && (o.on || o.skipMenuClosing);
		if (o && o.on)
		{
		    if (o.e == e)
		        return;
			o.blur();
		}
		if (e == 'end')
		    return;
		me._nbObj = o = {
		    e: e,
		    // D.A. 8th May 2014, Bug #169278 Clicking on a focusable element inside a submenu shouldn't close the menu.
            skipMenuClosing: true,
		    foc: function () {
		        o.on = true;
		        o.skipMenuClosing = false;
			    delete $util.__lastFocusedElement;
			    delete me.__cancelBlur;
		    },
            blur: function () {
		        if (!o.foc)
				    return;
			    $removeHandler(o.e, 'blur', o.blur);
			    $removeHandler(o.e, 'focus', o.foc);
			    o.on = o.foc = null;
		    }};
		$addHandler(e, 'blur',  o.blur);
		$addHandler(e, 'focus',  o.foc);
	},
	_onMousedownHandler: function(elem, adr, event)
	{
		
		delete $util.__lastFocusedElement;
		
		if (!this.get_isInitialized())
			return false;
		
	    // prepare to process focus over INPUT in template, which will disable focus-on-hover
		if (this._isUserElem(elem)) {
		    this._focInTempl(elem);
		} else {
		    this.__cancelBlur = true;
		}
		
		this._IEWheelClick = 1;
		if (this._isScrollButtonTarget(event))
		{
			this.__accelerateScrolling = true;
			if ($util.IsIE)
			{
				this.__cancelBlur = true;
			}
			
			if ($util.isDocActive())
				$util.cancelEvent(event);
			return false;
		}
		// K.D. June 20th, 2012 Bug #112511 Submenu items randomly not posting back even with the AutoPostBack flags set.
		if ($util.IsIE && this.__activateOnHover)
			this.__cancelBlur = true;
	},

	__closeMenuOnClick: function(itemClicked)
	{
		if (!itemClicked)
			return;
		if (itemClicked.get_level() > 0) // applys only to non root items.
		{
			if (this.__closeOnClick && !itemClicked.hasChildren())
			{
				if (this.get_isContextMenu())
				{
					this.hide();
				}
				else
				{
					this.__hideAll();
				}
			}
		}
		else
		{
			if (this.get_isContextMenu())
			{
				if (!itemClicked.hasChildren())
					// we clicked on a root item of a context menu that do not have children -> close the menu.
					this.hide();
			}
			else if (itemClicked.get_expanded())
			{
				// if we click for a second time on a root menu item of a non context menu, close the item.
				this.__hideAll();
			}
		}
	},
    // K.D. September 12th, 2013 Bug #150775 The keyboard navigation does not account for disabled items at all
	_getFirstEnabled: function () {
	    var item = this.getItems().getItem(0);
	    if (item) {
	        while (item && (item.get_isSeparator() || !item.get_enabled())) {
	            item = item.get_nextItem();
	        }
	    }
	    return item;
	},
	_onKeydownHandler: function(event)
	{
	    
		if (!this.get_isInitialized() || this._focInTempl())
			return;
		var item = this._activeItem || this._getFirstEnabled();

		if (!item)
			return false;

		this.__setActiveItem(item);

		
		args = this._raiseClientEvent("KeyDown", "DataMenuItemCancel", event, null, item);
		if (args && args.get_cancel())
		{
			return false;
		}

		switch (event.keyCode)
		{
			case Sys.UI.Key.space:
				{
					this.__selectItem(item, !item.get_selected(), true);
					return;
				}

			case Sys.UI.Key.left:
				{
					if (item.get_orientation() == $IG.Orientation.Horizontal)
					{
						this.__focusPrevious(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}
			case Sys.UI.Key.right:
				{
					
					var orientation = item.get_orientation();
					if (orientation == $IG.Orientation.Horizontal)
					{
						this.__focusNext(item);
					}
					
					else if (orientation == $IG.Orientation.Vertical && item.hasChildren())
					{
						this.__focusChild(item);
					}
					
					else if (orientation == $IG.Orientation.Vertical && !item.hasChildren())
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.enter:
			    {
			        // D.A. 18th December 2013 Bug# 159311 ItemSelected event doesn't fire when selecting an item by keyboard. Removing ItemClick event trigger when using the keyboard.
					
					this._posted = false;

		            

		            item._navigateOnClick();

					if(this._posted)
						item._clearTransactions();
                    // D.A. 7th February 2014 Bug# 159311 Selecting item with the mouse tiggers two times the event.
                    this._itemCollection._getUIBehaviorsObj().select(item, event);
					this.__focusLink(item);
					
					
					if (!this.get_enableExpandOnClick())
					{
						if (this.get_isContextMenu())
							this._timeOutClose(2);
						else
							this._timeOutSub(true);
					}
					break;
				}
			case Sys.UI.Key.esc:
				{
					if (this._unselectIfCollapsed())
						return;
					
					this.__hideAll();
					
					// ensure that activeItem belongs to top-parent
					var test = item = this._activeItem;
					while (test)
					{
						test = test.get_parentItem();
						if (test)
							item = test;
					}
					if (item && item != this._activeItem)
						this.__setActiveItem(item);
				    
				    // K.D. September 12th, 2013 Bug #150775 The keyboard navigation does not account for disabled items at all
					
					//var firstItem = this._getFirstEnabled();
					//this.__focusLink(firstItem);
					return;
				}

			case Sys.UI.Key.up:
				{
					
					if (item.get_orientation() == $IG.Orientation.Vertical)
					{
						this.__focusPrevious(item);
					}
					else if (item.hasChildren())
					{
						this.__focusChild(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.down:
				{
					if (item.get_orientation() == $IG.Orientation.Vertical)
					{
						this.__focusNext(item);
					}
					else if (item.hasChildren())
					{
						this.__focusChild(item);
					}
					else
					{
						this.__focusParent(item);
					}
					break;
				}

			case Sys.UI.Key.home:
				{
					var items = this.getItems();
					if (this._activeItem)
					{
						var parentItem = this._activeItem.get_parentItem();
						if (parentItem)
						{
							items = parentItem.getItems();
						}
					}

					var firstItem = items.getItem(0);
                    // K.D. April 13, 2011 Bug #72230 We need to clear selection and restore style if the active
                    // item is not the first item
                    if(firstItem && firstItem != this._activeItem)
                    {
                        this._activeItem.set_selected(false);
                        this._activeItem.restore_style();
                    }

					if (firstItem && firstItem.get_enabled() &&
                   this._activeItem &&
                   firstItem._get_address() != this._activeItem._get_address())
					{
						this.__focusLink(firstItem);
					}
					else if (!this._activeItem && firstItem)
					{
						this.__focusLink(firstItem);
					}
					break;
				}

			case Sys.UI.Key.end:
				{
					var items = this.getItems();
					if (this._activeItem)
					{
						var parentItem = this._activeItem.get_parentItem();
						if (parentItem)
						{
							items = parentItem.getItems();
						}
					}

					var lastItem = items.getItem(items.getChildrenCount() - 1);
                    // K.D. April 13, 2011 Bug #72230 We need to clear selection and restore style if the active
                    // item is not the last item
                    if(lastItem && lastItem != this._activeItem)
                    {
                        this._activeItem.set_selected(false);
                        this._activeItem.restore_style();
                    }

					if (lastItem && lastItem.get_enabled() &&
						this._activeItem &&
						lastItem._get_address() != this._activeItem._get_address())
					{
						this.__focusLink(lastItem);
					}
					else if (!this._activeItem)
					{
						this.__focusLink(lastItem);
					}
					break;
				}

			default:
				return;
		}

		this.__scrollToActiveItem();

		$util.cancelEvent(event);
	},

	__scrollToActiveItem: function()
	{
		var item = this._activeItem;
		if (!item || !this.get_enableScrolling())
			return;
		var parentItem = item.get_parentItem();
		var firstScrollButtonVisible = false;
		var secondScrollButtonVisible = false;
		var scrollContainer;
		var orientation;
		if (parentItem)
		{
			scrollContainer = parentItem._get_scrollContainer();
			firstScrollButtonVisible = parentItem._getScrollButtonVisible(0);
			secondScrollButtonVisible = parentItem._getScrollButtonVisible(1);
			orientation = parentItem.get_itemsGroupSettings().get_orientation();
		}
		else
		{
			scrollContainer = this._get_scrollContainer();
			firstScrollButtonVisible = this._getScrollButtonVisible(this._child(scrollContainer, "A", 0));
			secondScrollButtonVisible = this._getScrollButtonVisible(this._child(scrollContainer, "A", 1));
			orientation = this.get_menuGroupSettings().get_orientation();
		}

		var itemBounds = Sys.UI.DomElement.getBounds(item.get_element());
		var scrollContainerBounds = this.__getElementBounds(scrollContainer);
		var subgroup = this._child(scrollContainer, "UL", 0);
		var firstButton = this._child(scrollContainer, "A", 0);
		var secondButton = this._child(scrollContainer, "A", 1);
		var firstButtonBounds = Sys.UI.DomElement.getBounds(firstButton);
		var secondButtonBounds = Sys.UI.DomElement.getBounds(secondButton);

		if (orientation == $IG.Orientation.Horizontal)
		{
			var oldLeft = $util.toIntPX(null, 'left', 0, subgroup);

			if (itemBounds.x > scrollContainerBounds.x + scrollContainerBounds.width - secondButtonBounds.width)
			{
				// item is not visible on the right side of the container.                
				subgroup.style.left = (oldLeft + ((itemBounds.x - (scrollContainerBounds.x + scrollContainerBounds.width) + itemBounds.width + (secondScrollButtonVisible ? 10 : 0)) * -1)) + "px";
				this._displayScrollButton(scrollContainer, 0, true);
				this.__resizedId++;
			}
			else if (itemBounds.x < scrollContainerBounds.x + firstButtonBounds.width)
			{
				// item is not visible on the left of the container.
				subgroup.style.left = (oldLeft + (scrollContainerBounds.x - itemBounds.x) + (firstScrollButtonVisible ? 10 : 0)) + "px";
				this._displayScrollButton(scrollContainer, 1, true);
				this.__resizedId++;
			}
		}
		else if (orientation == $IG.Orientation.Vertical)
		{
			var oldTop = $util.toIntPX(null, 'top', 0, subgroup);

			if (itemBounds.y > scrollContainerBounds.y + scrollContainerBounds.height - secondButtonBounds.height)
			{
				// item is not visible and is below the container.
				subgroup.style.top = (oldTop + ((itemBounds.y - (scrollContainerBounds.y + scrollContainerBounds.height) + itemBounds.height + (secondScrollButtonVisible ? 10 : 0)) * -1)) + "px";
				this._displayScrollButton(scrollContainer, 0, true);
				this.__resizedId++;
			}
			else if (itemBounds.y < scrollContainerBounds.y + firstButtonBounds.height)
			{
				// item is not visible and is before the container.
				subgroup.style.top = (oldTop + (scrollContainerBounds.y - itemBounds.y) + (firstScrollButtonVisible ? 10 : 0)) + "px";
				this._displayScrollButton(scrollContainer, 1, true);
				this.__resizedId++;
			}
		}

		var hasNextItem = !$util.isNullOrUndefined(item.get_nextItem());
		if (!hasNextItem && this._getScrollButtonVisible(secondButton))
		{
			if (orientation == $IG.Orientation.Horizontal)
			{
				var ulWidth = Sys.UI.DomElement.getBounds(subgroup).width;
				if (scrollContainerBounds.width - $util.toIntPX(null, 'left', 0, subgroup) >= ulWidth)
				{
					subgroup.style.left = ((ulWidth - scrollContainerBounds.width) * -1) + "px";
				}
			}
			else
			{
				var ulHeight = Sys.UI.DomElement.getBounds(subgroup).height;
				if (scrollContainerBounds.height - $util.toIntPX(null, 'top', 0, subgroup) >= ulHeight)
				{
					subgroup.style.top = ((ulHeight - scrollContainerBounds.height) * -1) + "px";
				}
			}
			// if we scrolled to last item hide the last scroll button
			this._displayScrollButton(scrollContainer, 1, false);
		}

		var hasPreviousItem = !$util.isNullOrUndefined(item.get_previousItem());
		if (!hasPreviousItem && this._getScrollButtonVisible(firstButton))
		{
			// if we scrolled to first item hide the first scroll button
			this._displayScrollButton(scrollContainer, 0, false);
			orientation == $IG.Orientation.Horizontal ? subgroup.style.left = "0px" : subgroup.style.top = "0px";
		}
	},

	__focusParent: function(item)
	{
		



		var parent = item.get_parentItem();
		
		if (parent != null)
		{
			// L.T. 11/11/2010 59618 Do this only when ItemCollapsing is not cancelled!
			if(this.__hideItem(item))
			{
				item.set_selected(false);
				this.__focusLink(parent);
				item.restore_style();
			}
		}
	},

	__focusChild: function(item)
	{
		




		if (item)
		{
			
			//item.set_selected(false);
		    if (this.__showItem(item) || item.get_expanded()) {
		        // D.A 18th December 2013 Update __expandedItems when showing item
		        this.__expandedItems.push(item);
		        this.__focusLink(item.get_childItem(0, true), true);
		    }
		}
	},

	__focusPrevious: function(item)
	{
		





		item.set_selected(false);
		item.restore_style();

		var collection = item.getItems()._ownerNode;
		var collectionLength = collection.get_length();
		var prevItem = item.get_previousItem();
		var index = collection.get_indexOf(item);
		var initialIndex = index;

		index--;

		if (index < 0)
		{
			index = collectionLength - 1;
			prevItem = collection.getItem(index);
		}

		while (prevItem && (prevItem.get_isSeparator() || !prevItem._getFlags().getEnabled(this)))
		{
			prevItem = prevItem.get_previousItem();
			index--;
			if (index == initialIndex) break;
			if (index < 0) { index = collectionLength - 1; prevItem = collection.getItem(index); }
		}

		this.__focusLink(prevItem);
	},

	__focusNext: function(item)
	{
		





		item.set_selected(false);
		item.restore_style();

		var collection = item.getItems()._ownerNode;
		var collectionLength = collection.get_length();
		var nextItem = item.get_nextItem();
		var index = collection.get_indexOf(item);
		var initialIndex = index;

		index++;

		if (index >= collectionLength)
		{
			index = 0;
			nextItem = collection.getItem(index);
		}

		while (nextItem && (nextItem.get_isSeparator() || !nextItem._getFlags().getEnabled(this)))
		{
			nextItem = nextItem.get_nextItem();
			index++;
			if (index == initialIndex) break;
			if (index >= collectionLength) { index = 0; nextItem = collection.getItem(index); }
		}

		this.__focusLink(nextItem);
	},

	_setupCollections: function()
	{
		this._itemCollection = this._collectionsManager.register_collection(0, $IG.DataMenuItemCollection);
		this._itemCollection._owner = this;
		this._collectionsManager.registerUIBehaviors(this._itemCollection);
		this._groupSettingsCollection = this._collectionsManager.register_collection(1, $IG.DataMenuGroupSettingsCollection);
		this._groupSettingsCollection._owner = this;

		this._itemCollection._getUIBehaviorsObj().initElemAttr = this._uiBehaviorsObject_initElemAttr;
	},

	_uiBehaviorsObject_initElemAttr: function(elem)
	{
		if (elem.getAttribute("adr") == null)
		{
			$util._initAttr(elem);
		}
	},

	__hideAll: function()
	{
		if (!this.get_element()) // we are somehow called after the control is disposed.
			return;

		this._clearOpeningDelayTimeoutContext();
		this._timeOutSub();
		for (var key in this._visibleItems)
		{
			
			if (this._visibleItems.hasOwnProperty(key))
			{
				
				// L.T. 11/11/2010 59618 Do this only when ItemCollapsing is not cancelled!
				this.__hideItem(this._visibleItems[key]);
			}
		}
		this.hide();
	},

	__hideUpLevelItems: function(currentItem)
	{
		var currentLevel = currentItem.get_level();
		for (var key in this._visibleItems)
		{
			
			if (this._visibleItems.hasOwnProperty(key))
			{
				var item = this._visibleItems[key];
				
				if (item && item != currentItem && item.get_level() >= currentLevel)
				{
					if (!currentItem.isDescendant(item) && key != currentItem._get_address())
						this.__hideItem(item);
				}
			}
		}
	},
	
	// adjust unselectable of child SPAN within A
	_unselSpan: function (e, val)
	{
		e = e.childNodes;
		var ii = e ? e.length : 0;
		while (ii-- > 0)
		{
			var elems = e[ii].nodeName == 'A' ? e[ii].childNodes : null, i = elems ? elems.length : 0;
			while (i-- > 0)
				if (elems[i].nodeName == 'SPAN')
					elems[i].setAttribute('unselectable', val);
		}
	},
	
	// To allow default functionality of IE-browser for mousedown (release focus from address bar),
	// temporary disable "unselectable" of LI and SPAN for top-level elements in menu
	_unselLiSpan: function()
	{
		var val = !this._unselOff;
		if (!$util.IsIE || val != !$util.isDocActive())
			return;
		this._unselOff = val;
		val = val ? 'off' : 'on';
		var elem = this._get_subgroup();
		this._unselSpan(elem.parentNode, val);
		var elems = elem.childNodes, i = elems ? elems.length : 0;
		while (i-- > 0)
		{
			elem = elems[i];
			if (elem.nodeName == 'LI')
			{
				elem.setAttribute('unselectable', val);
				this._unselSpan(elem, val);
			}
		}
	},
	
	_shouldHover: function(item, e)
	{
		
		if (!this.get_isInitialized() || !this.__enabled) return false;
		e.cancelBubble = true;
		
		if (item.get_isSeparator()) return false;

		if (e.type == "mouseover")
		{
			
			this._unselLiSpan();
			
			if (item._getFlags().getHovered()) return false;
			else return true;
		}
		else if (e.type == "mouseout") // && e.target.nodeName == "LI")
		{
			
			if (!item._getFlags().getHovered()) return false;

			
			return $util.isOut(e, item._element);
		}
		return false;
	},

	_clearOpeningDelayTimeoutContext: function()
	{
		this._timeOutOpen();
		delete this.__hoverItemContext_Item;
		delete this.__hoverItemContext_Subgroup;
		delete this.__subMenuOpeningDelayInProgress;
	},

	_expandOnHoverHelper: function(subgroup, item)
	{
		if (this.__hoverItemContext_Subgroup && (!subgroup || ($util.IsFireFox && (typeof (subgroup)).toLowerCase() == "number")))
		{
			// fetch the subgroup from the context if we are called by setTimeout.
			subgroup = this.__hoverItemContext_Subgroup;
		}

		if (this.__hoverItemContext_Item && !item)
		{
			// fetch the item from the context if we are called by setTimeout.
			item = this.__hoverItemContext_Item;
			// We assume subgroup is properly fetched and we are good to go to clear.
			this._clearOpeningDelayTimeoutContext();
		}

		if (item && subgroup)
		{
			// Show the sub menu.
			if (this.__showItem(item))
			{
				//A.T. Fix for #48430
				this.__expandedItems.push(item);
			}
		}
	},

	_isSubMenuOpeningDelayApplied: function(subgroup, item)
	{
		if (this.__subMenuOpeningDelay > 0 &&
           !this.get_enableExpandOnClick() &&
           !item.get_expanded())
		{
			if (item.hasChildren())
			{
				if ($util.isNullOrUndefined(this.__subMenuOpeningDelayInProgress))
				{
					this.__subMenuOpeningDelayInProgress = true;
					this.__hoverItemContext_Item = item;
					this.__hoverItemContext_Subgroup = subgroup;
					this._timeOutOpen(true);
					return true;
				}
				else if (this.__subMenuOpeningDelayInProgress)
				{
					if (this.__hoverItemContext_Item != item)
					{
						this.__hoverItemContext_Item = item;
						this.__hoverItemContext_Subgroup = subgroup;
						this._timeOutOpen(true);
						return true;
					}
				}
			}
			else
			{
				if (!$util.isNullOrUndefined(this.__subMenuOpeningDelayInProgress) &&
                    this.__subMenuOpeningDelayInProgress)
				{
					if (!(this.__hoverItemContext_Item === item))
					{
						this._clearOpeningDelayTimeoutContext();
					}
				}
			}
		}
		return false;
	},

	
	_hoverItem: function(item, shouldHover)
	{
	    
	    // K.D. September 10th, 2013 Bug #150608 Items hover styles are not applied when the control is nested inside an iframe when the iframe does not have focus
	    this._focus();
		if (this.__activateOnHover && !this.__controlActive)
		{
			
			var elementNames = [ "input", "textarea", "a", "button", "select" ];
			var e, menu = this;
			if (!this._blurFx)
			{
				this._blurFx = function (args) {
					$util.__lastFocusedElement = args.target;
					for (var x = 0; x < menu._blurElements.length; ++x)
					{
						
						try
						{
							$removeHandler(menu._blurElements[x], "blur", menu._blurFx);
						}
						catch (e)
						{ }
					}
					menu._blurElements = [];
				};
				this._blurElements = [];
			}
			for (var x = 0; x < elementNames.length; ++x)
			{
				var actualEls = document.getElementsByTagName(elementNames[x]);
				for (var y = 0; y < actualEls.length; ++y)
				{ 
					e = actualEls[y];
					if (e && !e._menu_fe)
					{
						this._blurElements.push(e);
						$addHandler(e, "blur",  this._blurFx);
					}
				}
			}

            

			this.__setActiveItem(item);
			this._onFocusHandler();
			this.__cancelBlur = true;
			
			// 2nd param - validate if focus belongs to INPUT in template
			this._focusEventElement(item, 1);
		}
		else if (this.__controlActive)
		{
			this.__setActiveItem(item);
		}

		if (shouldHover)
		{
			if (!this._touchNoHide)
				this._timeOutSub();
			var hide = true, hoveredItem = this._hoveredItem;
			if (hoveredItem && hoveredItem._get_address() != item._get_address())
			{
				
				hoveredItem._getFlags().setHovered(false);
				hoveredItem.restore_style();
			}

			this._raiseClientEvent("ItemHovered", "DataMenuItemCancel", null, null, item);			

			if (this.__controlActive)
			{
				// allow hover, but open only when control is active.
				var subgroup = this.get_enableScrolling() ? item._get_scrollContainer() : item._get_subgroup();
				if (!this._isSubMenuOpeningDelayApplied(subgroup, item))
				{
					if (subgroup && !this.get_enableExpandOnClick())
					{
						this._expandOnHoverHelper(subgroup, item);
						hide = false;
					}
				}

				if (hide && !this.get_enableExpandOnClick())
				{
					this.__hideUpLevelItems(item);
				}
			}

			this._hoveredItem = item;
		}
		else
		{
			this._hoveredItem = null;
			this._raiseClientEvent("ItemUnhovered", "DataMenuItemCancel", null, null, item);
		}
		
		setTimeout(function(){ try{item.set_hover(shouldHover);}catch(ex){} }, 0);
	},

	get_menuGroupSettings: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_menuGroupSettings">Get the menu group settings.</summary>
		///<value type="Infragistics.Web.UI.DataMenuGroupSettings"></value>
		return this._menuGroupSettings;
	},

	get_orientation: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.get_orientation">Get the menu orientation setting.</summary>
		///<value type="Infragistics.Web.UI.Orientation"></value>
		return this.get_menuGroupSettings().get_orientation()
	},

	removeItem: function(item)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.removeItem">Remove an item from the menu.</summary>
		///<param name="item" type="Infragistics.Web.UI.DataMenuItem">Menu item.</param>
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		if(!item || !item._owner || item._owner._id !== this._id) // item does not belong to this control.
			return false;

		var adr = item._get_address();
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = cbo.clientContext.type = "remove";
		cbo.serverContext.address = adr;
		cbo.clientContext.item = item;
		cbo.clientContext.parentItem = item.get_parentItem();		

		if (this._activeItem && this._activeItem._get_address() === adr)
		{
			this.__clearActiveItem();
		}

		if (this._selectedItem && this._selectedItem._get_address() === adr)
		{
			this.__unselectAll();
		}

		if (this._activeItem)
		{
			cbo.serverContext.activeItemAddress = this._activeItem._get_address();
		}

		if (this._selectedItem)
		{
			cbo.serverContext.selectedItemAddress = this._selectedItem._get_address();
		}

		if(this.get_enableScrolling())
		{
			var slider = $get(this._id + "_" + ($adrutil.getLevelByAdr(adr) > 0 ? $adrutil.getParentAddress(adr) : adr));
			if(slider)
			    slider.parentNode.removeChild(slider);
		}

		this._callbackManager.execute(cbo, true, true, false);
	},

	addItem: function(txt, parentItem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataMenu.addItem">Add an item to the menu.</summary>
		///<param name="itemText" type="String">Specify item text.</param>
		///<param name="parentItem" type="Infragistics.Web.UI.DataMenuItem">Specify the parent menu item of the new item that will be added.</param>
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		var adr = "";
		if (parentItem)
		{
			adr = parentItem._get_address();

			if(this.get_enableScrolling())
			{
				var slider = $get(this._id + "_" + adr);
				if(slider)
				    slider.parentNode.removeChild(slider);
			}
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = cbo.clientContext.type = "add";
		cbo.serverContext.address = adr;
		cbo.serverContext.text = txt;
		cbo.clientContext.parentItem = parentItem;
		this._callbackManager.execute(cbo, true, true, false);
	},

	_responseComplete: function(callbackObject, responseObject, obj)
	{
		
		$IG.WebDataMenu.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		// L.T. 3/11/2010 48650, 48654 fix add/remove API to work properly, until now it was released untested.
		switch (callbackObject.serverContext.type)
		{
			case "add":
			{
				var html = responseObject.context[1];
				var parentItem = callbackObject.clientContext.parentItem;
				var element;
				if (parentItem)
				{
					element = parentItem.get_element();
				}
				else
				{
					var ul = this._child(this.get_enableScrolling() ? this._get_scrollContainer() : this.get_element(), "UL", 0);
					if (ul)
					{
						element = document.createElement("LI");
						ul.appendChild(element);
					}
				}

				var helperEl = document.createElement("DIV");
				helperEl.innerHTML = html;
				element.id = helperEl.firstChild.id;
				element.className = helperEl.firstChild.className;
				element.innerHTML = helperEl.firstChild.innerHTML;
				delete helperEl;

				if(this.get_enableScrolling())
				{
					// reset the height of the ULs so that initalization code in initalize() could handle this.
					var uls = this.get_element().getElementsByTagName("UL");
					for(var i=0, len = uls.length; i < len; i++)
					{
						var style = uls[i].style;
						style.height = "";
						style.width = "";
					}
				}
			}
			break;

			case "remove":
			{
				var html = responseObject.context[1];
				var parentItem = callbackObject.clientContext.parentItem;
				var element = this.get_element();
				if (parentItem)
				{
					element = parentItem.get_element();
					var helperEl = document.createElement("DIV");
					helperEl.innerHTML = html;
					element.id = helperEl.firstChild.id;
					element.className = helperEl.firstChild.className;
					element.innerHTML = helperEl.firstChild.innerHTML;
					delete helperEl;
				}
				else
				{
					element.innerHTML = html;
				}
			}
			break;
		}

		this.__isInitialized = false;
		this._soft_dispose();
		var props = eval(responseObject.context[0]);
		this.set_props(props);
		this.preventInitEvent = true;
		this.initialize();

		if(callbackObject.serverContext.activeItemAddress)
			this._activeItem = this._itemCollection._getObjectByAdr(callbackObject.serverContext.activeItemAddress);

		if(callbackObject.serverContext.selectedItemAddress)
			this._selectedItem = this._itemCollection._getObjectByAdr(callbackObject.serverContext.selectedItemAddress);
	},

	_ensureItem: function(e, adr)
	{
		var item = this._itemCollection._getObjectByAdr(adr);
		if (item == null || e != null)
			item = this._itemCollection._addObject($IG.DataMenuItem, e, adr);
		return item;
	},

	/////////////////////////////////////////////////// SCROLLING FEATURE ////////////////////////////////////////

	__createTopLevelDivStructure: function()
	{
		var div = document.createElement("DIV");
		div.style.width = "0px";
		div.style.height = "0px";
		div.style.visibility = "hidden";
		div.style.position = "absolute";
		div.style.left = "0px";
		div.style.margin = "0px";
		div.style.padding = "0px";
		div.style.display = "inline-block";
        // K.D. April 27, 2011 If the parent element of the menu had text-align: center this messes up the submenu
        // items in IE7 so applying default ltr value. If rtl compatibility is added to the menu then the default
        // value for rtl should be 'right'.
        if($util.IsIE7) {
            // B.C. April 19, 2012 Bug #105708. This fix the problem in IE7 when the submenu of one WDM is rendered under another control.
		    div.style.zIndex = "1000";
            div.style.textAlign = 'left';
        }
		return div;
	},

	__createRelativeDiv: function()
	{
		var innerDiv = document.createElement("DIV");
		innerDiv.style.position = "relative";
		return innerDiv;
	},

	__createSliderDiv: function(width, height, adr)
	{
		var div = document.createElement("DIV");
		div.style.width = width + "px";
		div.style.height = height + "px";
		div.style.visibility = "visible";
		//!div.style.overflow = "hidden"; !never!
		div.style.display = "none";
		div.style.left = "0px";
		div.style.top = "0px";
		div.style.position = "absolute";
		div.id = adr;
		return div;
	},

	__showSliderDivByItem: function(item)
	{
		if (item.get_itemsGroupSettings().get_enableAnimation())
		{
			this.__animateItem(item);
		}
		else
		{
			if($util.IsIE7)
			{
				item.get_element().className = item.get_element().className;
			}
			var div = item._get_sliderContainer();
			if (div && div.nodeName == "DIV")
			{
				div.style.display = ($util.IsIE7 ? "" : "inline-block");
				div.style.visibility = 'visible';
				if($util.IsIE7)
				{
					div.firstChild.style.display = '';
					div.firstChild.style.visibility = 'visible';
				}
			}
			if($util.IsIE7)
			{
				// L.T. Fix for 37631. IE7 does not redraw when enable animation is false.
				item.get_element().className = item.get_element().className;
				var cont = item._get_scrollContainer();
				if(cont)
					cont.className = cont.className;
			}
		}
	},

	
	_getExpandDir: function(item, check)
	{
		// _dirs: keep track of last/parent directions. It is array of {dir:direction, useParent:flag}.
		// If useParent of parent is set, then child should use that direction instead of its own.
		// Main use case: direction is automatic and child nodes use same direction as the very first parent.
		// Note: direction can be swapped when submenu hits edge of browser window.
		var useDad, dir = 0, orient = item.get_orientation(), dirs = this._dirs, level = item ? item.get_level() : 0;
		if (level < 1 && !check)
			dirs = this._dirs = [];
		if (dirs)
			dirs = level > 0 ? dirs[level - 1] : null;
		else
			this._dirs = [];
		if (!check)
			this._dirs[level] = {};
		while (item && !dir)
		{
			
			if (item.get_orientation() == orient)
				dir = item.get_itemsGroupSettings().get_expandDirection();
			item = item.get_parentItem();
		}
		
		if (!dir && orient == this.get_menuGroupSettings().get_orientation())
			dir = this.get_menuGroupSettings().get_expandDirection();
		// check if direction of parent menu should be used
		if (dirs && dirs.useDad && (orient == $IG.Orientation.Horizontal) == (dirs.dir < 3))
			// use direction of parent and enable/keep useDad
			dir = useDad = dirs.dir;
		if (!dir)
			dir = orient == $IG.Orientation.Horizontal ? $IG.MenuExpandDirection.Down : $IG.MenuExpandDirection.Right;
		if (!check)
			this._dirs[level] = {dir: dir, useDad: useDad};
		return dir;
	},

	__animateItem: function(item)
	{
		var itemGroupSettings = item.get_itemsGroupSettings();

		if (!this.get_menuGroupSettings().get_enableAnimation() &&
           !itemGroupSettings.get_enableAnimation())
			return;

		var animationType = itemGroupSettings.get_animationType();
		var elemToAnimate = this.get_enableScrolling() ? item._get_sliderContainer() : item._get_subgroup();

		if (!elemToAnimate)
			return;

		if (this.get_enableScrolling())
		{
			elemToAnimate.style.display = ($util.IsIE7 ? "" : "inline-block");
			elemToAnimate.style.visibility = 'visible';
			elemToAnimate = item._get_scrollContainer();
		}

		
	    // show iframe for item
	    // D.A. Bug #176716 Removing showHideIframe used to support IE6. It was causing huge performance impact.
		//this._showHideIframe(item, elemToAnimate);

		var animation = item._get_animation();

		if (animationType == $IG.DataMenuAnimationtype.ExpandAnimation)
		{
			if(!animation)
			{
				if(this.get_enableScrolling() && $util.IsIE7 && elemToAnimate)
				{
					// hack, the right border is not shown on IE7! so increase the slider width with 2px! 1 does not work.
					var slider = elemToAnimate.parentNode;
					if(slider)
					{
						if(itemGroupSettings.get_orientation() == $IG.Orientation.Vertical)
							slider.style.width = ($util.toIntPX(null, 'width', 0, slider) + 2) + "px";
						else
							slider.style.height = ($util.toIntPX(null, 'height', 0, slider) + 2) + "px";
					}
				}
				animation = new $IG.SlideAnimation(elemToAnimate);
				animation.onEnd = function()
				{
					var menu = item._get_owner();
					menu._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
					menu._visibleItems[item._get_address()] = item;
				};
				item._set_animation(animation);
			}
			
			//Up=1, Down=2, Left=3, Right=4
			var dir = this._getExpandDir(item, true);
			animation.play(true, itemGroupSettings.get_animationEquationType(),
				itemGroupSettings.get_animationDuration(),
				dir > 2 ? $IG.AnimationSlideDirection.Horizontal : $IG.AnimationSlideDirection.Vertical,
				dir == 1, dir == 3);
		}
		else if (animationType == $IG.DataMenuAnimationtype.OpacityAnimation)
		{
			if(!animation)
			{
				animation = new $IG.OpacityAnimation(elemToAnimate, itemGroupSettings.get_animationEquationType());
				animation.set_duration(itemGroupSettings.get_animationDuration());
				animation.onEnd = function()
				{
					var menu = item._get_owner();
					menu._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
					menu._visibleItems[item._get_address()] = item;
				};
				item._set_animation(animation);
			}
			elemToAnimate.style.display = ($util.IsIE7 ? "" : "inline-block");
			elemToAnimate.style.visibility = "visible";
			animation.play(0, 100, true);
		}
	},

	__get_scrollbarWidth: function()
	{
		if ($util.isNullOrUndefined(this.__scrollbarWidth))
		{
			var scr = null;
			var inn = null;
			var wNoScroll = 0;
			var wScroll = 0;

			// Outer scrolling div
			scr = document.createElement('div');
			scr.style.position = 'absolute';
			scr.style.top = '-1000px';
			scr.style.left = '-1000px';
			scr.style.width = '100px';
			scr.style.height = '50px';
			// Start with no scrollbar
			scr.style.overflow = 'hidden';

			// Inner content div
			inn = document.createElement('div');
			inn.style.width = '100%';
			inn.style.height = '200px';

			// Put the inner div in the scrolling div
			scr.appendChild(inn);
			// Append the scrolling div to the doc
			document.body.appendChild(scr);

			// Width of the inner div sans scrollbar
			wNoScroll = inn.offsetWidth;
			// Add the scrollbar
			scr.style.overflow = 'auto';
			// Width of the inner div width scrollbar
			wScroll = inn.offsetWidth;

			// Remove the scrolling div from the doc
			document.body.removeChild(document.body.lastChild);

			// Pixel width of the scroller
			this.__scrollbarWidth = wNoScroll - wScroll;
		}
		return this.__scrollbarWidth;
	},

	__getElementBounds: function(domElem)
	{
		///<summary>
		/// Retrieves the dom elemnts bounds by showing the element and shifting its top left to a position that is
		/// not visible on the screen. If one of element parents is not displayed get bounds will return 0 for wheight and width.
		///</summary>
		if (domElem)
		{
			var originalTop = domElem.style.top;
			var originalLeft = domElem.style.left;
			var originalOverflow = domElem.style.overflow;
			var display = domElem.style.display;
			var visibility = domElem.style.visibility;
			domElem.style.top = "-10000px";
			domElem.style.left = "-10000px";
			domElem.style.overflow = "visible";
			domElem.style.visibility = "visible";
			domElem.style.display = "";
			var bounds = Sys.UI.DomElement.getBounds(domElem);
			domElem.style.display = display;
			domElem.style.visibility = visibility;
			domElem.style.top = originalTop;
			domElem.style.left = originalLeft;
			domElem.style.overflow = originalOverflow;
			// correct the corrdinates because get bounds sets top & left to -10000px;
			if(domElem.style.position != "")
			{
				bounds.x = bounds.x + 10000;
				bounds.y = bounds.y + 10000;
			}
			return bounds;
		}
	},

	__getSizer: function()
	{
		if ($util.isNullOrUndefined(this.__sizer))
		{
			var div = document.createElement("DIV");
			div.style.position = "absolute";
			div.style.top = "-10000px";
			div.style.left = "-10000px";
			div.style.display = "block";
            // K.D. March 21, 2011 Bug #63211 The sizer should not wrap white spaces in order to avoid 
            // rendering issues for items containing white spaces in their text
            div.style.whiteSpace = "nowrap";
			div.style.border = "solid";
			document.body.appendChild(div);
			
			div.className = this._element.className;
			
			if (!$util.IsIE6)
			{
				var childDiv = document.createElement("DIV");
				div.style.width = "auto";
				div.style.height = "auto";
				childDiv.style.width = "auto";
				childDiv.style.height = "auto";
				div.style.overflow = "auto";
				childDiv.style.overflow = "auto";
				div.appendChild(childDiv);
				this.__sizer = childDiv;
			}
			else
				this.__sizer = div;
		}
		return this.__sizer;
	},

	__getElementBoundsEx: function(domElem)
	{
		///<summary>
		/// Retrieves the dom elemnts bounds by detaching the element from its current location
		/// and attaches it to a sizer div that is displayed in the document and is out of the visible screen area.
		/// We show the domElement if it is not visible and we get its bounds. Then we restore the original
		/// display/visibility state and restore the element to its inital location in the DOM tree.
		/// This way we overcome the problem that __getElementBounds have, when the element has parents
		/// that are not displayed on the page.
		///</summary>
		if (domElem)
		{
			// attaching an element to the body causes a body rezsize.
			// In the case of context menu, it is attached to the body
			// and we receive a fake on window resize event.
			this.__stopResize = true;
			try
			{
				var sizer = this.__getSizer();
				
				var cssClassName = (domElem && domElem.parentNode && domElem.parentNode.className ? domElem.parentNode.className : "");
				
				if (!$util.IsIE6)
					sizer.className = cssClassName;

				//B.C. January 27th, 2012 Bug #99947. We replace the target node with a temporary node which saves the real node place.
                // K.D. February 13th, 2012 Bug #101295 replaceNode is a method only defined in IE
                // the regular DOM way of doing it is oldNode.parentNode.replaceChild(newNode, oldNode)
				var placeHolder = document.createElement("div");
				if (domElem.replaceNode) {
                    domElem.replaceNode(placeHolder);
                } else {
                    domElem.parentNode.replaceChild(placeHolder, domElem);
                }
				sizer.appendChild(domElem);

				var display = domElem.style.display; 
				var visibility = domElem.style.visibility;
				domElem.style.visibility = "visible";
				if (display == "none")
					domElem.style.display = "";
				var bounds = Sys.UI.DomElement.getBounds(domElem);

				//Here the real node is returned in its place.
                if (placeHolder.replaceNode) {
				    placeHolder.replaceNode(domElem);
                } else {
                    placeHolder.parentNode.replaceChild(domElem, placeHolder);
                }
				domElem.style.display = display;
				domElem.style.visibility = visibility;
			}
			finally
			{
				this.__stopResize = false;
			}

			return bounds;
		}
	},

	__onBeforeShowItem: function(item)
	{
		
		
		// this._resizeSubLevelSeparators(item, item._get_scrollContainer().offsetWidth, item.get_childItem(0, false).get_element().offsetHeight);
		
		this.__resizeListItems(item);
	},

	__renderStructure: function(item)
	{
		if (!item)
			return;
		var itemAddress = item._get_address();
		var slider = $get(this._id + "_" + itemAddress);

		if (!slider && item.hasChildren())
		{
			// if the structure is not created yet, create it.
			var itemLevel = item.get_level();
			var ul = item._get_scrollContainer();
			slider = this.__createSliderDiv($util.toIntPX(null, 'width', 0, ul),
                                            $util.toIntPX(null, 'height', 0, ul),
                                            this._id + "_" + itemAddress);

			if (itemLevel == 0)
			{
				var div = this.__createTopLevelDivStructure();
				var innerDiv = this.__createRelativeDiv();
				innerDiv.appendChild(slider);
				div.appendChild(innerDiv);
				this.get_element().appendChild(div);
				item.get_element().style['font-weight'] = 'inherit';
			}
			else
			{
				var parentSlider = $get(this._id + "_" + $adrutil.getParentAddress(itemAddress));
				parentSlider.appendChild(slider);
			}
			this.__attachItemChildrenToSlider(item, slider);

            //I.I.: 100853: Sub Menu Item doesn�t show on hover over with mouse in IE6
            if (div !== undefined && $util.IsIE6) {
                div.style.visibility = 'visible';
            }

            var itemsBounds = Sys.UI.DomElement.getBounds(item.get_element());
            if (itemsBounds && this.__itemBoundsHash)
                this.__itemBoundsHash[this._id + "_" + itemAddress] = itemsBounds;
        }

	    // Fix bug: 129526 - Since the context menu item's location can change, 
	    // the position of the sub-menu should be recomputed for each location change
	    var itemsBoundsActual = Sys.UI.DomElement.getBounds(item.get_element());
	    if (itemsBoundsActual && this.__itemBoundsHash && this.__itemBoundsHash.hasOwnProperty(this._id + "_" + itemAddress)) {
	        var itemBoundsStored = this.__itemBoundsHash[this._id + "_" + itemAddress];
	        if (itemBoundsStored && itemsBoundsActual &&
                (itemBoundsStored.x != itemsBoundsActual.x || itemBoundsStored.y != itemsBoundsActual.y)) {
	            this.__resizedId++;
	            this.__itemBoundsHash[this._id + "_" + itemAddress] = itemsBoundsActual;
	        }
	    }

		if (this.__needsResize(slider.resizeId))
		{
			this.__positionSliderDiv(item, slider);
			slider.resizeId = this.__resizedId;
		}
	},

	__positionSliderDiv: function(item, slider)
	{
		if (!item || !slider || slider.nodeName != "DIV")
			return;
		var itemGroupSettings = item.get_itemsGroupSettings();
		var vertOrient = itemGroupSettings.get_orientation() == $IG.Orientation.Vertical;
		
		
		var expandDirection = this._getExpandDir(item);
		var orientation = item.get_orientation(), level = item.get_level();
		var itemsBounds = Sys.UI.DomElement.getBounds(item.get_element());
		
		if (level === 0)
		{
		    var h = this._element.offsetHeight, w = this._element.offsetWidth;

		    
			h = Math.max(h - 1, 0);
			w = Math.max(w - 1, 0);

			itemsBounds.height = Math.min(itemsBounds.height, h);
			itemsBounds.width = Math.min(itemsBounds.width, w);
		}

		var itemUl = item._get_subgroup();
		var ulBounds = new Object();
		ulBounds.width = $util.toIntPX(null, 'width', 0, itemUl);
		ulBounds.height = $util.toIntPX(null, 'height', 0, itemUl);

		slider.style.top = "0px";
		slider.style.left = "0px";
		var sliderBounds = this.__getElementBounds(slider);

		var pageDims = this.__getPageDimensions();
		var x, y, top, left, dx = itemGroupSettings.get_offsetX(), dy = itemGroupSettings.get_offsetY();
		// note: _dirs is created within _getExpandDir
		var dirs = this._dirs[level];
		var twice = -1;
		
		while (twice++ < 1)
		{
			if (twice)
				// swap direction to opposite
				expandDirection += (expandDirection == 1 || expandDirection == 3) ? 1 : -1;
			top = left = 0;
			if (orientation == $IG.Orientation.Horizontal)
			{
				// align the sub menu to the item left edge, else align it to the item right edge,
				// depending on which distance is bigger (from item left edge to right page end or from left page start to item right edge)
				var alignToItemLeft = ((pageDims.MaxX - itemsBounds.x > itemsBounds.x + itemsBounds.width) || (pageDims.MaxX - itemsBounds.x > sliderBounds.width)) || vertOrient;
				if (expandDirection == $IG.MenuExpandDirection.Down)
				{
					x = (alignToItemLeft ? itemsBounds.x - sliderBounds.x : itemsBounds.x - sliderBounds.x + itemsBounds.width - (ulBounds.width < sliderBounds.width ? ulBounds.width : sliderBounds.width));
					y = itemsBounds.y + itemsBounds.height - sliderBounds.y + dy;
				}
				else
				{
					x = (alignToItemLeft ? itemsBounds.x - sliderBounds.x : itemsBounds.x - sliderBounds.x + itemsBounds.width - (ulBounds.width < sliderBounds.width ? ulBounds.width : sliderBounds.width));
					//B.C. 3, January 2012. Bug #98650.
					//Because the slider's parent is set with "position=relative", its "y=0" position is just bellow the root menu. 
					//And because we need to position the slider above the menu, we substract from 0 the items height + slider height.
					y = -(itemsBounds.height + sliderBounds.height) - dy;
				}
				top += y;
				left += x + dx;
				if (vertOrient)
					break;
				
				if (sliderBounds.y + top < pageDims.ScrollTop)
				{
					top = pageDims.ScrollTop - sliderBounds.y;
				}
				else if (sliderBounds.y + top + sliderBounds.height > pageDims.MaxY)
				{
					
					//top = sliderBounds.y + sliderBounds.height - pageDims.MaxY;
				}
				else
					break;
			}
			else
			{
				// align the sub menu to the item top edge, else align it to the item bottom edge,
				// depending on which distance is bigger (from item top edge to page end or from page start to item bottom)
				var alignToItemTop = ((pageDims.MaxY - itemsBounds.y > itemsBounds.y + itemsBounds.height) || (pageDims.MaxY - itemsBounds.y > sliderBounds.height)) || !vertOrient;
				if (expandDirection == $IG.MenuExpandDirection.Left)
				{
					x = itemsBounds.x - sliderBounds.x - sliderBounds.width - dx;
					y = (alignToItemTop ? itemsBounds.y - sliderBounds.y : itemsBounds.y + itemsBounds.height - sliderBounds.y - (ulBounds.height < sliderBounds.height ? ulBounds.height : sliderBounds.height));
				}
				else
				{
					// K.D. March 13th, 2012 Bug #101380 When the menu has set width and the item text exceeds
					// the width of the container, then the submenu is expanded at a distance from the parent container
					if (level == 0)
						itemsBounds.width = Sys.UI.DomElement.getBounds(this.get_element()).width;
					x = itemsBounds.x - sliderBounds.x + itemsBounds.width + dx;
					y = (alignToItemTop ? itemsBounds.y - sliderBounds.y : itemsBounds.y + itemsBounds.height - sliderBounds.y - (ulBounds.height < sliderBounds.height ? ulBounds.height : sliderBounds.height));
				}
				left += x;
				top += y + dy;
				if (!vertOrient)
					break;
				
				if (sliderBounds.x + left < pageDims.ScrollLeft)
				{
					left = pageDims.ScrollLeft - sliderBounds.x;
				}
				else if (sliderBounds.x + left + sliderBounds.width > pageDims.MaxX)
				{
					
					//left = sliderBounds.x + sliderBounds.width - pageDims.MaxX;
				}
				else
					break;
			}
		}
		
		dirs.dir = expandDirection;
		if (twice > 0)
			dirs.useDad = true;
		slider.style.top = top + "px";
		slider.style.left = left + "px";

		this.__fitSliderInPage(slider, sliderBounds, top, left, item);
	},

	__fitSliderInPage: function(slider, sliderBounds, top, left, item)
	{
		
		delete this._hasSlider;
		if (!slider || !sliderBounds || !item || !this.get_enableScrolling())
			return;
		



		var pageDims = this.__getPageDimensions();
		var scrollContainer = item._get_scrollContainer();
		var scrollContainerBounds = this.__getElementBoundsEx(scrollContainer);
		var orientation = item.get_itemsGroupSettings().get_orientation();
		var minSize = 0; // min size, we can not decrease below.

		if ((sliderBounds.x + left + scrollContainerBounds.width > pageDims.MaxX &&
            orientation == $IG.Orientation.Horizontal) ||
           (sliderBounds.y + top + scrollContainerBounds.height > pageDims.MaxY &&
            orientation == $IG.Orientation.Vertical))
		{
			// When Width/Height is not applied, we should set this.
			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			if (orientation == $IG.Orientation.Vertical)
			{
				// decrease the height with the piece that goes beyond the page max Y value.
				var decreasedHeight = scrollContainerBounds.height - ((sliderBounds.y + top + scrollContainerBounds.height) - pageDims.MaxY);
				if (decreasedHeight > minSize)
				{
					scrollContainer.style.height = decreasedHeight + "px";
					slider.style.height = decreasedHeight + "px";
				}
			}
			else if (orientation == $IG.Orientation.Horizontal)
			{
				// decrease the width with the piece that goes beyond the page max X value.
				var decreasedWidth = scrollContainerBounds.width - ((sliderBounds.x + left + scrollContainerBounds.width) - pageDims.MaxX);
				if (decreasedWidth > minSize)
				{
					scrollContainer.style.width = decreasedWidth + "px"; // scroll container must be 3px smaller than the slider as created in __renderStructure.
					slider.style.width = decreasedWidth + "px";
				}
			}
			item._displayScrollButton(1, true);
		}

		if ((sliderBounds.x + left < 0 && orientation == $IG.Orientation.Horizontal) ||
		   (sliderBounds.y + top < 0 && orientation == $IG.Orientation.Vertical))
		{
			// When Width/Height is not applied, we should set this.
			if (scrollContainer.style.overflow != "hidden")
				scrollContainer.style.overflow = "hidden";

			if (orientation == $IG.Orientation.Vertical)
			{
				// decrease the height with the piece that goes beyond the page max Y value.
				var decreasedHeight = scrollContainerBounds.height + sliderBounds.y + top;
				if (decreasedHeight > minSize)
				{
					scrollContainer.style.height = decreasedHeight + "px";
					slider.style.height = decreasedHeight + "px";
					slider.style.top = top + ((sliderBounds.y + top) * -1) + "px";
				}
			}
			else if (orientation == $IG.Orientation.Horizontal)
			{
				// decrease the width with the piece that goes beyond the page max X value.
				var decreasedWidth = scrollContainerBounds.width + sliderBounds.x + left;
				if (decreasedWidth > minSize)
				{
					scrollContainer.style.width = decreasedWidth + "px";
					slider.style.width = decreasedWidth + "px";
					slider.style.left = left + ((sliderBounds.x + left) * -1) + "px";
				}
			}
			item._displayScrollButton(1, true);
		}
	},

	__needsResize: function(resizeId)
	{
		return this.__resizedId != resizeId;
	},

	_onWindowResizeHandler: function(event)
	{
		if(this.__stopResize || !this.get_element() || this.get_element().offsetHeight == 0) // return, when menu element is not visible!
			return;

		var pageSize = this.__pageSize;
		this.__getPageDimensions(true); // repopulate this.__pageSize;
		var newPageSize = this.__pageSize;

		var isResized = (!pageSize || (pageSize.Width != newPageSize.Width || pageSize.Height != newPageSize.Height));
		if (isResized)
		{
			this.__resizedId++;
			this.__resizeScrollArea(this.__getElementBoundsEx(this._get_subgroup()), this._get_scrollContainer(), this._menuGroupSettings);
		}
	},

	__attachItemChildrenToSlider: function(item, sliderContainer)
	{
		if (!item || !sliderContainer || sliderContainer.nodeName != "DIV")
			return;
		var scrollDiv = item._get_scrollContainer();
		var realParent = scrollDiv.parentNode;
		sliderContainer.appendChild(scrollDiv);
		item._set_scrollContainer(scrollDiv);
		item._set_sliderContainer(sliderContainer);
		scrollDiv.realParent = realParent;
		scrollDiv.style.display = ($util.IsIE7 ? "" : "inline-block");
		scrollDiv.style.visibility = "visible";
	},

	__showItem: function(item)
	{
		if (!item || item.get_expanded())
			return false;
		var parent = this;
		if (item.get_level() > 0)
		{
			parent = item.get_parentItem();
			if (!parent.get_expanded())
				this.__showItem(parent);
		}
		if (!item.hasChildren())
			return false;
		
		var ii, items = parent.getItems(), i = items ? items.getChildrenCount() : 0;
		while (i-- > 0)
		{
			ii = items.getItem(i);
			if (ii && ii != item && ii.get_expanded())
				this.__hideItem(ii);
		}
		if (!this.get_enableScrolling())
		{
			
			return this.__showItemOld(item);
		}
		this.__onBeforeShowItem(item);
		this.__renderStructure(item);
		args = this._raiseClientEvent('ItemExpanding', 'DataMenuItemCancel', null, null, item);
		if (args && args.get_cancel())
			return false;
		item.set_expanded(true);
		this.__showSliderDivByItem(item);
		this._visibleItems[item._get_address()] = item;
		if (!item.get_itemsGroupSettings().get_enableAnimation())
			this._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
		return true;
	},

	_onMouseWheel: function(event)
	{
		var delta = 0;
		if (event.rawEvent.wheelDelta)
		{
			
			delta = event.rawEvent.wheelDelta / 120;
			

			
			

		}
		else if (event.rawEvent.detail)
		{ 
			


			delta = -event.rawEvent.detail / 3;
		}
		



		if (delta)
			this._onRealMouseWheel(delta, event);
		



		if (event.preventDefault)
			event.preventDefault();
		event.preventDefault();
	},

	__getNearestScrollingDiv: function(domElement)
	{
		while (domElement)
		{
			var id = $util._getXAttr(domElement);
			if (domElement.nodeName == "DIV" && id && id.indexOf("mkr:sd") != -1)
			{
				return domElement;
			}
			else
			{
				domElement = domElement.parentNode;
			}
		}

		return null;
	},

	__isVerticalScroll: function(scrollButton)
	{
		if (scrollButton && scrollButton.nodeName == "A")
		{
			var css = $util.getCssClass(scrollButton);
			return (css && (css.indexOf("MenuScrollerTop") != -1 || css.indexOf("MenuScrollerBottom") != -1));
		}
	},

	__getScrollSpeedDimensions: function(numberOfItems)
	{
		var triplet;
		var speed = this._touchSpeed ? this._touchSpeed : this.get_scrollingSpeed();
		if (speed == $IG.DataMenuScrollingSpeed.VerySlow)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.VerySlow);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Slow)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Slow);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Normal)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Normal);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.Fast)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.Fast);
		}
		else if (speed == $IG.DataMenuScrollingSpeed.VeryFast)
		{
			triplet = this.__getScrollSpeedValues($IG.DataMenuScrollingSpeedFormula.VeryFast);
		}

		triplet.itemsFactor = this.__getScrollSpeedFactor(numberOfItems);

		return triplet;
	},

	__getScrollSpeedValues: function(speedType)
	{
		var triplet = new Object();
		triplet.pixelsToScroll = speedType[0];
		triplet.perTime = speedType[1];
		triplet.itemsFactor = 1;
		return triplet;
	},

	__getScrollSpeedFactor: function(numberOfItems)
	{
		if (!$util.isNullOrUndefined(numberOfItems) && typeof (numberOfItems) == "number")
		{
			var factor = $IG.DataMenuScrollingItemsFactor.Slow;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];

			factor = $IG.DataMenuScrollingItemsFactor.Normal;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];

			factor = $IG.DataMenuScrollingItemsFactor.Fast;

			if (numberOfItems > factor[0] && numberOfItems <= factor[1])
				return factor[2];
		}
		return 1;
	},

	_onRealMouseWheel: function(delta, browserEvent)
	{
		var target = this._getTarget(browserEvent);
		var div = this.__getNearestScrollingDiv(target);

		if (!div)
			return;

		var ul = this._child(div, "UL", 0);
		var scrollUp = delta > 0;
		var firstScrollButton = this._child(div, "A", 0);
		var secondScrollButton = this._child(div, "A", 1);

		if ((!this._getScrollButtonVisible(firstScrollButton) && scrollUp) ||
           (!this._getScrollButtonVisible(secondScrollButton) && !scrollUp))
			return; 


		this.__resizedId++; // when scrolling is done, we should advance the resizeId, because submenus that are already positioned with top/left needs to be recalculated.

		this.__doScroll(0, ul, scrollUp,
                        firstScrollButton,
                        secondScrollButton,
                        this.__isVerticalScroll(firstScrollButton), Math.abs(delta));

		// hide the menus that are expanded and are with level deeper than the scroll container.
		this.__hideUpLevelItems(this._itemCollection._getUIBehaviorsObj().getItemFromElem(this._child(ul, "LI", 0)));
	},

	_getTarget: function(e, li)
	{
		e = e ? (e.target || e.srcElement) : null;
		if (e && e.nodeName == "#text")
			e = e.parentNode;
		return (li && e && e.nodeName == "SPAN") ? e.parentNode : e;
	},

	_onMouseOverHandler: function(browserEvent)
	{
		var target = this._getTarget(browserEvent, true);
		
		this._mOver = true;
		if (this._isScrollButtonTarget(browserEvent))
		{
			if (this._cancelScrolling)
			{
				delete this._touchSpeed;
				this._cancelScrolling = false;
				return;
			}
			if (!this._isScrolling)
			{
				this._timeOutSub();
				this._isScrolling = true;

				this.__resizedId++; // when scrolling is done, we should advance the resizeId, because submenus that are already positioned with top/left needs to be recalculated.

				var ul = this._child(target.parentNode, "UL", 0);
				var css = $util.getCssClass(target);
				if (css && css.indexOf("MenuScrollerTop") != -1)
				{
					this.__doScroll(0, ul, true, target, this._child(ul.parentNode, "A", 1), true);
				}
				else if (css && css.indexOf("MenuScrollerBottom") != -1)
				{
					this.__doScroll(0, ul, false, this._child(ul.parentNode, "A", 0), target, true);
				}
				else if (css && css.indexOf("MenuScrollerLeft") != -1)
				{
					this.__doScroll(0, ul, true, target, this._child(ul.parentNode, "A", 1), false);
				}
				else if (css && css.indexOf("MenuScrollerRight") != -1)
				{
					this.__doScroll(0, ul, false, this._child(ul.parentNode, "A", 0), target, false);
				}

				// hide the menus that are expanded and are with level deeper than the scroll container.
				this.__hideUpLevelItems(this._itemCollection._getUIBehaviorsObj().getItemFromElem(this._child(ul, "LI", 0)));
			}
			return; // prevent from stop scrolling
		}
		this.__stopScroll();
	},

	_isScrollButtonTarget: function(e)
	{
		var target = this._getTarget(e, true);
		return target && target.nodeName == "A" && $util._isXAttrContains(target, "mkr:sb");
	},

	_onMouseOutHandler: function(e)
	{
		
		delete this._mOver;
		if (this.get_enableScrolling())
		{
			var target = this._getTarget(e);
			var relTarget = e.rawEvent.relatedTarget || e.rawEvent.toElement;
			var isScrollButtonTarget = this._isScrollButtonTarget(e);
			if (isScrollButtonTarget &&
			   ((target.nodeName == "A" && (relTarget ? relTarget.parentNode != target : true)) ||
				(target.nodeName == "SPAN" && target.parentNode != relTarget)))
			{
				this.__stopScroll();
			}
		}

		if ($util.isOut(e, this.get_element()) && this.__activateOnHover)
		{
			// close the menu on mouse out from the whole menu, when enable expand on hover is true.
			if (!this.get_isContextMenu())
			{
				this._timeOutSub(true);
				this.__returnFocusIfNeeded();
			}
			
			var me = this, delay = me.__subMenuClosingDelay, fn = function() { me._unselectIfCollapsed(true); };
			setTimeout(fn, 10);
			if (delay)
				setTimeout(fn, delay + 10);
		}
		
		//this.__iframeItemsListBackground.style.display = "none";
	},
	
	_unselectIfCollapsed: function (checkMouse)
	{
		if (checkMouse && this._mOver)
			return;
		for (var key in this._visibleItems)
		{
			if (this._visibleItems.hasOwnProperty(key))
				return;
		}
		if (this._activeItem)
		    this._activeItem.set_active(false);
	    // K.D. December 18th, 2013 Bug #159750 Separating selection and activation.
		//this.__unselectAll();
		return true;
	},
	_onTouchStart: function (evnt)
	{
		var target = this._getTarget(evnt, true);
		var adr = $util.resolveMarkedElement(target, true);
		if (adr)
		{
			var item = this.getItems()._getObjectByAdr(adr[1]);
			if (item)// && item.get_level())
			{
				this._touch = { t: new Date().getTime(), item: item, adr: adr[1], e: target };
				$util.cancelEvent(evnt);
			}
		}
		if (this._isScrollButtonTarget(evnt))
		{
			this._cancelScrolling = true;
			if (!this._isScrolling)
			{
				this._timeOutSub();
				this._isScrolling = true;
				this.__resizedId++; // when scrolling is done, we should advance the resizeId, because submenus that are already positioned with top/left needs to be recalculated.
				var ul = this._child(target.parentNode, "UL", 0);
				var css = $util.getCssClass(target);
				if (css && css.indexOf("MenuScrollerTop") != -1)
				{
					this.__doScroll(0, ul, true, target, this._child(ul.parentNode, "A", 1), true);
				}
				else if (css && css.indexOf("MenuScrollerBottom") != -1)
				{
					this.__doScroll(0, ul, false, this._child(ul.parentNode, "A", 0), target, true);
				}
				else if (css && css.indexOf("MenuScrollerLeft") != -1)
				{
					this.__doScroll(0, ul, true, target, this._child(ul.parentNode, "A", 1), false);
				}
				else if (css && css.indexOf("MenuScrollerRight") != -1)
				{
					this.__doScroll(0, ul, false, this._child(ul.parentNode, "A", 0), target, false);
				}
				// hide the menus that are expanded and are with level deeper than the scroll container.
				this.__hideUpLevelItems(this._itemCollection._getUIBehaviorsObj().getItemFromElem(this._child(ul, "LI", 0)));
			}
			return;
		}
	},
	_onTouchMove: function (evnt)
	{
	    delete this._touch;
		var target = this._getTarget(evnt, true);
		var touchCoords = $util._getTouchCoords(evnt.rawEvent);
		if (!this._isScrollButtonTarget(evnt) && this._lastTouchCoords == null)
		{
			this._lastTouchCoords = touchCoords;
			if (!this.__stopScroll())
				evnt.preventDefault();
		}
		else if (this._lastTouchCoords != null)
		{
			var touchDeltaX = touchCoords.x - this._lastTouchCoords.x;
			var touchDeltaY = touchCoords.y - this._lastTouchCoords.y;
			var div = this.__getNearestScrollingDiv(target);
			var delta = div && div.className.indexOf('Vertical') == -1 ? touchDeltaX : touchDeltaY;
			if (delta)
			{
				this._touchSpeed = Math.abs(delta) / 4;
				if (this._touchSpeed > $IG.DataMenuScrollingSpeed.VeryFast)
					this._touchSpeed = $IG.DataMenuScrollingSpeed.VeryFast;
				this._onRealMouseWheel(delta > 0 ? 1 : -1, evnt);
				evnt.preventDefault();
			}
			this._lastTouchCoords = touchCoords;
		}
	},
	_onTouchEnd: function (evnt)
	{
	    var t = this._touch;
		if (t)
		{
			if (!t.item.get_level() && !t.item.get_expanded() && t.item.hasChildren())
				this._touchNoHide = true;
			this._hoverItem(t.item, true);
			this._selectItem(t.item, true);
			this._onClickHandler(t.e, t.adr, evnt);
		}
		delete this._touchNoHide;
		this._lastTouchCoords = null;
		this._touchSpeed = null;
		if (this.get_enableScrolling())
			this.__stopScroll();
		if (this.__activateOnHover)
		{
			// close the menu on mouse out from the whole menu, when enable expand on hover is true.
			if (!this.get_isContextMenu() && (!t || !t.item.hasChildren()))
			{
				this._timeOutSub(true);
				this.__returnFocusIfNeeded();
			}
		}
		delete this._touch;
	},
	__returnFocusIfNeeded: function()
	{
		
		if (!this.__activateOnHover || this._focInTempl())
			return;
		var lfe = $util.__lastFocusedElement;
		this.__cancelBlur = false;
		
		if (lfe && lfe.offsetWidth && lfe.offsetHeight)
		{
			var me = this, xy = $util.getLocation(lfe), r = $util.getWinRect();
			if (xy.x + 10 > r.x && xy.y + 10 > r.y && xy.x < r.x + r.width && xy.y < r.y + r.height)
				
				setTimeout(function(){ if (me._focus(lfe)) me.__setCaretTo(lfe); }, 5);
			else
				delete $util.__lastFocusedElement;
		}
	},

	__doScroll: function(fakeOnFF, scrollElement, scrollUp, upButton, downButton, isVertical, delta)
	{
		var continueScrolling = false;

		var scrollElemParent = scrollElement.parentNode;
		var scrollSpeedVaribales = this.__getScrollSpeedDimensions(scrollElemParent.realParent ? this._itemCollection._getUIBehaviorsObj().getItemFromElem(scrollElemParent.realParent).getItems().get_length() : this.getItems().get_length());

		if (isVertical)
			continueScrolling = this.__scrollVerticalItems(scrollElement, scrollUp, scrollSpeedVaribales, upButton, downButton);
		else
			continueScrolling = this.__scrollHorizontalItems(scrollElement, scrollUp, scrollSpeedVaribales, upButton, downButton);

		if (!$util.isNullOrUndefined(delta) && typeof (delta) == "number")
		{
			// delta is defined only when we scroll with the mouse wheel.
			// We will call this handler exactly delta times, this way we will have the so called scroll wheel effect.
			if (delta <= 0)
			{
				this.__stopScroll();
				continueScrolling = false;
			}
			delta--;
		}

		if (continueScrolling)
		{
			this._timeOutScroll();
			this.__scrollingTimeoutID = setTimeout($util.createDelegate(this, this.__doScroll, [0, scrollElement, scrollUp, upButton, downButton, isVertical, delta]), (this.__accelerateScrolling ? Math.ceil(scrollSpeedVaribales.perTime / 3) : scrollSpeedVaribales.perTime));
		}

        //A.T. Fix for bug #37646 - Scrolling inside context menu not working well
        // hack to fix a well-known bug in IE - we need to force the browser to reflow, so that scrolling is smooth and updated on time 
        if ($util.IsIE)
        {
            if (scrollElemParent.realParent)
            {
                scrollElemParent.realParent.className = scrollElemParent.realParent.className;
            }

            if (scrollElemParent)
            {
                scrollElemParent.className = scrollElemParent.className;
            }

			if(this.get_isContextMenu())
				this.get_element().className = this.get_element().className;
        }
	},

	__stopScroll: function()
	{
		
		
		var ret = this._timeOutScroll();
		if (this._isScrolling)
		{
			this.__accelerateScrolling = this._isScrolling = false;
			ret = true;
		}
		
		if (!this._hasSlider || !$util.IsIE9PlusMode)
			return ret;
		var id = '_igMenu_IE9fix_el_', fix = document.getElementById(id);
		if (!fix)
		{
			fix = document.createElement('SPAN');
			fix.id = id;
			fix.style.position = 'absolute';
			fix.style.display = 'none';
			document.body.insertBefore(fix, document.body.firstChild);
		}
		fix.innerHTML = fix.innerHTML ? '' : 'hi IE9';
		return ret;
	},

	__scrollVerticalItems: function(scrollElement, scrollUp, speed, upButton, downButton)
	{
		var continueScrolling = false;
		if (scrollElement && upButton && downButton)
		{
			continueScrolling = true;
			var currentTop = $util.toIntPX(null, 'top', 0, scrollElement);
			var pixelsToScroll = (this.__accelerateScrolling ? speed.pixelsToScroll * speed.itemsFactor * 2 : speed.pixelsToScroll * speed.itemsFactor);
			var newTop = scrollUp ? currentTop + (pixelsToScroll) : currentTop - (pixelsToScroll);
			scrollElement.style.top = newTop + "px";

			if (currentTop == 0 && newTop < 0 && upButton.style.display == "none")
			{
				// show the top button
				upButton.style.display = "";
			}
			else if (newTop >= 0 && currentTop != 0 && upButton.style.display != "none")
			{
				// hide the top button
				this.__stopScroll();
				continueScrolling = false;
				upButton.style.display = "none";
				scrollElement.style.top = "0px";
			}

			var downButtonDisplay = downButton.style.display;
			var ulHeight = Sys.UI.DomElement.getBounds(scrollElement).height;
			var scrollContainerHeight = Sys.UI.DomElement.getBounds(scrollElement.parentNode).height;
			if (scrollContainerHeight - newTop >= ulHeight && downButtonDisplay != "none")
			{
				// hide the bottom button
				this.__stopScroll();
				continueScrolling = false;
				scrollElement.style.top = ((ulHeight - scrollContainerHeight) * -1) + "px";
				downButton.style.display = "none";
			}
			else if (downButtonDisplay == "none")
			{
				// show the bottom button
				downButton.style.display = "";
			}
		}
		return continueScrolling;
	},

	__scrollHorizontalItems: function(scrollElement, scrollLeft, speed, leftButton, rightButton)
	{
		var continueScrolling = false;
		if (scrollElement && leftButton && rightButton)
		{
			continueScrolling = true;
			var currentLeft = $util.toIntPX(null, 'left', 0, scrollElement);
			var pixelsToScroll = (this.__accelerateScrolling ? speed.pixelsToScroll * speed.itemsFactor * 2 : speed.pixelsToScroll * speed.itemsFactor);
			var newLeft = scrollLeft ? currentLeft + (pixelsToScroll) : currentLeft - (pixelsToScroll);
			scrollElement.style.left = newLeft + "px";

			if (currentLeft == 0 && newLeft < 0 && leftButton.style.display == "none")
			{
				// show the left button
				leftButton.style.display = "";
			}
			else if (newLeft >= 0 && currentLeft != 0 && leftButton.style.display != "none")
			{
				// hide the left button
				this.__stopScroll();
				continueScrolling = false;
				leftButton.style.display = "none";
				scrollElement.style.left = "0px";
			}

			var rightButtonDisplay = rightButton.style.display;
			var ulWidth = Sys.UI.DomElement.getBounds(scrollElement).width;
			var scrollContainerWidth = Sys.UI.DomElement.getBounds(scrollElement.parentNode).width;
			if (scrollContainerWidth - newLeft >= ulWidth && rightButtonDisplay != "none")
			{
				// hide the right button
				this.__stopScroll();
				continueScrolling = false;
				scrollElement.style.left = ((ulWidth - scrollContainerWidth) * -1) + "px";
				rightButton.style.display = "none";
			}
			else if (rightButtonDisplay == "none")
			{
				// show the right button
				rightButton.style.display = "";
			}
		}
		return continueScrolling;
	},

	_get_scrollContainer: function()
	{
		
		return this._child(this.get_element(), "DIV", 0);
	},

	_get_subgroup: function()
	{
		var element = this.get_enableScrolling() ? this._get_scrollContainer() : this.get_element();
		return this._child(element, "UL", 0);
	},

	_displayScrollButton: function(scroller, buttonIndex, show)
	{
		if (!scroller || (buttonIndex != 0 && buttonIndex != 1))
			return;
		var button = this._child(scroller, "A", buttonIndex);
		if (show)
		{
			button.style.display = "";
			
			this._hasSlider = true;
		}
		else
		{
			button.style.display = "none";
		}
	},

	_getScrollButtonVisible: function(button)
	{
		if (button && button.nodeName == "A")
		{
			return button.style.display != "none";
		}
	},

	__setCaretTo: function(obj)
	{
		var pos = obj && obj.type == 'text' && obj.nodeName == 'INPUT' ? obj.value.length : 0;
		if (pos) try
		{
			if (obj.createTextRange)
			{
				var range = obj.createTextRange();
				range.move('character', pos);
				range.select();
			}
			else if (obj.selectionStart)
				obj.setSelectionRange(pos, pos);
		} catch (ex) { }
	},
	/////////////////////////////////////////////////// END SCROLLING FEATURE ////////////////////////////////////

	/////////////////////////////////////////////OBSOLETE CODE////////////////////////////////////////////////////
	

	__showItemOld: function(item)
	{
		
		var sg = item._get_subgroup();

		if (!sg || sg.style.display != 'none')
			return false;
		if (item)
		{
			
			args = this._raiseClientEvent('ItemExpanding', 'DataMenuItemCancel', null, null, item);
			if (args && args.get_cancel())
				return false;
		}
		
		var pageDims = this.__getPageDimensions();
		var itemElement = item.get_element();
		var itemGroupSettings = item.get_itemsGroupSettings();
		var orientation = itemGroupSettings.get_orientation();
		var bounds = Sys.UI.DomElement.getBounds(itemElement);
		var level = item.get_level();
		
		if (level === 0)
		{
			var h = this._element.offsetHeight, w = this._element.offsetWidth;
			if ($util.IsChrome || $util.IsSafari)
			{
				h = Math.max(h - 1, 0);
				w = Math.max(w - 1, 0);
			}
			bounds.height = Math.min(bounds.height, h);
			bounds.width = Math.min(bounds.width, w);
		}

		sg.style.position = 'absolute';
		sg.style.display = 'block';
		sg.style.visibility = 'hidden';
		sg.style.zIndex = "10000";

		if (sg.style.width == "" && orientation == $IG.Orientation.Horizontal)
		{
			var sgBounds = $util.IsIE7 ? this.__getElementBoundsEx(sg) : this.__getElementBounds(sg);
			sg.style.width = sgBounds.width + 'px';
			delete sgBounds;
		}
		//this._resizeSeparators(item, sg.offsetWidth, item.get_childItem(0, false)._element.offsetHeight);
		
		this.__resizeListItems(item);
		
		sg.style.marginTop = "0px";
		sg.style.marginLeft = "0px";
		var x = 0, y = 0;
		if (item.get_orientation() == $IG.Orientation.Vertical || (level == 0 && this.get_orientation() == $IG.Orientation.Vertical))
		{
			x += bounds.width;
		}
		else
		{
			y += bounds.height;
		}

		var p0 = $util.getLocation(itemElement);
		var p1 = $util.getLocation(sg);
		x += p0.x - p1.x;
		y += p0.y - p1.y;

		if (!$util.IsIE && level > 0)
		{
			scrolls = item.calcScrolls();
			x += scrolls.Left;
			y += scrolls.Top;
		}

		
		var dx = item.get_itemsGroupSettings().get_offsetX(), dy = item.get_itemsGroupSettings().get_offsetY();
		x += dx;
		y += dy;

		sg.style.marginTop = y + 'px';
		sg.style.marginLeft = x + 'px';
		
		var expandDirection = this._getExpandDir(item);
		var sgBounds = Sys.UI.DomElement.getBounds(sg);
		var itemsBounds = Sys.UI.DomElement.getBounds(itemElement);
		// note: _dirs is created within _getExpandDir
		var fix, edge, dir = this._dirs[level];
		if (item.get_orientation() == $IG.Orientation.Horizontal)
		{
			fix = itemsBounds.height + sgBounds.height + 2 * dy;
			edge = sgBounds.y + sgBounds.height;
			
			dir.dir = $IG.MenuExpandDirection.Down;
			
			
			if ((expandDirection == $IG.MenuExpandDirection.Up && sgBounds.y - fix >= pageDims.ScrollTop) || edge > pageDims.MaxY)
			{
				dir.dir = $IG.MenuExpandDirection.Up;
				// available space between top edge of browser and top edge of parent menu-item is larger than space below parent menu item
				if (itemsBounds.y - pageDims.ScrollTop > pageDims.MaxY - sgBounds.y)
					// do not allow top edge of child menu appear beyond top edge of browser
					fix = Math.min(fix, sgBounds.y - pageDims.ScrollTop);
				// do not allow bottom edge of child menu appear beyond bottom edge of browser
				else if (edge > pageDims.MaxY)
					// do not allow right edge of child menu appear beyond right edge of browser
					fix = edge - pageDims.MaxY;
				if (fix)
					// adjust position of child menu
					sg.style.marginTop = (y - fix) + 'px';
			}
		}
		else if (item.get_orientation() == $IG.Orientation.Vertical)
		{
			fix = itemsBounds.width + sgBounds.width + 2 * dx;
			edge = sgBounds.x + sgBounds.width;
			
			dir.dir = $IG.MenuExpandDirection.Right;
			
			
			if ((expandDirection == $IG.MenuExpandDirection.Left && sgBounds.x - fix >= pageDims.ScrollLeft) || edge > pageDims.MaxX)
			{
				dir.dir = $IG.MenuExpandDirection.Left;
				// available space between left edge of browser and left edge of parent menu-item is larger than space on right side of parent menu item
				if (itemsBounds.x - pageDims.ScrollLeft > pageDims.MaxX - sgBounds.x)
					// do not allow left edge of child menu appear beyond left edge of browser
					fix = Math.min(fix, sgBounds.x - pageDims.ScrollLeft);
				else if (edge > pageDims.MaxX)
					// do not allow right edge of child menu appear beyond right edge of browser
					fix = edge - pageDims.MaxX;
				if (fix)
					// adjust position of child menu
					sg.style.marginLeft = (x - fix) + 'px';
			}
		}
		dir.useDad = dir.useDad || expandDirection != dir.dir;

		item.set_expanded(true);
		this._visibleItems[item._get_address()] = item;
		if (itemGroupSettings.get_enableAnimation())
		{
			this.__animateItem(item);
		}
		else
		{
			sg.style.visibility = 'visible';
			
		    // show iframe for item
		    // D.A. Bug #176716 Removing showHideIframe used to support IE6. It was causing huge performance impact.
			//this._showHideIframe(item, sg);

			this._raiseClientEvent("ItemExpanded", "DataMenuItemCancel", null, null, item);
		}
		return true;
	}
	
	
	
	//_showHideIframe: function (item, elem)
	//{
	//	var iframe = this._iframe, style = iframe ? iframe.style : null;
	//	item = item ? item._get_address() : null;
	//	// hide iframe
	//	if (!elem)
	//	{
	//		if (!iframe || item != iframe._item)
	//			return;
	//		style.display = 'none';
	//		style.visibility = 'hidden';
	//	}
	//	if (!iframe)
	//	{
	//		iframe = this._iframe = document.createElement('IFRAME');
	//		iframe.textContent = 'Your browser does not support iframes';
	//		iframe.src = 'javascript:"<html></html>"';
	//		iframe.frameBorder = 0;
	//		iframe.scrolling = 'no';
	//		iframe.allowtransparency = 'true';
	//		style = iframe.style;
	//		style.position = 'absolute';
	//		/* VS 01/30/2013 Bug 131452: $util.setOpacity(0) fails */
	//		style.opacity = 0;
	//		style.filter = 'alpha(opacity=0)';
	//	}
	//	else if (iframe.parentNode)
	//	{
	//	    iframe.parentNode.removeChild(iframe);
	//		/* OK 5/31/2012 111979 - in IE7 deleting this causes and exception */
	//		iframe._item = null;
	//	}
	//	if (!elem)
	//		return;
	//	iframe._item = item;
	//	var eStyle = elem.style, zi = parseInt((eStyle.zIndex || 0), 10);
	//	/* OK 6/11/2012 110979 - IE8 when set to have DocumentMode of IE7 still says its IE8, so we have to look at the actual document mode to get this right */
	//	var dm = parseFloat(document.documentMode);
	//	/* OK 6/6/2012 110979 - Menu item children are drawn behind parent�s parent menu in IE7 Standards. */
	//	if (($util.IsIE7 || (!isNaN(dm) && dm == 7 && $util.IsIE8)) && this.get_enableScrolling() && zi && elem.parentNode)
	//		elem.parentNode.style.zIndex = zi;
	//	style.marginLeft = eStyle.marginLeft;
	//	style.marginTop = eStyle.marginTop;
	//	var bounds = this.__getElementBounds(elem);
	//	style.width = (bounds.width || 0) + 'px';
	//	style.height = (bounds.height || 0) + 'px';
	//	style.zIndex = zi - 1;
	//	elem.parentNode.appendChild(iframe);
	//	style.display = 'block';
	//	style.visibility = 'visible';
	//}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

$IG.WebDataMenu.registerClass('Infragistics.Web.UI.WebDataMenu', $IG.NavControl);

$IG.WebDataMenu.find = function (clientID)
{
	///<summary>Finds WebDataMenu by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDataMenu">Reference to the WebDataMenu control object that corresponds to specified client ID.</returns>
};

$IG.WebDataMenu.from = function (obj)
{
	///<summary>Casts passed in object to the WebDataMenu type.</summary>
	///<param name="obj">Object to convert to the WebDataMenu type.</param>
	///<returns type="Infragistics.Web.UI.WebDataMenu">Reference to the same object that is passed in, only type converted to the WebDataMenu type.</returns>
};


$IG.DataMenuItemCollection = function(control, clientStateManager, index, manager)
{
    ///<summary locid="T:J#Infragistics.Web.UI.DataMenuItemCollection">
    /// Used internally to construct the DataMenuItemCollection of the WebDataMenu
    ///</summary>
    $IG.DataMenuItemCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.DataMenuItemCollection.prototype = 
{
    _createNewCollection:function(parent)
    {
        var nodes = new $IG.DataMenuItemCollection(this._control, this._csm, this._index, this._manager);
        nodes._ownerNode = parent ? parent : this;
        return nodes;
    },

    _createObject: function(adr, element)
	{
		var item = this._addObject($IG.DataMenuItem, element, adr);
        item._set_itemsGroupSettings(this._control._groupSettingsCollection.getGroupSettingsObjectByAdr(adr));
        return item;
	},

    getItem:function(index)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.getItem">
        /// Get the item at the specified index in the collection.
        ///</summary>
        ///<param name="index" type="int">Specify index of an item.</param>
        ///<returns type="Infragistics.Web.UI.DataMenuItem" mayBeNull="true">The menu item at the specified index. Null if index is out of range.</returns>
        var item = null;
        if(index >= 0)
        {
            item = this._getObjectByIndex(index);
		    if (!item)
		    {
                if (!this._owner)
                    return null;

	            var adr;
	            if(this._owner._get_address)
		            adr = this._owner._get_address() + "." + index;
	            else
		            adr = index.toString();

	            item = this._getObjectByAdr(adr);
		    }
        }
        return item;
    },

    _getObjectByAdr: function(adr)
	{
		var item = $IG.DataMenuItemCollection.callBaseMethod(this, '_getObjectByAdr', [adr]);
		if(item)
        {
			return item;
        }
		// Lazy loading of items
		var elem = this._findDomElementByAdr(adr);
        return this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(elem);
	},

	_addObject:function(navItemType, element, adr)
	{
		var object = null;		
		var indexes = adr.split('.');
		if(indexes.length == 1)
		{
			var val = parseInt(adr);
			if(val.toString() != "NaN")
				object = this._items[val] = new navItemType(adr, element,  null, this._control, this._csm, this._createNewCollection(), null);
		}
		else
		{
			var scrollDiv = element.parentNode.parentNode; // get through the UL to the scroll div.
			// if the element has been moved it will have realParent, if not we will use the parentNode.
			var parentElem = (this._control.get_enableScrolling() ? (scrollDiv.realParent ? scrollDiv.realParent : scrollDiv.parentNode) : scrollDiv);			
			var parent = this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(parentElem);
			if(parent != null)
			{
				var parentCollection = parent.getItems();
				object = new navItemType(adr, element, null, this._control, this._csm, this._createNewCollection(parentCollection), parent);
				parentCollection._items[$adrutil.indexOfDomElement(element)] = object;
			}
		}
		this._manager.addObject(this._index, adr, object);
		return object;
	},

    _findDomElementByAdr: function(adr)
	{
        var nodes = this._control.get_element().getElementsByTagName("li");
        for(var i=0, len=nodes.length; i < len; i++)
        {
            var li = nodes[i];
            // D.A. 14th Feb 2014, Bug #164273 Updated to get the items by 'data-ig' attribute
            var nodeId = li.getAttribute("data-ig");
            if($adrutil.getAdrFromId(nodeId) === adr)
            {
                return li;
            }
        }
        return null;
	},

	_get_childrenCount: function(rootElement) 
	{
		///<summary>
		/// Returns the subnodes count of the given root element.
		///</summary>
		var count = 0, child = (rootElement && rootElement.tagName == "UL") ? rootElement.firstChild : null;
		while(child)
		{
			if (child.tagName == "LI")
				count++;
			child = child.nextSibling;
		}
		return count;
	},

    getChildrenCount: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.getChildrenCount">Get number of items in the collection.</summary>
        ///<value type="int"></value>
        if($util.isNullOrUndefined(this.__itemCount))
        {
            this.__itemCount = this._get_childrenCount(this._owner._get_subgroup());
        }
        return this.__itemCount;
    },

    get_length: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DataMenuItemCollection.length">
		/// The number of objects in the collection.
		///</summary> 
		///<returns type="Integer" mayBeNull="false">Number of objects in the collection.</returns>
		return this.getChildrenCount();
	},

	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataMenuItemCollection.dispose">
		/// Disposes the object. 
		///</summary>
		this._ownerNode = null;
		$IG.DataMenuItemCollection.callBaseMethod(this, "dispose");
		if (this._docMouseFn)
			$removeHandler(document, 'mousedown', this._docMouseFn);
		delete this._docMouseFn;
	}
}
$IG.DataMenuItemCollection.registerClass('Infragistics.Web.UI.DataMenuItemCollection', $IG.NavItemCollection);



$IG.DataMenuGroupSettingsCollection = function(control, clientStateManager, index, manager)
{
    $IG.DataMenuGroupSettingsCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.DataMenuGroupSettingsCollection.prototype = 
{
    getGroupSettingsObjectByAdr: function(adr)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettingsCollection.getGroupSettingsObjectByAdr">Get new instance of DataMenuGroupSettings.</summary>
        /// <param name="adr">Address of collection.</param>
        /// <returns type="Object">DataMenuGroupSettings.</returns>
        return new $IG.DataMenuGroupSettings(null, [this._csm._items[adr]], this._control);
    }
}
$IG.DataMenuGroupSettingsCollection.registerClass('Infragistics.Web.UI.DataMenuGroupSettingsCollection', $IG.ObjectCollection);




$IG.DataMenuItemCancelEventArgs = function(eventName, params)
{
    ///<summary locid="T:J#Infragistics.Web.UI.DataMenuItemCancelEventArgs">
    /// Used internally to constuct cancelable event arguments to be passed to WebDataMenu event handlers
    ///</summary>
    $IG.DataMenuItemCancelEventArgs.initializeBase(this);
	this._context = {};
	// L.T. 4/11/2010 59265 exception when ItemHovered is raised.
	if(params && params[0])
		this._props[2] = params[0];

	if(this._props[2])
		this._context["adr"] = this.getItem()._get_address();
}

$IG.DataMenuItemCancelEventArgs.prototype =
{
    
    getItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.getItem">Get the menu item for which the event fired.</summary>
        ///<value type="Infragistics.Web.UI.DataMenuItem"></value>
        return this._props[2];
    },

    dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DataMenuGroupSettings.dispose">Disposes object.</summary>
		this._props[0] = null;
		this._props[1] = null;
		this._props[2] = null;
	},
	get_postBack: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.postBack">Gets postback flag.</summary>
		/// <value type="Number">One of the following: 0 - do not trigger postback, 1 - trigger full postback, 2 - trigger async postback.</value>
		return this._props[1];
	},
	set_postBack: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataMenuGroupSettings.postBack">Sets postback flag.</summary>
		/// <param name="val" type="Number">One of the following: 0 - do not trigger postback, 1 - trigger full postback, 2 - trigger async postback.</param>
		this._props[1] = val;
	},
    _getPostArgs: function()
    {
        return ':' + this.getItem()._get_address();
    }
}
$IG.DataMenuItemCancelEventArgs.registerClass('Infragistics.Web.UI.DataMenuItemCancelEventArgs', $IG.CancelEventArgs);



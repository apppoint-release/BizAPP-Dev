/*
* igWebDropDown.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');

$IG.WebDropDown = function(element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebDropDown">
	/// the WebDropDown is an AJAX-enabled control ASP.NET consisting of an input box and a dropdown list of items
	/// its main functionalities include auto-complete/suggest, selection, value editing, binding to many
	/// data sources out of the box, templating, and a rich client-side and server-side API
	/// </summary>
	$IG.WebDropDown.initializeBase(this, [element]);

	this._bindings = this._getPropertyBindings();

	$IG.WebDropDown.find = $find;
	$IG.WebDropDown.from = $IG._from;
}

$IG.WebDropDown.prototype =
{

	_thisType: 'dropDown',
	_supportsClientRendering: true,
	_usesCollectionsClientState: true,
	//_clickedOutside: false,

	
	initialize: function ()
	{
		$IG.WebDropDown.callBaseMethod(this, 'initialize');

		if (this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
		{
			this._checkedAlt = this._get_clientOnlyValue("chkAT");
			this._uncheckedAlt = this._get_clientOnlyValue("unchkAT");
			
			this._element.value = this.get_currentValue() || this._elements["Input"].value;
		}

		// Client rendering
		if (this._get_enableClientRendering())
		{
			if (typeof (jQuery) === "undefined")
			{
				throw new Error("The Infragistics WebDropDown Client Rendering requires jQuery to be loaded");
			}

			// Fire the databinding event
			var args = this._raiseClientEvent("DataBinding", "DropDownControl", null, null);

			var rootList = $(this._elements['DropDown']).children().children('ul'); // Selects the UL element of the drop down
			//var template = '<li><a>${Text}</a></li>';
			var template, cachedTemplate = this.get_template();

			if (cachedTemplate && cachedTemplate.firstChild)
				template = cachedTemplate; // Template has already been cloned or set by user on the user end
			else
			{
				template = rootList[0].cloneNode(true); // Clone the template
				this.set_template(template); // Store the template
			}

			rootList.empty(); // Clear the ${Text} from the drop down

			// If event is not canceled run the databinding with the data coming from the server
			if (args == null || !args.get_cancel())
			{
				this._dataBind();
			}
			else
			{
				// Wait for the DataBind call because then datasource would be provided externally using the set_dataSource
				this._awaitingData = true;
			}
		}

		//A.T. 08/07/2009 Fix for bug 19154
		// strip whitespace nodes, Firefox is really annoying because it considers these as real nodes
		var list = this._elements["List"];
		// K.D. May 18, 2011 Bug #75145 When an item selection in dropdown list is selected after a post-back , incorrect item is checked relative to the item selected
		if (list && (!$util.IsIE || $util.IsIE9Plus))
		{
			this.__clearTextNodesFromUL();
		}

		if ($util.IsIE6)
		{
			// L.T. 22/12/2010 61575, WDD does not render correctly under IE6.
			Sys.UI.DomElement.addCssClass(this._element, "ie6");
		}
		// we use the shared DropDown behavior for the dropdown control as well
		var dd = this.behavior = new $IG.DropDownBehavior(this._elements["Target"], this.get_dropDownIsChild());
		dd.set_targetContainer(this._elements["DropDown"]);
		
		dd._autoHeight = -this.get_valueListMaxHeight() || -1;

		// this.resizeBehavior = new $IG.ResizeBehavior(this._elements["DropDown"]);

		dd.set_position(this.get_dropDownOrientation());
		if (this.get_dropDownOrientation() != $IG.DropDownPopupPosition.Default)
		{
			dd.set_enableAutomaticPositioning(false);
		}

		dd.set_enableAnimations(this.get_enableAnimations());
		dd.set_animationDurationMs(this.get_dropDownAnimationDuration());
		dd.set_animationType(this.get_dropDownAnimationType());

		// set offsetX and offsetY if any
		if (this.get_offsetX() != 0)
		{
			dd.set_offsetX(this.get_offsetX());
		}

		if (this.get_offsetY() != 0)
		{
			dd.set_offsetY(this.get_offsetY());
		}
		// set dropdown container height
		// if (this.get_dropDownContainerHeight() && parseInt(this.get_dropDownContainerHeight()) > 0)
		// {
		//     var height =  parseInt(this.get_dropDownContainerHeight());
		//     $util.setAbsoluteHeight(this._elements["DropDown"], height);
		// }

		// this is used in case the EditorID property is set on the server-side control, and we want to use
		// out of the box Infragistics editors such as mask editors, percentage editors, etc
		// in that case we just set the reference of the editor to be our target and it is positioned correctly once the
		// dropdown behavior is initialized
		// we assume all editors we want to link to, are presented by HTML INPUT components
		if (this.get_editorID() != null)
		{

			var editor = $get(this.get_editorID());
			if (editor != null && editor.nodeName == "INPUT")
			{
				editor.className = this._elements["Input"].className;
				this._elements["Input"].parentNode.replaceChild(editor, this._elements["Input"]);
				//  this._elements["Input"].parentNode.appendChild(editor);
				this._elements["Input"] = editor;

				var inputCustomDelegate = Function.createDelegate(this, this._onKeyupHandler);
				$addHandler(this._elements["Input"], 'keyup', inputCustomDelegate);
			}


		}

		// client cache can be configured and means that once we do a auto-suggest postback to fetch results, they are 
		// cached on the client, so if the user subsequently types the same string, we don't go to the server again
		this._clientCache = [];
		//this._activeItem = this.get_activeItemIndex() == -1 ? null : this.get_items()._getObjectByIndex(this.get_activeItemIndex());
		if (!this._awaitingData) {
			this._activeItem = this.get_activeItemIndex() == -1 ? null : this.get_items().getItem(this.get_activeItemIndex());
			this._selectedItem = this.get_selectedItemIndex() == -1 ? null : this.get_items().getItem(this.get_selectedItemIndex());
			this._clientStateManager.override_value($IG.DropDownProps.SelectedItemIndex, $IG.DropDownProps.SelectedItemIndex[1]);
		}

		// attach the delegate for selection
		var dropDownList = this._elements["List"];
		var selectDelegate = Function.createDelegate(this, this._select);
		// A.T. 12 March 2010 - fix for bug #28867 (changing 'mousedown' to 'mouseup')
		$addHandler(dropDownList, 'mouseup', selectDelegate);

		//this._docClickHandler = Function.createDelegate(this, this._onDocumentClick);
		//$addHandler(document, 'click', this._docClickHandler);

		// K.D. January 5th, 2012 Bug #75133 FF Opens a new tab on ctrl+click and a new window on shift+click
		var clickHandler = Function.createDelegate(this, this._onClickHandler);
		$addHandler(dropDownList, 'click', clickHandler);

		var blurDelegate = Function.createDelegate(this, this._onBlurHandler);
		$addHandler(this._elements["Input"], 'blur', blurDelegate);

		var focusDelegate = Function.createDelegate(this, this._onFocusHandler);
		$addHandler(this._elements["Input"], 'focus', focusDelegate);

		var compositionStartDelegate = Function.createDelegate(this, this._onCompositionStartHandler);
		$addHandler(this._elements["Input"], 'compositionstart', compositionStartDelegate);

		var compositionEndDelegate = Function.createDelegate(this, this._onCompositionEndHandler);
		$addHandler(this._elements["Input"], 'compositionend', compositionEndDelegate);


		var inputMouseOutDelegate = Function.createDelegate(this, this._onInputMouseOutHandler);
		$addHandler(this._elements["Input"], 'mouseout', inputMouseOutDelegate);

		var inputMouseOverDelegate = Function.createDelegate(this, this._onInputMouseOverHandler);
		$addHandler(this._elements["Input"], 'mouseover', inputMouseOverDelegate);

		var mouseOver = Function.createDelegate(this, this._mouseOverForBlur);
		$addHandler(this._elements["DropDown"], 'mouseover', mouseOver);

		var pasteHandler = Function.createDelegate(this, this._onPasteHandler);
		$addHandler(this._elements["Input"], 'paste', pasteHandler);

		var cutHandler = Function.createDelegate(this, this._onCutHandler);
		$addHandler(this._elements["Input"], 'cut', cutHandler);

		var changeHandler = Function.createDelegate(this, this._onChangeHandler);
		$addHandler(this._elements["Input"], 'change', changeHandler);

		// K.D. July 25th, 2014 Bug #171683 The drop down closes the first time the list gets mousedown
		if (!$util.IsIE) {
			$addHandler(dropDownList, 'mousedown', function (e) { $util.preventDefaults(e); });
			$addHandler(this._elements["Button"], 'mousedown', function (e) { $util.preventDefaults(e); });
		}
		// we have an option to show / hide the button next to the input box
		// if it is hidden we shouldn't attach any event handlers
		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			$addHandler(this._elements["Button"], 'mouseover', mouseOver);
			$addHandler(this._elements["ButtonImage"], 'mouseover', mouseOver);
		}

		var mouseOut = Function.createDelegate(this, this._mouseOutForBlur);
		$addHandler(this._elements["DropDown"], 'mouseout', mouseOut);


		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			$addHandler(this._elements["Button"], 'mouseout', mouseOut);
			$addHandler(this._elements["ButtonImage"], 'mouseout', mouseOut);
		}

		// we listen to browser scroll events for the LoadOnDemand feature - we check if the
		// current scrollTop value has reached a certain treshold (i.e. if the scrollbar is at the end of the container
		// and then invoke the load on demand postback
		if (this.get_enableLoadOnDemand())
		{
			var loadOnDemandDelegate = Function.createDelegate(this, this._scrollingLoadOnDemand);
			$addHandler(this._elements["DropDownContents"], 'scroll', loadOnDemandDelegate);
		} // else
		//{
		





		// catch blur on the list
		var listBlurDelegate = Function.createDelegate(this, this._listBlurHandler);
		$addHandler(this._elements["DropDownContents"], 'blur', listBlurDelegate);
		//}
		
		if (($util.IsSafari || $util.IsChrome) && !this.get_dropDownIsChild())
		{
			this._elements["DropDownContents"].tabIndex = "-1";
			this._elements["DropDownContents"].style.outline = "none";
		}
		// pager event
		if (this.get_enablePaging())
		{
			//var pagerDelegate = Function.createDelegate(this, this._onPagerMoreResults);
			//$addHandler(this._elements["PagerLink"], 'mousedown', pagerDelegate);

			if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPrevious)
			{
				var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
				$addHandler(this._elements["PagerPrevLink"], 'mousedown', pagerPrevDelegate);

				var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
				$addHandler(this._elements["PagerNextLink"], 'mousedown', pagerNextDelegate);

			} else if (this.get_pagerMode() == $IG.DropDownPagerMode.Numeric || this.get_pagerMode() == $IG.DropDownPagerMode.NumericFirstLast)
			{
				var numberDelegate = Function.createDelegate(this, this._onPagerNumberResults);
				// for (var i=0; i<this.get_pageCount(); i++)
				// {
				//     $addHandler(this._elements["PagerNumberLink"], 'mousedown', numberDelegate);
				// }
				// attach the handler on the pager itself
				$addHandler(this._elements["Pager"], 'mousedown', numberDelegate);

				// check if we have quick pages
				if (this._elements["PagerQPPrevLink"])
				{
					var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
					$addHandler(this._elements["PagerQPPrevLink"], 'mousedown', pagerPrevDelegate);
				}

				if (this._elements["PagerQPNextLink"])
				{
					var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
					$addHandler(this._elements["PagerQPNextLink"], 'mousedown', pagerNextDelegate);
				}

			} else if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPreviousFirstLast)
			{
				var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
				$addHandler(this._elements["PagerPrevLink"], 'mousedown', pagerPrevDelegate);

				var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
				$addHandler(this._elements["PagerNextLink"], 'mousedown', pagerNextDelegate);

				var pagerFirstDelegate = Function.createDelegate(this, this._onPagerFirstResults);
				$addHandler(this._elements["PagerFirstLink"], 'mousedown', pagerFirstDelegate);

				var pagerLastDelegate = Function.createDelegate(this, this._onPagerLastResults);
				$addHandler(this._elements["PagerLastLink"], 'mousedown', pagerLastDelegate);
			}
		}

		// we need to detach the span element displaying the loading message and display it on top of the 
		// list, so that it doesn't take any space for the items, and we don't have unwanted visual effects
		// i mean the list popping up and down to accomodate the loading message element
		if (this.get_loadingItemsMessageText() != null)
		{
			this.__detachLoadingItemsMessage();
		}

		// attach the delegate for keyboard navigation
		var navDelegate = Function.createDelegate(this, this._navigateItems);
		$addHandler(dropDownList, 'keydown', navDelegate);

		var mouseOverDelegate = Function.createDelegate(this, this._onMouseoverListHandler);
		$addHandler(dropDownList, 'mouseover', mouseOverDelegate);

		var mouseOutDelegate = Function.createDelegate(this, this._onMouseoutListHandler);
		$addHandler(dropDownList, 'mouseout', mouseOutDelegate);

		// behavior.init();
		// var valueDisplay = this._elements["Input"];
		// $addHandler(valueDisplay, "keydown", Function.createDelegate(this, this._onInputKeyDownHandler) );

		dd._setAnimationEndListener(this);

		// initialize the dropdown behavior
		dd.init();

		if (this.get_valueListMaxHeight() > 0)
		{
			dd.set_containerMaxHeight(this.get_valueListMaxHeight(), this._elements["List"], this._elements["DropDownContents"]);
		}

		if (this.get_enableDropDownContainerAutoWidth())
		{
			var height = this.get_valueListMaxHeight() > 0 ? this.get_valueListMaxHeight() : this.get_dropDownContainerHeight();
			dd.set_containerAutoWidth(this._elements["List"], this._elements["DropDown"], height);
		}

		// restore value
		//A.T. 18/11/2009 Fix for bug #24952
		// K.D. October 14th, 2011 Bug #91350 Performing a check against the length of the current value because null text
		// may be set and it's being overridden
		if (this.get_currentValue() != null && this.get_currentValue != undefined && this.get_currentValue().length > 0)
		{
			this._elements["Input"].value = this.get_currentValue();
		}

		this.set_hoverItemIndex(-1);
		//this._elements["Input"].focus();

		// manage max drop down height property
		//  this._adjustMaxHeight();


		// A.T. 17/08/2009 Support for Ajax Indicator
		if (this._pi != null)
		{
			this._pi.setRelativeContainer(this._elements["DropDown"]);
		}

		// fire the initialize client-side event
		this._raiseClientEvent('Initialize', 'DropDown', null, null);

		this.__blurFlag = true;

		this.__clearTextNodesFromUL();

		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
		{
			this.__clientFilteringItemCount = this.get_items().getLength();

			for (i = 0; i < this.get_items().getLength(); i++)
			{
				// dummy, serves just to create every item, since lazy loading & client side filtering require some special attention
				this.get_items().getItem(i);
			}
		}

		this.__keydowncount = 0;

		// pre-load button images 
		if (this.get_buttonNormalImageUrl() != null && this.get_buttonNormalImageUrl() != "")
		{
			var buttonNormalImage = new Image();
			buttonNormalImage.src = this.get_buttonNormalImageUrl();
		}

		if (this.get_buttonHoverImageUrl() != null && this.get_buttonHoverImageUrl() != "")
		{
			var buttonHoverImage = new Image();
			buttonHoverImage.src = this.get_buttonHoverImageUrl();
		}

		if (this.get_buttonPressedImageUrl() != null && this.get_buttonPressedImageUrl() != "")
		{
			var buttonPressedImage = new Image();
			buttonPressedImage.src = this.get_buttonPressedImageUrl();
		}

		// restore back button state if any
		var backState = this._getBackState(0);

		if (backState != null && !this.get_enableMultipleSelection())
		{
			this.__restoreBackButtonValues(backState);
		}

		//A.T. 19 March Fix for bug #29627 - LoadItems function opens dropdown container automatically.
		this.__openAfterLoad = true;

	},

	//_onDocumentClick: function (event) {
	//    this._clickedOutside = false;

	//    try {
	//        if (this.get_element() && this.get_element().id != event.target.id && event.target.id != this._elements["Input"].id) {
	//            this._clickedOutside = true;
	//            // K.D. July 16th, 2013 Bug #145376 The list closes on blur even if enableClosingDropDownOnBlur
	//            // is false
	//            if (this.get_enableClosingDropDownOnBlur()) {
	//                this.__closeOnListBlur();
	//            }
	//        }
	//    }
	//    catch (ex) { }
	//},

	///
	/// restores the CurrentValue and the SelectedItemIndex, also marks the corresponding item as selected
	/// 
	__restoreBackButtonValues: function (backState)
	{
		var states = backState.split('|');

		// states[0] - current value
		if (states[0])
		{
			this.set_currentValue(states[0], true);
		}
		// states[1] - selected item index
		if (states[1])
		{
			this.set_selectedItemIndex(states[1]);
			var item = this.get_items().getItem(states[1]);
			if (item)
			{
				item.select();
			}
		}
	},

	__clearTextNodesFromUL: function ()
	{
		// clear text nodes: Firefox and other browsers consider text as a node, so the UL.childNodes.length is wrong !
		var initialLength = this._elements["List"].childNodes.length;
		for (i = 0; i < initialLength; i++)
		{
			if (this._elements["List"].childNodes[i] && this._elements["List"].childNodes[i].tagName != 'LI')
			{
				this._elements["List"].removeChild(this._elements["List"].childNodes[i]);
			}
		}
	},

	// add global control event handlers 
	_addHandlers: function ()
	{

		$IG.WebDropDown.callBaseMethod(this, '_addHandlers');
		this._registerHandlers(["keydown", "keyup", "mouseup", "mousedown", "keypress", "mouseover", "mouseout"]);
	},

	
	_registerEventListener: function (obj, evntName, listener, priority)
	{
		if (obj._internalEventListeners == null)
			obj._internalEventListeners = {};
		if (obj._internalEventListeners[evntName] == null)
			obj._internalEventListeners[evntName] = [];

		if (priority)
			obj._internalEventListeners[evntName].unshift(listener);
		else
			obj._internalEventListeners[evntName].push(listener);
	},

	
	_fireEvent: function (obj, evntName, args)
	{
		if (obj._internalEventListeners == null)
			return;

		var listeners = obj._internalEventListeners[evntName];
		if (listeners != null && listeners.length > 0)
		{
			for (var i = 0; i < listeners.length; i++)
				if (listeners[i](args))
					return true;
		}
		return false;
	},
	
	_unregisterEventListener: function (obj, evntName, listener)
	{
		if (obj._internalEventListeners == null)
			return;

		var listeners = obj._internalEventListeners[evntName];
		if (listeners != null && listeners.length > 0)
		{
			for (var i = 0; i < listeners.length; i++)
			{
				if (listeners[i] == listener)
				{
					Array.removeAt(obj._internalEventListeners[evntName], i);
					return;
				}
			}
		}
	},
	dataBind: function ()
	{
		// Public databind method to be called after canceling the databinding event with the new datasource
		if (this._get_enableClientRendering())
		{
			this._awaitingData = false;
			this._setupCollections();
			this._collectionsManager._items = this._dataStore[4];
			this._collectionsManager._itemCollections[0]._csm._items = this._dataStore[4];
			// K.D. July 3rd, 2013 Bug #144780 If we call internal databind with timeout then the collections are not properly setup on rebinding
			this._dataBind();
		}
	},

	







	_dataBind: function ()
	{
		// Private databind
		var json = this.get_dataSource();

		// Generate FullAddress-es if they haven't been generated in the items
		this._generateJSONAddresses(json);

		var rootList = $(this._elements['DropDown']).children().children('ul'); // Selects the UL element of the drop down
		//var template = '<li><a>${Text}</a></li>';
		var template, cachedTemplate = this.get_template();

		// K.D. June 27th, 2011 Bug #75499 The template was not properly retrieved when set by the client
		if (cachedTemplate)
			template = cachedTemplate; // Template has already been cloned or set by user on the user end
		else
		{
			template = rootList[0].cloneNode(true); // Clone the template
			this.set_template(template); // Store the template
		}

		rootList.empty(); // Clear the ${Text} from the drop down
		var checkBoxes = this.get_enableMultipleSelection() && this.get_multipleSelectionType() === $IG.DropDownMultipleSelectionType.Checkbox ? this.get_displayMode() : -1;
		for (var i = 0, len = json.length; i < len; i++)
		{
			// To do: create the template entirely on the client side and do not send it from the server

			var item = json[i];
			// K.D. June 27th, 2011 Bug #75499 The template was not properly retrieved when set by the client
			$.tmpl(template, item).appendTo(rootList[0]);

			var itemList = $(rootList[0].lastChild);
			var itemAnchor = $(itemList[0].lastChild);

			// Li item attributes
			if (item.cssClass && item.cssClass.length > 0)
				itemList.addClass(item.cssClass);
			else
				itemList.addClass(this._get_clientOnlyValue("dropDownItemClass"));

			if (item.Selected && item.Selected === $IG.DropDownItemProps.Selected[0])
			{
				if (item.selectedCssClass && item.selectedCssClass.length > 0)
					itemList.addClass(item.selectedCssClass);
				else
					itemList.addClass(this._get_clientOnlyValue("dropDownItemSelected"));
			}
			if (item.Active && item.Active === $IG.DropDownItemProps.Activated[0])
			{
				if (item.activeCssClass && item.activeCssClass.length > 0)
					itemList.addClass(item.activeCssClass);
				else
					itemList.addClass(this._get_clientOnlyValue("dropDownItemActiveClass"));
			}
			if (item.Disabled && item.Disabled === $IG.DropDownItemProps.Disabled[0])
			{
				if (item.disabledCssClass && item.disabledCssClass.length > 0)
					itemList.addClass(item.disabledCssClass);
				else
					itemList.addClass(this._get_clientOnlyValue("controlDisabledClass"));
			}
			if (item.Visible && item.Visible === 'false')
				itemList.css({ display: 'none', visibility: 'hidden' });

			if (item.Tooltip && item.Tooltip.length > 0)
				itemList.attr('title', item.Tooltip);

			itemList.attr($util._xAttr, this._getHashCode() + ':adr:' + item.FullAddress);
			itemList.attr('adr', item.FullAddress);

			// Checkbox input renderer
			if (checkBoxes >= 0)
			{
				var checkBox = document.createElement('INPUT');
				checkBox.type = 'checkbox';

				if (item.Selected && item.Selected === $IG.DropDownItemProps.Selected[0])
				{
					checkBox.checked = true;
					checkBox.setAttribute('alt', this._checkedAlt);
					checkBox.setAttribute('title', this._checkedAlt);
				}
				else
				{
					checkBox.setAttribute('alt', this._uncheckedAlt);
					checkBox.setAttribute('title', this._uncheckedAlt);
				}

				if (checkBoxes > 1 || (item.Disabled && item.Disabled === $IG.DropDownItemProps.Disabled[0]))
					checkBox.disabled = true;

				itemList[0].insertBefore(checkBox, itemList[0].firstChild);
			}

			// A-nchor attributes
			if (item.NavigateUrl && item.NavigateUrl.length > 0)
				itemAnchor.attr('href', item.NavigateUrl);
			else
				itemAnchor.attr('href', 'javascript:void(0)');
		}
		
		while (len-- > 0)
			this.get_items().getItem(len);
		
		this._raiseClientEvent("DataBound", "DropDownControl", null, null);
	},

	_generateJSONAddresses: function (json)
	{
		// Logic for generating addresses for the JSON data if such haven't already been generated
		if (json && json.length > 0 && json[0].FullAddress)
			return;
		for (var i = 0, len = json.length; i < len; i++)
		{
			json[i].FullAddress = i.toString();
		}
	},

	get_template: function ()
	{
		// Gets the client rendering template
		if (this._clientRenderingTemplate && this._clientRenderingTemplate !== null)
			return this._clientRenderingTemplate;
		return null;
	},

	set_template: function (newTemplate)
	{
		// Sets the client rendering template
		this._clientRenderingTemplate = newTemplate;
	},

	_getPropertyBindings: function ()
	{
		var bindings = [];

		this._addPropertyBindings(bindings, $IG.ObjectBaseProps);
		this._addPropertyBindings(bindings, $IG.ControlObjectProps);
		this._addPropertyBindings(bindings, $IG.ListItemProps);
		this._addPropertyBindings(bindings, $IG.DropDownItemProps);

		return bindings;
	},

	_addPropertyBindings: function (bindingsArray, object)
	{
		for (var property in object)
		{
			if (property != "Count")
				bindingsArray.push(property);
		}
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.dispose">
		/// Clears all attached event handlers and additional references 
		/// </summary>

		// very important - make sure we don't have any memory leaks

		// L.T. 18 October 2010 #56783 Javascript error inside UpdatePanel when Space button is pressed.
		clearTimeout(this._timeoutID);

		$clearHandlers(this.get_element());
		// A.T. 22 April 2010 Fix for bug # 
		$clearHandlers(this._elements["Input"]);

		$clearHandlers(this._elements["Target"]);
		$clearHandlers(this._elements["DropDown"]);
		$clearHandlers(this._elements["List"]);
		$clearHandlers(this._elements["DropDownContents"]);
		if (this._docClickHandler)
			$removeHandler(document, 'click', this._docClickHandler);
		delete this._docClickHandler;

		//A.T. 22 Nov 2010 - additional fix for bug #48330
		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			$clearHandlers(this._elements["Button"]);
			$clearHandlers(this._elements["ButtonImage"]);
		}

		if (this.get_enablePaging())
		{
			if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPrevious)
			{
				$clearHandlers(this._elements["PagerPrevLink"]);
				$clearHandlers(this._elements["PagerNextLink"]);
			}
			else if (this.get_pagerMode() == $IG.DropDownPagerMode.Numeric || this.get_pagerMode() == $IG.DropDownPagerMode.NumericFirstLast)
			{
				$clearHandlers(this._elements["Pager"]);
				if (this._elements["PagerQPPrevLink"])
				{
					$clearHandlers(this._elements["PagerQPPrevLink"]);
				}
				if (this._elements["PagerQPNextLink"])
				{
					$clearHandlers(this._elements["PagerQPNextLink"]);
				}

			} else if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPreviousFirstLast)
			{
				$clearHandlers(this._elements["PagerPrevLink"]);
				$clearHandlers(this._elements["PagerNextLink"]);
				$clearHandlers(this._elements["PagerFirstLink"]);
				$clearHandlers(this._elements["PagerLastLink"]);
			}

		}

		if (this.behavior)
			this.behavior.dispose();

		$IG.WebDropDown.callBaseMethod(this, 'dispose');
	},

	// if the ValueListMaxHeight property is set on the server-side control, we need to calculate whether to set explicit height style or not
	_adjustMaxHeight: function ()
	{

		// do some hacks in order to circumvent flickering issues 
		//  this._elements["DropDownContents"].style.position = 'absolute';
		//  this._elements["DropDownContents"].style.left = -10000;
		//  this._elements["DropDownContents"].style.top = -10000;
		//  this._elements["DropDownContents"].style.display='';
		//  this._elements["DropDownContents"].style.visibility = 'visible';

		//  this._elements["List"].style.display='';
		//  this._elements["List"].style.visibility = 'visible';

		if (this.get_dropDownContainerHeight() > 0 && this.get_valueListMaxHeight() > 0)
		{
			if (this._elements["List"].offsetHeight > this.get_valueListMaxHeight())
			{
				this._elements["DropDown"].style.height = this._elements["DropDownContents"].style.height =
					(this.get_dropDownContainerHeight() ? this.get_dropDownContainerHeight() : this.get_valueListMaxHeight()) + 'px';

			} else
			{

				this._elements["DropDownContents"].style.height = '';
			}
		}

		//  this._elements["DropDownContents"].style.position = '';
		//  this._elements["DropDownContents"].style.left = 0;
		//  this._elements["DropDownContents"].style.top =  0;
		//  this._elements["DropDownContents"].style.display='none';
		//  this._elements["DropDownContents"].style.visibility = 'hidden';

	},
	_adjustMaxWidth: function () {
		if (this._elements["DropDown"].parentNode.offsetWidth < 10) {
			this._elements["DropDown"].parentNode.style.width = this._elements["DropDown"].offsetWidth + 'px';
		}
	},
	// this function allows a developer to programatically populate the dropdown with items, based on certain filtering criteria
	loadItems: function (text, openAfterLoad)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.loadItems"> this function allows a developer to programatically populate the dropdown with items, based on certain filtering criteria </summary>
		/// <param name="text" type="String"> the filtering text to filter by  </param>
		/// <param name="openAfterLoad" type="Boolean"> indicated whether to open the drop down after loading the items  </param>
		// K.D. Encoding the text before sending to the server
		text = encodeURIComponent(text);
		this._setLoadItemsText(text);
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "itemsRequested";
		this.__manualLoadItems = true;
		this.set_valueBeforeFilter(this.get_currentValue());

		// Fixed bug: 133788 by setting the text to the default selected value
		if (this.get_currentValue() && this._elements["Input"].value != this.get_currentValue())
			this._elements["Input"].value = this.get_currentValue();

		// cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(this._clientStateManager.get_transactionList());

		//A.T. 19 March Fix for bug #29627 - LoadItems function opens dropdown container automatically.
		if (openAfterLoad != undefined)
		{
			this.__openAfterLoad = openAfterLoad;
		}

		if (this._pi)
		{
			this._pi.set_enabled(false);
		}
		this._callbackManager.execute(cbo, true);
		if (this._pi)
		{
			this._pi.set_enabled(true);
		}
	},

	// reset cache
	invalidateCache: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.invalidateCache"> Clears all cached items on the client, when EnableCachingOnClient=true </summary>

		this._clientCache = [];
	},

	get_enabled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enabled"> Indicates whether the whole control is enabled or not (if it is editable, and can be opened, items selected, etc.) </summary>
		/// <returns type="Boolean"> boolean flag indicating whether the control is currently enabled </returns>    

		return this._get_value($IG.DropDownProps.Enabled);
	},

	// A.T. 30/06/2009: Fix for bug # 18703 - adding functions to enable / disable control from client-side
	set_enabled: function (controlEnabled)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enabled"> Enables or Disables the control </summary>
		/// <param name="controlEnabled" type="Boolean"> value indicating whether to enable or disable the control   </param>


		this._set_value($IG.DropDownProps.Enabled, controlEnabled);

		if (this._elements["Input"].disabled && !controlEnabled)
		{
			return; // do nothing if control is already disabled and we still want to disable it 
		} else if (!this._elements["Input"].disabled && !controlEnabled)
		{
			this._elements["Input"].disabled = true;
			this._elements["Input"].className = this.get_inputDisabledCssClass();
			this._element.className = this.get_controlDisabledCssClass();

			// change the dropdown image
			if (this.get_showDropDownButton() && this._elements["ButtonImage"])
			{
				if (this._elements["ButtonImage"] && this.get_buttonDisabledImageUrl() != null && this.get_buttonDisabledImageUrl() != "" && this._elements["ButtonImage"].src != this.get_buttonDisabledImageUrl())
				{
					this._elements["ButtonImage"].src = this.get_buttonDisabledImageUrl();
				}
			}

		} else if (this._elements["Input"].disabled && controlEnabled)
		{
			this._elements["Input"].disabled = false;
			this._elements["Input"].className = this.get_inputCssClass();
			this._element.className = this.get_controlCssClass();

			// change the dropdown image back to the normal state
			if (this.get_showDropDownButton() && this._elements["ButtonImage"])
			{
				if (this._elements["ButtonImage"] && this.get_buttonNormalImageUrl() != null && this.get_buttonNormalImageUrl() != "" && this._elements["ButtonImage"].src != this.get_buttonNormalImageUrl())
				{
					this._elements["ButtonImage"].src = this.get_buttonNormalImageUrl();
				}
			}
		}
	},

	// opens the dropdown container and fires the associated events 
	openDropDown: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.openDropDown"> Causes the dropdown container to open. Client-side Events (DropDownOpening/Opened) will be fired.  </summary>
		if (this.get_displayMode() != $IG.DropDownDisplayMode.ReadOnly)
		{

			if (this.behavior._dropDownAnimation && this.behavior._dropDownAnimation.get_isAnimating() && this.__isButtonClick)
			{
				this.__isButtonClick = false;
				this.behavior._dropDownAnimation.stop();
				this.behavior._dropDownAnimation.onEnd();
				this.closeDropDown();
				return;
			}

			var args = this._raiseClientEvent('DropDownOpening', 'DropDownContainer', null, null);
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				
				delete this._dontOpen;
				this.__willDoInternalFocus = true;
				this.behavior.set_visible(true);
				//this._adjustMaxHeight();

				if (!this.get_enableAnimations())
				{
					this._raiseClientEvent('DropDownOpened', 'DropDownContainer', null, null);

				} else
				{
					// will be handled in _onAnimationEnd
					this.__isOpening = true;
				}
			}

		}
	},

	// closes the dropdown container and fires the associated events
	closeDropDown: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.closeDropDown"> Causes the dropdown container to close. Client-side Events (DropDownClosing/Closed) will be fired.  </summary>

		if (this.behavior._dropDownAnimation && this.behavior._dropDownAnimation.get_isAnimating() && !this.__isClosing)
		{
			this.behavior._dropDownAnimation.stop();
			this.behavior._dropDownAnimation.onEnd();
			this.openDropDown();
			return;
		}

		var args = this._raiseClientEvent('DropDownClosing', 'DropDownContainer', null, null);
		var cancel = args ? args.get_cancel() : false;
		if (!cancel)
		{
			
			this._dontOpen = true;
			this.behavior.set_visible(false);

			if (!this.get_enableAnimations())
			{
				this._raiseClientEvent('DropDownClosed', 'DropDownContainer', null, null);

			} else
			{
				// will be handled in _onAnimationEnd
				this.__isClosing = true;
			}
		}
	},

	// overriden, called at initialization
	_createItem: function (element, adr)
	{
		this._itemCollection._addObject($IG.DropDownItem, element, adr);
	},

	// overriden _hoverItem from $IG.Behavior
	_hoverItem: function (item, val)
	{
		if (val)
			item.hover();
		else
			item.unhover();
	},

	// returns a reference to the current active item, if any
	get_activeItem: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.activeItem"> returns a reference to the current active item, if any  </summary>
		/// <returns type="Infragistics.Web.UI.DropDownItem" mayBeNull="true"> The current active item if any </returns>

		if (this._activeItem)
		{
			return this._activeItem;
		}
		else if (this.get_activeItemIndex() != -1)
		{
			return this.get_items().getItem(this.get_activeItemIndex());
		}
	},

	set_activeItem: function (item, cancelEvents)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.activeItem"> </summary>
		/// <param name="item" optional="false" type="Infragistics.Web.UI.DropDownItem"> The active DropDown item to set </param>
		/// <param name="cancelEvents" optional="true" type="Boolean"> if true, client-side events ActivationChanging/ActivationChanged will be fired </param>
		var args = null;

		if (!cancelEvents)
		{
			args = this._raiseClientEvent('ActivationChanging', 'DropDownActivation', null, null, item, this._activeItem);
		}

		var cancel = args ? args.get_cancel() : false;

		var oldActiveItem = null;

		if (!cancel || cancelEvents)
		{

			if (this._activeItem)
			{
				this._activeItem.inactivate();
				oldActiveItem = this._activeItem;

			} else if (this.get_activeItemIndex() != -1)
			{
				// look up active item
				// var currentActiveItem = this.get_items()._getObjectByIndex(this.get_activeItemIndex());
				var currentActiveItem = this.get_items().getItem(this.get_activeItemIndex());
				if (currentActiveItem != null)
				{
					currentActiveItem.inactivate();
					oldActiveItem = currentActiveItem;
				}
			}

			item.activate();
			this.set_activeItemIndex(item.get_index());
			this._activeItem = item;

			if (!cancelEvents)
			{
				this._raiseClientEvent('ActivationChanged', 'DropDownActivation', null, null, item, oldActiveItem);
			}
		}
	},

	// this is the text -  filtering criteria , with which the load items postback was initiated (see loadItems)
	_setLoadItemsText: function (text)
	{
		this._set_value($IG.DropDownProps.LoadItemsText, text);
	},

	// overriden, called by Aikido automatically at initialization
	_setupCollections: function ()
	{
		this._itemCollection = this._collectionsManager.register_collection(0, $IG.DropDownItemCollection);
		this._collectionsManager.registerUIBehaviors(this._itemCollection);
	},

	//_createItem:function(element, adr)
	//{
	//    this._itemCollection._addObject($IG.DropDownItem, element, adr);
	// },


	








	get_items: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.items">
		/// The collection of DropDownItem in the WebDropDown.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.DropDownItemCollection" mayBeNull="false"> A collection of DropDown Items </returns>
		return this._itemCollection;
	},

	/// get item based on selectedItemIndex - this should be used only with single item selection
	get_selectedItem: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItem">
		/// Returns the selected dropdown item
		/// </summary>
		/// <returns type="Infragistics.Web.UI.DropDownItem" mayBeNull="true"> The current selected item if any. </returns>
		// K.D. November 18, 2015 Bug #209379 After resetting the initial index in client state and caching the initial item, we return it here.
		if (this._selectedItem && this._selectedItem.get_selected()) {
			return this._selectedItem;
		} else if (this.get_selectedItemIndex() < 0) {
			return null;
		} else {
			//return this.get_items()._items[this.get_selectedItemIndex()];
			return this.get_items().getItem(this.get_selectedItemIndex());
		}
	},

	__createSelectedItems: function ()
	{
		if (this.get_enableMultipleSelection())
		{
			var results = [];
			var count = 0;

			for (i = 0; i < this.get_items().getLength(); i++)
			{
				//if (this.get_items()._items[i].get_selected()) {
				//    results[count] = this.get_items()._items[i];
				if (this.get_items().getItem(i).get_selected())
				{
					results[count] = this.get_items().getItem(i);
					count++;
				}
			}

			this.__selectedItemsArray = results;

		} else
		{
			this.__selectedItemsArray = [this.get_selectedItem()];
		}
	},

	/// get an array of selected items, if multiple selection is enabled
	/// this is done by iterating through all items and checking if the "selected" property is enabled
	get_selectedItems: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItems">
		/// Returns the array of DropDown items that are selected 
		/// </summary>
		/// <returns type="Array" mayBeNull="false" elementMayBeNull="false" elementType="Infragistics.Web.UI.DropDownItem"> Returns the array of DropDown items that are selected </returns>

		if (this.get_enableMultipleSelection())
		{
			var results = [];
			var count = 0;

			for (i = 0; i < this.get_items().getLength(); i++)
			{
				// if (this.get_items()._items[i].get_selected()) {
				//     results[count] = this.get_items()._items[i];
				if (this.get_items().getItem(i).get_selected())
				{
					results[count] = this.get_items().getItem(i);
					count++;
				}
			}
			return results;

		} else
		{
			return this.get_selectedItem() == null ? [] : [this.get_selectedItem()];
		}

		//return this.__selectedItemsArray;
	},

	set_valueBeforeFilter: function (val)
	{
		this.__valueBeforeFilter = val;
	},

	get_valueBeforeFilter: function ()
	{
		return this.__valueBeforeFilter;
	},

	get_closeDropDownOnSelect: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.closeDropDownOnSelect">
		/// if the dropdown is opened, and we select an item, the dropdown container will be automatically closed
		/// if this property is enabled
		///</summary>
		///<value type="Boolean"> Indicates whether the dropdown container will be closed once an item is selected </value>

		return this._get_value($IG.DropDownProps.CloseDropDownOnSelect);
	},

	set_closeDropDownOnSelect: function (closeDropDownOnSelect)
	{

		return this._set_value($IG.DropDownProps.CloseDropDownOnSelect, closeDropDownOnSelect);
	},

	get_dropDownAnimationDuration: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownAnimationDuration">
		/// the animation duration in milliseconds of the dropdown container 
		/// </summary>
		///<value type="Integer"> The animation duration in milliseconds </value>
		return this._get_value($IG.DropDownProps.DropDownAnimationDuration);
	},

	get_dropDownOrientation: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownOrientation">
		/// orientation of the dropdown container relative to its target (input box)
		/// </summary>
		///<value type="Infragistics.Web.UI.DropDownPopupPosition"> the orientation of the dropdown container </value>
		return this._get_value($IG.DropDownProps.DropDownOrientation);
	},

	get_dropDownIsChild: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownIsChild">
		/// indicates whether the dropdown container will be attached directly to the body of the document, or will be a first child of the table 
		/// where the input box is contained
		/// </summary>
		///<value type="Boolean"> indicates whether the dropdown container will be attached directly to the body of the document, or will be a first child of the table where the input box is contained </value>
		return this._get_value($IG.DropDownProps.DropDownIsChild);
	},

	get_enableCachingOnClient: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableCachingOnClient">
		/// enables caching filtering results on the client, for that purpose a hashtable is used where the key is the search string
		/// </summary>
		/// <value type="Boolean"> enables caching filtering results on the client, for that purpose a hashtable is used where the key is the search string </value>
		return this._get_value($IG.DropDownProps.EnableCachingOnClient);
	},

	get_enableCustomValues: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableCustomValues">
		/// enables or disables custom text in the input box
		/// </summary>
		/// <value type="Boolean"> enables or disables custom text in the input box </value>
		return this._get_value($IG.DropDownProps.EnableCustomValues);
	},

	get_enableMarkingMatchedText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableMarkingMatchedText">
		/// If enabled, the matched (full or partial) text in the items will be marked in em tags
		/// </summary>
		/// <value type="Boolean"> If true, the matched (full or partial) text in the items will be marked in em tags </value>
		return this._get_value($IG.DropDownProps.EnableMarkingMatchedText);
	},

	get_autoSelectOnMatch: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.autoSelectOnMatch">
		/// automatically selects the matched item
		/// </summary>
		/// <value type="Boolean"> value indicating whether to automatically select the matched item </value>

		return this._get_value($IG.DropDownProps.AutoSelectOnMatch);
	},

	get_keepFocusOnSelection: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.keepFocusOnSelection">
		/// keeps focus after selecting an item with the mouse 
		/// </summary>
		/// <value type="Boolean"> keeps focus after selecting an item with the mouse  </value>
		return this._get_value($IG.DropDownProps.KeepFocusOnSelection);
	},

	get_enableDropDownContainerAutoWidth: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableDropDownContainerAutoWidth">
		/// Width of the dropdown container is going to grow with the contents 
		/// </summary>
		/// <value type="Boolean"> value indicating if the Width of the dropdown container is going to grow with the contents </value>
		return this._get_value($IG.DropDownProps.EnableDropDownAutoWidth);
	},

	get_editorID: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.editorID">
		/// editorID is the client side ID of the editor control, if we have associated any Infragistics built-in editors and want to 
		/// use them in place of the vanilla input box
		/// </summary>
		/// <value type="String"> editorID is the client side ID of the editor control, if we have associated any Infragistics built-in editors </value>
		return this._get_value($IG.DropDownProps.EditorID);
	},

	get_enableAutoCompleteFirstMatch: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableAutoCompleteFirstMatch">
		/// if this property is enabled, when we type text in the dropdown input box, once a match is made, it will be automatically completed 
		/// and the remaining text will be highlighted
		/// </summary>
		/// <value type="Boolean"> if this property is enabled, when we type text in the dropdown input box, once a match is made, it will be automatically completed and the remaining text will be highlighted</value>
		return this._get_value($IG.DropDownProps.EnableAutoCompleteFirstMatch);
	},

	set_enableAutoCompleteFirstMatch: function (autoComplete)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableAutoCompleteFirstMatch"> Indicates whether first matching item text will be automatically completed and highlighted </summary>
		///<param name="autoComplete" type="Boolean"></param>
		return this._set_value($IG.DropDownProps.EnableAutoCompleteFirstMatch, autoComplete);
	},

	get_enableClosingDropDownOnBlur: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableClosingDropDownOnBlur">
		/// if the control loses focus, and the dropdown container is opened, it will be automatically closed
		/// </summary>
		/// <value type="Boolean"> if the control loses focus, and the dropdown container is opened, it will be automatically closed </value>
		return this._get_value($IG.DropDownProps.EnableClosingDropDownOnBlur);
	},

	set_enableClosingDropDownOnBlur: function (close)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableClosingDropDownOnBlur"> Indicates whether dropdown container will be closed when the control loses focus </summary>
		///<param name="close" type="Boolean"></param>
		return this._set_value($IG.DropDownProps.EnableClosingDropDownOnBlur, close);
	},

	get_dropDownAnimationType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownAnimationType">
		/// look at the $IG.AnimationEquationType enum, for the list of available enums 
		/// </summary>
		/// <value type="Infragistics.Web.UI.AnimationEquationType"> the animation equation type </value>
		return this._get_value($IG.DropDownProps.DropDownAnimationType);
	},

	get_loadingItemsMessageText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.loadingItemsMessageText">
		/// shows a loading message while the AJAX postback to request more items is executing 
		/// </summary>
		/// <value type="String"> shows a loading message while the AJAX postback to request more items is executing </value>
		return this._get_value($IG.DropDownProps.LoadingItemsMessageText);
	},

	get_displayMode: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.displayMode">
		/// display mode can be DropDown (full-blown), DropDownList(dropdown with selection), ReadOnlyList (dropdown readonly) and ReadOnly (only input box)
		/// </summary>
		/// <value type="Infragistics.Web.UI.DisplayMode"> the dropdown display mode </value>
		return this._get_value($IG.DropDownProps.DisplayMode);
	},

	get_valueListMaxHeight: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.valueListMaxHeight">
		/// if not set this will be zero by default. If greater than zero, scrollbars will be added once contents exceed the max height
		/// </summary>
		/// <value type="Integer"> if not set this will be zero by default. If greater than zero, scrollbars will be added once contents exceed the max height </value>
		return this._get_value($IG.DropDownProps.ValueListMaxHeight);
	},

	set_valueListMaxHeight: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.valueListMaxHeight"> The maximum height of the dropdown container to which it may grow, before scrollbars are shown  </summary>
		///<param name="value" type="Integer"></param>
		return this._set_value($IG.DropDownProps.ValueListMaxHeight, value);
	},

	get_offsetX: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.offsetX">
		/// horizontal offset in pixels of the dropdown container relative to the target (allows for manual adjustment of the source and target)
		/// </summary>
		/// <value type="Integer"> horizontal offset in pixels of the dropdown container relative to the target (allows for manual adjustment of the source and target) </value>
		return this._get_value($IG.DropDownProps.OffsetX);
	},

	get_offsetY: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.offsetY">
		/// vertical offset in pixels of the dropdown container relative to the target (allows for manual adjustment of the source and target)
		/// </summary>
		/// <value type="Integer"> vertical offset in pixels of the dropdown container relative to the target (allows for manual adjustment of the source and target) </value>
		return this._get_value($IG.DropDownProps.OffsetY);
	},

	set_offsetX: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.offsetX"> offset of the dropdown container relative to the input  </summary>
		///<param name="value" type="Integer"></param>
		return this._set_value($IG.DropDownProps.OffsetX, value);
	},

	set_offsetY: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.offsetY"> Y offset of the dropdown container relative to the input </summary>
		///<param name="value" type="Integer"></param>
		return this._set_value($IG.DropDownProps.OffsetY, value);
	},

	get_enablePaging: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enablePaging">
		/// Enables paging 
		/// </summary>
		/// <value type="Boolean"> value indicating if paging is enabled </value>
		return this._get_value($IG.DropDownProps.EnablePaging);
	},

	get_pageSize: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.pageSize">
		/// number of drop down items on a single page
		/// </summary>
		/// <value type="Integer"> Page size when paging is enabled (number of items) </value>
		return this._get_value($IG.DropDownProps.PageSize);
	},

	get_selectedItemIndex: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItemIndex">
		/// Index of the currently selected item
		/// </summary>
		/// <value type="Integer"> The index of the selected item if any. If there is no selection, -1 is returned. </value>
		// K.D. November 18, 2015 Bug #209379 After resetting the initial index in client state and caching the initial item, we return its index here.
		if (this._selectedItem) {
			return this._selectedItem.get_index();
		}
		return this._get_value($IG.DropDownProps.SelectedItemIndex);
	},

	set_selectedItemIndex: function (index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItemIndex"> current selected index, -1 indicates no item is selected (default value ) </summary>
		///<param name="index" type="Integer"></param>
		// N.A. 7/27/2015 Bug #201050: When back client-state is lost due to a Response.Redirect, then it's value is "". In such case we don't want to load it, cause it's wrong. This happens only when drop down has AutoPostBackFlags SelectionChanged="On".
		if (!this.get_enableMultipleSelection() && this.__backState !== "")
		{
			//A.T. 14 Jan 2010 Fix for bug #26293 - back button support for WebDropDown
			this._setBackState(0, this.get_currentValue() + '|' + index);
		}
		if (this._selectedItem && this._selectedItem.get_index() !== index) {
			this._selectedItem.unselect();
			delete this._selectedItem;
		}
		return this._set_value($IG.DropDownProps.SelectedItemIndex, index);
	},


	get_selectedItemIndices: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItemIndices">
		/// array of selected item indices
		/// </summary>
		/// <value type="Array" elementType="Integer" elementDomElement="false">  an array of selected items' indices when multiple selection is enabled  </value>
		return this._get_value($IG.DropDownProps.SelectedItemIndices);
	},

	set_selectedItemIndices: function (indices)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.selectedItemIndices"> for internal use </summary>
		return this._set_value($IG.DropDownProps.SelectedItemIndices, indices);
	},

	get_multiSelectValueDelimiter: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.multiSelectValueDelimiter">
		/// this represents a single character that will automatically delimit in the input box the list of multiple-selected items
		/// </summary>
		/// <value type="String"> this represents a single character that will automatically delimit in the input box the list of multiple-selected items </value>
		return this._get_value($IG.DropDownProps.MultiSelectValueDelimiter);
	},

	get_enableCustomValueSelection: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableCustomValueSelection">
		/// items marked "Custom" will not be allowed for selection, if this property is turned on
		/// </summary>
		/// <value type="Boolean"> items marked "Custom" will not be allowed for selection, if this property is turned on </value>
		return this._get_value($IG.DropDownProps.EnableCustomValueSelection);
	},

	get_enableMultipleSelection: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableMultipleSelection">
		/// sets / enables multiple selection in general. Further, multiple selection can be either implemented with checkboxes
		/// or with 
		/// </summary>
		/// <value type="Boolean"> sets / enables multiple selection in general. Further, multiple selection can be either implemented with checkboxes </value>
		return this._get_value($IG.DropDownProps.EnableMultipleSelection);
	},

	get_persistCustomValues: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.persistCustomValues">
		/// enables / disables persisting of custom values. If some value that doesn't exist in the list is typed, and we remove the
		/// focus from the control, a new item is created, and marked IsCustom=true, and persisted to the server
		/// persisting of custom values SHOULD NOT be enabled along with loadOnDemand or Paging ! 
		/// or with 
		/// </summary>
		/// <value type="Boolean"> enables / disables persisting of custom values. </value>
		return this._get_value($IG.DropDownProps.PersistCustomValues);
	},

	get_autoFilterTimeoutMs: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.autoFilterTimeoutMs">
		/// milliseconds that will pass while the user is typing, until a postback will be made
		/// this means we don't do a postback on every keystroke in the input box, in order to fetch filtering results 
		/// </summary>
		/// <value type="Integer"> milliseconds that will pass while the user is typing, until an async postback will be made </value>
		return this._get_value($IG.DropDownProps.AutoFilterTimeoutMs);
	},

	get_enableAutoFiltering: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableAutoFiltering">
		/// sets the type of automatic filtering: Server,Client or Off (selection-only) 
		///</summary>
		/// <value type="Infragistics.Web.UI.DropDownAutoFiltering"> value indicating the type of automatic filtering: Server,Client or Off (selection-only) </value>
		return this._get_value($IG.DropDownProps.EnableAutoFiltering);
	},

	get_autoFilterQueryType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.autoFilterQueryType">
		/// We support a predefined set of automatic server-side filtering queries, such as StartsWith, EndsWith, Contains, etc.
		/// </summary>
		/// <value type="Infragistics.Web.UI.DropDownAutoFilterQueryType"> We support a predefined set of automatic server-side filtering queries, such as StartsWith, EndsWith, Contains, etc. </value>
		return this._get_value($IG.DropDownProps.AutoFilterQueryType);
	},

	get_autoFilterResultSize: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.autoFilterResultSize">
		/// maximum number of items to return when a filtering request is made
		/// </summary>
		/// <value type="Integer"> maximum number of items to return when a filtering request is made </value>
		return this._get_value($IG.DropDownProps.AutoFilterResultSize);
	},

	get_autoFilterSortOrder: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.autoFilterSortOrder">
		/// we support sorting of the resulting items (ascending and descending)
		/// </summary>
		/// <value type="Infragistics.Web.UI.DropDownAutoFilterSortOrder">
		/// The sorting order of items when filtering
		/// </value>
		return this._get_value($IG.DropDownProps.AutoFilterSortOrder);
	},

	get_multipleSelectionType: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.multipleSelectionType">
		/// type of multiple selection - Keyboard or Checkbox (if checkbox, checkboxes are automatically rendered in front of every item)
		/// </summary>
		/// <value type="Infragistics.Web.UI.DropDownMultipleSelectionType"> type of multiple selection - Keyboard or Checkbox  </value>
		return this._get_value($IG.DropDownProps.MultipleSelectionType);
	},

	get_pagerMode: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.pagerMode">
		/// pager mode (numeric, first-last, etc.) 
		///</summary>
		/// <value type="Infragistics.Web.UI.DropDownPagerMode"> paging mode </value>
		return this._get_value($IG.DropDownProps.PagerMode);
	},

	get_lastPageIndex: function ()
	{
		return this._get_value($IG.DropDownProps.LastPageIndex);
	},

	get_shouldFireMultipleSelect: function ()
	{
		return this._get_value($IG.DropDownProps.ShouldFireMultipleSelect);
	},

	get_enableAnimations: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableAnimations">
		/// Enable animations for the dropdown container
		///</summary>
		/// <value type="Boolean"> Indicates whether animations are enabled or not </value>
		return this._get_value($IG.DropDownProps.EnableAnimations);
	},

	get_enableDropDownOpenOnClick: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableDropDownOpenOnClick"> for internal use </summary>
		return this._get_value($IG.DropDownProps.EnableDropDownOpenOnClick);
	},

	get_activeItemIndex: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.activeItemIndex"> for internal use </summary>

		// N.A. 10/12/2016 Bug #226780: Active item is getting the index of selected item, when the auto filtering is set to client.
		// Basically the server is sending the ActiveItemIndex as - 1, which means that the fix should be made on the server,
		// but on the server ActiveItemIndex is not manupulated intentionally, and it is said that such a logic should be made on the client.
		var activeItemIndex = this._get_value($IG.DropDownProps.ActiveItemIndex);
		var selectedItemIndex = this.get_selectedItemIndex();
		if (activeItemIndex === -1 && this.get_enableAutoFiltering() === $IG.DropDownAutoFiltering.Client) {
			activeItemIndex = selectedItemIndex;
		}
		return activeItemIndex;
	},

	set_activeItemIndex: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.activeItemIndex"> for internal use </summary>
		this._set_value($IG.DropDownProps.ActiveItemIndex, value);
	},

	set_shouldFireMultipleSelect: function (val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.shouldFireMultipleSelect"> for internal use </summary>
		return this._set_value($IG.DropDownProps.ShouldFireMultipleSelect, val);
	},

	get_enableLoadOnDemand: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableLoadOnDemand">
		/// load on demand is a kind of "virtual scrolling" where , once the user scrolls down to the bottom of the dropdown container
		/// new items are fetched from the server, if any
		/// </summary>
		/// <value type="Boolean"> indicates whether load on demand is enabled </value>
		return this._get_value($IG.DropDownProps.EnableLoadOnDemand);
	},

	/// <summary>
	/// as one types, filtering is only performed on the item collection which is on the client, and no postback is done
	/// </summary>
	// get_enableClientFilteringOnly: function() {
	//     return this._get_value($IG.DropDownProps.EnableClientFilteringOnly);
	// },

	get_dropDownContainerWidth: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownContainerWidth">
		/// fixed width of the dropdown container 
		///</summary>
		/// <value type="Integer"> width of the dropdown container </value>
		return this._get_value($IG.DropDownProps.DropDownContainerWidth);
	},

	get_dropDownContainerHeight: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownContainerHeight">
		/// fixed height of the dropdown container 
		///</summary>
		/// <value type="Integer"> height of the dropdown container </value>
		return this._get_value($IG.DropDownProps.DropDownContainerHeight);
	},

	get_enableCaseSensitivity: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.enableCaseSensitivity">
		/// Enables case sensitivity when filtering is done on the client-cide
		///</summary>
		/// <value type="Boolean"> indicates whether filtering is case sensitive or not (applies for client-side filtering only) </value>
		return this._get_value($IG.DropDownProps.EnableCaseSensitivity);
	},

	get_showDropDownButton: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.showDropDownButton">
		/// if false, the dropdown button will be hidden and the input box will be the only visible element where filtering can be done
		///</summary>
		/// <value type="Boolean"> indicates whether dropdown button will be shown or not  </value>
		return this._get_value($IG.DropDownProps.ShowDropDownButton);
	},

	get_dropDownValueDisplayType: function ()
	{
		return this._get_value($IG.DropDownProps.DropDownValueDisplayType);
	},

	get_nullTextCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.nullTextCssClass">
		/// the css class that will be applied when the control has focus
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for Focus state </value>
		return this._get_clientOnlyValue("nullTextCssClass");
	},

	get_inputFocusCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.inputFocusCssClass">
		/// the css class that will be applied when the control has focus
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for Focus state </value>
		return this._get_clientOnlyValue("dropDownInputFocusClass");
	},

	get_inputHoverCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.inputHoverCssClass">
		/// the css class that will be applied when the control is hovered with the mouse
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for Hover state  </value>
		return this._get_clientOnlyValue("dropDownInputHoverClass");
	},

	get_inputCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.inputCssClass">
		/// the css class that will be applied on the input box
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for the input box </value>
		return this._get_clientOnlyValue("dropDownInputClass");
	},

	get_inputDisabledCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.inputDisabledCssClass">
		/// the css class that will be applied on the input box when the control is disabled
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for disabled input state  </value>
		return this._get_clientOnlyValue("dropDownInputDisabledClass");
	},

	get_controlDisabledCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.controlDisabledCssClass">
		/// the css class that will be applied on the control's div when the control is disabled 
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for disabled state of the control </value>
		return this._get_clientOnlyValue("controlDisabledClass");
	},

	get_controlCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.controlCssClass">
		/// the css class that will be applied on the control's div
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass for the control's Div element </value>
		return this._get_clientOnlyValue("controlClass");
	},

	get_dropDownFocusCssClass: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.dropDownFocusCssClass">
		/// the css class that will be applied on the control's div when the control has focus
		///</summary>
		/// <value type="String" mayBeNull="true"> indicates the CssClass when the control is focused (applied on the main control DIV) </value>
		return this._get_clientOnlyValue("dropDownFocusClass");
	},

	get_dropDownHoverCssClass: function ()
	{
		/// <value type="String" mayBeNull="true"> indicates the CssClass when the mouse is over the control </value>
		return this._get_clientOnlyValue("dropDownHoverClass");
	},

	get_controlAreaHoverCssClass: function ()
	{
		return this._get_clientOnlyValue("controlAreaHoverClass");
	},

	_get_enableClientRendering: function ()
	{
		return this._get_value($IG.DropDownProps.EnableClientRendering, true);
	},

	get_dataSource: function ()
	{
		return this._dataStore[4];
	},

	set_dataSource: function (dataSourceJSON)
	{
		this._dataStore[4] = dataSourceJSON;
	},

	get_buttonCssClass: function ()
	{
		return this._get_clientOnlyValue("dropDownButtonClass");
	},

	get_controlAreaFocusCssClass: function ()
	{
		return this._get_clientOnlyValue("controlAreaFocusClass");
	},


	get_controlAreaCssClass: function ()
	{
		return this._get_clientOnlyValue("controlAreaClass");
	},

	get_pageCount: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.pageCount">
		/// number of pages when paging is enabled
		///</summary>
		/// <value type="Integer"> returns the number of pages when paging is enabled </value>
		return this._get_clientOnlyValue("pageCount");
	},

	get_buttonNormalImageUrl: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.buttonNormalImageUrl">
		/// the Url for the dropdown button when in normal state
		///</summary>
		/// <value type="String" mayBeNull="true"> returns the Url for the dropdown button image  </value>
		return this._get_clientOnlyValue("dropDownButtonNormalImageUrl");
	},

	get_buttonHoverImageUrl: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.buttonHoverImageUrl">
		/// the Url for the dropdown button when it is hovered
		///</summary>
		/// <value type="String" mayBeNull="true"> returns the Url for the dropdown hover button image </value>
		return this._get_clientOnlyValue("dropDownButtonHoverImageUrl");
	},

	get_buttonPressedImageUrl: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.buttonPressedImageUrl">
		/// the Url for the dropdown button when it is pressed
		///</summary>
		/// <value type="String" mayBeNull="true"> returns the Url for the dropdown pressed button image </value>
		return this._get_clientOnlyValue("dropDownButtonPressedImageUrl");
	},

	get_buttonDisabledImageUrl: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.buttonDisabledImageUrl">
		/// the Url for the dropdown button when it is pressed
		///</summary>
		/// <value type="String" mayBeNull="true"> returns the Url for the dropdown disabled button image </value>
		return this._get_clientOnlyValue("dropDownButtonDisabledImageUrl");
	},

	get_nullText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.nullText">
		/// nullText is default text that's shown when the control doesn't have focus 
		/// </summary>
		/// <value type="String" mayBeNull="false">nullText is default text that's shown when the control doesn't have focus </value>
		return this._get_value($IG.DropDownProps.NullText);
	},

	set_nullText: function (text)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.nullText"> nullText is default text that's shown when the control doesn't have focus </summary>
		///<param name="val"> the null text </param>
		this._set_value($IG.DropDownProps.NullText, text);
	},

	get_currentValue: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDropDown.currentValue">
		/// 'currentValue' is the value in the input box of the dropdown control. It could be assumed to mean the "Display Value". The setter accepts two parameters: set_currentValue(val, copyToInputValue). 'val' represents the text of the current value and 'copyToInputValue' is a Boolean value that if 'true', updates the input element's value.
		/// </summary>
		/// <value type="String" mayBeNull="false">'currentValue' is the value in the input box of the dropdown control. It could be assumed to mean the "Display Value"  </value>
		// K.D. November 7th, 2011 Bug #95380 Ampersands need to be decoded before retrieving
		// K.D. March 8th, 2012 Bug #104206 Apparently sometime we have unencoded special characters coming from server-side (which should be avoided) and thus wrapping the decodeURIComponent inside try-catch
		var val = this._get_value($IG.DropDownProps.CurrentValue);
		// K.D. April 2nd, 2012 Bug #107427 When there are no items the current value gets set to “null”.
		if (!$util.isNullOrUndefined(val))
		{
			try
			{
				val = decodeURIComponent(val);
			} catch (e)
			{
				val = this._get_value($IG.DropDownProps.CurrentValue);
			}
		}
		return val;
	},

	/// <summary>
	/// programatically set the display value
	/// </summary>
	set_currentValue: function (val, copyToInputValue)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.currentValue"> sets the currently displayed value in the input box </summary>
		///<param name="val"> text of the current value </param>
	    ///<param name="copyToInputValue">if true, the input element's value will also be updated </param>
		if (copyToInputValue)
		{
			// K.D. July 11th, 2014 Bug #174250 In IE <= 9 Setting null as value sets it to "null" and not to empty string
			// K.D. September 4ht, 2014 Bug #179935 Making the fix more general and changing the value to "" from null.
			if (val === null) {
				val = "";
			}
			this._elements["Input"].value = val;
			
			
			if (this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
				this._element.value = val || this.get_nullText();
		}
		
		var oldVal = this._lastVal || this.get_currentValue();
		if (val != oldVal || !this.__getViewStateEnabled())
		{
			// K.D. November 7th, 2011 Bug #95380 Ampersands need to be encoded before being sent to the server
			var encVal = encodeURIComponent(val);
			
			// K.D. September 29th, 2014 Bug #181255 Paging numbers disappear when filtering a value
			this._lastVal = typeof val === "number" ? val.toString() : val;
			this._set_value($IG.DropDownProps.CurrentValue, encVal);

			// N.A. 7/27/2015 Bug #201050: When back client-state is lost due to a Response.Redirect, then it's value is "". In such case we don't want to load it, cause it's wrong. This happens only when drop down has AutoPostBackFlags SelectionChanged="On".
			if (!this.get_enableMultipleSelection() && this.__backState !== "")
			{
				//A.T. 14 Jan 2010 Fix for bug #26293 - back button support for WebDropDown
				this._setBackState(0, val + '|' + this.get_selectedItemIndex());
			}
		}
	},


	set_previousValue: function (val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.previousValue"> for internal use </summary>
		this._previousValue = val;
	},

	get_previousValue: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.previousValue"> for internal use </summary>
		return this._previousValue;
	},

	get_hoverItemIndex: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.hoverItemIndex"> for internal use </summary>
		return this.__hoverItemIndex;
	},

	set_hoverItemIndex: function (index)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDropDown.hoverItemIndex"> for internal use </summary>
		this.__hoverItemIndex = index;
	},

	_selectItem: function (item, val)
	{
		this.__selectItem(item, val, true);
	},

	__selectItem: function (item, val, fireEvent)
	{
		//  if(!this.__initializing)
		//  {
		//      $util.removeCompoundClass(item._element, this.get_selectedClass());
		//      $util.removeCompoundClass(item._element, item.get_selectedCssClass());
		//  }
		if (val)
		{
			//   $util.addCompoundClass(item._element, this.get_selectedClass());
			//   $util.addCompoundClass(item._element, item.get_selectedCssClass());
			if (fireEvent && !this.__initializing)
				this._raiseClientEvent('ItemSelected', 'DropDownControl', null, null, item);
		}

	},

	/// <summary>
	/// in case there is event, such as key up / down or mouse down / up , we don't automatically assume that the 
	/// target event element will be an item (i.e. <LI> tag), but we search up (bubble) in order to find the actual item 
	/// represented by the LI tag.
	/// </summary>
	__getNearestItem: function (elem)
	{
		var parent = elem ? elem.parentNode : null, list = this._elements["DropDown"];
		
		if (!parent || !list || elem == list)
		{
			return null;
		}

		var item = null;
		var adr = null;

		$util._initAttr(elem);

		if (elem.getAttribute)
		{

			adr = elem.getAttribute("adr");

			// A.T. 6th Feb. 2010 Fix for bug #26987 - Microsoft JScript runtime error: 'this._items[...].0' is null or not an object (WebDataTree interop.)
			// A.T. 26 April 2010 - (additional) Fix for bug #29940 - DataTree throws exception (this._items[address] is undefined) when nested in template of drop down.
			//if (adr != null && elem.getAttribute && !elem.getAttribute('_expImage') && (!elem.getAttribute('mkr') || (elem.getAttribute('mkr') && elem.getAttribute('mkr') != 'dtnContent'))) {
			if (adr != null)
			{
				if (parent && parent.getAttribute && parent.getAttribute('mkr') != "List")
					return null;

				
				var items = this.get_items && this.get_items();
				item = items ? items.getItem(adr) : null;

				if (item != null)
					return item;
			}
		}
		return this.__getNearestItem(parent);
	},

	_select: function (event)
	{
		// N.A. This is more or less major change. If there is too much regression, just remove that 'if' block. 
		if (this._mouseDownItem && event.target) {
			// N.A. 5/10/2016 Bug #217892: If mouse down and up are not on the same DOM element there isn't a selection.
			// You can look the first 'if' in that funciton: _onMouseupHandler. The same check is needed here.
			// N.A. 5/12/2016 Bug #217892: Additional to the previous fix - we decided that (de)selection will happen, if mouse down and up happens inside one DD item, not only DOM element.
			isMouseDownDefinedAndInList = this._mouseDownItem.tagName === "LI" || this._mouseDownItem.parentElement.tagName === "LI";
			mouseDownItem = this._mouseDownItem.tagName === "LI" ? this._mouseDownItem : this._mouseDownItem.parentElement;
			mouseUpItem = event.target.tagName === "LI" ? event.target : event.target.parentElement;
			isOnlyMouseUpOnCheckbox = event.target.tagName === "INPUT" && event.target.type === "checkbox" && this._mouseDownItem.tagName !== "INPUT" && this._mouseDownItem.type !== "checkbox";
			//if (event.target != this._mouseDownItem) {
			if (isMouseDownDefinedAndInList && (mouseDownItem !== mouseUpItem || isOnlyMouseUpOnCheckbox)) {
				return;
			}
		}

		this.__isDropDownEvent = true;

		var navigate = true;

		// selection is not allowed when we are in read only list mode
		if (this.get_displayMode() > 1)
			return;

		var item = this.__getNearestItem(event.target);

		if (item != null && !item.get_disabled())
		{

			//A.T. 24 June 2010 Fix for bug #35054 - When filtering is performed, and AutoSelectOnMatch=true, when the first matched item is clicked, the input text doesn't change to the full item's text
			if (item.get_index() == this.get_selectedItemIndex() && this.get_currentValue() != item.get_text())
			{
				args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', event, null, item.get_text(), this.get_currentValue());

				var cancel = args ? args.get_cancel() : false;
				if (!cancel)
				{
					var previousValue = this.get_currentValue();
					this.set_currentValue(item.get_text(), true);
					this._raiseClientEvent('ValueChanged', 'DropDownEdit', event, null, this.get_currentValue(), previousValue);
				}
			}

			//A.T. 1 Sept. 2009 - Fix for bug 21172: When selection is set to the same previous selection, postback is made, but the SelectionChanged event is not fired on the server-side
			if (!this.get_enableMultipleSelection() && item.get_index() != this.get_selectedItemIndex())
			{

				// handle single item selection first 
				var oldIndex = this.get_selectedItemIndex();
				// var oldItem = oldIndex == -1 ? null : this.get_items()._getObjectByIndex(oldIndex);
				var oldItem = oldIndex == -1 ? null : this.get_items().getItem(oldIndex);

				if ((!item.get_custom()) || (item.get_custom() && this.get_enableCustomValueSelection()))
				{

					this.set_activeItem(item);

					var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, [item], [oldItem]);
					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{

						if (this.get_enableMultipleSelection())
						{
							this.__unselectAllItems();
						} else
						{
							if (this.get_selectedItem() != null)
								this.get_selectedItem().unselect();
						}

						item.select();
						// this.set_selectedItemIndex(this.get_items().get_indexOf(item));
						this.set_selectedItemIndex(item.get_index());
						this.__lastSelectionWasContinuous = false;

						//A.T. 12 July - Fix for bug #25242 - ValueChanged event is fired on the client when selecting the first list item (the value is not actually changed)
						if (this.get_currentValue() != item.get_text() || this._elements["Input"].value != this.get_currentValue())
						{
							args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', event, null, item.get_text(), this.get_currentValue());

							var cancel = args ? args.get_cancel() : false;
							if (!cancel)
							{
								var previousValue = this.get_currentValue();
								this.set_currentValue(item.get_text(), true);
								this._raiseClientEvent('ValueChanged', 'DropDownEdit', event, null, this.get_currentValue(), previousValue);
								// A.M. June 2nd, 2015 Bug #200568 "Valid value is not permitted after selecting an item using the mouse when EnableCustomValues="False""
								if (this.get_enableAutoCompleteFirstMatch())
								{
									this.__set_valueBeforeAutoCompleteFirstMatch(this.get_currentValue());
								}
							}
						}

						var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, [item], [oldItem]);

					}

				} else
				{

					















				}
			}
			// change value display
			// this._elements["Input"].value = item.get_text();
			if (this.get_enableMultipleSelection())
			{

				if (this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
				{
					var checked = item._element.childNodes[0].checked;
					var isEventOnCheckbox = false;
					var eventSource = event.target;
					if (eventSource.getAttribute && eventSource.getAttribute("type") == "checkbox")
					{
						isEventOnCheckbox = true;
					}

					if (!isEventOnCheckbox)
					{
						// A.T. 27/11/2009 Fix for bug #23711
						//return;
						checked = item.get_selected();
						item._element.childNodes[0].checked = !checked;
						item._element.childNodes[0].setAttribute('alt', !checked ? this._checkedAlt : this._uncheckedAlt);
						item._element.childNodes[0].setAttribute('title', !checked ? this._checkedAlt : this._uncheckedAlt);
					}

					if (!item.get_disabled() && (!item.get_custom()) || (item.get_custom() && this.get_enableCustomValueSelection()))
					{

						// fire the SelectionChanging event 
						// 1. get current array of selected items
						var oldSelectedItems = this.get_selectedItems();

						// construct newSelectedItems
						if (checked)
						{
							// remove item 
							var newSelectedItems = new Array();
							for (var i = 0; i < oldSelectedItems.length; i++)
							{
								if (oldSelectedItems[i].get_index() != item.get_index())
								{
									newSelectedItems.push(oldSelectedItems[i]);
								}
							}

						} else
						{
							// add item
							var newSelectedItems = Array.clone(oldSelectedItems);
							newSelectedItems.push(item);
						}

						// fire selection changing event
						var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);
						var cancel = args ? args.get_cancel() : false;

						if (!cancel)
						{
							if (checked)
							{

								item.unselect(true);

							} else
							{
								item.select(true);
							}

							// fire selection changed event
							this.set_shouldFireMultipleSelect(true);
							// set active item just in case Async Postback flags are used, because if we set it afterwards
							// it will not get set if we set it in client code AFTER the event is fired 
							this.set_activeItem(item);

							this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);

							this.__lastSelectionWasContinuous = false;
						}

					}

				} else
				{

					// keyboard multiple selection
					var eventSource = event.target;

					if (event.ctrlKey || ($util.IsMac && event.rawEvent && event.rawEvent.metaKey))
					{
						//navigate = false;

						if (!item.get_disabled() && (!item.get_custom()) || (item.get_custom() && this.get_enableCustomValueSelection()))
						{

							// fire the SelectionChanging event 
							// 1. get current array of selected items
							var oldSelectedItems = this.get_selectedItems();

							// construct newSelectedItems
							if (item.get_selected())
							{
								// remove item 
								var newSelectedItems = new Array();
								for (var i = 0; i < oldSelectedItems.length; i++)
								{
									if (oldSelectedItems[i].get_index() != item.get_index())
									{
										newSelectedItems.push(oldSelectedItems[i]);
									}
								}

							} else
							{
								// add item
								var newSelectedItems = Array.clone(oldSelectedItems);
								newSelectedItems.push(item);
							}

							// fire selection changing event
							var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);
							var cancel = args ? args.get_cancel() : false;

							if (!cancel)
							{

								if (!item.get_selected())
								{
									item.select(true);
								} else
								{
									item.unselect(true);
								}

								// fire selection changed event
								this.set_shouldFireMultipleSelect(true);
								// set active item just in case Async Postback flags are used, because if we set it afterwards
								// it will not get set if we set it in client code AFTER the event is fired 
								this.set_activeItem(item);
								this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);

								this.__lastSelectionWasContinuous = false;
							}
						}

					} else if (event.shiftKey)
					{
						// navigate = false;

						// var currentItemIndex = this.get_items().get_indexOf(item);
						// var prevItemIndex = this.get_items().get_indexOf(this.get_activeItem());

						var currentItemIndex = item.get_index();

						if (!this.get_activeItem())
							return;

						var prevItemIndex = this.get_activeItem().get_index();

						if (prevItemIndex < 0)
						{
							return;
						}
						// construct selected items arrays
						var oldSelectedItems = this.get_selectedItems();
						var newSelectedItems = null;

						var itemsForUnselect = new Array();

						if (this.__lastSelectionWasContinuous)
						{
							newSelectedItems = Array.clone(oldSelectedItems);
						} else
						{
							newSelectedItems = new Array();
						}

						if (currentItemIndex > prevItemIndex)
						{

							//newSelectedItems.push( this.get_items().getItem(prevItemIndex));
							if (!item.get_disabled() && this.__lastSelectionWasContinuous)
							{
								if (!Array.contains(newSelectedItems, item))
									newSelectedItems.push(item);
							}

							for (i = prevItemIndex; i <= currentItemIndex; i++)
							{

								if (!this.__lastSelectionWasContinuous)
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));
								}

								if (this.get_items().getItem(i).get_activated() && !this.get_items().getItem(prevItemIndex + 1).get_selected() && this.get_items().getItem(i).get_index() != item.get_index())
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));
								}

								if (!this.get_items().getItem(i).get_disabled() && !this.get_items().getItem(i).get_selected() && this.get_items().getItem(i).get_index() != item.get_index())
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));

								} //else 
								//{
								//    this.get_items().getItem(i).unselect();
								//}
								else if (this.__lastSelectionWasContinuous && this.get_items().getItem(i).get_index() != item.get_index() && this.get_items().getItem(i).get_selected() && (!this.get_items().getItem(i).get_activated() || (this.get_items().getItem(i).get_activated() && this.get_items().getItem(prevItemIndex + 1).get_selected())))
								{
									itemsForUnselect.push(this.get_items().getItem(i));
									if (Array.contains(newSelectedItems, this.get_items().getItem(i)))
									{
										Array.remove(newSelectedItems, this.get_items().getItem(i));
									}
								}
							}

							// fire 'ing' event
							// fire selection changing event
							var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);
							var cancel = args ? args.get_cancel() : false;

							if (!cancel)
							{
								// unselect all first
								if (!this.__lastSelectionWasContinuous)
									this.__unselectAllItems();

								for (i = 0; i < newSelectedItems.length; i++)
								{
									var tmpItem = newSelectedItems[i];
									if (!tmpItem.get_disabled() && (!tmpItem.get_custom()) || (tmpItem.get_custom() && this.get_enableCustomValueSelection()))
									{
										tmpItem.select(true);
									}
								}

								for (i = 0; i < itemsForUnselect.length; i++)
								{
									itemsForUnselect[i].unselect(true);
								}

								// fire selection changed event
								this.set_shouldFireMultipleSelect(true);
								// set active item just in case Async Postback flags are used, because if we set it afterwards
								// it will not get set if we set it in client code AFTER the event is fired 
								this.set_activeItem(item);
								this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);

								this.__lastSelectionWasContinuous = true;

							}

						} else if (currentItemIndex < prevItemIndex)
						{
							//  newSelectedItems.push( this.get_items().getItem(prevItemIndex));

							if (!item.get_disabled() && this.__lastSelectionWasContinuous)
							{
								if (!Array.contains(newSelectedItems, item))
									newSelectedItems.push(item);
							}

							for (i = currentItemIndex; i <= prevItemIndex; i++)
							{
								if (!this.__lastSelectionWasContinuous)
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));
								}

								if (this.get_items().getItem(i).get_activated() && !this.get_items().getItem(prevItemIndex - 1).get_selected() && this.get_items().getItem(i).get_index() != item.get_index())
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));
								}

								if (!this.get_items().getItem(i).get_disabled() && !this.get_items().getItem(i).get_selected() && this.get_items().getItem(i).get_index() != item.get_index())
								{
									if (!Array.contains(newSelectedItems, this.get_items().getItem(i)))
										newSelectedItems.push(this.get_items().getItem(i));

								}
								











								// the item that will become active (CurrentItemIndex), must always be also selected
								else if (this.__lastSelectionWasContinuous && this.get_items().getItem(i).get_index() != item.get_index() && this.get_items().getItem(i).get_selected() && (!this.get_items().getItem(i).get_activated() || (this.get_items().getItem(i).get_activated() && this.get_items().getItem(prevItemIndex - 1).get_selected())))
								{
									itemsForUnselect.push(this.get_items().getItem(i));
									if (Array.contains(newSelectedItems, this.get_items().getItem(i)))
									{
										Array.remove(newSelectedItems, this.get_items().getItem(i));
									}
								}
							}

							// fire 'ing' event
							// fire selection changing event
							var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);
							var cancel = args ? args.get_cancel() : false;

							if (!cancel)
							{
								// unselect all items first, if last selection was not of type multiple continuous
								if (!this.__lastSelectionWasContinuous)
								{
									this.__unselectAllItems();
								}

								for (i = 0; i < newSelectedItems.length; i++)
								{
									var tmpItem = newSelectedItems[i];
									if (!tmpItem.get_disabled() && (!tmpItem.get_custom()) || (tmpItem.get_custom() && this.get_enableCustomValueSelection()))
									{
										tmpItem.select(true);
									}
								}

								for (i = 0; i < itemsForUnselect.length; i++)
								{
									itemsForUnselect[i].unselect(true);
								}

								// fire selection changed event
								this.set_shouldFireMultipleSelect(true);
								// set active item just in case Async Postback flags are used, because if we set it afterwards
								// it will not get set if we set it in client code AFTER the event is fired 
								this.set_activeItem(item);
								this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, newSelectedItems, oldSelectedItems);

								this.__lastSelectionWasContinuous = true;
							}
						}

					} else
					{
						//A.T. 1 Sept. 2009 - Fix for bug 21172: When selection is set to the same previous selection, postback is made, but the SelectionChanged event is not fired on the server-side
						if (item.get_index() != this.get_selectedItemIndex() && !item.get_disabled() && (!item.get_custom()) || (item.get_custom() && this.get_enableCustomValueSelection()))
						{
							// fire selection events !!! 
							var oldSelectedIndex = this.get_selectedItemIndex();
							// var oldItem = oldSelectedIndex == -1 ? null : this.get_items()._getObjectByIndex(oldSelectedIndex);
							var oldItem = oldSelectedIndex == -1 ? null : this.get_items().getItem(oldSelectedIndex);
							var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, [item], [oldItem]);
							var cancel = args ? args.get_cancel() : false;
							if (!cancel)
							{
								this.__unselectAllItems();
								item.select(true);
								//  this.set_selectedItemIndex(item.get_index());
								this.set_selectedItemIndex(item.get_index());
								// set active item just in case Async Postback flags are used, because if we set it afterwards
								// it will not get set if we set it in client code AFTER the event is fired 
								this.set_activeItem(item);
								this.set_shouldFireMultipleSelect(true);
								this.__lastSelectionWasContinuous = false;
								this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, [item], [oldItem]);

							}
						}
					}
				}
				this.set_activeItem(item);
				//var currentVal = this.get_currentValue();
				//var delim = this.get_multiSelectValueDelimiter();
				//this.set_currentValue(currentVal+delim+item.get_text());

				this.__constructMultiSelectValue(event);
				
			}

			// close drop down

			if (this.get_closeDropDownOnSelect())
			{

				//A.T. 16 Sept. 2010 - Additional fix for #36326 -  The client-side event DropDownClosed fires before the list with items is closed.
				this.closeDropDown();
				









			}

			// A.T. 17 April Fix for bug #29940 - DataTree throws exception (this._items[address] is undefined) when nested in template of drop down.
			if (this.get_keepFocusOnSelection())
			{
				if (!this._elements["Input"].disabled)
				{
					setTimeout(Function.createDelegate(this, this.__focusInput), 20);

				} else
				{

					// A.T. Fix for bug #22775
					try
					{
						this._element.focus();

					} catch (e)
					{
						// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
						// for some reason - there is no stable way to detect when to call focus() and when not to 
					}
				}
			}

		}

		//     event.cancelBubble = true;
		//     return false;
		// K.D. October 10th, 2011 Bug #91065 Item doesn't navigate if you don't click on the text (anchor)
		// and does not navigate at all if there are no anchors
		// K.D. March 5th, 2012 Bug #99730 Performing a check for multiple selection
		if (!this.get_enableMultipleSelection() && !event.shiftKey && !event.ctrlKey && item && item.get_navigateUrl())
		{
			// K.D. February 27th, 2012 Bug #102331 Should not be using window.navigate as this is IE specific
			// K.D. September 17th, 2013 Bug #150981 The target property was previously ignored. Switching to 
			// window.open
			if (event.target.nodeName !== "A") {
				var target = item.get_target() ? item.get_target() : '_self';
				window.open(item.get_navigateUrl(), target);
			}
		}

	},

	selectItemByIndex: function (itemIndex, activate, updateCurrentValue)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.selectItemByIndex">
		/// same as selectItem(), but uses the passed item index instead:
		/// usage: selectItemByIndex(2)
		/// </summary>
		/// <param name="itemIndex" type="Integer"> index of the item to select </param>
		/// <param name="activate" type="Boolean"> if the item should be activated or not </param>
		/// <param name="updateCurrentValue" type="Boolean"> if the current input value should be updated or not </param>

		this.selectItem(this.get_items().getItem(itemIndex), activate, updateCurrentValue);
	},

	selectItem: function (item, activate, updateCurrentValue)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDropDown.selectItem">
		/// Selects an item and optionally activates it and updates the current value and input text
		/// usage: selectItem(myItem,activate,updateCurrentValue);
		/// if the second parameter is true, the item will be also activated
		/// if the third parameter is true, the current value and the input text will also be updated
		/// this works for both Single (EnableMultipleSelection=false) and Multiple selections
		/// the default values for the second and third parameters are both 'true' 
		/// </summary>
		/// <param name="item" type="Infragistics.Web.UI.DropDownItem"> reference to the item to select </param>
		/// <param name="activate" type="Boolean"> if the item should be activated or not </param>
		/// <param name="updateCurrentValue" type="Boolean"> if the current input value should be updated or not  </param>

		var localActivate = true;
		var localUpdateCurrentValue = true;

		if (activate != undefined && !activate) localActivate = false;
		if (updateCurrentValue != undefined && !updateCurrentValue) localUpdateCurrentValue = false;

		if (item == null)
			return;

		// get actual collection item
		var newItem = this.get_items().getItem(item.get_index());

		if (newItem == null)
			return;

		var oldIndex = this.get_selectedItemIndex();
		var oldItem = oldIndex == -1 ? null : this.get_items().getItem(oldIndex);

		if (oldItem != null)
		{
			if (!this.get_enableMultipleSelection())
			{
				// deselect old item
				oldItem.unselect();
				this.set_selectedItemIndex(-1);
				// inactivate it
				if (oldItem.get_activated() && localActivate)
				{
					oldItem.inactivate();
					this.set_activeItemIndex(-1);
				}
			} else
			{
				var currentActiveItem = this.get_activeItem();
				if (currentActiveItem != null && localActivate)
				{
					currentActiveItem.inactivate();
					this.set_activeItemIndex(-1);
				}
			}

		}

		// select , activate new item, and update current value
		newItem.select();
		this.set_selectedItemIndex(newItem.get_index());
		if (localActivate)
		{
			newItem.activate();
			this.set_activeItemIndex(newItem.get_index());
		}

		// finally , update current value
		if (localUpdateCurrentValue)
		{
			if (!this.get_enableMultipleSelection())
			{
				this.set_currentValue(newItem.get_text(), true);
			}
			else
			{
				var newVal = this.__constructMultiSelectValueInternal();
				this.set_currentValue(newVal, true);
			}
		}

	},

	__focusInput: function ()
	{

		if (this._elements && this._elements["Input"])
		{
			// A.T. Fix for bug #22775
			try
			{
				this._elements["Input"].focus();

			} catch (e)
			{
				// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
				// for some reason - there is no stable way to detect when to call focus() and when not to 
			}
			this.__moveInputCursorToEnd();
			this.__isInternalFocus = true;
		}
	},

	__unselectAllItems: function ()
	{

		//  var items = this.get_items()._items;
		//var items = this.get_selectedItems();
		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		for (i = 0; i < length; i++)
		{
			// if (!items[i].get_disabled()) {
			// items[i].unselect();
			this.get_items().getItem(i).unselect();
			// }
		}
	},

	__unselectAllItemsWithoutActiveItem: function ()
	{

		//  var items = this.get_items()._items;
		//var items = this.get_selectedItems();
		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		for (i = 0; i < length; i++)
		{
			// if (!items[i].get_activated() && items[i].get_selected()) {
			//     items[i].unselect();
			// }
			if (!this.get_items().getItem(i).get_activated() && this.get_items().getItem(i).get_selected())
			{
				this.get_items().getItem(i).unselect();
			}
		}
	},

	_navigateItems: function (event)
	{
		// item navigation
	},


	_onPagerMoreResults: function (event)
	{
		if (!this._noMoreResults)
		{

			if (this.get_loadingItemsMessageText() != null)
			{
				this.__showLoadingItemsMessage();
			}

			//A.T. 8 March 2010 - Fix for bugs #29001 and #24299
			// store selected item indices:
			this._selectedBeforeLoD = [];

			var counter = 0;

			for (i = 0; i < this.get_items()._items.length; i++)
			{
				//this.get_items()._items[i].dispose();
				var item = this.get_items()._items[i];
				if (item != null)
				{
					if (item.get_selected())
					{
						this._selectedBeforeLoD[counter++] = item.get_index();
					}
				}
			}

			var cbo = this._callbackManager.createCallbackObject();
			cbo.serverContext.type = "pagerMoreResults";
			//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
			this._callbackManager.execute(cbo, true);
		}

	},

	_onPagerPrevResults: function (event)
	{

		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "prevPage";
		//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		this._callbackManager.execute(cbo, true);

	},

	_onPagerNextResults: function (event)
	{

		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "nextPage";
		//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		this._callbackManager.execute(cbo, true);

	},

	_onPagerFirstResults: function (event)
	{

		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "firstPage";
		//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		this._callbackManager.execute(cbo, true);

	},

	_onPagerLastResults: function (event)
	{

		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}
		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "lastPage";
		//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		this._callbackManager.execute(cbo, true);

	},

	_onPagerNumberResults: function (event)
	{

		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}

		var cbo = this._callbackManager.createCallbackObject();
		cbo.serverContext.type = "gotoPage";

		//A.T. 2 Sept. 2010 - Fix for bug #35816 - When clicking on Pager area border of Control as usercontrol, it throws an exception or error.
		if (event.target && event.target.nodeName && event.target.nodeName != 'A')
			return;

		cbo.serverContext.value = escape(event.target.innerHTML);
		//cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		this._callbackManager.execute(cbo, true);
	},

	_scrollingLoadOnDemand: function (event)
	{

		//A.T. 12 July - Fix for bug #24397 - Scrolling by clicking the down the scrollbar arrow loads duplicate items to the list in IE 8
		if (this.__requestInProgress)
			return;

		this.__requestInProgress = true;
		var container = this._elements["DropDownContents"];

		//alert (container.scrollHeight + " ; " + container.clientHeight + " ; " + container.scrollTop);

		if (container.scrollHeight == container.clientHeight + container.scrollTop)
		{
			// trigger load on demand
			// store scroll top
			this._dropDownScrollTop = container.scrollTop;
			this._onPagerMoreResults(event);
		}
		else
		{
			//A.T. 12 July - Fix for bug #24397 - Scrolling by clicking the down the scrollbar arrow loads duplicate items to the list in IE 8
			this.__requestInProgress = false;
		}
	},

	_genericScrollHandler: function (event)
	{

		// A.T. Fix for bug #22775
		try
		{
			if (!this.__isMouseDown)
			{
				this._elements["Input"].focus();
			}

		} catch (e)
		{
			// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
			// for some reason - there is no stable way to detect when to call focus() and when not to 
		}
	},

	_listBlurHandler: function (event)
	{
		if (this.get_enableClosingDropDownOnBlur())
		{
			setTimeout(Function.createDelegate(this, this.__closeOnListBlur), 100);
			this.__listBlurEvent = event;
		}
	},

	__closeOnListBlur: function ()
	{
		// check if focus is in the input, and if not, close the dropdown
		if (this.__listBlurFlag)
		{
			// A.T. 12 March 2010 - fix for bug #28867 (additional check for mouseOver)
			if (this.behavior.get_visible() && !this.__mouseOver && this.get_enableClosingDropDownOnBlur())
			{
				this.closeDropDown();
				// K.D. July 5th, 2013 Bug #146193 The clientside Blur event is fired for all WebDropDowns on the page
				// K.D. July 16th, 2013 Bug #145376 WebDropDown raises multiple Blur events 
				// Blur should be raised only on the _onBlurHandler. Removing the blur event from here
				//this._raiseClientEvent('Blur', 'DropDownControl', this.__listBlurEvent, null);
			}

			if (this.get_showDropDownButton() && this._elements["ButtonImage"])
			{
				this._elements["ButtonImage"].className = this.get_buttonCssClass();
			}
			// K.D. May 30th, 2011 Bug #76381 Have to check whether TargetTable element is defined
			if (this._elements["TargetTable"])
				this._elements["TargetTable"].className = this.get_controlAreaCssClass();

			// persisting logic
			
			// custom value persistence: if the current value in the input doesn't match any of the items text EXACTLY
			var shouldPersist = true;
			if (this.get_persistCustomValues())
			{
				for (i = 0; i < this.get_items().getLength(); i++)
				{
					// if (this.get_currentValue() == this.get_items()._items[i].get_text())
					if (this.get_currentValue() == this.get_items().getItem(i).get_text())
					{
						shouldPersist = false;
						break;
					}
				}

				if (shouldPersist)
				{
					// create a new item object
					var newItem = this.get_items().createItem();
					// K.D. Bug #103159 When EnablePersistingCustomValues is true and add value which contains character & an error is previwed
					newItem.set_text(encodeURIComponent(this.get_currentValue()));
					// mark the item as custom so that we can check the EnableCustomSelection later on 
					newItem.set_custom(true);
					// persist the item
					this.get_items().add(newItem);
				}
			}
		}
	},

	_mouseOverForBlur: function (evnt)
	{
		this.__mouseOver = true;
	},

	_mouseOutForBlur: function (evnt)
	{
		this.__mouseOver = false;
	},

	_onInputMouseOutHandler: function (evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		// if (this._elements["Input"].id == evnt.id) {
		// fire InputMouseDown event 
		this._raiseClientEvent('InputMouseOut', 'DropDownControl', evnt, null);

		// remove hover style
		$util.removeCompoundClass(this._elements["Input"], this.get_inputHoverCssClass());
		//}

	},

	_onInputMouseOverHandler: function (evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}
		// if (this._elements["Input"].id == evnt.id) {
		// fire InputMouseDown event 
		this._raiseClientEvent('InputMouseOver', 'DropDownControl', evnt, null);

		// add hover style
		$util.addCompoundClass(this._elements["Input"], this.get_inputHoverCssClass());

		//}

	},
	_onCompositionStartHandler: function (evnt) {
		this._inComposition = true;
		this._compositionStartValue = evnt.target.value;
	},
	_onCompositionEndHandler: function (evnt) {
		if (!this.get_enableCustomValues()) {
			var compareToValue = evnt.target.value;
			// check selection

			if (compareToValue && this.__checkIfValueIsCustom(compareToValue)) {

				evnt.target.value = this._compositionStartValue;
				this.set_currentValue(this._elements["Input"].value, false);
				this._raiseClientEvent('ValueChanged', 'DropDownEdit', null, null, this.get_currentValue(), this.get_previousValue());
				$util.preventDefaults(evnt);
			}
		}
		this._inComposition = false;
	},
	_onFocusHandler: function (evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		if (evnt.target == this._elements["Input"])
		{
			// change style to focused
			$util.addCompoundClass(this._elements["Input"], this.get_inputFocusCssClass());
			// this._elements["ButtonImage"].className =  this.get_buttonFocusCssClass();
			this._elements["TargetTable"].className = this.get_controlAreaFocusCssClass();
			// raise focus event on the control itself

			if (this.__blurFlag)
			{
				if (this._elements["Input"].value == this.get_nullText() && this.get_nullText() != '')
				{
					this._elements["Input"].value = '';
					$util.removeCompoundClass(this._elements["Input"], this.get_nullTextCssClass());
				}
				this._raiseClientEvent('Focus', 'DropDownControl', evnt, null);
			}

			this.__blurFlag = false;

			this.__listBlurFlag = false;
		}

		






		//  this.__isInternalFocus=false;

	},

	// this handler is needed in order to set focus on the dropdown input element, as soon as the animation ends
	_onAnimationEnd: function ()
	{

		try
		{

			// N.A. 6/6/2016 Bug #217237: Focus back on the input, only if there isn't a blur event.
			if (this.__isDropDownEvent && !this.__listBlurFlag)
			{
				// A.T. Fix for bug #22775
				try
				{
					this._elements["Input"].focus();

				} catch (e)
				{
					// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
					// for some reason - there is no stable way to detect when to call focus() and when not to 
				}
				//this.__moveInputCursorToEnd();
				this.__isInternalFocus = true;
				this.__isDropDownEvent = false;

			}

			// fire dropdown closing / opening events 
			//A.T. Fix for bug #36326 - The client-side event DropDownClosed fires before the list with items is closed.
			this.__fireOpenCloseEvents();

		} catch (err)
		{
			this.__fireOpenCloseEvents();
		}

	},

	__fireOpenCloseEvents: function ()
	{
		// fire dropdown closing / opening events 
		if (this.__isClosing)
		{
			this._raiseClientEvent('DropDownClosed', 'DropDownContainer', null, null);
			this.__isClosing = false;

		} else if (this.__isOpening)
		{
			this._raiseClientEvent('DropDownOpened', 'DropDownContainer', null, null);
			this.__isOpening = false;
		}
	},

	_onBlurHandler: function (evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		if (evnt.target == this._elements["Input"])
		{
			this.__listBlurFlag = true;
		}
		//K.D. October 31st, 2013 Bug #155821 The Opend drop down list remains displayed although it has lost focus if the mouse cursor hovers over the pull down button or its list when lost focus.
		
		if (evnt.target == this._elements["Input"] && (!this.__mouseOver || this.__isTabKey))
		{

			this.__blurFlag = true;

			$util.removeCompoundClass(this._elements["Input"], this.get_inputFocusCssClass());
			//$util.removeCompoundClass(this._elements["ButtonImage"], this.get_buttonFocusCssClass());
			//$util.removeCompoundClass(this._elements["TargetTable"], this.get_controlAreaFocusCssClass());

			if (this.get_showDropDownButton() && this._elements["ButtonImage"])
			{
				this._elements["ButtonImage"].className = this.get_buttonCssClass();
			}
			this._elements["TargetTable"].className = this.get_controlAreaCssClass();

			// focus is somewhere else, therefore close this dropdown and fire blur even

			if (this.get_enableClosingDropDownOnBlur())
			{
				// this.behavior.set_visible(false);
				

				if (this.behavior.get_visible() && !(this.behavior._dropDownAnimation && this.behavior._dropDownAnimation.get_isAnimating() && this.__isClosing))
				{
					this.closeDropDown();
				}
			}
			//this._adjustMaxHeight();
			// blur event for the control itself
			if ((this.get_currentValue() == '' || this.get_currentValue() == null) && this.get_nullText() != '')
			{
				this._elements["Input"].value = this.get_nullText();
				$util.addCompoundClass(this._elements["Input"], this.get_nullTextCssClass());
			}

			this._raiseClientEvent('Blur', 'DropDownControl', evnt, null);

			// custom value persistence: if the current value in the input doesn't match any of the items text EXACTLY
			var shouldPersist = true;
			if (this.get_persistCustomValues())
			{
				for (i = 0; i < this.get_items().getLength(); i++)
				{
					// if (this.get_currentValue() == this.get_items()._items[i].get_text())
					if (this.get_currentValue() == this.get_items().getItem(i).get_text())
					{
						shouldPersist = false;
						break;
					}
				}

				if (shouldPersist)
				{
					// create a new item object
					var newItem = this.get_items().createItem();
					// K.D. Bug #103159 When EnablePersistingCustomValues is true and add value which contains character & an error is previwed
					newItem.set_text(encodeURIComponent(this.get_currentValue()));
					// mark the item as custom so that we can check the EnableCustomSelection later on 
					newItem.set_custom(true);
					// persist the item
					this.get_items().add(newItem);
				}
			}
		}
		
		delete this.__isTabKey;
	},

	_onSelectstartHandler: function (elem, adr, evnt)
	{
		//   $util.cancelEvent(evnt);
	},

	_onMouseoverListHandler: function (evnt)
	{

		//A.T. 23 July 2010 - Fix for bug #24349 - Hovering item during LoadOnDemand preserves the hovered style of the item after the request is finished
		if (this.__requestInProgress)
			return;

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		clearTimeout(this._unhoverTimeoutID);

		var item = this.__getNearestItem(evnt.target);

		if (item != null && !item.get_disabled())
		{
			// if (this.__getHoveredItem()) {
			//     this.__getHoveredItem().unhover();

			// }
			item.hover();
		}

		if (this.__getHoveredItem() != null && item != null && item.get_index() == this.__getHoveredItem().get_index())
		{
			return;
		}

		if (item != null)
		{
			if (this.__getHoveredItem())
			{
				this._raiseClientEvent('ItemMouseOut', 'DropDownControl', evnt, null, this.__getHoveredItem());
			}
			this._raiseClientEvent('ItemMouseOver', 'DropDownControl', evnt, null, item);
		}

		if (item != null && !item.get_disabled())
		{
			this.__setHoveredItem(item);
		}
	},

	__setHoveredItem: function (item)
	{
		this.__hoveredItem = item;
	},

	__getHoveredItem: function ()
	{
		return this.__hoveredItem;
	},

	// __unhoverItems: function() {
	//     for (i = 0; i < this.get_items()._items.length; i++) {
	//         if (!this.get_items()._items[i].get_disabled()) {
	//             this.get_items()._items[i].unhover();
	//         }
	//     }
	// },

	// we support automatic postback when the dropdown is initially opened, if and only if there are no items
	// this enables us to support lazy loading scenarios, where we don't want any initial footprint, unless the user types or opens the dropdown
	__loadInitial: function (elem, adr, evnt)
	{
		if (this.get_items()._items.length == 0)
		{

			












			// go to the server, no items avaiiable
			// this.__autoFilterOnServer(elem, adr, evnt);
			this.loadItems();
		}
	},

	_onMousedownHandler: function (elem, adr, evnt)
	{
		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		var item = this.__getNearestItem(elem);
		// K.D. June 10th, 2011 We should keep track on where mousedown is performed and should check 
		// against the value on mouseup to ensure mouseup not performing action if mousedown was outside of the
		// drop down
		this._mouseDownItem = elem;

		if (item != null)
		{
			this._raiseClientEvent('ItemMouseDown', 'DropDownControl', evnt, null, item);
		}

		// handle mouse down on the value display (Input is the marker / mkr of the input value display component)
		if (this._elements["Input"].id == elem.id)
		{

			// fire InputMouseDown event 
			this._raiseClientEvent('InputMouseDown', 'DropDownControl', evnt, null);
		}

		// change button image
		//A.T. 26 Feb. Fix for bug #27945 - Exception thrown on hovering the drop-down input field when Button.Visible = False
		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			if ((this._elements["Button"].id == elem.id || this._elements["ButtonImage"].id == elem.id) &&

			this.get_buttonPressedImageUrl() != null && this.get_buttonPressedImageUrl() != "")
			{
				this._elements["ButtonImage"].src = this.get_buttonPressedImageUrl();
			}
		}
		



		// K.D. July 25th, 2014 Bug #171683 The drop down closes the first time the list gets mousedown
		//if (!$util.IsIE)
		//{
		//    $util.cancelEvent(evnt);
		//}
	},

	_onMouseupHandler: function (elem, adr, evnt)
	{
		// K.D. June 10th, 2011 We should keep track on where mousedown is performed and should check 
		// against the value on mouseup to ensure mouseup not performing action if mousedown was outside of the
		// drop down.
		if (this.get_enabled() == false || elem != this._mouseDownItem)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		this.__isDropDownEvent = true;
		// K.D. March 10th, 2014 Bug #166043 Since the ID changes we should no longer compare by ID.
		if (this.get_showDropDownButton() && this._elements["ButtonImage"] && (this._elements["Button"] === elem || this._elements["ButtonImage"] === elem))
		{

			// change button image
			if (this.get_buttonNormalImageUrl() != null && this.get_buttonNormalImageUrl() != "")
			{
				if (this.get_buttonHoverImageUrl() != null && this.get_buttonHoverImageUrl() != "")
				{
					this._elements["ButtonImage"].src = this.get_buttonHoverImageUrl();
				}
				else
				{
					this._elements["ButtonImage"].src = this.get_buttonNormalImageUrl();
				}
			}

			this.__isButtonClick = true;
			//    this._elements["Input"].focus();

			//this.__loadInitial(elem, adr, evnt);

			// trigger dropdown open / close
			// this.set_selectedItemIndex(0); // set the first item as the selected one
			if (this.behavior.get_visible())
			{

				








				this.closeDropDown();

			}
			else if (this.get_displayMode() != $IG.DropDownDisplayMode.ReadOnly)
			{
				








				this.openDropDown();
			}
			// A.T. Fix for bug #22775
			try
			{
				this._elements["Input"].focus();

			} catch (e)
			{
				// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
				// for some reason - there is no stable way to detect when to call focus() and when not to 
			}
			this.__moveInputCursorToEnd();
			this.__isInternalFocus = true;

		} else
		{

		}

		






	},

	_onPasteHandler: function (elem, adr, evnt)
	{
		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		// detect whether value has changed, and if so , fire filtering
		if (evnt == null)
			evnt = elem;

		this._currentEvent = evnt;

		setTimeout(Function.createDelegate(this, this.filter), 20);
		this.__isPasteOperation = true;
	},

	_onCutHandler: function (evnt)
	{
		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		this._currentEvent = evnt;
		setTimeout(Function.createDelegate(this, this.filter), 20);
		this.__isPasteOperation = true;
	},

	// K.D. January 5th, 2012 Bug #75133 FF Opens a new tab on ctrl+click and a new window on shift+click
	// so preventing the default behavior
	_onClickHandler: function (evnt)
	{
		if (this.get_enableMultipleSelection())
		{
			if (evnt && (evnt.ctrlKey || evnt.shiftKey))
			{
				$util.cancelEvent(evnt);
			}
		}
	},

	filter: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDropDown.filter">
		/// invokes filtering programatically. Filtering will be executed on the text that's currently in the input box 
		///</summary>
		args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', null, null, this._elements["Input"].value, this.get_currentValue());
		var cancel = args ? args.get_cancel() : false;

		if (!cancel && this.get_displayMode() == $IG.DropDownDisplayMode.DropDown)
		{

			// handle value display
			this.set_currentValue(this._elements["Input"].value, false);
			this._raiseClientEvent('ValueChanged', 'DropDownEdit', null, null, this.get_currentValue(), this.get_previousValue());


			if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
			{
				var args = this._raiseClientEvent('AutoFilterStarting', 'DropDownEdit', null, null, this.get_currentValue(), this.get_previousValue());
				var cancel = args ? args.get_cancel() : false;
				if (!cancel)
				{
					this.__autoFilter();
					this._raiseClientEvent('AutoFilterStarted', 'DropDownEdit', null, null, this.get_currentValue(), this.get_previousValue());

				}

				if (this.get_enableAutoCompleteFirstMatch())
				{
					this.__autoCompleteFirstMatch(this._elements["Input"]);
				}

			} else if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server)
			{
				clearTimeout(this._timeoutID);
				this.__autoFilterOnServer();

			}
			else
			{
				// find and select first match
				this.__findAndSelectItem();
			}
		} else
		{
			// rollback old value
			this._elements["Input"].value = this.get_currentValue();
		}
	},
	clearFilter: function () {
		///<summary locid="M:J#Infragistics.Web.UI.WebDropDown.clearFilter">
		/// Clears the applied filter programmatically.
		///</summary>
		var list = this._elements["List"],
			item;

		this.set_currentValue("", true);
		// K.D. September 3rd, 2014 Bug #162266 Handling the server case as well
		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server) {
			clearTimeout(this._timeoutID);
			this.__autoFilterOnServer();
		} else {
			// remove the items
			while (list.childNodes[0]) {
				list.removeChild(list.childNodes[0]);
			}
			for (var j = 0; j < this.get_items().get_length() ; j++) {
				// K.D. September 2nd, 2014 Bug #179655 When select a value from dropdown and then click on other cell an error is previewed
				item = this.get_items()._getObjectByAdr(j);
				if (item) {
					list.appendChild(item._element);
					item._set_visible(true);
				}
			}
		}
	},
	/// onchange event for the input box component
	/// this may be triggered whenever the user pastes text or sth
	_onChangeHandler: function (elem, adr, evnt)
	{

		





















































		//this.filter();
		//this.__isPasteOperation=true;

	},

	_onMouseoutHandler: function (elem, adr, evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		// remove hover class for control
		$util.removeCompoundClass(this._elements["TargetTable"], this.get_controlAreaHoverCssClass());

		// change button image
		//A.T. 26 Feb. Fix for bug #27945 - Exception thrown on hovering the drop-down input field when Button.Visible = False
		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			if (this.get_buttonNormalImageUrl() != null && this.get_buttonNormalImageUrl() != "" && this._elements["ButtonImage"].src != this.get_buttonNormalImageUrl())
			{
				this._elements["ButtonImage"].src = this.get_buttonNormalImageUrl();
			}
		}
	},

	_onMouseoverHandler: function (elem, adr, evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		$util.addCompoundClass(this._elements["TargetTable"], this.get_controlAreaHoverCssClass());

		// change button image
		//A.T. 26 Feb. Fix for bug #27945 - Exception thrown on hovering the drop-down input field when Button.Visible = False
		if (this.get_showDropDownButton() && this._elements["ButtonImage"])
		{
			if (this.get_buttonHoverImageUrl() != null && this.get_buttonHoverImageUrl() != "" && this._elements["ButtonImage"].src != this.get_buttonHoverImageUrl())
			{
				this._elements["ButtonImage"].src = this.get_buttonHoverImageUrl();
			}
		}
	},

	_onMouseoutListHandler: function (elem, adr, evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		if (evnt == null) evnt = elem;

		var item = this.__getNearestItem(evnt.target);

		//  if (item==null) item = this.__getHoveredItem();

		if (item != null)
		{
			// unhover item , if any
			if (this.__getHoveredItem())
			{
				this.__getHoveredItem().unhover();

			}
		}
		this._currentUnhoverEvent = evnt;
		this._unhoverTimeoutID = setTimeout(Function.createDelegate(this, this.__realUnhover), 20);
	},

	__realUnhover: function ()
	{
		this.__setHoveredItem(null);
		var item = this.__getNearestItem(this._currentUnhoverEvent.target);
		this._raiseClientEvent('ItemMouseOut', 'DropDownControl', this._currentUnhoverEvent, null, item);

	},

	_onKeypressHandler: function (elem, adr, evnt)
	{

		if (this.get_enabled() == false)
		{
			// do not intercept events if control is marked as disabled
			return;
		}

		// check if there is a match, and if EnableCustomValues is false, and there is no match, set cancel to true
		if (!this.get_enableCustomValues())
		{
			if (this.__isDeleting)
			{
				this.__isDeleting = false;
				return;
			}

			// A.T. 30 March 2010 Fix for bug 30071 - You are not allowed to move the focus from the control when value is selected. (FF)
			if (this.__isTabKey)
			{
				this.__isTabKey = false;
				return;
			}

			var character = String.fromCharCode(evnt.charCode);

			// A.T. 23/11/2009 Fix for bug #24843 Not able to type matched value on the selected text when EnableCustomValues set to "false".
			var compareToValue = "";

			if (!this.get_enableAutoCompleteFirstMatch())
			{
				compareToValue = this._elements["Input"].value + character;
			} else
			{
				compareToValue = this.__get_valueBeforeAutoCompleteFirstMatch() + character;
			}


			// check selection
			var selectionText = "";
			// K.D. December 10th, 2013 Bug #159179 The selection should be handled as for the rest of the browsers in the case of IE11
			if ($util.IsIE && !$util.IsIE11Plus)
			{
				selectionText = document.selection.createRange().htmlText;
			} else
			{
				var start = this._elements["Input"].selectionStart;
				var end = this._elements["Input"].selectionEnd;
				selectionText = this._elements["Input"].value.substring(start, end);
			}

			if (selectionText == this._elements["Input"].value)
			{
				// value will be deleted, so compare only with the character
				compareToValue = character;
			}

			this._cancelKeyUp = this.__checkIfValueIsCustom(compareToValue);

			if (this._cancelKeyUp)
			{
				$util.cancelEvent(evnt);
			}
		}
	},

	
	_get_selectedText: function ()
	{
		var elem = this._elements["Input"];
		if (this._tr === undefined)
		{
			try
			{
				
				// K.D. December 5th, 2013 Bug #159179 With IE11 we can use selection start and end
				if ((!($util.IsIE) || $util.IsIE11Plus) && elem.selectionStart != null)
					this._tr = 1;
			} catch (ex) { }
			if (this._tr != 1)
				this._tr = (elem.createTextRange != null) ? elem.createTextRange() : null;
		}

		var txt = '', tr = this._tr;
		var sel0 = 0, sel1;
		
		if (tr == null)
			return { text: txt };
		
		if (tr == 1)
		{
			if ((sel0 = elem.selectionStart) < (sel1 = elem.selectionEnd))
				txt = elem.value.substring(sel0, sel1);
			return { text: txt, start: sel0, end: sel1 };
		}
		
		
		try
		{
			
			var range = document.selection.createRange(), val = elem.value;
			var i = val.length;
			tr = range.duplicate();
			tr.move('textedit', -1);
			try
			{
				while (tr.compareEndPoints('StartToStart', range) < 0)
				{
					tr.moveStart('character', 1);
					sel0++;

					if (sel0 > i)
						break;
				}
			}
			catch (ex) { }
			txt = range.text;
		}
		catch (ex) { }
		sel1 = sel0 + txt.length;
		return { text: txt, start: sel0, end: sel1 };
	},
	__checkIfValueMatches: function (val)
	{
		// A.M. April 27th, 2015 Bug #192955 "Inconsistent behavior for using backspace when EnableCustomValues="False""
		// We get the length of all items in WDD, not only of those filtered in the list
		for (i = 0; i < this.get_items().get_length(); i++)
		{
			if (this.get_items().getItem(i).get_text() == val)
				return true;
		}
		return false;
	},

	_onKeydownHandler: function (elem, adr, evnt)
	{
		var key = evnt ? evnt.keyCode : 0, input = this._elements["Input"];
		if (!input || !this.get_enabled() || key < 5)
		{
			// do not intercept events if control is marked as disabled
			return;
		}
		// raise the keydown client event
		// this._raiseClientEvent('KeyDown', 'DropDownControl', evnt, null);
		this.__isButtonClick = false;
		this.__inKeyUp = false;
		
		delete this._dontOpen;
		
		var args = (input.id == elem.id) ? this._raiseClientEvent('InputKeyDown', 'DropDownControl', evnt, null) : null;
		if (args && args.get_cancel())
		{
			$util.cancelEvent(evnt);
			return;
		}
		// A.T. 10/07/2009 Fix for bug 19246 (adding support for DEL key)
		if (key == 8 || key == 127) // backspace and DEL 
		{
			this.__isDeleting = true;
			
			if (!this.get_enableCustomValues())
			{
				var compareToValue = "";
				// check selection
				var selectionText = this._get_selectedText();
				var start = selectionText.start, end = selectionText.end;
				if (start != end)
					compareToValue = input.value.substring(0, start) + input.value.substr(end);
				else
				{
					if (key == 127)
						compareToValue = input.value.substring(0, start) + input.value.substr(end + 1);
					else
						compareToValue = input.value.substring(0, start - 1) + input.value.substr(end);
				}

				if (compareToValue && !this.__checkIfValueMatches(compareToValue))
				{
					$util.cancelEvent(evnt);
				}
				return;
			}
		} else
		{
			this.__isDeleting = false;
		}

		//A.T. 30 March 2010 Fix for bug 30071 - You are not allowed to move the focus from the control when value is selected. (FF)
		this.__isTabKey = key == 9;

		// disallow F1 to F12 ;
		// A.T. 20/07/2009 Bug 19586: keyCode "99" is Numlock 3 and should not be disallowed 
		//A.T. 30/07/2010 Fix for bug #36118 Japanese Katakana string are converted back to Hiragana upon postback
		if (((key >= 112 && key <= 123) && key != 118 && key != 121) || key == 20 || key == 19 || (key == 45 && !evnt.shiftKey) || key == 93 || key == 92 || key == 145)
		{
			$util.cancelEvent(evnt);
			return;
		}
		// K.D. September 24th, 2013 Bug #152535 Hitting enter now performs selection if the input value
		// matches an item from the WDD list.
		if (input.id == elem.id) {
			// store previous value
			this.set_previousValue(input.value);

			// RETURN KEY
			if (key == 13) {
				// cancel the form submission on Enter key
				// K.D. October 14th, 2013 Bug #154665 When selecting an item via the keyboard with multiple
				// selection the first item always gets selected
				if (!this.get_enableMultipleSelection()) {
					var item, oldItem, items = this.get_items();
					for (var i = 0; i < items.getLength() ; i++) {
						item = items.getItem(i);
						if (item.get_text() === input.value) {
							oldItem = this.get_selectedItem();
							this.set_activeItem(item);
							this.__singleSelect(evnt, item, oldItem);
						}
					}
				}
				$util.preventDefaults(evnt);
				//$util.cancelEvent(evnt);
			}
		}

		
		//A.T. 27 August 2014 - fix for #177686 - First value in WebDropDownEditor provider is selected when a Space key is pressed in the input field of the provide with already entered number
		if (this.get_displayMode() < 2 && (key == 40 || key == 38 || key == 13 || (key >= 32 && key <= 36 && evnt.ctrlKey)))
		{
			this.__handleKbNavigation(evnt);
		}
		
		// arrows,home,end + not-readOnly
		if (key >= 35 && key <= 40 && ($util.IsChrome || $util.IsSafari) && this.get_displayMode() != 1)
		{
			$util.preventDefaults(evnt);
		}

		if (key == 27) // ESC key 
		{
			if (this.behavior.get_visible() && !this.__isClosing)
			{
				this.closeDropDown();
			}
		}
	},

	_onKeyupHandler: function (elem, adr, evnt)
	{
		var key = evnt ? evnt.keyCode : 0, input = this._elements["Input"];
		if (!input || !this.get_enabled() || key < 5)
		{
			// do not intercept events if control is marked as disabled
			return;
		}
		if (this.__isPasteOperation)
		{
			this.__isPasteOperation = false;
			return;
		}
		if (this._cancelKeyUp)
		{
			this._cancelKeyUp = false;
			return;
		}
		// K.D. August 25th, 2011 Bug #84465 The event is passed as the first argument when a WebTextEditor is
		// used and the rest of the arguments are undefined causing a javascript exception when checking keyCodes
		if (elem && elem.keyCode && !evnt)
		{
			evnt = elem;
		}
		// paste keyboard commands are handled by the onPasteHandler
		if ((key == 45 && evnt.shiftKey) || (evnt.ctrlKey && key == 86))
		{
			return;
		}
		if (evnt == null)
		{
			evnt = elem;
			elem = evnt.target;
		}
		if (evnt.event)
			evnt = evnt.event;
		if (input.id == elem.id)
		{
			// fire InputKeyUp event 
			this._raiseClientEvent('InputKeyUp', 'DropDownControl', evnt, null);
		}
		if (key == 27 || key == 9) // ESC key is handled in onKeydownHandler; Do nothing for TAB key
			return;
		// Fx keys
		// disallow F1 to F12 ; 
		//A.T. 30/07/2010 Fix for bug #36118 Japanese Katakana string are converted back to Hiragana upon postback
		//T.P. 12/27/2016 Fix for bug #230098 When conversion using F6, F8 and F9 is used the value should be internally updated, but no return from the handler.
		if ((key >= 112 && key <= 116) || key == 122 || key == 123 || key == 20 || key == 19 || key == 45
	   || key == 93 || key == 92 || key == 145
	   )
		{
			return;
		}
		// A.T. 20/07/2009 Bug 19586: keyCode "99" is Numlock 3 and should not be disallowed 
		if (key == 16 || key == 17 || key == 18
		|| key == 33 || key == 34 || key == 35 || key == 36
		|| key == 91 || key == 144)
		{
			return;
		}
		// handle key up on the list -> up arrow and down arrow !
		// toggle dropdown (open or close)
		if (evnt.altKey && (key == 40 || key == 38))
		{
			if (key == 38)
			{
				






				if (this.behavior.get_visible() && !this.__isClosing) {
					this.closeDropDown();
				}
				return;
			}
			else if (key == 40 && this.get_displayMode() != $IG.DropDownDisplayMode.ReadOnly)
			{
				








				if (!this.behavior.get_visible() && !this.__isOpening) {
					this.openDropDown();
				}
				return;
			}
		}
		// keycode 45 == INSERT key
		if (evnt.ctrlKey || evnt.altKey || (evnt.shiftKey && key == 45))
			return;
		// if (key== 40 || key==38 || key==13) 
		// {
		//     this.__handleKbNavigation(evnt);
		// } else 
		if (key == 37 || key == 39)
		{
			// we will do filtering if there was selected text in the input, and by moving
			// the left and right arrow keys, the selection is gone
			if (this.get_currentValue() == this.__get_valueBeforeAutoCompleteFirstMatch())
			{
				return;
			}
		}

		if (key != 40 && key != 38 && key != 13)
		{
			var args;
			if (input.id == elem.id || this._element == elem.id)
			{

				// check if custom selection is enabled
				//   if (this.get_enableCustomValueSelection() && this.get_enableClientFilteringOnly() && key != 27 &&

				

























				


				







				args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', evnt, null, input.value, this.get_currentValue());
			}
			var cancel = args ? args.get_cancel() : false;
			if (!cancel && this.get_displayMode() == $IG.DropDownDisplayMode.DropDown)
			{
				// handle value display
				if (input.id == elem.id)
				{
					// no change
					// if (input.value.toLowerCase() == this.get_currentValue().toLowerCase())
					// {
					//     return;
				    // }

				    




					if (($util.IsChrome && key == 121) || ($util.IsFireFox && evnt.rawEvent.isComposing))
					{
						this.__inKeyUp = false;
					}
					if (this.__inKeyUp)
					{
						return;
					}
					this.__inKeyUp = true;
					this.set_currentValue(input.value, false);
					this._raiseClientEvent('ValueChanged', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
					if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
					{
						this._currentEvent = evnt;
						//  if (this.get_enableAutoFiltering()) {
						if (!(key == 40 || key == 38)) // up and down arrow keys are intercepted by another event
						{
							var args = this._raiseClientEvent('AutoFilterStarting', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
							var cancel = args ? args.get_cancel() : false;
							if (!cancel)
							{
								// this.__autoFilter(elem, adr, evnt);
								clearTimeout(this._timeoutID);
								// this.__start1 = new Date().getTime();
								// A.M. May 21st, 2015 Bug #194052 "When inputing values too fast in the WDD input field, the input value is
								// allowed even when EnableCustomValues="False" and this value is not existing in the items collection"
								this._timeoutID = setTimeout(Function.createDelegate(this, this.__autoFilter), 15);
								this._raiseClientEvent('AutoFilterStarted', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
							}
						}
						//  }
						// perform auto complete
						if (this.get_enableAutoCompleteFirstMatch())
						{
							//this.__autoCompleteFirstMatch(elem, adr, evnt);
							clearTimeout(this._autoCompleteTimeoutID);
							// this.__start1 = new Date().getTime();
							this._autoCompleteTimeoutID = setTimeout(Function.createDelegate(this, this.__autoCompleteFirstMatch), 15);
						}
					} else if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server)
					{

						// go to the server to fetch the items
						// if (this.get_previousValue() != this.get_currentValue())
						// {
						this._currentEvent = evnt;
						clearTimeout(this._timeoutID);
						// this.__start1 = new Date().getTime();
						this._timeoutID = setTimeout(Function.createDelegate(this, this.__autoFilterOnServer), this.get_autoFilterTimeoutMs());
						// } 

					} else
					{
						this.__findAndSelectItem(elem, adr, evnt);
					}
				}
			} else
			{
				// rollback old value
				input.value = this.get_currentValue();
			}
		}
	},

	__get_valueBeforeAutoCompleteFirstMatch: function ()
	{
		return (this.__valueBeforeAutoCompleteFirstMatch == null) ? this.get_currentValue() : this.__valueBeforeAutoCompleteFirstMatch;
	},

	__set_valueBeforeAutoCompleteFirstMatch: function (val)
	{
		this.__valueBeforeAutoCompleteFirstMatch = val;
	},

	__findAndSelectItem: function (elem, adr, evnt)
	{
		if (evnt && evnt.keyCode != 27 && evnt.keyCode != 13 && evnt.keyCode != 40 && evnt.keyCode != 38) // also handle backspace ?
		{
			
			
			var txt, txtII, item, ii, i, items = this.get_items(), len = items.getLength(), low = !this.get_enableCaseSensitivity();
			var selLen = 0, selItems = [], txts = this._elements["Input"].value;
			if (low)
				txts = txts.toLowerCase();
			txts = this.get_enableMultipleSelection() ? txts.split(this.get_multiSelectValueDelimiter() || ',') : [txts];
			var txtsLen = txts ? txts.length : 1;
			// remove blanks on the middle and matching texts
			for (i = 0; i < txtsLen; i++)
			{
				txt = txts[i];
				if (!txt.replace(/ /g, ''))
				{
					// keep last blank item as validation flag for startsWith (find selected items)
					if (i < txtsLen - 1)
					{
						txts.splice(i, 1);
						txtsLen--;
					}
					else
						txts[i] = "";
				}
				// remove same texts
				else for (ii = i + 1; ii < txtsLen; ii++)
				{
					if (txt == txts[ii])
					{
						txts.splice(ii, 1);
						txtsLen--;
					}
				}
			}
			// last item after separator: use to process startsWith
			var last = txts[txtsLen - 1];
			// find selected items
			i = -1;
			while (txtsLen && ++i < len)
			{
				item = items.getItem(i);
				if (!item || item.get_disabled())
					continue;
				txt = item.get_text();
				if (low)
					txt = txt.toLowerCase();
				for (ii = 0; ii < txtsLen; ii++)
				{
					txtII = txts[ii];
					// use startsWith only for last item after separator
					if (txt == txtII || (txtII && last == txtII && txt.startsWith(txtII)))
					{
						selItems[selLen++] = item;
						// remove processed text-item
						txts.splice(ii, 1);
						txtsLen--;
					}
				}
			}
			// adjust selection for found matching items
			var oldIndex = this.get_selectedItemIndex();
			var oldItem = oldIndex == -1 ? null : items.getItem(oldIndex);
			// no new selection
			if (selLen < 1)
			{
				this.__unselectAllItems();
				this.__resetSelection(oldItem, evnt);
			}
			// do not select matching items
			else if (!this.get_autoSelectOnMatch())
			{
				if (!this.behavior.get_visible() && !this.behavior.get_isAnimating())
					this.openDropDown();
				this.__scrollToItem(selItems[0]);
			}
			// select matching items
			else
			{
				var oldSel = this.get_selectedItems();
				if ((!oldSel || !oldSel.length) && oldItem)
					oldSel = [oldItem];
				var oldLen = oldSel ? oldSel.length : 0;
				// check if old selection is same as new
				if (oldLen == selLen)
				{
					while (oldLen-- > 0)
					{
						i = selLen;
						ii = oldSel[oldLen].get_index();
						while (i-- > 0)
							if (selItems[i].get_index() == ii)
								break;
						if (i < 0)
							break;
					}
				}
				// new selection is not same as old
				if (oldLen >= 0)
				{
					var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', evnt, null, selItems, oldSel);
					if (!args || !args.get_cancel())
					{
						item = selItems[0];
						this.__unselectAllItems();
						i = selLen;
						if (i == 1)
							this.set_selectedItemIndex(item.get_index());
						else while (i-- > 0)
							selItems[i].select(true);
						this.set_activeItem(item);
						if (!this.behavior.get_visible() && !this.behavior.get_isAnimating())
							this.openDropDown();
						this.__scrollToItem(item);
						this._raiseClientEvent('SelectionChanged', 'DropDownSelection', evnt, null, selItems, oldSel);
						// no autocomplete for multiple selection
						if (selLen > 1)
							return;
					}
				}
			}
			
			













































































		}
		if (this.get_enableAutoCompleteFirstMatch())
		{
			if (elem == null)
				elem = this._elements["Input"];
			this.__autoCompleteFirstMatch(elem, adr, evnt);
		}
	},

	__resetSelection: function (currentSelectedItem, event)
	{
		// check index and if the old one is != -1, change it and fire events 
		if (this.get_selectedItemIndex() != -1)
		{
			// fire events and change index 
			//A.T. 6th of Feb 2010 - Fix for bug #27004 - Javascript error is thrown when we  try to access the old selected items.
			var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', event, null, [], [currentSelectedItem]);
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				this.set_selectedItemIndex(-1);
				//A.T. 6th of Feb 2010 - Fix for bug #27004 - Javascript error is thrown when we  try to access the old selected items.
				this._raiseClientEvent('SelectionChanged', 'DropDownSelection', event, null, [], [currentSelectedItem]);
			}
		}
	},

	__scrollToItem: function (item)
	{

		// var firstItem = this.get_items()._items[0];
		// var offset = Sys.UI.DomElement.getBounds(item._element).height* item.get_index();
		var offset = Math.abs($util.getPosition(item._element).y - $util.getPosition(this._elements["DropDownContents"]).y);
		this._elements["DropDownContents"].scrollTop = offset;

	},

	__checkIfValueIsCustom: function (val)
	{
		// var items = this.get_items()._items;
		// K.D. July 20th, 2011 Bug #81523 getLength() returns the current number of DOM elements and when they have been filtered we don't
		// go through the correct number of items. Changing it with get_length()
		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
		{
			for (i = 0; i < this.get_items().get_length(); i++)
			{
				//A.T. 22 June 2010 - Fix for bug #32138 - Drop down has limitations when AutoFilterQueryType=Contains and EnableCustomValues=False
				// if (items[i].get_text().toLowerCase().startsWith(val.toLowerCase()))
				if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.StartsWith && this.get_items().getItem(i).get_text().toLowerCase().startsWith(val.toLowerCase()))
					return false;
				else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.Contains && this.get_items().getItem(i).get_text().toLowerCase().indexOf(val.toLowerCase()) != -1)
					return false;
			}
		}
		else
		{
			for (i = 0; i < this.get_items().getLength(); i++)
			{
				//A.T. 22 June 2010 - Fix for bug #32138 - Drop down has limitations when AutoFilterQueryType=Contains and EnableCustomValues=False
				// if (items[i].get_text().toLowerCase().startsWith(val.toLowerCase()))
				if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.StartsWith && this.get_items().getItem(i).get_text().toLowerCase().startsWith(val.toLowerCase()))
					return false;
				else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.Contains && this.get_items().getItem(i).get_text().toLowerCase().indexOf(val.toLowerCase()) != -1)
					return false;
			}
		}
		return true;
	},

	__getNextVisibleItem: function (selectedIndex)
	{

		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		if (selectedIndex >= 0 && selectedIndex < length)
		{
			var index = selectedIndex + 1;

			while (index < length)
			{
				//  var nextItem = this.get_items()._getObjectByIndex(index);
				var nextItem = this.get_items().getItem(index);
				if (nextItem._get_visible() && !nextItem.get_disabled())
					return nextItem;

				index++;
			}
		}

		return null;
	},

	__getPreviousVisibleItem: function (selectedIndex)
	{

		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		if (selectedIndex >= 0 && selectedIndex < length)
		{
			var index = selectedIndex - 1;
			while (index >= 0)
			{
				//var prevItem = this.get_items()._getObjectByIndex(index);
				var prevItem = this.get_items().getItem(index);
				if (prevItem._get_visible() && !prevItem.get_disabled())
					return prevItem;

				index--;
			}
		}

		return null;
	},

	// e - event, newItem - item that will be selected, oldItem - currently selected item 
	__singleSelect: function (e, newItem, oldItem)
	{
		if ((newItem != null && oldItem != null && newItem.get_index() != oldItem.get_index()) || (newItem == null || oldItem == null))
		{
			var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', e, null, [newItem], [oldItem]);
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{

				if (this.get_enableMultipleSelection())
				{
					this.__unselectAllItems();
				} else
				{
					if (this.get_selectedItem() != null)
					{
						this.get_selectedItem().unselect();
					}
				}
				newItem.select();

				//this.set_selectedItemIndex(newItem.get_index());
				this.set_selectedItemIndex(newItem.get_index());

				if (this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
				{
					newItem._element.childNodes[0].checked = true;
					newItem._element.childNodes[0].setAttribute('alt', this._checkedAlt);
					newItem._element.childNodes[0].setAttribute('title', this._checkedAlt);

					if (oldItem)
					{
						oldItem._element.childNodes[0].checked = false;
						oldItem._element.childNodes[0].setAttribute('alt', this._uncheckedAlt);
						oldItem._element.childNodes[0].setAttribute('title', this._uncheckedAlt);
					}
				}

				this._raiseClientEvent('SelectionChanged', 'DropDownSelection', e, null, [newItem], [oldItem]);
			}
		}
	},

	__multipleNoncontinuousSelect: function (e, newItem, allowUnselectActiveItem)
	{

		var oldSelectedItems = this.get_selectedItems();
		var newSelectedItems;

		// construct newSelectedItems
		if (newItem.get_selected())
		{
			// remove item 
			newSelectedItems = new Array();
			for (var i = 0; i < oldSelectedItems.length; i++)
			{
				if (oldSelectedItems[i].get_index() != newItem.get_index())
				{
					newSelectedItems.push(oldSelectedItems[i]);
				}
			}

		} else
		{
			// add item
			newSelectedItems = Array.clone(oldSelectedItems);
			newSelectedItems.push(newItem);
		}

		var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', e, null, newSelectedItems, oldSelectedItems);
		var cancel = args ? args.get_cancel() : false;
		if (!cancel)
		{

			if (newItem.get_selected() && (!newItem.get_activated() || allowUnselectActiveItem))
			{
				newItem.unselect();
			}
			else if (!newItem.get_selected())
			{
				newItem.select();
				//this.set_selectedItemIndex(newItem.get_index());
				this.set_selectedItemIndex(newItem.get_index());
			}

			if (this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
			{
				newItem._element.childNodes[0].checked = true;
				newItem._element.childNodes[0].setAttribute('alt', this._checkedAlt);
				newItem._element.childNodes[0].setAttribute('title', this._checkedAlt);
				//  if (currentItem)
				newItem._element.childNodes[0].checked = false;
				newItem._element.childNodes[0].setAttribute('alt', this._uncheckedAlt);
				newItem._element.childNodes[0].setAttribute('title', this._nucheckedAlt);
			}

			this._raiseClientEvent('SelectionChanged', 'DropDownSelection', e, null, newSelectedItems, oldSelectedItems);
		}
	},

	__multipleContinuousSelect: function ()
	{

	},

	// implements all of the keyboard navigation functionality
	__handleKbNavigation: function (e)
	{
		this.__isDropDownEvent = true;
		//var selectedIndex = this.get_selectedItemIndex();
		var activeItemIndex = 0;
		if (this.get_activeItem() != null)
		{
			//activeItemIndex = this.get_items().get_indexOf(this.get_activeItem());
			activeItemIndex = this.get_activeItem().get_index();
		}

		//if (selectedIndex == null)
		//    selectedIndex=0;

		//var currentItem = this.get_items()._getObjectByIndex(activeItemIndex);
		var currentItem = this.get_items().getItem(activeItemIndex);

		// if (currentItem==null)
		//     return;

		// END KEY
		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		if (e.keyCode == 35)
		{

			if (length == 0)
				return;

			// var lastItem = this.get_items()._items[this.get_items()._items.length-1];
			var lastItem = this.get_items().getItem(length - 1);
			if (lastItem != null)
			{
				this.__scrollToItem(lastItem);
				this.set_activeItem(lastItem);
				if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					this.__singleSelect(e, lastItem, currentItem);
			}
			return;
		}

		// HOME KEY
		if (e.keyCode == 36)
		{
			if (length <= 0)
				return;

			// var firstItem = this.get_items()._items[0];
			var firstItem = this.get_items().getItem(0);
			if (firstItem != null)
			{
				this.__scrollToItem(firstItem);
				this.set_activeItem(firstItem);
				if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					this.__singleSelect(e, firstItem, currentItem);
			}
			return;

		}

		
















		if (currentItem && currentItem._get_visible())
		{

			//if (!currentItem.get_selected()) {
			//    currentItem.select();
			//    return;
			//}
			// K.D. January 21st, 2012 Bug #99021 WebDropDown postbacks if we are filtering items on client and hit
			// the space bar, so including a check for autoselect on mat
			if (!currentItem.get_activated() && !e.altKey && !e.ctrlKey && !e.shiftKey && !currentItem.get_disabled() && this.get_autoSelectOnMatch())
			{
				this.set_activeItem(currentItem);
				
				
				if (currentItem.get_text() != this.get_currentValue())
					this.set_currentValue(currentItem.get_text(), true);
				if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					this.__singleSelect(e, currentItem, null);
				return;
			}

		} else
		{

			// get the nearest item that is visible
			currentItem = this.__getNextVisibleItem(activeItemIndex);

			if (!currentItem)
				currentItem = this.__getPreviousVisibleItem(activeItemIndex);

			//  if (currentItem && !currentItem.get_selected()) {
			//      currentItem.select();
			//      return;
			//  }
			// K.D. August 18th, 2011 Bug #83565 WebDropDown postbacks if we are filtering items on client and hit
			// the space bar, so including a check for autoselect on mat
			if (currentItem && !currentItem.get_activated() && !e.altKey && !e.ctrlKey && !e.shiftKey && !currentItem.get_disabled() && this.get_autoSelectOnMatch())
			{
				this.set_activeItem(currentItem);
				if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					this.__singleSelect(e, currentItem, null);
				return;
			}

		}

		// if (currentItem==null)
		//     return;

		//if (currentItem && currentItem.get_disabled())
		//    return;

		var container = this._elements["DropDownContents"];
		var container_pos = $util.getPosition(container);

		// ENTER and SPACE key handling
		//  if ((e.keyCode == 13 || (e.keyCode == 32 && !this._elements["Input"].focused)) && currentItem!=null) 

		if (e.keyCode == 32 && e.ctrlKey && currentItem != null)
		{
			this.__multipleNoncontinuousSelect(e, currentItem, true);
			// rollback the old value, so that we avoid having an interval character in the input box 
			this.__constructMultiSelectValue(e);
			this.__moveInputCursorToEnd();
			this.__lastSelectionWasContinuous = false;
		}

		if (e.keyCode == 13 && currentItem != null)
		{

			//if (currentItem != null) {
			//    this._elements["Input"].value = currentItem.get_text();
			//}

			// A.T. 22/09/2009 Fix for bug #22142 Keyboard directional should be used as navigation when multiple selection through checkboxes is enabled
			if (currentItem.get_selected() || (this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()) || !this.get_enableMultipleSelection())
			{

				if (!currentItem.get_selected())
				{
					this.__singleSelect(e, currentItem, null);

					args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', e, null, currentItem.get_text(), this.get_currentValue());

					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{
						var previousValue = this.get_currentValue();
						this.set_currentValue(currentItem.get_text(), true);
						this._raiseClientEvent('ValueChanged', 'DropDownEdit', e, null, this.get_currentValue(), previousValue);
					}
				}

				if (this.get_closeDropDownOnSelect())
				{
					//  var args = this._raiseClientEvent('DropDownClosing', 'DropDownContainer', e, null);
					//  var cancel = args ? args.get_cancel() : false;
					//  if (!cancel) {
					//      this.behavior.set_visible(false);
					//      this._raiseClientEvent('DropDownClosed', 'DropDownContainer', e, null);
					//  }

					this.closeDropDown();

				}

				// navigate URL 
				var url = currentItem.get_navigateUrl();
				var targetFrame = currentItem.get_target();

				// TFS Bug # 15806: if the url is empty, set the target frame to self, so that
				// we don't get a blank new window. Instead the dropdown will be just closed 
				if (url == null || url == "") targetFrame = "_self";

				if (targetFrame == "_self"
						|| targetFrame == "_parent"
						|| targetFrame == "_media"
						|| targetFrame == "_top"
						|| targetFrame == "_blank"
						|| targetFrame == "_search")
					window.open(url, targetFrame);
				else
					window.open(url);

			}
			










































































































































































































































		}

		// down arrow and up arrows only change the activation, when we hit space or enter, selection happens for the active item !
		if (e.keyCode == 40 && !e.altKey) // down arrow
		{

			// K.D. October 3rd, 2013 Bug #153584 When the list is filtered we cannot select an item with 
			// down arrow if the previous selected item was higher up in the list
			prevActive = this.get_activeItem();
			if (prevActive && !prevActive._get_visible()) {
				activeItemIndex = -1;
			}
			var nextItem = this.get_items().getItem(++activeItemIndex);

			if (nextItem && (!nextItem._get_visible() || nextItem.get_disabled())) {
				nextItem = this.__getNextVisibleItem(activeItemIndex);
			}

			if (nextItem)
			{
				if (!e.ctrlKey && !e.shiftKey)
				{
					
					//this.set_activeItem(nextItem);
					// select item
					var oldIndex = this.get_selectedItemIndex();

					// unselect old item
					// var oldItem = this.get_items()._getObjectByIndex(oldIndex);
					var oldItem = this.get_items().getItem(oldIndex);

					// A.T. 22/09/2009 Fix for bug #22142 Keyboard directional should be used as navigation when multiple selection through checkboxes is enabled
					if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					{
						// K.D. April 25th, 2012 Bug #109400 When use keyboard to select values and there is autopostback on selection changed the selected value is not correct
						// The value is now changed before the item is selected in order for the new value to appear after
						// the postback
						if (!oldItem || (oldItem && nextItem.get_index() != oldItem.get_index()))
						{
							var oldVal = this.get_currentValue();
							var newVal = nextItem.get_text();
							args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', e, null, newVal, oldVal);
							if (args && args.get_cancel())
							
								return;
							
							this.set_activeItem(nextItem);
							this.set_currentValue(newVal, true);
							newVal = this.get_currentValue();
							
							this.__singleSelect(e, nextItem, oldItem);
							this._raiseClientEvent('ValueChanged', 'DropDownEdit', e, null, newVal, oldVal);
						}
						
						else
						{
							this.set_activeItem(nextItem);
							this.__singleSelect(e, nextItem, oldItem);
						}
					}
					
					else
						this.set_activeItem(nextItem);
				} else if (e.keyCode == 40 && e.shiftKey && this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Keyboard)
				{

					if (!this.__lastSelectionWasContinuous)
					{
						this.__unselectAllItemsWithoutActiveItem();
					}

					this.set_activeItem(nextItem);
					if (nextItem.get_selected())
					{
						currentItem.unselect();
					}

					this.__multipleNoncontinuousSelect(e, nextItem);

					this.__lastSelectionWasContinuous = true;

				} else if (e.keyCode == 40 && e.ctrlKey && this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Keyboard)
				{
					this.set_activeItem(nextItem);
					this.__lastSelectionWasContinuous = false;
					// this.__multipleNoncontinuousSelect(e,nextItem);
				}

			} else
			{

				










			}

			// this._elements["Input"].value = nextItem.get_text();

			if (nextItem)
			{

				var pos = $util.getPosition(nextItem._element);

				if (pos.y + Sys.UI.DomElement.getBounds(nextItem._element).height > container_pos.y + container.offsetHeight)
				{
					//    container.scrollTop = container.scrollTop + Sys.UI.DomElement.getBounds(nextItem._element).height;
					//   container.scrollTop =container.scrollTop +  pos.y - container_pos.y;
					container.scrollTop = (pos.y + Sys.UI.DomElement.getBounds(nextItem._element).height) - (container_pos.y + container.offsetHeight);

				}

			}
			//  selectedIndex++;  

		} else if (e.keyCode == 38 && !e.altKey) // up arrow
		{

			// selectedIndex--;
			//var prevItem = this.get_items()._getObjectByIndex(--activeItemIndex);
			var prevItem = this.get_items().getItem(--activeItemIndex);

			if (prevItem && (!prevItem._get_visible() || prevItem.get_disabled()))
				prevItem = this.__getPreviousVisibleItem(activeItemIndex);

			if (prevItem)
			{

				//prevItem.activate();
				//this.set_activeItem(prevItem);

				if (!e.ctrlKey && !e.shiftKey)
				{
					
					//this.set_activeItem(prevItem);
					// select item
					var oldIndex = this.get_selectedItemIndex();

					// unselect old item
					//var oldItem = this.get_items()._getObjectByIndex(oldIndex);
					var oldItem = this.get_items().getItem(oldIndex);
					//if (oldItem!=null && oldItem.get_selected())
					//{
					//    oldItem.unselect();
					//}

					// A.T. 22/09/2009 Fix for bug #22142 Keyboard directional should be used as navigation when multiple selection through checkboxes is enabled
					if (!this.get_enableMultipleSelection() || (this.get_multipleSelectionType() != $IG.DropDownMultipleSelectionType.Checkbox && this.get_enableMultipleSelection()))
					{
						// K.D. April 25th, 2012 Bug #109400 When use keyboard to select values and there is autopostback on selection changed the selected value is not correct
						// The value is now changed before the item is selected in order for the new value to appear after
						// the postback
						if (!oldItem || (oldItem && oldItem.get_index() != prevItem.get_index()))
						{
							var oldVal = this.get_currentValue();
							var newVal = prevItem.get_text();
							args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', e, null, newVal, oldVal);
							if (args && args.get_cancel())
							
								return;
							
							this.set_activeItem(prevItem);
							this.set_currentValue(newVal, true);
							newVal = this.get_currentValue();
							
							this.__singleSelect(e, prevItem, oldItem);
							this._raiseClientEvent('ValueChanged', 'DropDownEdit', e, null, newVal, oldVal);
						}
						
						else
						{
							this.set_activeItem(prevItem);
							this.__singleSelect(e, prevItem, oldItem);
						}
					}
					
					else
						this.set_activeItem(prevItem);
				} else if (e.keyCode == 38 && e.shiftKey && this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Keyboard)
				{
					if (!this.__lastSelectionWasContinuous)
					{
						this.__unselectAllItemsWithoutActiveItem();
					}
					this.set_activeItem(prevItem);
					if (prevItem.get_selected())
					{
						currentItem.unselect();
					}

					this.__multipleNoncontinuousSelect(e, prevItem);

					this.__lastSelectionWasContinuous = true;


				} else if (e.keyCode == 38 && e.ctrlKey && this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Keyboard)
				{
					this.set_activeItem(prevItem);
					this.__lastSelectionWasContinuous = false;
					// this.__multipleNoncontinuousSelect(e,nextItem);
				}

			} else
			{

				









			}

			if (prevItem)
			{

				var pos = $util.getPosition(prevItem._element);

				if (pos.y < container_pos.y + container.scrollTop)
				{
					if (container.scrollTop - Sys.UI.DomElement.getBounds(prevItem._element).height >= 0)
					{
						container.scrollTop = container.scrollTop - Sys.UI.DomElement.getBounds(prevItem._element).height;
						//  container.scrollTop =  container_pos.y - pos.y;
						// container.scrollTop = pos.y  
					}
					else
					{

						container.scrollTop = 0;
					}
				}

			}

			//    selectedIndex--;
		}

		if (((e.keyCode == 40 && (e.shiftKey)) || (e.keyCode == 38 && (e.shiftKey))) && this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Keyboard)
		{
			this.__constructMultiSelectValue(e);
		}

	},

	__constructMultiSelectValue: function (e)
	{
		var currentVal = this.__constructMultiSelectValueInternal();

		//A.T. 1 Sept. 2009 - Fix for bug 21172: When selection is set to the same previous selection, postback is made, but the SelectionChanged event is not fired on the server-side
		if (currentVal != this.get_currentValue())
		{
			// args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', e, null, this._elements["Input"].value, this.get_currentValue());
			var args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', e, null, currentVal, this.get_currentValue());

			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				var previousValue = this.get_currentValue();
				this.set_currentValue(currentVal, true);
				this._raiseClientEvent('ValueChanged', 'DropDownEdit', e, null, this.get_currentValue(), previousValue);
			}
		}
	},

	// same as the above, but doesn't fire events and doesn't need an event as an argument
	__constructMultiSelectValueInternal: function ()
	{
		var currentVal = '';
		var delim = this.get_multiSelectValueDelimiter();

		// go through all items and check which are selected
		var isFirst = true;

		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		for (var i = 0; i < length; i++)
		{
			if (this.get_items().getItem(i).get_selected())
			{
				if (!isFirst)
				{
					currentVal += delim + this.get_items().getItem(i).get_text();
				}
				else
				{
					currentVal += this.get_items().getItem(i).get_text();
					isFirst = false;
				}
			}
		}
		return currentVal;
	},

	__findClosestSelected: function (index)
	{

		var nextIndex = index;
		var prevIndex = index;

		var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

		for (i = index; i < length; i++)
		{
			// if (this.get_items()._getObjectByIndex(i).get_selected())
			if (this.get_items().getItem(i).get_selected())
				break;

			nextIndex++;
		}

		for (i = index; i >= 0; i--)
		{
			// if (this.get_items()._getObjectByIndex(i).get_selected())
			if (this.get_items().getItem(i).get_selected())
				break;

			prevIndex--;
		}


		if (prevIndex < 0 && nextIndex >= 0) return nextIndex;
		if (nextIndex < 0 && prevIndex >= 0) return prevIndex;
		if (prevIndex < 0 && nextIndex < 0) return index;
		return (nextIndex < prevIndex) ? nextIndex : prevIndex;

	},

	// handles async AJAX response
	_responseComplete: function (callbackObject, responseObject, obj)
	{

		
		$IG.WebDropDown.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		// hide loading items message if needed
		if (this.get_loadingItemsMessageText() != null)
		{
			this.__hideLoadingItemsMessage();
		}

		// handle results from the Items requested event
		var manualLoadItems = this.__manualLoadItems;
		var currentControl = this;
		var props = eval(responseObject.context[0]);
		var html = responseObject.context[1];
		var pagerHtml = responseObject.context[2];
		var type = callbackObject.serverContext.type;

		var eventName = callbackObject.serverContext.eventName;

		// replace Li items
		var list = this._elements["List"];

		var val = this.get_currentValue();

		//I.G. 29 Dec 2016 - Fix for 229901 - [WebDropDown] does not load more items when scroll down after filtering, 
		//when LoadOnDemand and EnableAutoFiltering=Server are used
		if (val === "" && type == "itemsRequested") {
			this._noMoreResults = false;
		}

		if (this.get_enableCustomValueSelection())
		{
			val = this._elements["Input"].value;
		}

		if ((type == "itemsRequested" || type == "itemsRequestedCustom") && this.get_valueBeforeFilter() != val)
		{
			if (this.get_enableCustomValueSelection())
				this.__autoFilterOnServerCustom();
			// initiate a new request
			else
			{
				//   if (this.get_enableAutoCompleteFirstMatch() && this.__get_valueBeforeAutoCompleteFirstMatch() != this.get_valueBeforeFilter())
				// {
				//   this.set_currentValue(this.__get_valueBeforeAutoCompleteFirstMatch());
				//  this.__autoFilterOnServer();
				//} else if (!this.get_enableAutoCompleteFirstMatch())
				// {
				//    this.__autoFilterOnServer();
				// }
				clearTimeout(this._timeoutID);
				this._timeoutID = setTimeout(Function.createDelegate(this, this.__autoFilterOnServer), this.get_autoFilterTimeoutMs());
			}

			return;
		}

		//L.A. 29 March 2012 - Fix for bug 102302 When filtering mode is client and add new item incorrect items are previwed
		if (type == "itemsRequested" || type == "itemsRequestedCustom" || type == "remove" || type == null ||
		type == "nextPage" || type == "prevPage" || type == "gotoPage" || type == "firstPage" || type == "lastPage" ||
		type == "add" || type == "insert" || eventName == "SelectionChanged" || eventName == "ValueChanged")
		{

			if (type == "itemsRequestedCustom" && !html.toLowerCase().startsWith("<li")) // no items available
			{
				// no results
				this._elements["Input"].value = this.get_currentValue();
				return;

			}

			//LEAKS FIX
			for (i = 0; i < this.get_items()._items.length; i++)
			{
				//this.get_items()._items[i].dispose();
				var item = this.get_items()._items[i];
				if (item != null)
				{
					this.get_items()._items[i].dispose();
				}
			}
			this.get_items().dispose();

			list.innerHTML = html;
			//L.A. 29 March 2012 - Fix for bug 102302 When filtering mode is client and add new item incorrect items are previwed
			if (type == "add")
			{
				//var span = document.createElement("span");
				// K.D. September 3rd, 2011 Bug #85506 Unlocking the add request and executing _onUnlockRequest to 
				// check for more items in the add queue
				lockedRequest = false;
				this.get_items()._onUnlockRequest();
				//list.appendChild(span);
			}

		} else if (type == "pagerMoreResults")
		{
			if (!html.toLowerCase().startsWith("<li"))
			{
				this._noMoreResults = true;
			}
			else
			{
				list.innerHTML += html;
			}
		}

		if (this.get_enablePaging())
		{
			var pager = this._elements["PagerArea"];
			pager.innerHTML = pagerHtml;
		}
		//else if (type == "insert")
		//{
		//
		//}

		this.__clearTextNodesFromUL();
		// we need to re-attach the dropdown to the parent , before the initialization/walkThrough is done

		this._elements = []; // clear markers
		//this._events._list = []; // it's very important to clear the events !
		$clearHandlers(this._element);
		this.__clearOtherEvents();

		//this.set_props(props);
		// everything that's done in set_props, except setting again the client event handlers
		this._dataStore = props;
		this._props = props[0];
		this._clientStateManager = new $IG.ObjectClientStateManager(this._props);
		this._objectsManager = new $IG.ObjectsManager(this, props[1]);
		this._collectionsManager = new $IG.CollectionsManager(this, props[2]);
		// K.D. October 2nd, 2013 Bug #129963 New items text is undefined after loading items on demand when EnableClientRendering="true"
		if (this._get_enableClientRendering()) {
			this._collectionsManager._items = this._dataStore[4];
			this._collectionsManager._clientStateManagers[0]._items = this._dataStore[4];
		}

		//var items = responseObject.context[2];
		//var itemsCount = items.length;

		this.behavior._attach();

		$IG.WebDropDown.callBaseMethod(this, 'initialize');

		//L.A. 29 March 2012 - Fix for bug 102302 When filtering mode is client and add new item incorrect items are previwed
		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
		{
			for (i = 0; i < this.get_items().getLength(); i++)
			{
				// dummy, serves just to create every item, since lazy loading & client side filtering require some special attention
				this.get_items().getItem(i);
			}
			this.__clientFilteringItemCount = this.get_items().getLength();
		}

		// we need to re-attach the paging event, since we have replaced the whole inner HTML
		// and have swiped out the handler

		








		if (this.get_enablePaging())
		{
			//var pagerDelegate = Function.createDelegate(this, this._onPagerMoreResults);
			//$addHandler(this._elements["PagerLink"], 'mousedown', pagerDelegate);

			if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPrevious)
			{
				var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
				$addHandler(this._elements["PagerPrevLink"], 'mousedown', pagerPrevDelegate);

				var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
				$addHandler(this._elements["PagerNextLink"], 'mousedown', pagerNextDelegate);

			} else if (this.get_pagerMode() == $IG.DropDownPagerMode.Numeric || this.get_pagerMode() == $IG.DropDownPagerMode.NumericFirstLast)
			{
				var numberDelegate = Function.createDelegate(this, this._onPagerNumberResults);
				$addHandler(this._elements["Pager"], 'mousedown', numberDelegate);

				// check if we have quick pages
				if (this._elements["PagerQPPrevLink"])
				{
					var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
					$addHandler(this._elements["PagerQPPrevLink"], 'mousedown', pagerPrevDelegate);
				}

				if (this._elements["PagerQPNextLink"])
				{
					var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
					$addHandler(this._elements["PagerQPNextLink"], 'mousedown', pagerNextDelegate);
				}

			} else if (this.get_pagerMode() == $IG.DropDownPagerMode.NextPreviousFirstLast)
			{
				var pagerPrevDelegate = Function.createDelegate(this, this._onPagerPrevResults);
				$addHandler(this._elements["PagerPrevLink"], 'mousedown', pagerPrevDelegate);

				var pagerNextDelegate = Function.createDelegate(this, this._onPagerNextResults);
				$addHandler(this._elements["PagerNextLink"], 'mousedown', pagerNextDelegate);

				var pagerFirstDelegate = Function.createDelegate(this, this._onPagerFirstResults);
				$addHandler(this._elements["PagerFirstLink"], 'mousedown', pagerFirstDelegate);

				var pagerLastDelegate = Function.createDelegate(this, this._onPagerLastResults);
				$addHandler(this._elements["PagerLastLink"], 'mousedown', pagerLastDelegate);
			}
		}

		this.behavior._detach();

		// reattach handlers
		// var selectDelegate = Function.createDelegate(this, this._select);  
		// $addHandler(list, 'mousedown', selectDelegate);

		// attach the delegate for keyboard navigation
		// var navDelegate = Function.createDelegate(this, this._navigateItems);
		// $addHandler(list, 'keydown', navDelegate);

		// this._registerHandlers(["selectstart", "keydown", "keyup", "mousedown"]);

		if (type == "itemsRequestedCustom")
		{
			// update value
			args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', this._currentEvent, null, this._elements["Input"].value, this.get_currentValue());
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				var previousValue = this.get_currentValue();
				this.set_currentValue(this._elements["Input"].value, false);
				this._raiseClientEvent('ValueChanged', 'DropDownEdit', this._currentEvent, null, this.get_currentValue(), previousValue);
			}
		}

		// select the first item when there are results ; update the current value and fire value changing/ed events 
		// if (type=="itemsRequested"  && !manualLoadItems && this.get_items().getLength() > 0 && this._elements["Input"].value != this.get_currentValue() )
		if (type != "itemsRequested" && !manualLoadItems && this._elements["Input"].value != this.get_currentValue())
		{
			// fire value changing
			args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', this._currentEvent, null, this._elements["Input"].value, this.get_currentValue());
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				//var previousValue = this.get_currentValue();
				// this.set_currentValue(this._elements["Input"].value, false);
				var previousValue = this._elements["Input"].value;
				this._elements["Input"].value = this.get_currentValue();
				this._raiseClientEvent('ValueChanged', 'DropDownEdit', this._currentEvent, null, this.get_currentValue(), previousValue);
			}
		}

		if (this.get_items().getLength() > 0 && type == "itemsRequested" && !manualLoadItems && this.get_autoSelectOnMatch())
		{
			// fire selection events
			var oldIndex = this.get_selectedItemIndex();
			// var oldItem = oldIndex == -1 ? null : this.get_items()._getObjectByIndex(oldIndex);
			var oldItem = oldIndex == -1 ? null : this.get_items().getItem(oldIndex);
			// var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', this._currentEvent, null, [this.get_items()._getObjectByIndex(0)], [oldItem]);
			var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', this._currentEvent, null, [this.get_items().getItem(0)], [oldItem]);
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{

				var previousIndex = this.get_selectedItemIndex();
				//this.get_items()._getObjectByIndex(0).select();
				this.get_items().getItem(0).select();
				this.set_selectedItemIndex(0);

				//var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', this._currentEvent, null, [this.get_items()._getObjectByIndex(0)], [oldItem]);
				var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', this._currentEvent, null, [this.get_items().getItem(0)], [oldItem]);

				// also activate first item
				//  this.set_activeItem(this.get_items()._getObjectByIndex(0));
				this.set_activeItem(this.get_items().getItem(0));

				// N.A. 3/16/2017 Bug #230141: When WDD is filtered and first element is selected, then scroll to top.
				if (this.behavior.get_visible()) {
					this._elements["DropDownContents"].scrollTop = 0;
				}
				this._needScrollTop = true;
			}
		}

		// K.D. Bug #108267 When loadOnDemand is true and load new items get_selected does not return correct value
		var selected = this.get_selectedItems();
		if (selected && selected.length > 0)
		{
			for (var i = 0; i < selected.length; i++)
			{
				selected[i].select(true);
			}
		}

		if (this._currentEvent && this.get_enableAutoCompleteFirstMatch())
		{
			this.__autoCompleteFirstMatch(this._elements["Input"], 0, this._currentEvent);
		}

		// STORE IN CACHE, if enabled
		if (type == "itemsRequested" && this.get_enableCachingOnClient())
		{
			if (this.get_enableAutoCompleteFirstMatch())
			{
				this._clientCache[this.get_valueBeforeFilter().toLowerCase()] = [html, props];
			} else
			{

				this._clientCache[val.toLowerCase()] = [html, props];
			}
		}

		// this.set_selectedItemIndex(-1);

		// items requested is raised whenever the items arrive from the server
		// on the other hand, the AutoFilteringStarted is raised, without caring whether items have arrived or not

		if (type == "itemsRequested")
			this._raiseClientEvent('ItemsRequested', 'DropDownControl', this._currentEvent, null);

		// fire client events for items
		if (type == "add" || type == "insert")
		{
			var items;
			if (this.get_enablePaging())
			{
				items = responseObject.context[3];

			} else
			{
				items = responseObject.context[2];
			}

			//this._raiseClientEvent('ItemAdded', 'DropDownControl', null, null, item);
			if (items != null && items.length > 0)
			{
				for (var i = 0; i < items.length; i++)
				{
					//var item = this.get_items()._getObjectByAdr(items[i]);
					var item = this.get_items().getItem(items[i]);
					if (type == "add")
						this._raiseClientEvent('ItemAdded', 'DropDownControl', null, null, item);
					else if (type == "insert")
						this._raiseClientEvent('ItemInserted', 'DropDownControl', null, null, item);
				}
			}
		}
		else if (type == "remove")
		{
			var item = callbackObject.clientContext.item;
			this._raiseClientEvent('ItemRemoved', 'DropDownControl', null, null, item);
		}


		if (this.get_displayMode() != $IG.DropDownDisplayMode.ReadOnly)
		{
			if (this._currentEvent)
			{
				
				
				if (!this._dontOpen && this._element.offsetHeight)
				{
					var args = this._raiseClientEvent('DropDownOpening', 'DropDownContainer', this._currentEvent, null);
					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{
						this.behavior.set_visible(true);
						if (this._needScrollTop) {
							this._elements["DropDownContents"].scrollTop = 0;
						}
						//this._adjustMaxHeight();
						this._raiseClientEvent('DropDownOpened', 'DropDownContainer', this._currentEvent, null);
					}
				}
			} else
			{

				if (this.get_items().getLength() > 0 && (type == "nextPage" || type == "prevPage" || type == "gotoPage" || type == "firstPage" || type == "lastPage"))
				{
					// this.set_currentValue(this.get_items()._items[0].get_text(), true);
					this.set_currentValue(this.get_items().getItem(0).get_text(), true);
				}

				//A.T. 19 March Fix for bug #29627 - LoadItems function opens dropdown container automatically.
				//A.T. 2 March 2010 - Fix for bug #27919 - multiSelection and using Blur event to trigger postback leaves dropdown opening and closing when looses focus
				
				if (type != undefined && this.__openAfterLoad && this._element.offsetHeight)
				{
					//this._clickedOutside = false;
					
					var internalArgs = { cancel: false };
					this._fireEvent(this, "InternalDropDownOpening", internalArgs)
					
					if (!this.behavior.get_visible() || !this._dontOpen && !internalArgs.cancel)
					{
						var args = this._raiseClientEvent('DropDownOpening', 'DropDownContainer', null, null);
						var cancel = args ? args.get_cancel() : false;
						if (!cancel)
						{
							this.behavior.set_visible(true); 
							
							if (this.get_valueListMaxHeight() > 0 && this._elements["List"].offsetHeight > this.get_valueListMaxHeight())
							{
								
								this._elements["List"].style.height = this.get_valueListMaxHeight() + 'px';
							}
							// N.A. 3/15/2017 Bug #226845: Adjust height and width of drop down when items are requested on demand.
							this._adjustMaxHeight();
							this._adjustMaxWidth();
							this._raiseClientEvent('DropDownOpened', 'DropDownContainer', null, null);
						}
					}
				}
				
				if (this._element.offsetHeight)
				{
					// A.T. Fix for bug #22775
					try
					{
						this._elements["Input"].focus();

					} catch (e)
					{
						// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
						// for some reason - there is no stable way to detect when to call focus() and when not to 
					}
					this.__moveInputCursorToEnd();
					this.__isInternalFocus = true;
				}
			}
		}

		// unhover any hanging items
		//this.__unhoverItems();

		// this._activeItem = this.get_activeItemIndex() == -1 ? null : this.get_items()._getObjectByIndex(this.get_activeItemIndex());
		this._activeItem = this.get_activeItemIndex() == -1 ? null : this.get_items().getItem(this.get_activeItemIndex());

		// restore drop down scroll top state
		
		if (this._dropDownScrollTop != null && this._dropDownScrollTop > 0 && this._element.offsetHeight && !this._needScrollTop)
		{
			this._elements["DropDownContents"].scrollTop = this._dropDownScrollTop;
		}

		// adjust max container height, if this property is set 
		// this._adjustMaxHeight();

		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client)
		{
			for (i = 0; i < this.get_items().getLength(); i++)
			{
				// dummy, serves just to create every item, since lazy loading & client side filtering require some special attention
				this.get_items().getItem(i);
			}
			this.__clientFilteringItemCount = this.get_items().getLength();
		}

		//A.T. 8 March 2010 - Fix for bugs #29001 and #24299
		// restore checkboxes
		if (this.get_enableMultipleSelection() && this.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox
		&& this.get_enableLoadOnDemand() && type == "pagerMoreResults")
		{
			for (var i = 0; i < this._selectedBeforeLoD.length; i++)
			{
				var element = null;
				if (this.get_items().getItem(this._selectedBeforeLoD[i]) != null)
				{
					element = this.get_items().getItem(this._selectedBeforeLoD[i])._element;
				}

				if (element != null && element.childNodes[0] != null)
				{
					element.childNodes[0].checked = true;
					element.childNodes[0].setAttribute('alt', this._checkedAlt);
					element.childNodes[0].setAttribute('title', this._checkedAlt);
				}
			}
			this._selectedBeforeLoD = [];
		}

		//A.T. 12 July - Fix for bug #24397 - Scrolling by clicking the down the scrollbar arrow loads duplicate items to the list in IE 8
		this.__requestInProgress = false;
		this._needScrollTop = false;
	},

	__autoFilterOnServer: function (elem, adr, evnt)
	{

		// check if the current value is the same as the value at the time at which the auto filtering
		// timeout was registered
		// if the values are not the same, don't proceed !

		// if (this.get_previousValue() == this.get_currentValue()) {

		// show loading items message if needed
		if (this.get_loadingItemsMessageText() != null)
		{
			this.__showLoadingItemsMessage();
		}

		// will do ajax - items requested
		this._raiseClientEvent('ItemsRequesting', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());

		var args = this._raiseClientEvent('AutoFilterStarting', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
		var cancel = args ? args.get_cancel() : false;
		if (!cancel)
		{
			//A.T. 30/07/2010 Fix for bug #23287 - Autocomplete function crashes the sample in "WebDropDown > Filtering and autocomplete"
			// K.D. February 16, 2011 Bug #66431 - Have to do .toString() before .toLowerCase() in order to not get
			// a javascript error when the type of the value is different from string
			if (this.get_currentValue() != null && this._clientCache[this.get_currentValue().toString().toLowerCase()] != null && this._clientCache[this.get_currentValue().toString().toLowerCase()][0] != '' && this.get_enableCachingOnClient())
			{
				//LEAKS FIX
				for (i = 0; i < this.get_items()._items.length; i++)
				{
					//this.get_items()._items[i].dispose();
					var item = this.get_items()._items[i];
					if (item != null)
					{
						this.get_items()._items[i].dispose();
					}
				}
				this.get_items().dispose();

				var html = this._clientCache[this.get_currentValue().toString().toLowerCase()][0];

				var list = this._elements["List"];
				// remove the items 
				//while (list.childNodes[0]) {
				//    list.removeChild(list.childNodes[0]);
				//}

				list.innerHTML = html;
				this.__clearTextNodesFromUL();
				var props = this._clientCache[this.get_currentValue().toString().toLowerCase()][1];

				this._elements = []; // clear markers
				$clearHandlers(this._element);
				this.__clearOtherEvents();

				this._dataStore = props;
				this._props = props[0];
				this._clientStateManager = new $IG.ObjectClientStateManager(this._props);
				this._objectsManager = new $IG.ObjectsManager(this, props[1]);
				this._collectionsManager = new $IG.CollectionsManager(this, props[2]);

				this.behavior._attach();
				$IG.WebDropDown.callBaseMethod(this, 'initialize');
				this.behavior._detach();

				//this.get_items()._items = items[0];
				this.openDropDown();
				// A.T. Fix for bug #22775
				try
				{
					this._elements["Input"].focus();

				} catch (e)
				{
					// maybe control is disabled, maybe it's not visible, maybe this._element was disposed
					// for some reason - there is no stable way to detect when to call focus() and when not to 
				}
				this.__moveInputCursorToEnd();
				this.__isInternalFocus = true;
				if (this._currentEvent)
				{
					this.__autoCompleteFirstMatch(this._elements["Input"], 0, this._currentEvent);
				}

				// unhover any hanging items
				//this.__unhoverItems();

				// fire selection events
				if (this.get_autoSelectOnMatch())
				{
					var oldIndex = this.get_selectedItemIndex();
					// var oldItem = oldIndex == -1 ? null : this.get_items()._getObjectByIndex(oldIndex);
					var oldItem = oldIndex == -1 ? null : this.get_items().getItem(oldIndex);
					// var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', this._currentEvent, null, [this.get_items()._getObjectByIndex(0)], [oldItem]);
					var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', this._currentEvent, null, [this.get_items().getItem(0)], [oldItem]);
					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{

						var previousIndex = this.get_selectedItemIndex();
						//this.get_items()._getObjectByIndex(0).select();
						this.get_items().getItem(0).select();
						this.set_selectedItemIndex(0);

						//var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', this._currentEvent, null, [this.get_items()._getObjectByIndex(0)], [oldItem]);
						var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', this._currentEvent, null, [this.get_items().getItem(0)], [oldItem]);

						// also activate first item
						//  this.set_activeItem(this.get_items()._getObjectByIndex(0));
						this.set_activeItem(this.get_items().getItem(0));

						// N.A. 3/16/2017 Bug #230141: When WDD is filtered and first element is selected, then scroll to top.
						if (this.behavior.get_visible()) {
							this._elements["DropDownContents"].scrollTop = 0;
						}
					}

					this._activeItem = this.get_activeItemIndex() == -1 ? null : this.get_items().getItem(this.get_activeItemIndex());
				}

				if (this._dropDownScrollTop != null && this._dropDownScrollTop > 0)
				{
					this._elements["DropDownContents"].scrollTop = this._dropDownScrollTop;
				}
			}
			else
			{
				if (this._pi && !this.behavior.get_visible())
				{
					this._pi.set_enabled(false);
				}
				var cbo = this._callbackManager.createCallbackObject();
				cbo.serverContext.type = "itemsRequested";
				
				
				// temporary replace %22 by original " and %5C by original \: get around exception on server
				var val = this._lastVal && (this._lastVal.indexOf('"') >= 0 || this._lastVal.indexOf('\\') >= 0) ? this._get_value($IG.DropDownProps.CurrentValue) : null;
				if (val)
					this._set_value($IG.DropDownProps.CurrentValue, val.replace(/%22/g, '"').replace(/%5C/g, '\\'));
				// K.D. March 11, 2011 Encoding URI component in order to fix the issue with filtering & character
				cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(this._clientStateManager.get_transactionList());
				
				// restore old value
				if (val)
					this._set_value($IG.DropDownProps.CurrentValue, val);
				this.set_valueBeforeFilter(this.get_currentValue());
				this._callbackManager.execute(cbo, true);

				if (this._pi)
				{
					this._pi.set_enabled(true);
				}

			}
			// raise autoFilter started event
			this._raiseClientEvent('AutoFilterStarted', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());

		}

		// } 
	},

	__autoFilterOnServerCustom: function (elem, adr, evnt)
	{
		this._raiseClientEvent('ItemsRequesting', 'DropDownEdit', evnt, null, this._elements["Input"].value, this.get_currentValue());

		var args = this._raiseClientEvent('AutoFilterStarting', 'DropDownEdit', evnt, null, this._elements["Input"].value, this.get_currentValue());
		var cancel = args ? args.get_cancel() : false;
		if (!cancel)
		{
			this._setLoadItemsText(this._elements["Input"].value);
			var cbo = this._callbackManager.createCallbackObject();
			cbo.serverContext.type = "itemsRequestedCustom";
			
			// temporary replace %22 by original ": get around exception on server
			var val = this._lastVal && this._lastVal.indexOf('"') >= 0 ? this._get_value($IG.DropDownProps.CurrentValue) : null;
			if (val)
				this._set_value($IG.DropDownProps.CurrentValue, val.replace(/%22/g, '"'));
			// K.D. March 11, 2011 Encoding URI component in order to fix the issue with filtering & character
			cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(this._clientStateManager.get_transactionList());
			
			// restore old value
			if (val)
				this._set_value($IG.DropDownProps.CurrentValue, val);

			this.set_valueBeforeFilter(this._elements["Input"].value);

			if (this._pi && !this.behavior.get_visible())
			{
				this._pi.set_enabled(false);
			}
			this._callbackManager.execute(cbo, true);

			if (this._pi && !this.behavior.get_visible())
			{
				this._pi.set_enabled(true);
			}
			// raise autoFilter started event
			this._raiseClientEvent('AutoFilterStarted', 'DropDownEdit', evnt, null, this._elements["Input"].value, this.get_currentValue());

		}
	},

	__autoFilter: function (elem, adr, evnt)
	{
		// get input value
		// var text = this.get_autoFilterInputValue();

		var text = this.get_currentValue();

		//if (this.get_enableAutoCompleteFirstMatch())
		//{ 
		//     text = this.__get_valueBeforeAutoCompleteFirstMatch();
		//}

		//var items = this.get_items()._items;

		// if (this.get_enableClientFilteringOnly()) 
		// {

		// detach items 

		var list = this._elements["List"];

		// remove the items 
		while (list.childNodes[0])
		{
			list.removeChild(list.childNodes[0]);
		}

		var tempResults = new Array();


		//L.A. 14 March 2012 - Fix for bug 102326 When the WDD has loadOnDemand and filter with value which no item has an error is returned when clear filter
		//L.A. 19 March 2012 - Fix for bug 102302 When filtering mode is client and add new item incorrect items are previwed
		this.__clientFilteringItemCount = this.get_items().get_length();

		//L.A. 14 March 2012 - Show all items in case of empty text
		if (text == "")
		{
			for (var j = 0; j < this.get_items().get_length(); j++)
			{
				tempResults.push(this.get_items().getItem(j));
			}
		} else
		{
			for (var i = 0; i < this.__clientFilteringItemCount; i++)
			{
				// items[i]._set_visible(false);
				// var item_text = items[i].get_text();

				this.get_items().getItem(i)._set_visible(false);
				var item_text = this.get_items().getItem(i).get_text();

				if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.StartsWith)
				{

					// check case sensitivity !!! 
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase().startsWith(text.toLowerCase()))
						{
							// list.appendChild(items[i]._element);

							//tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text.startsWith(text))
						{
							// list.appendChild(items[i]._element);

							//tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					}

				} else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.EndsWith)
				{

					// check case sensitivity !!!
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase().endsWith(text.toLowerCase()))
						{
							// list.appendChild(items[i]._element);

							// tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text.endsWith(text))
						{
							// list.appendChild(items[i]._element);

							//tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					}

					//L.A. 14 March 2012 - Fix for bug 102566. Added DoesNotContain, DoesNotEqual, Equals checks on the Client side
				} else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.DoesNotContain)
				{
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase().indexOf(text.toLowerCase()) == -1)
						{
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text.indexOf(text) == -1)
						{
							tempResults.push(this.get_items().getItem(i));
						}
					}

				} else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.DoesNotEqual)
				{
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase() != text.toLowerCase())
						{
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text != text)
						{
							tempResults.push(this.get_items().getItem(i));
						}
					}

				} else if (this.get_autoFilterQueryType() == $IG.DropDownAutoFilterQueryTypes.Equals)
				{
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase() == text.toLowerCase())
						{
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text == text)
						{
							tempResults.push(this.get_items().getItem(i));
						}
					}

				} else
				{
					// contains
					// A.T. 12 July 2010 - Fix for bug #25024 - CaseSensitivity doesn't work when AutoFiltering = Client and AutoFilteringQueryType = Contains
					if (!this.get_enableCaseSensitivity())
					{
						if (item_text.toLowerCase().indexOf(text.toLowerCase()) != -1)
						{
							// list.appendChild(items[i]._element);

							// tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					} else
					{
						if (item_text.indexOf(text) != -1)
						{
							// list.appendChild(items[i]._element);

							//tempResults.push(items[i]);
							tempResults.push(this.get_items().getItem(i));
						}
					}
				}
			}
		}

		// sort array if descending
		if (this.get_autoFilterSortOrder() == $IG.DropDownAutoFilterSortOrder.Descending)
		{
			tempResults.sort(function sortItems(item1, item2) { return (item1.get_text() > item2.get_text()) ? -1 : 1; });
		}

		// if (tempResults.length==0 && this.get_persistCustomValues())
		// {
		//    var customItem =  this.get_items().createItem();
		//    customItem.set_text(this.get_currentValue());
		//    this.get_items().add(customItem);

		// } else {

		if (this.get_autoFilterResultSize() > 0)
		{

			for (i = 0; i < this.get_autoFilterResultSize() && i < tempResults.length; i++)
			{
				list.appendChild(tempResults[i]._element);
				if (this.get_enableMarkingMatchedText())
				{
					this.__markMatchedText(tempResults[i]._element, tempResults[i].get_text());
				}
				tempResults[i]._set_visible(true);
			}

		} else
		{

			for (i = 0; i < tempResults.length; i++)
			{
				list.appendChild(tempResults[i]._element);
				if (this.get_enableMarkingMatchedText())
				{
					this.__markMatchedText(tempResults[i]._element, tempResults[i].get_text());
				}
				tempResults[i]._set_visible(true);
			}
		}
		//}

		//A.T. 1 Sept. 2009 - Fix for bug 21172: When selection is set to the same previous selection, postback is made, but the SelectionChanged event is not fired on the server-side
		if (list.childNodes.length > 0 && this.get_autoSelectOnMatch() && tempResults[0].get_index() != this.get_selectedItemIndex())
		{

			// fire selection events
			//A.T. 6th of Feb 2010 - Fix for bug #27004 - Javascript error is thrown when we  try to access the old selected items.
			var oldItem = this.get_selectedItemIndex() == -1 ? null : this.get_items().getItem(this.get_selectedItemIndex());
			var args = this._raiseClientEvent('SelectionChanging', 'DropDownSelection', evnt, null, [tempResults[0]], [oldItem]);
			var cancel = args ? args.get_cancel() : false;
			if (!cancel)
			{
				var previousIndex = this.get_selectedItemIndex();
				this.__unselectAllItems();
				tempResults[0].select();
				//this.set_selectedItemIndex(tempResults[0].get_index());
				this.set_selectedItemIndex(tempResults[0].get_index());
				//A.T. 6th of Feb 2010 - Fix for bug #27004 - Javascript error is thrown when we  try to access the old selected items.
				var previousItem = previousIndex == -1 ? null : this.get_items().getItem(previousIndex);
				var args = this._raiseClientEvent('SelectionChanged', 'DropDownSelection', evnt, null, [this.get_items().getItem(this.get_selectedItemIndex())], [previousItem]);
				// also activate
				this.set_activeItem(tempResults[0]);
			}
		} else if (tempResults.length > 0 && tempResults[0].get_index() !== this.get_selectedItemIndex() && this.get_autoSelectOnMatch())
		// K.D. July 20th, 2011 Bug #81523 Adding this because when the new result is the same as the selected item it was getting unselected
		// K.D. April 12th, 2012 Bug #108257 WebDropDown posts back after deleting the current value or trying to select item with keyboard
		{
			// A.T. 30/11/2009 Fix for bug #25247 - When typing a custom value with EnableAutoFiltering = Off/Client, the index of the selected item is not reset to -1
			var selectedItem = this.get_selectedItem();

			if (this.get_enableMultipleSelection())
			{
				this.__unselectAllItems();
			} else
			{
				if (this.get_selectedItem() != null)
				{
					this.get_selectedItem().unselect();
				}
			}

			this.__resetSelection(selectedItem, evnt);
		}

		// this.behavior.set_targetContainerHeight(Sys.UI.DomElement.getBounds(this._elements["DropDown"]).height);

		if (list.childNodes.length > 0)
		{

			










			this.openDropDown();
		}

		//}
	},

	__markMatchedText: function (elem, elemText)
	{
		if (elem.childNodes[0] != null && elem.childNodes[0].nodeName != "A")
			return;

		var val = this.get_currentValue();
		if (elemText.toLowerCase().startsWith(val.toLowerCase()))
		{
			elem.childNodes[0].innerHTML = "<em>" + elemText.substring(0, val.length) + "</em>" + elemText.substring(val.length);
		}

	},

	__autoCompleteFirstMatch: function (elem, adr, evnt)
	{
		//if (!elem)
		elem = this._elements["Input"];

		if (!evnt)
			evnt = this._currentEvent;
		// K.D. November 26th, 2014 Bug #179606 The method can be called by an API call on filter which does 
		// not have a browser event.
		if (!evnt)
			return;
		// store current value, before auto complete
		//if (this.get_enableAutoFiltering() != $IG.DropDownAutoFiltering.Server) 
		//{
		//    this.__set_valueBeforeAutoCompleteFirstMatch(this.get_currentValue());
		//} else 
		//{
		// N.A. 5/4/2017 Bug #234658 Backspace/Delete should not disable continue writing in the WDD input.
		if (!((evnt.keyCode === 8 || evnt.keyCode === 127) && !this.get_enableCustomValueSelection())) {
			this.__set_valueBeforeAutoCompleteFirstMatch(elem.value);
		}
		//}

		// get items
		//var items = this.get_items()._items;

		var source = elem;
		var value;
		if (this.get_enableCaseSensitivity())
		{
			value = source.value;
		} else
		{
			value = source.value.toLowerCase();
		}

		if (this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server && (this.get_enableCachingOnClient() == false || (this.get_enableCachingOnClient() == true && this._clientCache[value.toLowerCase()] == null)))
		{

			if (this.get_currentValue() == null)
				return;

			// work on the currentValue
			if (this.get_enableCaseSensitivity())
			{
				if (this.get_currentValue().startsWith(value) && value.length < this.get_currentValue().length)
				{

					var args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', evnt, null, this.get_currentValue(), this._elements["Input"].value);
					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{

						this._elements["Input"].value = this.get_currentValue();

						if (source.createTextRange && !$util.IsOpera)
						{
							range = source.createTextRange();
							// range.findText(item_text.substr(value.length));
							//A.T. 18 Dec 2009 Fix for bug #25749 - AutoCompleteFirstMatch places focus in wrong letter of textbox after more than one match is found
							
							
							range.collapse(true);
							range.moveStart("character", value.length);
							range.moveEnd("character", this.get_currentValue().length - value.length);
							range.select();

						} else
						{
							source.setSelectionRange(value.length, this.get_currentValue().length);
						}
						this._raiseClientEvent('ValueChanged', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
					}
				}

			} else
			{
				if (this.get_currentValue().toLowerCase().startsWith(value) && value.length < this.get_currentValue().length)
				{
					// source.value = item_text;
					var args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', evnt, null, this.get_currentValue(), this._elements["Input"].value);
					var cancel = args ? args.get_cancel() : false;
					if (!cancel)
					{

						this._elements["Input"].value = this.get_currentValue();

						if (source.createTextRange && !$util.IsOpera)
						{
							range = source.createTextRange();
							//A.T. 18 Dec 2009 Fix for bug #25749 - AutoCompleteFirstMatch places focus in wrong letter of textbox after more than one match is found
							
							
							range.collapse(true);
							range.moveStart("character", value.length);
							range.moveEnd("character", this.get_currentValue().length - value.length);
							range.select();

						} else
						{
							source.setSelectionRange(value.length, this.get_currentValue().length);
						}

						this._raiseClientEvent('ValueChanged', 'DropDownEdit', evnt, null, this.get_currentValue(), this.get_previousValue());
					}
				}
			}

		} else
		{

			// if (value.length==0)
			//     return;

			//   if (evnt.keyCode== 40 || evnt.keyCode==38) // up and down arrow are intercepted by another event
			//   {
			//       this.__handleKbNavigation(evnt);
			//   }

			if (evnt.keyCode == 40 || evnt.keyCode == 38)
				return;

			if (evnt.keyCode == 16)
				return;


			// RETURN key   
			












			//  if (e.keyCode == 8) // backspace {
			//value=value.substr(0, value.length-1);
			//    return;

			// A.T. 10/07/2009 Fix for bug # 19246 (adding support for DEL key)
			if (evnt.keyCode != 8 && evnt.keyCode != 127)
			{

				var length = this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client ? this.__clientFilteringItemCount : this.get_items().getLength();

				for (i = 0; i < length; i++)
				{
					// var item_text = items[i].get_text();
					var item_text = this.get_items().getItem(i).get_text();

					if (this.get_enableCaseSensitivity())
					{
						// A.T. 15/06/2009 Fix for bug 18201
						if (item_text == value) // exact match, do nothing
						{
							break;
						}

						if (item_text.startsWith(value) && value.length < item_text.length)
						{
							//source.value = item_text;
							var args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', evnt, null, item_text, this.get_currentValue());

							var cancel = args ? args.get_cancel() : false;
							if (!cancel)
							{

								if (this.get_enableCachingOnClient() && this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server)
								{
									var previousValue = value;
									this._elements["Input"].value = this.get_currentValue();
								} else
								{
									var previousValue = this.get_currentValue();
									this.set_currentValue(item_text, true);
								}
								this._raiseClientEvent('ValueChanged', 'DropDownEdit', evnt, null, this.get_currentValue(), previousValue);
							}

							if (source.createTextRange && !$util.IsOpera)
							{
								range = source.createTextRange();
								//A.T. 18 Dec 2009 Fix for bug #25749 - AutoCompleteFirstMatch places focus in wrong letter of textbox after more than one match is found
								
								
								range.collapse(true);
								range.moveStart("character", value.length);
								range.moveEnd("character", item_text.length - value.length);
								range.select();

							} else
							{
								source.setSelectionRange(value.length, item_text.length);
							}
							break;
						}
					} else
					{
						// A.T. 15/06/2009 Fix for bug 18201
						if (item_text && value && item_text.toLowerCase() == value.toLowerCase()) // exact match, do nothing
						{
							break;
						}

						if (item_text.toLowerCase().startsWith(value.toLowerCase()) && value.length < item_text.length)
						{
							// source.value = item_text;
							var args = this._raiseClientEvent('ValueChanging', 'DropDownEdit', evnt, null, item_text, this.get_currentValue());
							var cancel = args ? args.get_cancel() : false;
							if (!cancel)
							{

								if (this.get_enableCachingOnClient() && this.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Server)
								{
									var previousValue = value;
									this._elements["Input"].value = this.get_currentValue();
								} else
								{
									var previousValue = this.get_currentValue();
									this.set_currentValue(item_text, true);
								}
								this._raiseClientEvent('ValueChanged', 'DropDownEdit', evnt, null, this.get_currentValue(), previousValue);
							}

							if (source.createTextRange && !$util.IsOpera)
							{
								range = source.createTextRange();
								//A.T. 18 Dec 2009 Fix for bug #25749 - AutoCompleteFirstMatch places focus in wrong letter of textbox after more than one match is found
								
								
								range.collapse(true);
								range.moveStart("character", value.length);
								range.moveEnd("character", item_text.length - value.length);
								range.select();
							} else
							{
								source.setSelectionRange(value.length, item_text.length);
							}
							break;
						}
					}
				}

			}

		}
	},

	__moveInputCursorToEnd: function ()
	{

		var input = this._elements["Input"];

		if (input.createTextRange && !$util.IsOpera)
		{
			range = input.createTextRange();
			range.move("character", input.value.length);
			range.select();

		} else
		{
			input.setSelectionRange(input.value.length, input.value.length);
		}
	},

	__showLoadingItemsMessage: function ()
	{
		// lookup loading items message element
		var msgBox = this._elements["LoadingMessage"];
		var dropDownList = this._elements["List"];
		var left = dropDownList.offsetLeft;
		var top = dropDownList.offsetTop;
		msgBox.style.display = "";
		msgBox.style.width = dropDownList.offsetWidth;
		msgBox.style.visibility = "visible";
		msgBox.style.left = left;
		msgBox.style.top = top;

	},

	__hideLoadingItemsMessage: function ()
	{

		var msgBox = this._elements["LoadingMessage"];
		msgBox.style.display = "none";
		msgBox.style.visibility = "hidden";
	},

	__detachLoadingItemsMessage: function ()
	{

		// var msgBox = this._elements["LoadingMessage"];

	}

}

$IG.WebDropDown.registerClass('Infragistics.Web.UI.WebDropDown', $IG.ControlMain);

$IG.WebDropDown.find = function (clientID)
{
	///<summary>Finds WebDropDown by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDropDown">Reference to the WebDropDown control object that corresponds to specified client ID.</returns>
};

$IG.WebDropDown.from = function (obj)
{
	///<summary>Casts passed in object to the WebDropDown type.</summary>
	///<param name="obj">Object to convert to the WebDropDown type.</param>
	///<returns type="Infragistics.Web.UI.WebDropDown">Reference to the same object that is passed in, only type converted to the WebDropDown type.</returns>
};

$IG.DropDownValueDisplayType  = function()
{

}

$IG.DropDownValueDisplayType.prototype = 
{  
   Simple:0,   
   WebTextEditor:1
   
};

$IG.DropDownValueDisplayType.registerEnum("Infragistics.Web.UI.DropDownValueDisplayType");

$IG.DropDownAutoFilterSortOrder  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DropDownAutoFilterSortOrder">
	/// Indicates the sorting order for filtering
	///</summary>
	///<field name="None" type="Number" integer="true" static="true"> no sorting will be done </field>
	///<field name="Ascending" type="Number" integer="true" static="true"> items will be sorted in an ascending way </field>
	///<field name="Descending" type="Number" integer="true" static="true"> items will be sorted in a descending way </field>
}

$IG.DropDownAutoFilterSortOrder.prototype = 
{  
   None:0,
   Ascending:1,   
   Descending:2
   
};


$IG.DropDownAutoFilterSortOrder.registerEnum("Infragistics.Web.UI.DropDownAutoFilterSortOrder");

$IG.DropDownMultipleSelectionType  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DropDownMultipleSelectionType">
	/// Indicates the type of multiple selection
	///</summary>
	///<field name="Checkbox" type="Number" integer="true" static="true"> checkboxes will be rendered in front of the items </field>
	///<field name="Keyboard" type="Number" integer="true" static="true"> multiple selection should be done with CTRL/SPACE and SHIFT keys </field>
}

$IG.DropDownMultipleSelectionType.prototype = 
{  
   Checkbox:0,   
   Keyboard:1
   
};

$IG.DropDownMultipleSelectionType.registerEnum("Infragistics.Web.UI.DropDownMultipleSelectionType");


$IG.DropDownPagerMode  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DropDownPagerMode">
	/// indicates the pager mode of the DropDown pager if paging is enabled 
	///</summary>
	///<field name="Numeric" type="Number" integer="true" static="true"> only numbers will be shown as links  </field>
	///<field name="NextPrevious" type="Number" integer="true" static="true"> only previous and next links will be shown in the pager </field>
	///<field name="NextPreviousFirstLast" type="Number" integer="true" static="true"> next, previous, first and last links will be shown in the pager  </field>
	///<field name="NumericFirstLast" type="Number" integer="true" static="true"> numbers for the pages, as well as first and last page links will be shown   </field>
}

$IG.DropDownPagerMode.prototype = 
{  
   Numeric:0,   
   NextPrevious:1,
   NextPreviousFirstLast:2,
   NumericFirstLast:3
   
};

$IG.DropDownPagerMode.registerEnum("Infragistics.Web.UI.DropDownPagerMode");

$IG.DropDownAutoFilterQueryTypes = function() {
	///<summary locid="T:J#Infragistics.Web.UI.DropDownAutoFilterQueryTypes">
	/// Indicates the query type when doing filtering on the server-side 
	///</summary>
	///<field name="StartsWith" type="Number" integer="true" static="true"> start of the item's text will be matched   </field>
	///<field name="EndsWith" type="Number" integer="true" static="true"> end of the item's text will be matched </field>
	///<field name="Contains" type="Number" integer="true" static="true"> text will be matched anywhere in the item's text </field>
	///<field name="DoesNotContain" type="Number" integer="true" static="true"> only text that's not contained in the item's text will be matched  </field>
	///<field name="Equals" type="Number" integer="true" static="true"> exact text will be matched </field>
	///<field name="DoesNotEqual" type="Number" integer="true" static="true"> only text that doesn't equal the item's text will be matched </field>
}

$IG.DropDownAutoFilterQueryTypes.prototype =
{
	StartsWith:0,
	EndsWith:1,
	Contains:2,
	DoesNotContain:3,
	Equals:4,
	DoesNotEqual:5
	
};

$IG.DropDownAutoFilterQueryTypes.registerEnum("Infragistics.Web.UI.DropDownAutoFilterQueryTypes");

$IG.DropDownDisplayMode  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DropDownDisplayMode">
	/// Indicates the display mode of the control
	///</summary>
	///<field name="DropDownList" type="Number" integer="true" static="true"> typing text in the input will not be allowed, selection and browsing through the items will be allowed  </field>
	///<field name="DropDown" type="Number" integer="true" static="true"> selection, browsing, navigation, editing </field>
	///<field name="ReadOnly" type="Number" integer="true" static="true"> only the current input value can be seen, list cannot be opened and items cannot be selected  </field>
	///<field name="ReadOnlyList" type="Number" integer="true" static="true"> editing not allowed, list can be opened but selection will not be allowed  </field>
}

$IG.DropDownDisplayMode.prototype = 
{  
	DropDownList:0,
	DropDown:1,
	ReadOnly:2,
	ReadOnlyList:3
   
};

$IG.DropDownDisplayMode.registerEnum("Infragistics.Web.UI.DropDownDisplayMode");

$IG.DropDownAutoFiltering  = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DropDownAutoFiltering">
	/// Indicates the type of filtering
	///</summary>
	///<field name="Server" type="Number" integer="true" static="true"> Async postback will be made when typing in the input box </field>
	///<field name="Client" type="Number" integer="true" static="true"> filtering will only be done in the items on the client-side, without a postback </field>
	///<field name="Off" type="Number" integer="true" static="true"> No filtering will be made, the matching item (if any) will only be selected and the container will automatically scroll to its position in the list </field>
}

$IG.DropDownAutoFiltering.prototype = 
{  
	Server:0,
	Client:1,
	Off:2
   
};

$IG.DropDownAutoFiltering.registerEnum("Infragistics.Web.UI.DropDownAutoFiltering");


$IG.DropDownProps = new function() {
	this.DisplayMode = [$IG.ControlMainProps.Count + 0, $IG.DropDownDisplayMode.DropDown];
	this.ValueListMaxHeight = [$IG.ControlMainProps.Count + 1, 0];
	this.OffsetX = [$IG.ControlMainProps.Count + 2, 0];
	this.OffsetY = [$IG.ControlMainProps.Count + 3, 0];
	this.EnablePaging = [$IG.ControlMainProps.Count + 4, false];
	this.PageSize = [$IG.ControlMainProps.Count + 5, 0];
	this.SelectedItemIndex = [$IG.ControlMainProps.Count + 6, -1];
	this.SelectedItemIndices = [$IG.ControlMainProps.Count + 7, []];
	this.MultiSelectValueDelimiter = [$IG.ControlMainProps.Count + 8, ","];
	this.EnableCustomValueSelection = [$IG.ControlMainProps.Count + 9, false];
	this.EnableMultipleSelection = [$IG.ControlMainProps.Count + 10, false];
	this.CloseDropDownOnSelect = [$IG.ControlMainProps.Count + 11, true];
	this.PersistCustomValues = [$IG.ControlMainProps.Count + 12, false];
	this.EnableAutoFiltering = [$IG.ControlMainProps.Count + 13, $IG.DropDownAutoFiltering.Off];
	this.AutoFilterQueryType = [$IG.ControlMainProps.Count + 14, $IG.DropDownAutoFilterQueryTypes.StartsWith];
	this.AutoFilterResultSize = [$IG.ControlMainProps.Count + 15, 0];
	this.AutoFilterSortOrder = [$IG.ControlMainProps.Count + 16, $IG.DropDownAutoFilterSortOrder.None];
	this.EnableAutoCompleteFirstMatch = [$IG.ControlMainProps.Count + 17, true];
	this.EnableLoadOnDemand = [$IG.ControlMainProps.Count + 18, false];
	this.DropDownContainerWidth = [$IG.ControlMainProps.Count + 19, 0];
	this.DropDownContainerHeight = [$IG.ControlMainProps.Count + 20, 0];
	this.EnableCaseSensitivity = [$IG.ControlMainProps.Count + 21, false];
	this.CurrentValue = [$IG.ControlMainProps.Count + 22, null];
	this.ShowDropDownButton = [$IG.ControlMainProps.Count + 23, true];
	this.DropDownValueDisplayType = [$IG.ControlMainProps.Count + 24, $IG.DropDownValueDisplayType.Simple];
	//this.EnableClientFilteringOnly = [$IG.ControlMainProps.Count + 25, false];
	this.DropDownAnimationDuration = [$IG.ControlMainProps.Count + 25, 500];
	this.DropDownOrientation = [$IG.ControlMainProps.Count + 26, 6];
	this.LoadItemsText = [$IG.ControlMainProps.Count + 27, null];
	this.EnableClosingDropDownOnBlur = [$IG.ControlMainProps.Count + 28, true];
	this.AutoFilterTimeoutMs = [$IG.ControlMainProps.Count + 29, 200];
	this.EnableCachingOnClient = [$IG.ControlMainProps.Count + 30, false];
	this.MultipleSelectionType = [$IG.ControlMainProps.Count + 31, $IG.DropDownMultipleSelectionType.Checkbox];
	this.EditorID = [$IG.ControlMainProps.Count + 32, null];
	this.DropDownAnimationType = [$IG.ControlMainProps.Count + 33, 0];
	this.LoadingItemsMessageText =[$IG.ControlMainProps.Count + 34,null];
	this.PagerMode =[$IG.ControlMainProps.Count + 35,$IG.DropDownPagerMode.Numeric];
	this.LastPageIndex =[$IG.ControlMainProps.Count + 36,-1];
	this.ShouldFireMultipleSelect =[$IG.ControlMainProps.Count + 37,false];
	this.EnableAnimations =[$IG.ControlMainProps.Count + 38,true];
	this.EnableDropDownOpenOnClick =[$IG.ControlMainProps.Count + 39,true];
	this.ActiveItemIndex = [$IG.ControlMainProps.Count + 40, -1];
	this.DropDownIsChild = [$IG.ControlMainProps.Count + 41, true];
	this.EnableCustomValues = [$IG.ControlMainProps.Count + 42, true];
	this.EnableMarkingMatchedText = [$IG.ControlMainProps.Count + 43, false];
	this.EnableDropDownAutoWidth = [$IG.ControlMainProps.Count + 44, false];
	this.AutoSelectOnMatch = [$IG.ControlMainProps.Count +45, true];
	this.KeepFocusOnSelection = [$IG.ControlMainProps.Count +46, true];
	this.Enabled = [$IG.ControlMainProps.Count +47, true];
	this.NullText = [$IG.ControlMainProps.Count +48, ""];
	this.EnableClientRendering = [$IG.ControlMainProps.Count + 49, false];
	this.Count = $IG.ControlMainProps.Count + 50;

}

$IG.DropDownItemProps = new function()
{
	this.Text        =[$IG.ListItemProps.Count + 0, ""];
	this.Value          =[$IG.ListItemProps.Count + 1, ""];
	this.Selected    =[$IG.ListItemProps.Count + 2, false];
	this.Disabled = [$IG.ListItemProps.Count + 3, false];
	this.Activated = [$IG.ListItemProps.Count + 4, false];
	this.IsCustom = [$IG.ListItemProps.Count + 5, false];
	this.Count            = $IG.ListItemProps.Count + 6;
};













$IG.DropDownItem = function(adr, element, props, control, csm)
{    
	/// <summary locid="T:J#Infragistics.Web.UI.DropDownItem">
	/// Represents an item in the WebImageViewer control. 
	/// </summary>
	this._control = control;
		 
	$IG.DropDownItem.initializeBase(this, [adr, element, props, control,csm]);
	//this._element.className = this.get_cssClass();
	//this._cssClass = element.className;
	this.__visible = true;
	
	// attach item over / out handlers
	
}

$IG.DropDownItem.prototype =
{
	
	activate:function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.activate">
	///Sets the DropDownItem as active.
	///</summary>
		if (this._element && this._element.className && this.get_activeCssClass() )
		$util.addCompoundClass(this._element, this.get_activeCssClass());
		
		this._set_value($IG.DropDownItemProps.Activated, true);
	   // this._element.className = this.get_selectedCssClass();
	   // this.set_selected(true);
		//this._element.focus();
	},
	
	inactivate:function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.inactivate">
	///Sets the DropDownItem as inactive.
	///</summary>
		if (this._element && this._element.className && this.get_activeCssClass() )
		$util.removeCompoundClass(this._element, this.get_activeCssClass());
		this._set_value($IG.DropDownItemProps.Activated, false);
	},
	
	select:function(triggeredByUser)
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.select">
	///Sets the DropDownItem as selected.
	///</summary>
		if (this._element && this._element.className && this.get_selectedCssClass() )
		$util.addCompoundClass(this._element, this.get_selectedCssClass());
	   // this._element.className = this.get_selectedCssClass();
		this.set_selected(true);
		//this._element.focus();
		
		// A.T. 22/06/2009 Fix for bug 18651
		if (this._control && this._control.get_enableMultipleSelection() && this._control.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
		{
			if (this._element !=null && this._element.childNodes[0] !=null)
			{
				if (!triggeredByUser)
					this._element.childNodes[0].checked = true;
				this._element.childNodes[0].setAttribute('alt', this._control._checkedAlt);
				this._element.childNodes[0].setAttribute('title', this._control._checkedAlt);
			}
		}
	},
	
	unselect: function(triggeredByUser)
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.unselect">
	///Sets the DropDownItem as not selected.
	///</summary>
		if (this._element && this._element.className && this.get_selectedCssClass() )
	   $util.removeCompoundClass(this._element, this.get_selectedCssClass());
	   // this._element.className = this.get_cssClass();
		this.set_selected(false);
		
		// A.T. 22/06/2009 Fix for bug 18651
		if (this._control && this._control.get_enableMultipleSelection() && this._control.get_multipleSelectionType() == $IG.DropDownMultipleSelectionType.Checkbox)
		{
			if (this._element !=null && this._element.childNodes[0] !=null)
			{
				if (!triggeredByUser)
					this._element.childNodes[0].checked = false;
				this._element.childNodes[0].setAttribute('alt', this._control._uncheckedAlt);
				this._element.childNodes[0].setAttribute('title', this._control._uncheckedAlt);
			}
		}
	},
	
	hover: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.hover">
	/// Causes the dropdown item to have hover state applied to it 
	///</summary>
	//A.T. 12 July - Fix for bug #24397 - Scrolling by clicking the down the scrollbar arrow loads duplicate items to the list in IE 8
		if (this._element && this._element.className && this.get_hoverCssClass() && (this._control && !this._control.__requestInProgress) )
			$util.addCompoundClass(this._element, this.get_hoverCssClass());

	   // this._element.className = this.get_hoverCssClass();
	},
	
	unhover: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.unhover">
	/// restores original state 
	///</summary>
		if (this._element && this._element.className && this.get_hoverCssClass() )
		$util.removeCompoundClass(this._element, this.get_hoverCssClass());
		//this._element.className = this.get_cssClass();
	},
	
	_ensureFlags:function()
	{
		$IG.DropDownItem.callBaseMethod(this, "_ensureFlag");
		this._ensureFlag($IG.ClientUIFlags.Selectable, $IG.DefaultableBoolean.True);
		this._ensureFlag($IG.ClientUIFlags.Visible, $IG.DefaultableBoolean.True);
	},
	
	get_text:function() 
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.text">
	///Returns/sets the text of the DropDownItem.
	///</summary>
	///<value type="String">text of the dropdown item </value>
		var key = this._control._get_clientOnlyValue('textField');
		
		if(this._control._get_enableClientRendering() && key && key.length > 0)
			return this._csm._items[this._address][key];
		return this._get_value($IG.DropDownItemProps.Text);
	},
	
	set_text:function(text)
	{	   
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.text">
	///Sets the DropDownItem text
	///</summary>
	/// <param name="text"> Text of the dropdown item to set </param>
		this._set_value($IG.DropDownItemProps.Text, text);
		// how do we set the inner item value !!!!
		
		// do we allow setting / modifying the text ???
		
		// what about templates ? 
	},
	
	get_value:function() 
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.value">
	///Returns/sets the value of the DropDownItem.
	///</summary>
	///<value type="String"> value of the item</value>
		
		var key = this._control._get_clientOnlyValue('valueField');
		if(this._control._get_enableClientRendering() && key && key.length > 0)
			return this._csm._items[this._address][key];
		return this._get_value($IG.DropDownItemProps.Value);
	},
	
	set_value:function(val)
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.value">
	///Sets the DropDownItem value
	///</summary>
	///<param name="val"> Value to set </param>
		this._set_value($IG.DropDownItemProps.Value, val);
		// how do we set the inner item value !!!!
		
		// do we allow setting / modifying the text ???
		
		// what about templates ? 
	},

	get_index:function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.index">
	///Returns the index of the item in the WebDropDown's DropDownItemCollection.
	///</summary>
	///<value type="Integer"> index of the item </value>
		return parseInt(this._get_address());
	},
	
	get_selected:function() 
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.selected">
	///Returns whether the dropdown item is selected or not
	///</summary>
	///<value type="Boolean"> value indicating whether the item is selected or not </value>
		// K.D. August 26th, 2011 Bug #84549 The selected property is a boolean so adding true as isbool parameter
		return this._get_value($IG.DropDownItemProps.Selected, true);
	},
	
	get_activated:function() 
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.activated">
	/// value indicating if the item is active or not
	///</summary>
	///<value type="Boolean"> value indicating if the item is active or not </value>
		return this._get_value($IG.DropDownItemProps.Activated);
	},
	
	get_custom:function() 
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.custom">
		/// for internal use
		///</summary>
		return this._get_value($IG.DropDownItemProps.IsCustom);
	},
	
	set_custom:function(custom)
	{
		this._set_value($IG.DropDownItemProps.IsCustom, custom);
	},
	
	get_disabled:function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.disabled">
	///Marks the DropDownItem as disabled
	///</summary>
	/// <value type="Boolean"> boolean value indicating if the item is disabled or not </value>
		return this._get_value($IG.DropDownItemProps.Disabled);
	},
	
	set_disabled:function(val)
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.disabled">
	///Sets the DropDownItem as disabled or not
	///</summary>
	/// <param name="val" type="Boolean"> </param>
		this._set_value($IG.DropDownItemProps.Disabled, val);
	   // this._element.className = this.get_disabledCssClass();

	   // K.D. March 21, 2011 Bug #68256 We need to disable the existing checkbox when disabling the item
	   if (this._control.get_enableMultipleSelection() && this._control.get_multipleSelectionType() === $IG.DropDownMultipleSelectionType.Checkbox)
	   {
			var checkBox = this._element.firstChild;
			if(checkBox && checkBox.nodeName == "INPUT")
				checkBox.disabled = true;
	   }

	   // A.T. fix for bug 17088
	   if (val)
	   {
			$util.addCompoundClass(this._element, this.get_disabledCssClass());
	   } else
	   {
			$util.removeCompoundClass(this._element, this.get_disabledCssClass());     
	   }
	},
	
	_get_visible: function()
	{
		return this.__visible;
	},
	
	_set_visible: function(visible)
	{
		this.__visible=visible;
	},
	
	set_selected:function(selected)
	{	   
	///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.selected"> marks the item as selected. Note that this does not update the CSS for the item. If you'd like the style to be also updated, please use the select() function from the API</summary>
	///<param name="selected"> indicates whether the current item should be selected or not</param>
		this._set_value($IG.DropDownItemProps.Selected, selected);
		// how do we set the inner item value !!!!
		
		// do we allow setting / modifying the text ???
		
		// what about templates ? 
	},
		
	isSelected:function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DropDownItem.isSelected">
		/// Determines if the item is selected.
		///</summary>
		///<returns>True if the image is in selected. </returns>
		// K.D. August 26th, 2011 Bug #84549 The WebDropDown doesn't use the Aikido client state flags
		return this.get_selected();
	},
	
	get_cssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.cssClass">
		///Returns/sets the CSS class that will be applied to the ImageItem when it is selected.
		///</summary>
		///<value type="String"> the CSS class applied to the item </value>
	   // return this._get_value($IG.DropDownItemProps.SelectedCssClass);
		var cssClass = this._get_clientOnlyValue("cssClass");
		if (cssClass && cssClass.length > 0)
			return cssClass;
		else
			return this._control._get_clientOnlyValue("dropDownItemClass");
	},
	
	get_activeCssClass: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.activeCssClass">
		///Returns/sets the CSS class that will be applied to the ImageItem when it is selected.
		///</summary>
		///<value type="String"> CssClass Applied when the item is active </value>
		var activeCssClass = this._get_clientOnlyValue("activeCssClass");
		if (activeCssClass && activeCssClass.length > 0)
			return activeCssClass;
		else
			return this._control._get_clientOnlyValue("dropDownItemActiveClass");
	},
	
	get_selectedCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.selectedCssClass">
		///Returns/sets the CSS class that will be applied to the ImageItem when it is selected.
		///</summary>
		///<value type="String"> Css Class applied when the item is selected </value>
	   // return this._get_value($IG.DropDownItemProps.SelectedCssClass);
		var selectedCssClass = this._get_clientOnlyValue("selectedCssClass");
		if (selectedCssClass && selectedCssClass.length > 0)
			return selectedCssClass;
		else
			return this._control._get_clientOnlyValue("dropDownItemSelected");
	},
	
	get_disabledCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.disabledCssClass">
		///Returns/sets the CSS class that will be applied to the ImageItem when it is selected.
		///</summary>
	   // return this._get_value($IG.DropDownItemProps.SelectedCssClass);
		var disabledCssClass = this._get_clientOnlyValue("disabledCssClass");
		if (disabledCssClass && disabledCssClass.length > 0)
			return disabledCssClass;
		else
			return this._control._get_clientOnlyValue("dropDownItemDisabled");
	},
	
	get_hoverCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.DropDownItem.hoverCssClass">
		///Returns/sets the CSS class that will be applied to the DropDownItem when it is selected.
		///</summary>
		///<value type="String"> CSS class when the item is hovered </value>
	   // return this._get_value($IG.DropDownItemProps.SelectedCssClass);
		var hoverCssClass = this._get_clientOnlyValue("hoverCssClass");
		if (hoverCssClass && hoverCssClass.length > 0)
			return hoverCssClass;
		else
			return this._control._get_clientOnlyValue("dropDownItemHover");
	}
	
}

$IG.DropDownItem.registerClass('Infragistics.Web.UI.DropDownItem', $IG.ListItem);


$IG.DropDownItemCollection = function(control, clientStateManager, index, manager)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DropDownItemCollection">
	/// A collection of DropDownItems.
	/// </summary>
	$IG.DropDownItemCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

// K.D. September 3rd, 2011 Bug #85506 Add request lock
var lockedRequest = false;

$IG.DropDownItemCollection.prototype = 
{
	// K.D. September 3rd, 2011 Bug #85506 Creating an empty add item queue
	_itemQueue: [],

	add:function(item)
	{        
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.add">
	///Adds the specified DropDownItem via an AJAX callback.
	///</summary>
	///<param name="item" type="Infragistics.Web.UI.DropDownItem">The DropDownItem that should be added</param>
		// K.D. September 3rd, 2011 Bug #85506 Checking if the request is currently locked and adding the item to 
		// the item queue in order to perform the add request after the previous is complete
		if (!lockedRequest) {
			lockedRequest = true;
			if(item == null)
				return;
			var cbo = this._control._callbackManager.createCallbackObject();
			cbo.serverContext.type = "add";
			cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList());
			if (this._pi) 
			{
				this._pi.set_enabled(false);
			}
			this._control._callbackManager.execute(cbo, true);
		
			if (this._pi) 
			{
				this._pi.set_enabled(true);
			}
		} else {
			this._itemQueue.push(item);
		}
	},

	// K.D. September 3rd, 2011 Bug #85506 Unlocking the request so a consecutive add request can be performed
	// if there are queued items to add
	_onUnlockRequest: function () {
		if (this._itemQueue.length > 0) {
			this.add(this._itemQueue[0]);
			this._itemQueue.splice(0, 1);
		}
	},
	
	remove:function(item)
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.remove">
	///Removes the specified DropDownItem from the collection.
	///</summary>
	///<param name="dropDownItem" type="Infragistics.Web.UI.DropDownItem">The DropDownItem that should be removed.</param>
		if(item != null)
		{
			var cbo = this._control._callbackManager.createCallbackObject();
			cbo.serverContext.type = "remove";
			cbo.clientContext.item = item;
			cbo.serverContext.index = item.get_index();

			if (this._pi) 
			{
				this._pi.set_enabled(false);
			}
			this._control._callbackManager.execute(cbo, true);

			if (this._pi) 
			{
				this._pi.set_enabled(true);
			}
		}
	},
	
	   
	insert:function(index, item)
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.insert">
	///Creates an DropDownItem with the specified parameters an inserts the Item at the specified index. via an AJAX callback.
	///</summary>
	///<param name="index">The index in which to insert the DropDownItem.</param>
	///<param name="item" type="Infragistics.Web.UI.DropDownItem">The DropDownItem that should be added</param>
		if(item == null)
			return;
		var cbo = this._control._callbackManager.createCallbackObject();
		// K.D. December 4th, 2013 Bug #158850 Adding of dropdown item client side sets an incorrect position
		// Changing get_length() - initialized collection to getLength() - DOM element length
		if(index >= 0 && index < this.getLength())
			cbo.serverContext.type = "insert";
		else
			cbo.serverContext.type = "add";        
		cbo.serverContext.index = index;
		cbo.serverContext.props = Sys.Serialization.JavaScriptSerializer.serialize(item._csm.get_transactionList())
		if (this._pi) 
		{
			this._pi.set_enabled(false);
		}
		this._control._callbackManager.execute(cbo, true);
		if (this._pi) 
		{
			this._pi.set_enabled(true);
		}
	}, 
	
	createItem:function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.createItem">
	///Creates an empty item that can be used in the add and insert methods.
	///</summary>
	///<returns type="Infragistics.Web.UI.DropDownItem" mayBeNull="false"> a newly created DropDownItem object, which does not belong to any collection </returns>
		var props = new Array();
		var clientProps = new Array();
		//A.T. 21 April - Fix for bug #31156 - $IG.DropDownItemProps.Count should be used instead of $IG.DropDownProps.Count in createItem() method
		var length = $IG.DropDownItemProps.Count;
		for(var i = 0; i < length; i++)
		{
			clientProps.push(null);
		}
		props.push(clientProps);
		var elem = document.createElement("li");
		var csm = new $IG.ObjectClientStateManager(props);
		var item = new $IG.DropDownItem("-1", elem, props, this._control, csm);
		return item;
	},
	
	getItem:function(index)
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getItem">
	///Returns the DropDownItem at the specified index. 
	///</summary>
	///<param name="index"> the index of the item in the DropDown collection </param>
	///<returns type="Infragistics.Web.UI.DropDownItem" mayBeNull="true"> the dropdown item at the specified index </returns>
		var item=null;
		
		// IMPLEMENTS LAZY LOADING OF ITEMS
		//if(index >= 0 && index < this.get_length())
		if (!this._control)
			return;
			
		var length = (this._control.get_enableAutoFiltering() == $IG.DropDownAutoFiltering.Client && this._control.__clientFilteringItemCount !== undefined) ?
			this._control.__clientFilteringItemCount :
			this._control._elements["List"].childNodes.length;
		
		if(index >= 0 && index < length)
		{
		   // item = this._items[index];
		   // if (item==null && this._itemCollection !=null)
		   // {
		   if(this._getObjectByAdr(index) == null)
		   {
				return this._addObject($IG.DropDownItem, this._control._elements["List"].childNodes[index], index);
		   } else
		   {
				return this._getObjectByAdr(index);
		   }
		}
		return item;
	},
	
	// USED IN LAZY LOADING
	getLength: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getLength">
	/// Returns the number of the dropdown items in the collection, regardless of whether they are instantiated or not
	///</summary>
	///<returns type="Integer"> The number of the dropdown items in the collection, regardless of whether they are instantiated or not </returns>
		return this._control._elements["List"].childNodes.length;
	}
	
	
}

$IG.DropDownItemCollection.registerClass('Infragistics.Web.UI.DropDownItemCollection', $IG.ObjectCollection);

/// Register event arguments
$IG.DropDownControlEventArgs = function()
{

	$IG.DropDownControlEventArgs.initializeBase(this);
}

$IG.DropDownControlEventArgs.prototype =
{
	get_value: function()
	{
		return this._props[2];
	}
}
$IG.DropDownControlEventArgs.registerClass('Infragistics.Web.UI.DropDownControlEventArgs', $IG.CancelEventArgs);

/// Register selection event arguments
$IG.DropDownSelectionEventArgs = function()
{

	$IG.DropDownSelectionEventArgs.initializeBase(this);
}

$IG.DropDownSelectionEventArgs.prototype =
{
	getNewSelection: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getNewSelection">
	/// an array of dropdown items that are selected but haven't been selected before
	/// </summary>
	///<returns type="Array" elementType="Infragistics.Web.UI.DropDownItem" elementMayBeNull="false" mayBeNull="false"> an array of newly selected items </returns>
		return this._props[2];
	},
	
	getOldSelection: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getOldSelection">
	/// returns an array of the old selected items 
	/// </summary>
	///<returns type="Array" elementType="Infragistics.Web.UI.DropDownItem" elementMayBeNull="false" mayBeNull="false"> an array of the old selected items </returns>
		return this._props[3];
	}
}
$IG.DropDownSelectionEventArgs.registerClass('Infragistics.Web.UI.DropDownSelectionEventArgs', $IG.DropDownControlEventArgs);

/// Register value changing event arguments
$IG.DropDownEditEventArgs = function()
{

	$IG.DropDownEditEventArgs.initializeBase(this);
}

$IG.DropDownEditEventArgs.prototype =
{
	getNewValue: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getNewValue">
	/// returns the new value after editing 
	/// </summary>
	///<returns type="String"> the new value after editing </returns>
		return this._props[2];
	},
	
	getOldValue: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getOldValue">
	/// returns the old value before editing
	/// </summary>
	///<returns type="String"> the old value before editing </returns>
		return this._props[3];
	}
}
$IG.DropDownEditEventArgs.registerClass('Infragistics.Web.UI.DropDownEditEventArgs', $IG.DropDownControlEventArgs);


/// Register selection event arguments
$IG.DropDownActivationEventArgs = function()
{

	$IG.DropDownActivationEventArgs.initializeBase(this);
}

$IG.DropDownActivationEventArgs.prototype =
{
	getNewActiveItem: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getNewActiveItem">
	/// 
	/// </summary>
		return this._props[2];
	},
	
	getOldActiveItem: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getOldActiveItem">
	/// 
	/// </summary>
		return this._props[3];
	}
}
$IG.DropDownActivationEventArgs.registerClass('Infragistics.Web.UI.DropDownActivationEventArgs', $IG.DropDownControlEventArgs);



/// Register selection event arguments
$IG.DropDownContainerEventArgs = function()
{

	$IG.DropDownContainerEventArgs.initializeBase(this);
}

$IG.DropDownContainerEventArgs.prototype =
{
	//getVisible: function()
	//{
		/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getVisible">
		/// returns the state of the dropdown container - 0 = closed, = 1 opened
		/// </summary>
	  //  return this._props[2];
	//}
}
$IG.DropDownContainerEventArgs.registerClass('Infragistics.Web.UI.DropDownContainerEventArgs', $IG.DropDownControlEventArgs);


/// Register selection event arguments
$IG.DropDownItemEventArgs = function()
{

	$IG.DropDownItemEventArgs.initializeBase(this);
}

$IG.DropDownItemEventArgs.prototype =
{
	getItem: function()
	{
	/// <summary locid="M:J#Infragistics.Web.UI.DropDownItemCollection.getItem">
	/// returns current item on which the event has been raised
	/// </summary>
	///<returns type="Infragistics.Web.UI.DropDownItem"> the current item on which the event is raised </returns>
		return this._props[1];
	}
}
$IG.DropDownItemEventArgs.registerClass('Infragistics.Web.UI.DropDownItemEventArgs', $IG.DropDownControlEventArgs);


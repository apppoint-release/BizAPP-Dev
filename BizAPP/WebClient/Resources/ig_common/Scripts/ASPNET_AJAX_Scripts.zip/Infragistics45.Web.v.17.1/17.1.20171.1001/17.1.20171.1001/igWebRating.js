/*
* igWebRating.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/



Type.registerNamespace('Infragistics.Web.UI');


$IG.RatingFillDirection = function() 
{
    ///<summary locid="T:J#Infragistics.Web.UI.RatingFillDirection">
    /// Direction that the bar will fill
    ///</summary>
    /// <field name="FromLeftOrTop" type="Number" integer="true" static="true">Rating's smaller values are at the top or left depending upon the orientation.</field>
    /// <field name="FromRightOrBottom" type="Number" integer="true" static="true">Rating's smaller values are at the bottom or right depending upon the orientation.</field>

}
$IG.RatingFillDirection.prototype =
{
    ///<summary>
    /// The rating will start from the left or the top depending on orientation.
    ///</summary>
    FromLeftOrTop: 0,
    ///<summary>
    /// The rating will start from the right or the bottom depending on orientation.
    ///</summary>
    FromRightOrBottom: 1
};
$IG.RatingFillDirection.registerEnum("Infragistics.Web.UI.RatingFillDirection");



$IG.RatingPrecision = function() 
{
    ///<summary locid="T:J#Infragistics.Web.UI.RatingPrecision">
    /// Precision that the stars are filled with
    ///</summary>
    /// <field name="Whole" type="Number" integer="true" static="true">Rating allows selection of whole items from UI.</field>
    /// <field name="Half" type="Number" integer="true" static="true">Rating allows selection of half item fractions from UI.</field>
    /// <field name="Exact" type="Number" integer="true" static="true">Rating allows selection of exact fraction of items from UI.</field>
}
$IG.RatingPrecision.prototype =
{
    ///<summary>
    /// The entire star will be selected/hovered
    ///</summary>
    Whole: 0,
    ///<summary>
    /// The star is divided into two halves.  Either half or whole star is selected/hovered
    ///</summary>
    Half: 1,
    ///<summary>
    /// The star is hovered/selected to an exact precision
    ///</summary>
    Exact: 2
};
$IG.RatingPrecision.registerEnum("Infragistics.Web.UI.RatingPrecision");



$IG.WebRatingProps = new function() 
{
	this.Value = [$IG.ControlMainProps.Count + 0, 0];
	this.ReadOnly = [$IG.ControlMainProps.Count + 1, false];
	this.Average = [$IG.ControlMainProps.Count + 2, 0.0];
	this.VoteCount = [$IG.ControlMainProps.Count + 3, 0];
    this.Precision = [$IG.ControlMainProps.Count + 4, 0];
    this.EnableContinuousSelection = [$IG.ControlMainProps.Count + 5, true];
    this.SelectionOnHover = [$IG.ControlMainProps.Count + 6, true];
    this.Count = $IG.ControlMainProps.Count + 7;
};



$IG.RatingBaseImageProps = new function()
{
	this.ImageCss = [$IG.ObjectBaseProps.Count + 0, ""];
	this.SelectedCss = [$IG.ObjectBaseProps.Count + 1, ""];
	this.HoveredCss = [$IG.ObjectBaseProps.Count + 2, ""];
	this.DisabledImageCss = [$IG.ObjectBaseProps.Count + 3, ""];
	this.DisabledSelectedCss = [$IG.ObjectBaseProps.Count + 4, ""];
	this.Count = $IG.ObjectBaseProps.Count + 5;
};



$IG.WebRating = function(element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebRating">
	/// Displays a WebRating. 
	/// </summary>
	$IG.WebRating.initializeBase(this, [element]);

	$IG.WebRating.find = $find;
	$IG.WebRating.from = $IG._from;
}

$IG.WebRating.prototype =
{
	_thisType: 'webRating',

	
	initialize: function()
	{
		$IG.WebRating.callBaseMethod(this, 'initialize');

		this._emptyDiv = this._elements['emptyDiv'];
		this._selectedDiv = this._elements['selectedDiv'];
		this._hoveredDiv = this._elements['hoveredDiv'];

		this._focusClass = this._get_clientOnlyValue("wrf");
		this._hasFocus = false;
		this._isHovered = false;
		this._focusOnClick = this.get_enableFocusOnClick();
		this._keyHover = 0;
		this._voted = false;
		this.__isHtml5 = this._get_clientOnlyValue("wrh5");

		this._hoverAnimationDuration = 400;
		if (this._hoveredDiv && this.get_enableAnimations() && !this.__isHtml5)
		{
			this._hoveredDivHoverAnimation = new $IG.OpacityAnimation(this._hoveredDiv);
			this._hoveredDivHoverAnimation.set_duration(this._hoverAnimationDuration);
			this._hoveredDivHoverAnimation.onEnd = Function.createDelegate(this, this._myAnimationEnded);
			this._finalHoverOpacity = $util.getOpacity(this._hoveredDiv);
			this._finalSelectOpacity = $util.getOpacity(this._selectedDiv);
			this._selectedDivHoverAnimation = new $IG.OpacityAnimation(this._selectedDiv);
			this._selectedDivHoverAnimation.set_duration(this._hoverAnimationDuration);
		}

		this._oldHover = 0;
		this._tooltip = this._get_clientOnlyValue("wrt");
		this._itemTooltipFormat = this._get_clientOnlyValue("wrtf");
		this._oldValue = this.get_value();

		this.__isHor = this._get_clientOnlyValue("wro") == 0;
		this.__isRev = this._get_clientOnlyValue("wrfd") == 1;
		this.__critLength = this.__isHor ? this._get_clientOnlyValue("wriw") : this._get_clientOnlyValue("wrih");
		this._exactPrecKeyboardChange = 1 / this.__critLength;
		if (this._selectedDiv)
		{
			this.__selHeight = parseInt(this._selectedDiv.style.height.replace('px', ''));
			var valWidth = this._lengthValFromRealVal(this._oldValue);
			this._adjustTooltips(valWidth);
			this._adjustSelectedTooltips(this._oldValue);
			this._clearEmptyTooltips();
		}
		if (this._hoveredDiv && this.get_enableAnimations() && !this.__isHtml5)
		{
			this._keyboardAnimation = new $IG.KeyBoardSlideAnimation(this._hoveredDiv, this);
			this._keyboardAnimation.set_duration(1000);
			this._keyboardFadeAnimation = new $IG.KeyBoardFadeAnimation(this._hoveredDiv, this, this._finalHoverOpacity);
			this._keyboardFadeAnimation.set_duration(500);
		}

		this._customTooltips = [];
		this._customValues = [];
		var values = this._get_clientOnlyValue("writ");
		if (values.length > 0)
		{
			values = values.split('|');
			for (var x = 0; x < values.length; ++x)
				this._customTooltips[x] = values[x];
		}
		values = this._get_clientOnlyValue("wriv");
		if (values.length > 0)
		{
			values = values.split('|');
			for (var x = 0; x < values.length; ++x)
				this._customValues[x] = parseFloat(values[x]);
		}
		this.__isCustom = this._customValues.length > 0;
		this.__enabled = this._get_clientOnlyValue("wree");

		this._ratingImage = new $IG.RatingImage("RatingImage", null, this._objectsManager.get_objectProps(0), this);
		this._objectsManager.register_object(0, this._ratingImage);

		if (!this.__isHtml5)
			$addHandlers(this._element, { 'mousedown': this._onClick, 'mouseover': this._onMouseOver, 'mouseout': this._onMouseOut, 'mousemove': this._onMouseMove }, this);
		if (this.__enabled)
			this._element.tabIndex = this._get_clientOnlyValue("wrti");
		if (this._element.tabIndex != -1)
		{
			$addHandlers(this._element, { 'keydown': this._onKeyDown, 'focus': this._onFocus, 'blur': this._onBlur }, this);
			if ($util.IsOpera)
				$addHandlers(this._element, { 'keypress': this._onKeyPress }, this);
		}
		if ($util.IsIE6 || $util.IsIE7)
			this._element.setAttribute('hideFocus', 'true');

		this._zeroVotePrecision = this._get_clientOnlyValue("wrz");

		if (this._thisType == 'webRating')
			this._raiseClientEvent('Initialize');
	},
	_responseComplete: function(callbackObject, responseObject, obj)
	{
		
		$IG.WebRating.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		this.set_value(responseObject.context[0]);
		this._ratingImage.set_imageCss(responseObject.context[1]);
		this._ratingImage.set_selectedImageCss(responseObject.context[2]);
		this._ratingImage.set_hoveredImageCss(responseObject.context[3]);
		this.set_average(responseObject.context[4]);
		this.set_voteCount(responseObject.context[5]);
		this.set_readOnly(responseObject.context[6]);
		this._voted = false;
	},

	

	
	get_enableHtml5Rendering: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableHtml5Rendering">
		/// Gets the EnableHtml5Rendering property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_clientOnlyValue("wrh5");
	},

	

	
	get_enabled: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enabled">
		/// Gets the Enabled property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this.__enabled;
	},
	get_orientation: function()
	{

		///<summary>
		/// Gets the Orientation property of the control.
		///</summary>
		///<value type="Infragistics.Web.UI.Orientation"></value>
		return this._get_clientOnlyValue("wro");
	},

	get_itemCount: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.itemCount">
		/// Returns the number of items in the rating, custom or regular.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._get_clientOnlyValue("wrni");
	},

	get_imageHeight: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.imageHeight">
		/// Gets the height of the images.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._get_clientOnlyValue("wrih");
	},

	get_imageWidth: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.imageWidth">
		/// Gets the width of the images.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._get_clientOnlyValue("wriw");
	},
	get_minimumValue: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.minimumValue">
		/// Gets the minimum custom value of the rating, if it were empty.
		///</summary>
		///<value type="Number"></value>
		return this._get_clientOnlyValue("wrmv");
	},
	get_maximumValue: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.maximumValue">
		/// Gets the maximum value possible for the rating.
		///</summary>
		///<value type="Number"></value>
		if (this.__isCustom)
			return this._customValues[this.get_itemCount() - 1];
		return this.get_itemCount() + this.get_minimumValue();
	},
	get_enableAnimations: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableAnimations">
		/// Gets the EnableAnimations property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_clientOnlyValue("wrea");
	},

	get_fillDirection: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.fillDirection">
		/// Gets the FillDirection property of the control.
		///</summary>
		///<value type="Infragistics.Web.UI.RatingFillDirection"></value>
		return this._get_clientOnlyValue("wrfd");
	},

	get_enableFocusOnClick: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableFocusOnClick">
		/// Gets whether to apply browser focus to the rating on click
		///</summary>
		///<value type="Boolean"></value>
		return this._get_clientOnlyValue("wrfc");
	},
	


	

	get_value: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.value">
		/// Gets the Value property of the control.
		///</summary>
		///<value type="Number"></value>
		return this._get_value($IG.WebRatingProps.Value);
	},

	set_value: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.value">
		/// Sets the Value property of the control.  If set below or above the
		/// minimum or maximum respectively, the value will be kept, but the 
		/// rating will clip at those edges.
		///</summary>
		///<param name="value" type="Number">The new value of the rating.</param>
		this._set_value($IG.WebRatingProps.Value, value);
		var valWidth = this._lengthValFromRealVal(value);
		if (this.__isHtml5)
		{
			this._drawEmpty();
			this._drawSelected(valWidth);
			if (this._isHovered || this._hasFocus)
				this._drawHovered(valWidth);
			this._adjustCanvasTooltip(value);
		}
		else
		{
			this._adjustSelectedTooltips(value);
			this._adjustSelected(valWidth);
		}
	},
	set_displayValue: function(displayValue)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.displayValue">
		/// This will set the control to display a value without actually setting the value property.
		///</summary>
		///<param name="val" type="Number">The new value of the rating to display.</param>
		var valWidth = this._lengthValFromRealVal(displayValue);
		if (this.__isHtml5)
		{
			this._drawEmpty();
			this._drawSelected(valWidth);
			if (this._isHovered || this._hasFocus)
				this._drawHovered(valWidth);
			this._adjustCanvasTooltip(value);
		}
		else
		{
			this._adjustSelectedTooltips(displayValue);
			this._adjustSelected(valWidth);
		}
	},
	get_ratingImage: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.ratingImage">
		/// Returns the object representing how plain images are displayed.
		///</summary>
		///<value type="Infragistics.Web.UI.RatingImage"></value>
		return this._ratingImage;
	},

	get_readOnly: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.readOnly">
		/// Gets the ReadOnly property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.WebRatingProps.ReadOnly);
	},
	set_readOnly: function(readOnly)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.readOnly">
		/// Sets the ReadOnly property of the control
		///</summary>
		///<param name="val" type="Boolean">Wehether to make the rating read only.</param>
		this._set_value($IG.WebRatingProps.ReadOnly, readOnly);
		if (readOnly)
			this._hideHovered();
	},

	get_average: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.average">
		/// Gets the Average property of the control.
		///</summary>
		///<value type="Number"></value>
		return this._get_value($IG.WebRatingProps.Average);
	},
	set_average: function(newAverage)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.average">
		/// Sets the Average property of the control
		///</summary>
		///<param name="newAverage" type="Number">The average for the rating to store</param>
		this._set_value($IG.WebRatingProps.Average, newAverage);
	},

	get_voteCount: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.voteCount">
		/// Gets the VoteCount property of the control.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._get_value($IG.WebRatingProps.VoteCount);
	},
	set_voteCount: function(newVoteCount)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.voteCount">
		/// Sets the VoteCount property of the control
		///</summary>
		///<param name="newVoteCount" type="Number" integer="true">The vote count for the rating to store</param>
		if (newVoteCount < 0)
			return;
		this._set_value($IG.WebRatingProps.VoteCount, newVoteCount);
	},

	get_precision: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.precision">
		/// Gets the Precision property of the control.
		///</summary>
		///<value type="Infragistics.Web.UI.RatingPrecision"></value>
		return this._get_value($IG.WebRatingProps.Precision);
	},
	set_precision: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.precision">
		/// Sets the Precision property of the control
		///</summary>
		///<param name="val" type="Infragistics.Web.UI.RatingPrecision">The new desired precision of the rating</param>
		this._set_value($IG.WebRatingProps.Precision, val);
	},

	get_enableContinuousSelection: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableContinuousSelection">
		/// Gets the EnableContinuousSelection property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.WebRatingProps.EnableContinuousSelection);
	},
	set_enableContinuousSelection: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableContinuousSelection">
		/// Sets the EnableContinuousSelection property of the control
		///</summary>
		///<param name="val" type="Boolean">The new boolean for whether to show entire selection up and including value</param>
		this._set_value($IG.WebRatingProps.EnableContinuousSelection, val);
		if (this.__isHtml5)
		{
			this._drawEmpty();
			this._drawSelected();
			if (this._isHovered || this._hasFocus())
				this._drawHovered(this._oldHover);
		}
		else
		{
			this._adjustSelected(this.get_value());
		}
	},

	get_enableShowSelectionOnHover: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableShowSelectionOnHover">
		/// Gets the SelectionOnHover property of the control.
		///</summary>
		///<value type="Boolean"></value>
		return this._get_value($IG.WebRatingProps.SelectionOnHover);
	},
	set_enableShowSelectionOnHover: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.enableShowSelectionOnHover">
		/// Sets the SelectionOnHover property of the control
		///</summary>
		///<param name="val" type="Boolean">Whether to show the selected value under hovered value when mouse is over the control</param>
		this._set_value($IG.WebRatingProps.SelectionOnHover, val);
	},

	


	

	get_hoverAnimationDuration: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.hoverAnimationDuration">
		/// Returns client-only property for duration of hover animations.  Default is 400.
		///</summary>
		///<value type="Number" integer="true"></value>
		return this._hoverAnimationDuration;
	},
	set_hoverAnimationDuration: function(newDuration)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.hoverAnimationDuration">
		/// Sets client-only property for duration of hover animations.
		///</summary>
		///<param name="newDuration" type="Number" integer="true">New duration of the hover animations.</param>
		this._hoverAnimationDuration = val;
		if (this.__isHtml5)
			this._canvasHoverAnimation.set_duration(this._hoverAnimationDuration);
		else
		{
			this._hoveredDivHoverAnimation.set_duration(this._hoverAnimationDuration);
			this._selctedDivHoverAnimation.set_duration(this._hoverAnimationDuration);
		}
	},
	get_exactKeyboardChange: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.exactKeyboardChange">
		/// Returns client-only property for how much of a change is caused when exact
		/// precision is used.  Default is approximately 1 pixel (1 / critical length).
		///</summary>
		///<value type="Number"></value>
		return this._exactPrecKeyboardChange;
	},
	set_exactKeyboardChange: function(val)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebRating.exactKeyboardChange">
		/// Sets client-only property for how much of a change is caused when exact
		/// precision is used.
		///</summary>
		///<param name="val" type="Number">New duration of the hover animations.</param>
		this._exactPrecKeyboardChange = val;
	},

	


	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebRating.dispose">
		/// Disposes of this instance of the control.
		///</summary>

		if (this._element == null)
			return;
		$clearHandlers(this._element);

		delete this._hasFocus;
		delete this._isHovered;
		delete this._focusClass;
		delete this._keyHover;
		delete this._voted;

		delete this._emptyDiv;
		delete this._selectedDiv;
		delete this._hoveredDiv;

		delete this.__isHor;
		delete this.__isRev;
		delete this.__critLength;
		delete this.__selHeight;
		delete this.__isHtml5;

		delete this._tooltip;
		delete this._itemTooltipFormat;
		delete this._oldValue;
		delete this._exactPrecKeyboardChange;

		if (this._hoveredDivHoverAnimation)
		{
			this._hoveredDivHoverAnimation.dispose();
			delete this._hoveredDivHoverAnimation;
		}
		if (this._selectedDivHoverAnimation)
		{
			this._selectedDivHoverAnimation.dispose();
			delete this._selectedDivHoverAnimation;
		}

		if (this._keyboardAnimation)
		{
			this._keyboardAnimation.dispose();
			delete this._keyboardAnimation;
		}
		if (this._keyboardFadeAnimation)
		{
			this._keyboardFadeAnimation.dispose();
			delete this._keyboardFadeAnimation;
		}

		if (this._customValues)
		{
			for (var x = 0; x < this._customValues.length; ++x)
				delete this._customValues[x];
			delete this._customValues;
		}

		if (this._customTooltips)
		{
			for (var x = 0; x < this._customTooltips.length; ++x)
				delete this._customTooltips[x];
			delete this._customTooltips;
		}

		$IG.WebRating.callBaseMethod(this, "dispose");
	},

	

	
	_onClick: function(e)
	{
		if (this.get_readOnly() || !this.__enabled || !this._isHovered)
			return;
		var oldVal = this.get_value();
		var newVal = this._valueFromArgs(e);
		if (newVal < 0)
			return;
		newVal = this._adjustValueForPrecision(newVal);
		newVal = this._realValFromLengthVal(newVal);

		this._changeValUI(oldVal, newVal);
		this._cancelFocus = false;
		this._cancelBlur = false;
		if (((!this._hasFocus && this._focusOnClick) || this._hasFocus) && this._element.tabIndex != -1)
		{
			if (this._element.offsetWidth != 0)
				this._element.focus();
			if ($util.IsIE)
				this._cancelBlur = true;
		}
		else
			this._cancelFocus = true;

	},
	_changeValUI: function(oldVal, newVal, event)
	{
		var args = this._raiseClientEvent('Rating', 'Rating', null, null, oldVal, newVal);
		if (args == null || !args.get_cancel())
		{
			this.set_value(newVal);
			if (this._voted)
			{
				var newAvg = (this.get_average() * this.get_voteCount() - oldVal + newVal) / (this.get_voteCount());
				this.set_average(newAvg);
			}
			else
			{
				var newAvg = (this.get_average() * this.get_voteCount() + newVal) / (this.get_voteCount() + 1);
				this.set_average(newAvg);
				this.set_voteCount(this.get_voteCount() + 1);
			}
			this._voted = true;
			this._raiseClientEvent('Rated', 'Rated', null, null, oldVal, newVal);
			if (this._provider)
				this._provider.notifyLostFocus(event);
		}
	},
	
	_onMouseOver: function(e)
	{
		var target = e.target;
		if (this._isHovered || target.tagName != 'SPAN')
			return;
		this._isHovered = true;
		this._raiseClientEvent('MouseOver', null, e);
		if (this.get_readOnly())
			return;
		var newVal = this._valueFromArgs(e);
		newVal = this._adjustValueForPrecision(newVal);
		this._adjustHover(newVal);
		if (!this._hasFocus)
			this._showHovered();
	},
	
	_onMouseOut: function(e)
	{
		if (!this._isHovered || this._inBounds(e))
			return;
		var target = e.target;
		this._isHovered = false;
		this._raiseClientEvent('MouseOut', null, e);
		this._adjustSelectedTooltips(this.get_value());
		this._clearEmptyTooltips();
		if (!this._hasFocus)
			this._hideHovered();
		else
			this._keyHover = this._oldHover;
	},

	
	_onMouseMove: function(e)
	{
		this._raiseClientEvent('MouseMove', null, e);
		var newVal = this._valueFromArgs(e);
		if (newVal <= 0 || newVal > this.get_itemCount())
			return;
		newVal = this._adjustValueForPrecision(newVal);
		if (this._oldHover != newVal)
		{
			this._adjustHover(newVal);
			this._keyHover = newVal;
			this._oldHover = newVal;
		}
	},
	
	_onKeyDown: function(e)
	{
		if (!this._hasFocus)
			return;
		this._raiseClientEvent('KeyDown', null, e);
		var keyCode = e.keyCode;
		var upDown = 0;
		var cancel = false;
        var newVal = this._keyHover;
        var swap = this.__isRev ? -1 : 1;
        var increment = 1;
        if (this.get_precision() == $IG.RatingPrecision.Half)
            increment = 0.5;
        else if (this.get_precision() == $IG.RatingPrecision.Exact)
            increment = this._exactPrecKeyboardChange;
        var incrementing = false;
        
		if ((keyCode == Sys.UI.Key.space || keyCode == Sys.UI.Key.enter) && !this.get_readOnly() && this.__enabled)
		{
			var newVal = this._realValFromLengthVal(this._keyHover);
			var event = keyCode == Sys.UI.Key.enter ? e : null;
			this._changeValUI(this.get_value(), newVal, event);
			$util.cancelEvent(e);
			this._operaCancelKeyPress = true;
            return;
		}

        if (keyCode == Sys.UI.Key.right && this.__isHor)
        {
            newVal += increment * swap;
            incrementing = !this.__isRev;
        }
        if (keyCode == Sys.UI.Key.left && this.__isHor)
        {
            newVal += increment * swap * -1;
            incrementing = !this.__isRev;
        }
        if (keyCode == Sys.UI.Key.up && !this.__isHor)
        {
            newVal += increment * swap * -1;
            incrementing = this.__isRev;
        }
        if (keyCode == Sys.UI.Key.down && !this.__isHor)
        {
            newVal += increment * swap;
            incrementing = !this.__isRev;
        }
        if (keyCode == Sys.UI.Key.pageUp)
        {
            newVal += increment * 4;
            incrementing = true;
        }
        if (keyCode == Sys.UI.Key.pageDown)
            newVal += increment * -4;
        if (keyCode == Sys.UI.Key.home)
            newVal = 0;
        if (keyCode == Sys.UI.Key.end)
        {
            newVal = this.get_itemCount();
            incrementing = true;
        }

        if (newVal <= 0)
            newVal = 0;
        if (newVal > this.get_itemCount())
            newVal = this.get_itemCount();
            
	    if (newVal != this._keyHover && !this._keyboardAnimationGoing())
	    {
	        var oldKeyHover = this._keyHover;
	        this._keyHover = newVal;
	        if (this.__isHtml5)
	        {
	            this._oldHover = this._keyHover;
	            this._adjustCanvasKeyboard(oldKeyHover, this._keyHover, incrementing);
	        }
	        else
	            this._adjustHoverKeyBoard(this._keyHover, incrementing);
	        var tooltip = this._itemTooltipFormat;
	        if (this.__isCustom)
	        {
	            var lengthVal = this._lengthValFromRealVal(this.get_value());
	            var index = this._underForVal(lengthVal);
	            tooltip = this._customTooltips[index];
	        }
	        this._element.title = this._formatTooltip(tooltip, this._realValFromLengthVal(this._keyHover));
	    }
	},
	
	_onKeyPress: function(e)
	{
		if (this._operaCancelKeyPress)
			$util.cancelEvent(e);
		this._operaCancelKeyPress = false;
	},
	
	_onFocus: function(e)
	{
		if (this._cancelFocus)
		{
			this._cancelFocus = false;
			$util.cancelEvent(e);
			return;
		}
		if (this._hasFocus || !this.get_enabled())
			return;
		this._raiseClientEvent('Focus', null, e);
		this._hasFocus = true;
		this._cancelBlur = false;
		$util.addCompoundClass(this.get_element(), this._focusClass);
		if (!this._isHovered)
		{
			this._keyHover = this._lengthValFromRealVal(this.get_value());
			this._keyHover = this._adjustValueForPrecision(this._keyHover);
			if (this._keyHover <= 0)
			{
				switch (this.get_precision())
				{
					case $IG.RatingPrecision.Whole:
						this._keyHover = 1;
						break;
					case $IG.RatingPrecision.Half:
						this._keyHover = 0.5;
						break;
					case $IG.RatingPrecision.Exact:
						this._keyHover = this._exactPrecKeyboardChange; //0.1;
						break;
				}
			}
			if (this.__isHtml5)
			{
				this._oldHover = this._keyHover;
			}
			else
				this._adjustHover(this._keyHover);
		}
		if (this.get_readOnly())
		{
			var tooltip = this._itemTooltipFormat;
			if (this.__isCustom)
			{
				var lengthVal = this._lengthValFromRealVal(this.get_value());
				var index = this._underForVal(lengthVal);
				tooltip = this._customTooltips[index];
			}
			this._element.title = this._formatTooltip(tooltip, this.get_value());
			return;
		}
		else
		{
			var tooltip = this._itemTooltipFormat;
			if (this.__isCustom)
			{
				var lengthVal = this._lengthValFromRealVal(this.get_value());
				var index = this._underForVal(lengthVal);
				tooltip = this._customTooltips[index];
			}
			this._element.title = this._formatTooltip(tooltip, this._realValFromLengthVal(this._keyHover));
		}
		if (!this._isHovered)
			this._showHovered();
	},
	
	_onBlur: function(e)
	{
		if (this._cancelBlur)
		{
			$util.cancelEvent(e);
			this._cancelBlur = false;
			if (this._element.offsetWidth != 0)
				this._element.focus();
			return;
		}
		if (!this._hasFocus)
			return;
		this._raiseClientEvent('Blur', null, e);
		this._hasFocus = false;
		this._cancelBlur = false;
		$util.removeCompoundClass(this.get_element(), this._focusClass);
		this._keyHover = this._lengthValFromRealVal(this.get_value());
		this._element.title = this._tooltip;
		if (!this._isHovered)
			this._hideHovered();
	},
	_inBounds: function(e)
	{
		if (e == null)
			return false;
		if ($util.IsIE)
			return !$util.isOut(e, this._emptyDiv) || !$util.isOut(e, this._selectedDiv) || !$util.isOut(e, this._hoveredDiv);
		if (e.rawEvent.relatedTarget)
			return $util.isChild(this._emptyDiv, e.rawEvent.relatedTarget) || $util.isChild(this._emptyDiv, e.rawEvent.relatedTarget) || $util.isChild(this._emptyDiv, e.rawEvent.relatedTarget);

		var bounds = Sys.UI.DomElement.getBounds(this._element);

		var style = $util.getRuntimeStyle(this._element);
		var paddingLeft = parseInt($util.getStyleValue(style, "paddingLeft", this._element));
		var paddingTop = parseInt($util.getStyleValue(style, "paddingTop", this._element));
		var paddingRight = parseInt($util.getStyleValue(style, "paddingRight", this._element));
		var paddingBottom = parseInt($util.getStyleValue(style, "paddingBottom", this._element));

		var borderLeft = parseInt($util.getStyleValue(style, "borderLeftWidth", this._element));
		if (isNaN(borderLeft))
			borderLeft = 0;
		var borderTop = parseInt($util.getStyleValue(style, "borderTopWidth", this._element));
		if (isNaN(borderTop))
			borderTop = 0;
		var borderRight = parseInt($util.getStyleValue(style, "borderRightWidth", this._element));
		if (isNaN(borderRight))
			borderRight = 0;
		var borderBottom = parseInt($util.getStyleValue(style, "borderBottomWidth", this._element));
		if (isNaN(borderBottom))
			borderBottom = 0;

		var x = e.clientX - bounds.x - paddingLeft - borderLeft + 1 + document.documentElement.scrollLeft;
		var y = e.clientY - bounds.y - paddingTop - borderTop + 1 + document.documentElement.scrollTop; ;
		var width = this._element.offsetWidth - paddingRight - borderRight - paddingLeft - borderLeft;
		var height = this._element.offsetHeight - paddingBottom - borderBottom - paddingTop - borderTop;
		return x > 0 && y > 0 && x <= width && y <= height;

	},
	_valueFromArgs: function(e)
	{
		if (e == null)
			return 0;
		var bounds = Sys.UI.DomElement.getBounds(this._element);

		var style = $util.getRuntimeStyle(this.get_element());
		var paddingLeft = parseInt($util.getStyleValue(style, "paddingLeft", this.get_element()));
		var paddingTop = parseInt($util.getStyleValue(style, "paddingTop", this.get_element()));

		var borderLeft = parseInt($util.getStyleValue(style, "borderLeftWidth", this.get_element()));
		if (isNaN(borderLeft))
			borderLeft = 0;
		var borderTop = parseInt($util.getStyleValue(style, "borderTopWidth", this.get_element()));
		if (isNaN(borderTop))
			borderTop = 0;

		var x = e.clientX - bounds.x - paddingLeft - borderLeft + 1 + document.documentElement.scrollLeft;
		var y = e.clientY - bounds.y - paddingTop - borderTop + 1 + document.documentElement.scrollTop;

		var importantVal = this.__isHor ? x : y;
		var val = importantVal / this.__critLength;
		
		if (val > this.get_itemCount())
			val = this.get_itemCount();
		if (this.__isRev)
			val = this.get_itemCount() - val;
		return val;
	},
	_adjustValueForPrecision: function(val)
	{
		if (this.get_precision() == $IG.RatingPrecision.Whole)
        {
            if (this._zeroVotePrecision < 0 || val > this._zeroVotePrecision)
			    val = Math.ceil(val);
            else
                val = 0;
        }
		else if (this.get_precision() == $IG.RatingPrecision.Half)
        {
            if (this._zeroVotePrecision < 0 || val > this._zeroVotePrecision)
			    val = Math.ceil(val * 2) / 2;
            else
                val = 0;
        }
		return val;
	},
	_showHovered: function()
	{
		if (this.__isHtml5)
		{
			if (this.get_enableAnimations())
				this._canvasHoverAnimation.play(0, 100);
			else
			{
				this._drawEmpty();
				if (this.get_enableShowSelectionOnHover())
					this._drawSelected();
				this._drawHovered(this._oldHover);
			}
			this._adjustCanvasTooltip(this._realValFromLengthVal(this._oldHover));
		}
		else
		{
			if (!this.get_enableShowSelectionOnHover())
			{
				if (this.get_enableAnimations())
					this._selectedDivHoverAnimation.play(this._finalSelectOpacity, 0);
				else
					this._selectedDiv.style.visibility = "hidden";
			}
			if (this._hoveredDiv != null)
			{
				this._hoveredDiv.style.display = "";
				if (this.get_enableAnimations())
					this._hoveredDivHoverAnimation.play(0, this._finalHoverOpacity);
			}
		}
	},
	_hideHovered: function()
	{
		if (this.__isHtml5)
		{
			if (this.get_enableAnimations())
				this._canvasHoverAnimation.play(100, 0);
			this._drawEmpty();
			this._drawSelected();
			this._adjustCanvasTooltip(this.get_value());
		}
		else
		{
			if (!this.get_enableShowSelectionOnHover())
			{
				if (this.get_enableAnimations())
					this._selectedDivHoverAnimation.play(0, this._finalSelectOpacity);
				else
					this._selectedDiv.style.visibility = "";
			}
			if (this._hoveredDiv != null)
			{
				if (this.get_enableAnimations())
					this._hoveredDivHoverAnimation.play(this._finalHoverOpacity, 0);
				else
					this._hoveredDiv.style.display = "none";
			}
		}
	},
	_underForVal: function(valLength)
	{
		var decimalPart = valLength - Math.floor(valLength);
		if (decimalPart == 0 && valLength != 0)
			return valLength - 1;
		return Math.floor(valLength);
	},
	_adjustHover: function(val)
	{
	    
	    if (val < 0 || !this._hoveredDiv)
			return;
		var width;
		var height;
		var left = 0;
		var top = 0;
		var margin = 0;
		var majorLength = Math.round(this.__critLength * val);
		if (!this.get_enableContinuousSelection())
			majorLength -= this.__critLength * this._underForVal(val);
		if (this.__isHor)
		{
			if (this.__isRev)
			{
				left = Math.round((this.get_itemCount() - val) * this.get_imageWidth());
			}
			else if (!this.get_enableContinuousSelection())
			{
				left = Math.round(this.__critLength * this._underForVal(val));
			}
		}
		else
		{
			if (this.__isRev)
			{
				top = Math.round(-1 * val * this.get_imageHeight() - this.__selHeight);
			}
			else
			{
				if (this.get_enableContinuousSelection())
				{
					top = Math.round(-1 * this.get_itemCount() * this.get_imageHeight() - this.__selHeight);
				}
				else
				{
					top = Math.round(-1 * this.get_imageHeight() * (this.get_itemCount() - this._underForVal(val)) - this.__selHeight);
				}
			}
		}
		if (this.__isRev)
		{
			margin = majorLength % this.__critLength;
			if (margin > 0)
				margin -= this.__critLength;
		}
		if (this.__isCustom)
		{
			if (this.__isRev)
			{
				margin = Math.round(-1 * (this.get_itemCount() - val) * this.__critLength);
			}
			else if (!this.get_enableContinuousSelection())
				margin = Math.round(-1 * this.__critLength * this._underForVal(val));
		}

		if (this.__isHor)
		{
			this._hoveredDiv.style.width = majorLength + "px";
			if (this.__isRev || this.__isCustom)
			{
				if ($util.IsIE)
					this._adjustMargin(this._hoveredDiv, 0);
				this._adjustMargin(this._hoveredDiv, margin);
			}
			this._hoveredDiv.style.left = left + "px";
		}
		else
		{
			this._hoveredDiv.style.height = majorLength + "px";
			if (this.__isRev || this.__isCustom)
			{
				if ($util.IsIE)
					this._adjustMargin(this._hoveredDiv, 0);
				this._adjustMargin(this._hoveredDiv, margin);
			}
			this._hoveredDiv.style.top = top + "px";
		}
		this._adjustTooltips(val);
	},
	_formatTooltip: function(tooltip, val)
	{
		/// <summary> Takes the tooltip format string and value and calculates the string for the tooltip. </summary>
		/// <param name="tooltip" type="String">The format string for the tooltip.</param>
		/// <param name="val" type="String">The selected or hovered value to use in the tooltip.</param>
		return String.localeFormat(tooltip, val, this.get_average(), this.get_voteCount(), this.get_minimumValue(), this.get_maximumValue(), this.get_itemCount());
	},
	_adjustTooltips: function(valLength)
	{
		if (!this._hoveredDiv)
			return;
		var index = this._underForVal(valLength);
		var count = 1;
		var actVal = this._realValFromLengthVal(valLength);
		var tooltip;
		if (this.__isCustom)
		{
			var increment = 1;
			if (this.__isRev)
			{
				count = this.get_itemCount();
				increment = -1;
			}
			for (var x = 0; x < this._hoveredDiv.childNodes.length; ++x)
			{
				if (this._hoveredDiv.childNodes[x].style)
				{
					tooltip = this._customTooltips[count - 1];
					tooltip = this._formatTooltip(tooltip, count - 1 == index ? actVal : this._realValFromLengthVal(count));
					this._hoveredDiv.childNodes[x].title = tooltip;
					this._hoveredDiv.childNodes[x].alt = tooltip;
					count += increment;
				}
			}
			if (this.get_precision() == $IG.RatingPrecision.Exact || valLength <= 0)
			{
				count = this.__isRev ? this.get_itemCount() : 1;
				for (var x = 0; x < this._selectedDiv.childNodes.length; ++x)
				{
					if (this._selectedDiv.childNodes[x].style)
					{
						tooltip = this._customTooltips[count - 1];
						tooltip = this._formatTooltip(tooltip, count - 1 == index ? actVal : this._realValFromLengthVal(count));
						this._selectedDiv.childNodes[x].title = tooltip;
						this._selectedDiv.childNodes[x].alt = tooltip;
						count += increment;
					}
				}
				count = this.__isRev ? this.get_itemCount() : 1;
				for (var x = 0; x < this._emptyDiv.childNodes.length; ++x)
				{
					if (this._emptyDiv.childNodes[x].style)
					{
						tooltip = this._customTooltips[count - 1];
						tooltip = this._formatTooltip(tooltip, count - 1 == index ? actVal : this._realValFromLengthVal(count));
						this._emptyDiv.childNodes[x].title = tooltip;
						this._emptyDiv.childNodes[x].alt = tooltip;
						count += increment;
					}
				}
			}
		}
		else
		{
			tooltip = this._formatTooltip(this._itemTooltipFormat, actVal);
			for (var x = 0; x < this._hoveredDiv.childNodes.length; ++x)
			{
				if (this._hoveredDiv.childNodes[x].style)
				{
					this._hoveredDiv.childNodes[x].title = tooltip;
					this._hoveredDiv.childNodes[x].alt = tooltip;
				}
			}
			if (this.get_precision() == $IG.RatingPrecision.Exact || valLength <= 0)
			{
				tooltip = this._formatTooltip(this._itemTooltipFormat, actVal);
				for (var x = 0; x < this._selectedDiv.childNodes.length; ++x)
				{
					if (this._selectedDiv.childNodes[x].style)
					{
						this._selectedDiv.childNodes[x].title = tooltip;
						this._selectedDiv.childNodes[x].alt = tooltip;
					}
				}
				for (var x = 0; x < this._emptyDiv.childNodes.length; ++x)
				{
					if (this._emptyDiv.childNodes[x].style)
					{
						this._emptyDiv.childNodes[x].title = tooltip;
						this._emptyDiv.childNodes[x].alt = tooltip;
					}
				}
			}
		}

	},
	_adjustSelectedTooltips: function(actVal)
	{
		var valLength = this._lengthValFromRealVal(actVal)
		var index = this._underForVal(valLength);
		var count = 1;
		var tooltip = this._formatTooltip(this._itemTooltipFormat, actVal);
		var increment = 1;
		if (this.__isRev && this.__isCustom)
		{
			count = this.get_itemCount();
			increment = -1;
		}
		for (var x = 0; x < this._selectedDiv.childNodes.length; ++x)
		{
			if (this._selectedDiv.childNodes[x].style)
			{
				if (this.__isCustom)
				{
					tooltip = this._customTooltips[count - 1];
					tooltip = this._formatTooltip(tooltip, count - 1 == index ? actVal : this._realValFromLengthVal(count));
				}
				this._selectedDiv.childNodes[x].title = tooltip;
				this._selectedDiv.childNodes[x].alt = tooltip;
				count += increment;
			}
		}
	},
	_clearEmptyTooltips: function()
	{
		if (this.__isCustom)
		{
			var count = 1;
			var increment = 1;
			if (this.__isRev)
			{
				count = this.get_itemCount();
				increment = -1;
			}
			for (var x = 0; x < this._emptyDiv.childNodes.length; ++x)
			{
				if (this._emptyDiv.childNodes[x].style)
				{
					tooltip = this._customTooltips[count - 1];
					tooltip = this._formatTooltip(tooltip, this._realValFromLengthVal(count));
					this._emptyDiv.childNodes[x].title = tooltip;
					this._emptyDiv.childNodes[x].alt = tooltip;
					count += increment;
				}
			}
			return;
		}
		for (var x = 0; x < this._emptyDiv.childNodes.length; ++x)
		{
			if (this._emptyDiv.childNodes[x].style)
			{
				this._emptyDiv.childNodes[x].removeAttribute("title");
				this._emptyDiv.childNodes[x].removeAttribute("alt");
			}
		}
	},
	_adjustHoverKeyBoard: function(val, goingUp)
	{
		if (val < 0)
			return;
		var width;
		var height;
		var left = 0;
		var top = 0;
		var margin = 0;
		var majorLength = Math.round(this.__critLength * val);
		if (!this.get_enableContinuousSelection())
			majorLength -= this.__critLength * this._underForVal(val);
		if (this.__isHor)
		{
			if (this.__isRev)
			{
				left = Math.round((this.get_itemCount() - val) * this.get_imageWidth());
			}
			else if (!this.get_enableContinuousSelection())
			{
				left = Math.round(this.__critLength * this._underForVal(val));
			}
		}
		else
		{
			if (this.__isRev)
			{
				top = Math.round(-1 * val * this.get_imageHeight() - this.__selHeight);
			}
			else
			{
				if (this.get_enableContinuousSelection())
				{
					top = Math.round(-1 * this.get_itemCount() * this.get_imageHeight() - this.__selHeight);
				}
				else
				{
					top = Math.round(-1 * this.get_imageHeight() * (this.get_itemCount() - this._underForVal(val)) - this.__selHeight);
				}
			}
		}
		if (this.__isRev)
		{
			margin = majorLength % this.__critLength;
			if (margin > 0)
				margin -= this.__critLength;
		}
		if (this.__isCustom)
		{
			if (this.__isRev)
			{
				margin = Math.round(-1 * (this.get_itemCount() - val) * this.__critLength);
			}
			else if (!this.get_enableContinuousSelection())
				margin = Math.round(-1 * this.__critLength * this._underForVal(val));
		}
		var adjust = true;
		if (this.get_enableAnimations())
		{
			var newOffset = this.__isHor ? left : top;
			var oldLength = this.__isHor ? parseInt(this._hoveredDiv.style.width.replace('px', '')) : parseInt(this._hoveredDiv.style.height.replace('px', ''));
			var oldOffset = this.__isHor ? parseInt(this._hoveredDiv.style.left.replace('px', '')) : parseInt(this._hoveredDiv.style.top.replace('px', ''));
			if (this.get_enableContinuousSelection() && this.get_precision() != $IG.RatingPrecision.Exact)
			{
				this._keyboardAnimation.play(oldLength, majorLength, oldOffset, newOffset, val);
				adjust = false;
			}
			else if (!this.get_enableContinuousSelection())
			{
				var remainder = val - this._underForVal(val);
				var oldRemainder = oldLength / this.__critLength;
				if (this.get_precision() == $IG.RatingPrecision.Half && ((remainder < 1) ^ goingUp))
				{
					this._keyboardAnimation.play(oldLength, majorLength, oldOffset, newOffset, val);
					adjust = false;
				}
				else if (this.get_precision() != $IG.RatingPrecision.Exact || (goingUp && remainder < oldRemainder && remainder != 0) || (!goingUp && remainder > oldRemainder))
				{
					this._keyboardFadeAnimation.play(oldLength, majorLength, oldOffset, newOffset, margin, val);
					adjust = false;
				}
			}
		}
		//else
		if (adjust)
		{
			if (this.__isHor)
			{
				this._hoveredDiv.style.width = majorLength + "px";
				if (this.__isRev || this.__isCustom)
				{
					if ($util.IsIE)
						this._adjustMargin(this._hoveredDiv, 0);
					this._adjustMargin(this._hoveredDiv, margin);
				}
				this._hoveredDiv.style.left = left + "px";
			}
			else
			{
				this._hoveredDiv.style.height = majorLength + "px";
				if (this.__isRev || this.__isCustom)
				{
					if ($util.IsIE)
						this._adjustMargin(this._hoveredDiv, 0);
					this._adjustMargin(this._hoveredDiv, margin);
				}
				this._hoveredDiv.style.top = top + "px";
			}
		}

	},
	_adjustSelected: function(val)
	{
		if (val < 0)
			return;
		var width;
		var height;
		var left = 0;
		var top = 0;
		var margin = 0;
		var newHovTop;
		var majorLength = Math.round(this.__critLength * val);
		if (!this.get_enableContinuousSelection())
			majorLength -= this.__critLength * this._underForVal(val);
		if (this.__isHor)
		{
			if (this.__isRev)
			{
				left = Math.round((this.get_itemCount() - val) * this.get_imageWidth());
			}
			else if (!this.get_enableContinuousSelection())
			{
				left = Math.round(this.__critLength * this._underForVal(val));
			}
		}
		else
		{
			if (this.__isRev)
			{
				top = Math.round(-1 * val * this.get_imageHeight());
			}
			else
			{
				if (this.get_enableContinuousSelection())
				{
					top = Math.round(-1 * this.get_itemCount() * this.get_imageHeight());
				}
				else
				{
					top = Math.round(-1 * this.get_imageHeight() * (this.get_itemCount() - this._underForVal(val)));
				}
			}
			newHovTop = top - majorLength;
		}
		if (this.__isRev)
		{
			margin = majorLength % this.__critLength;
			if (margin > 0)
				margin -= this.__critLength;
		}
		if (this.__isCustom)
		{
			if (this.__isRev)
			{
				margin = Math.round(-1 * (this.get_itemCount() - val) * this.__critLength);
			}
			else if (!this.get_enableContinuousSelection())
				margin = Math.round(-1 * this.__critLength * this._underForVal(val));
		}

		if (majorLength == 0 && !this.__isHor)
			this._selectedDiv.style.display = "none";
		else
			this._selectedDiv.style.display = "";
		if (this.__isHor)
		{
			this._selectedDiv.style.width = majorLength + "px";
			if (this.__isRev || this.__isCustom)
			{
				this._adjustMargin(this._selectedDiv, margin);
			}
			this._selectedDiv.style.left = left + "px";
		}
		else
		{
			this._selectedDiv.style.height = majorLength + "px";
			this.__selHeight = majorLength;
			if (this.__isRev || this.__isCustom)
			{
				this._adjustMargin(this._selectedDiv, margin);
			}
			this._selectedDiv.style.top = top + "px";
			if (newHovTop)
				this._hoveredDiv.style.top = newHovTop + "px";
		}

	},
	_adjustMargin: function(div, margin)
	{
		/// <summary> This adjusts the margin-left or magin-top (depending upon orientation)
		/// of the spans of the given div.  It breaks the margin into pieces for each span.
		/// </summary>
		for (var x = 0; x < div.childNodes.length; ++x)
		{
			if (div.childNodes[x].style)
			{
				if (margin < 0)
				{
					if (margin <= -1 * this.__critLength)
					{
						if (this.__isHor)
							div.childNodes[x].style.marginLeft = (-1 * this.__critLength) + "px";
						else
							div.childNodes[x].style.marginTop = (-1 * this.__critLength) + "px";
					}
					else
					{
						if (this.__isHor)
							div.childNodes[x].style.marginLeft = (margin) + "px";
						else
							div.childNodes[x].style.marginTop = (margin) + "px";
					}
					margin += this.__critLength;
				}
				else
				{
					if (this.__isHor)
						div.childNodes[x].style.marginLeft = "";
					else
						div.childNodes[x].style.marginTop = "";
				}
			}
		}
	},

	_realValFromLengthVal: function(valLength, noAdjust)
	{
		/// <summary>
		/// This converts a number between 0 and ItemCount into the value stored in the rating
		/// </summary>
		/// <param name="valLength" type="Number">Number between 0 and ItemCount for approx location of mouse on control</param>
		/// <returns type="Number">The actual value that will be stored from the location of the mouse </returns>

		if (!noAdjust)
		{
			if (this.get_precision() == $IG.RatingPrecision.Half)
				valLength = Math.round(valLength * 2) / 2;
			else if (this.get_precision() == $IG.RatingPrecision.Exact)
				valLength = Math.round(valLength * this.__critLength) / this.__critLength;
		}
		var realVal = valLength;
		if (this.__isCustom)
		{
			var index = this._underForVal(valLength);
			var fraction = valLength - index;
			var min = index == 0 ? this.get_minimumValue() : this._customValues[index - 1];
			var max = this._customValues[index];
			var customVal = min + fraction * (max - min);
			realVal = customVal;
		}
		else
		{
			// where max value is determined by item count
			realVal += this.get_minimumValue();
		}
		realVal = Math.round(realVal * this.__critLength) / this.__critLength;
		return realVal;
	},
	_lengthValFromRealVal: function(actVal)
	{
		/// <summary>
		/// Takes the actual value of the control and converts it into a number for calculating lenghts of the divs
		/// </summary>
		/// <param name="actVal" type="Number">The actual value of the rating</param>
		/// <returns type="Number">A number between 0 and ItemCount</returns>
		if (actVal < this.get_minimumValue())
			return 0;
		if (actVal > this.get_maximumValue())
			return this.get_itemCount();
		var length = actVal;
		if (this.__isCustom)
		{
			for (var x = 0; x < this._customValues.length; ++x)
			{
				var min = x == 0 ? this.get_minimumValue() : this._customValues[x - 1];
				var max = this._customValues[x];
				if (actVal == this._customValues[x])
				{
					length = x + 1;
					break;
				}
				if (actVal >= min && actVal <= max)
				{
					var fraction = (actVal - min) / (max - min);
					length = x + fraction;
					break;
				}
			}
		}
		else
		{
			// where max value is determined by item count
			length -= this.get_minimumValue();
		}
		length = Math.round(length * this.__critLength) / this.__critLength;
		return length;
	},

	_myAnimationEnded: function()
	{
		/// <summary>
		/// Hides the hovered div when mouse moves off the control after animaition is complete
		/// </summary>
		if (!this._isHovered && !this._hasFocus)
		{
			this._hoveredDiv.style.display = "none";
		}
	},
	_keyboardAnimationGoing: function()
	{
		return (this._keyboardAnimation != null && this._keyboardAnimation.get_isAnimating())
		 || (this._keyboardFadeAnimation != null && this._keyboardFadeAnimation.get_isAnimating())
		 || (this._canvasSlideAnimation != null && this._canvasSlideAnimation.get_isAnimating())
		 || (this._canvasKeyboardFadeAnimation != null && this._canvasKeyboardFadeAnimation.get_isAnimating());
	},


	
	_getCS: function()
	{
		return this._oldValue + "|" + this._voted;
	},
	
	_saveCS: function()
	{
	},
	
	_saveAdditionalClientState: function()
	{
		return this._getCS();
	}


	
}
$IG.WebRating.registerClass('Infragistics.Web.UI.WebRating', $IG.ControlMain);

$IG.WebRating.find = function(clientID)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebRating.find">Finds WebRating by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebRating">Reference to the WebRating control object that corresponds to specified client ID.</returns>
};

$IG.WebRating.from = function(obj)
{
	///<summary locid="M:J#Infragistics.Web.UI.WebRating.from">Casts passed in object to the WebRating type.</summary>
	///<param name="obj">Object to convert to the WebRating type.</param>
	///<returns type="Infragistics.Web.UI.WebRating">Reference to the same object that is passed in, only type converted to the WebRating type.</returns>
};


$IG.RatingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.RatingEventArgs">
	/// EventArgs that contain the old and new value
	/// </summary>
	$IG.RatingEventArgs.initializeBase(this);
}
$IG.RatingEventArgs.prototype =
{
	getCurrentValue: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RatingEventArgs.getCurrentValue">
		/// Returns the current value of the rating of the rating when it is about to change
		/// </summary>
		/// <returns type="Number" />
		return this._props[2];
	},
	getNewValue: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RatingEventArgs.getNewValue">
		/// Returns the new value of the rating.
		/// </summary>
		/// <returns type="Number" />
		return this._props[3];
	}
}
$IG.RatingEventArgs.registerClass('Infragistics.Web.UI.RatingEventArgs', $IG.CancelEventArgs);

$IG.RatedEventArgs = function()
{
    /// <summary locid="T:J#Infragistics.Web.UI.RatedEventArgs">
    /// EventArgs that contain the old and new values of the rating after it has changed
    /// </summary>
$IG.RatedEventArgs.initializeBase(this);
}
$IG.RatedEventArgs.prototype =
{
    getOldValue: function() {
        /// <summary locid="M:J#Infragistics.Web.UI.RatedEventArgs.getOldValue">
        /// Returns the old fill value of the rating.
        /// </summary>
        /// <returns type="Number" />
        return this._props[2];
    },
    getNewValue: function() {
        /// <summary locid="M:J#Infragistics.Web.UI.RatedEventArgs.getNewValue">
        /// Returns the new fill value of the rating.
        /// </summary>
        /// <returns type="Number" />
        return this._props[3];
    }
}
$IG.RatedEventArgs.registerClass('Infragistics.Web.UI.RatedEventArgs', $IG.EventArgs);




//$IG.RatingImage = function(owner, imageCss, selectedCss, hoveredCss)
$IG.RatingImage = function(obj, element, props, control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RatingImage">
	/// Defines an object to store and set the css for plain (non-custom) images in a WebRating.
	/// </summary>
	/// <param name="owner" type="Infragistics.Web.UI.WebRating" optional="false" mayBeNull="false">
	/// The rating that this Image Item belongs to.
	/// </param>
	/// <param name="imageCss" type="String">The css to apply empty image to the rating.</param>
	/// <param name="selectedCss" type="String">The css to apply selected image to the rating.</param>
	/// <param name="hoveredCss" type="String">The css to apply hovered image to the rating.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]); 
	$IG.RatingImage.initializeBase(this, [obj, element, props, control, csm]);

	this._defaultEmpty = this._owner._get_clientOnlyValue("wre");
	this._defaultSelected = this._defaultEmpty.replace('Empty', 'Selected');
	this._defaultHovered = this._defaultEmpty.replace('Empty', 'Hovered');
	this._defaultDisabledEmpty = this._defaultEmpty.replace('Empty', 'DisabledEmpty');
	this._defaultDisabledSelected = this._defaultEmpty.replace('Empty', 'DisabledSelected');
}

$IG.RatingImage.prototype =
{
	get_imageCss: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.imageCss">
		/// Returns the css for empty images.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.RatingBaseImageProps.ImageCss);
	},
	set_imageCss: function(css)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.imageCss">
		/// Sets the css for empty images.
		/// </summary>
		/// <param name="css" type="String">The new css for empty images</param>
		var newCss = css;
		if (newCss.length == 0)
			newCss = this._defaultEmpty;
		var oldCss = this._get_value($IG.RatingBaseImageProps.ImageCss);
		if (oldCss.length == 0)
			oldCss = this._defaultEmpty;
		this._set_value($IG.RatingBaseImageProps.ImageCss, css);
		if (!this._owner.__isCustom && this._owner.get_enabled())
		{
			if (this._owner.__isHtml5)
			{
				this._owner._initEmptyImg();
				this._owner._drawEmpty();
				this._owner._drawSelected();
				if (this._owner._isHovered || this._owner._hasFocus)
					this._owner._drawHovered(this._owner._oldHover);
			}
			else
				this._replaceCss(this._owner._emptyDiv, oldCss, newCss);
		}
	},
	get_selectedImageCss: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.selectedImageCss">
		/// Returns the css for selected images.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.RatingBaseImageProps.SelectedCss);
	},
	set_selectedImageCss: function(css)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.selectedImageCss">
		/// Sets the css for selected images.
		/// </summary>
		/// <param name="css" type="String">The new css for selected images</param>
		var newCss = css;
		if (newCss.length == 0)
			newCss = this._defaultSelected;
		var oldCss = this._get_value($IG.RatingBaseImageProps.SelectedCss);
		if (oldCss.length == 0)
			oldCss = this._defaultSelected;
		this._set_value($IG.RatingBaseImageProps.SelectedCss, css);
		if (!this._owner.__isCustom && this._owner.get_enabled())
		{
			if (this._owner.__isHtml5)
			{
				this._owner._initSelectedImg();
				this._owner._drawSelected();
				if (this._owner._isHovered || this._owner._hasFocus)
					this._owner._drawHovered(this._owner._oldHover);
			}
			else
				this._replaceCss(this._owner._selectedDiv, oldCss, newCss);
		}
	},
	get_hoveredImageCss: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.hoveredImageCss">
		/// Returns the css for hovered images.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.RatingBaseImageProps.HoveredCss);
	},
	set_hoveredImageCss: function(css)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.hoveredImageCss">
		/// Sets the css for hovered images.
		/// </summary>
		/// <param name="css" type="String">The new css for hovered images</param>
		var newCss = css;
		if (newCss.length == 0)
			newCss = this._defaultHovered;
		var oldCss = this._get_value($IG.RatingBaseImageProps.HoveredCss);
		if (oldCss.length == 0)
			oldCss = this._defaultHovered;
		this._set_value($IG.RatingBaseImageProps.HoveredCss, css);
		if (!this._owner.__isCustom)
		{
			if (this._owner.__isHtml5)
			{
				this._owner._initHoveredImg();
				if (this._owner._isHovered || this._owner._hasFocus)
					this._owner._drawHovered(this._owner._oldHover);
			}
			else
			{
				this._replaceCss(this._owner._hoveredDiv, this._imageCss, newCss);
				if (this._owner._keyboardFadeAnimation && this._owner._keyboardFadeAnimation._tempDiv)
					this._replaceCss(this._owner._keyboardFadeAnimation._tempDiv, oldCss, newCss);
			}
		}
	},

	get_disabledImageCss: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.disabledImageCss">
		/// Returns the css for disabled empty images.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.RatingBaseImageProps.DisabledImageCss);
	},
	set_disabledImageCss: function(css)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.disabledImageCss">
		/// Sets the css for disabled empty images.
		/// </summary>
		/// <param name="css" type="String">The new css for disabled empty images</param>
		var newCss = css;
		if (newCss.length == 0)
			newCss = this._defaultEmpty;
		var oldCss = this._get_value($IG.RatingBaseImageProps.DisabledImageCss);
		if (oldCss.length == 0)
			oldCss = this._defaultEmpty;
		this._set_value($IG.RatingBaseImageProps.DisabledImageCss, css);
		if (!this._owner.__isCustom && !this._owner.get_enabled())
		{
			if (this._owner.__isHtml5)
			{
				this._owner._initEmptyImg();
				this._owner._drawEmpty();
				this._owner._drawSelected();
			}
			else
				this._replaceCss(this._owner._emptyDiv, oldCss, newCss);
		}
	},
	get_disabledSelectedImageCss: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.disabledSelectedImageCss">
		/// Returns the css for disabled selected images.
		/// </summary>
		/// <value type="String"></value>
		return this._get_value($IG.RatingBaseImageProps.DisabledSelectedCss);
	},
	set_disabledSelectedImageCss: function(css)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.disabledSelectedImageCss">
		/// Sets the css for disabled selected images.
		/// </summary>
		/// <param name="css" type="String">The new css for disabled selected images</param>
		var newCss = css;
		if (newCss.length == 0)
			newCss = this._defaultSelected;
		var oldCss = this._get_value($IG.RatingBaseImageProps.DisabledSelectedCss);
		if (oldCss.length == 0)
			oldCss = this._defaultSelected;
		this._set_value($IG.RatingBaseImageProps.DisabledSelectedCss, css);
		if (!this._owner.__isCustom && !this._owner.get_enabled())
		{
			if (this._owner.__isHtml5)
			{
				this._owner._initSelectedImg();
				this._owner._drawSelected();
			}
			else
				this._replaceCss(this._owner._selectedDiv, oldCss, newCss);
		}
	},
	get_toolTipFormat: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RatingImage.toolTipFormat">
		/// Returns the string for formatting the tooltip of items.
		/// </summary>
		/// <value type="String"></value>
		return this._owner._itemTooltipFormat;
	},
	_replaceCss: function(div, oldCss, newCss)
	{
		for (var x = 0; x < div.childNodes.length; ++x)
		{
			if (div.childNodes[x].style)
			{
				$util.removeCompoundClass(div.childNodes[x], oldCss);
				$util.addCompoundClass(div.childNodes[x], newCss);
			}
		}
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RatingImage.dispose">
		/// Disposes of the RatingImage item
		/// </summary>
		this._imageCss = null;
		this._selectedCss = null;
		this._hoveredCss = null;
	}

}
$IG.RatingImage.registerClass('Infragistics.Web.UI.RatingImage', $IG.ObjectBase);





$IG.KeyBoardSlideAnimation = function(elem, owner)
{
	$IG.KeyBoardSlideAnimation.initializeBase(this, [elem]);
	this._equationType = $IG.AnimationEquationType.Linear;
	this._owner = owner;
	this._contSel = this._owner.get_enableContinuousSelection();
};

$IG.KeyBoardSlideAnimation.prototype =
{
	play: function(initLength, endLength, initOffset, endOffset, endVal)
	{
		this._initLength = initLength;
		this._endLength = endLength;
		this._initOffset = initOffset;
		this._endOffset = endOffset;
		this._endVal = endVal;
		$IG.KeyBoardSlideAnimation.callBaseMethod(this, "play");
	},

	_next: function()
	{
		var start = this._initLength, end = this._endLength;
		var newLength = Math.round(this._calc(this._equationType, this._time, start, end, this._duration));
		var newOffset;
		var newMargin = 0;
		if (this._owner.__isRev)
		{
			newOffset = Math.round(this._calc(this._equationType, this._time, this._initOffset, this._endOffset, this._duration));

			newMargin = newLength % this._owner.__critLength;
			if (newMargin > 0)
				newMargin -= this._owner.__critLength;
		}
		var newVal = this._contSel ? newLength / this._owner.__critLength : newLength / this._owner.__critLength + this._owner._underForVal(this._endVal);
		if (this._owner.__isCustom)
		{
			if (this._owner.__isRev)
			{
				newMargin = Math.round(-1 * (this._owner.get_itemCount() - newVal) * this._owner.__critLength);
			}
			else if (!this._contSel)
			{
				newMargin = Math.round(-1 * this._owner.__critLength * this._owner._underForVal(newVal));
			}
		}

		if (this._owner.__isHor)
		{
			this._element.style.width = newLength + "px";
			if (this._owner.__isRev || this._owner.__isCustom)
			{
				if (this._owner.__isRev)
					this._element.style.left = newOffset + "px";

				this._owner._adjustMargin(this._element, newMargin);
			}
		}
		else
		{
			this._element.style.height = newLength + "px";
			if (this._owner.__isRev || this._owner.__isCustom)
			{
				if (this._owner.__isRev)
					this._element.style.top = newOffset + "px";
				this._owner._adjustMargin(this._element, newMargin);
			}
		}
		if ((start < end && newLength >= end) || (start > end && newLength <= end))
			this.stop();
	},

	stop: function()
	{
		$IG.KeyBoardSlideAnimation.callBaseMethod(this, "stop");
	}
};

$IG.KeyBoardSlideAnimation.registerClass("Infragistics.Web.UI.KeyBoardSlideAnimation", $IG.AnimationBase);



$IG.KeyBoardFadeAnimation = function(elem, owner, hoverOpacity)
{
	$IG.KeyBoardFadeAnimation.initializeBase(this, [elem]);
	this._equationType = $IG.AnimationEquationType.Linear;
	this._owner = owner;
	this._hoverOpacity = hoverOpacity;

	if (!this._tempDiv)
	{
		this._tempDiv = document.createElement("div");
		this._tempDiv.style.position = "relative";
		this._tempDiv.style.overflow = "hidden";
		if (this._owner.__isHor)
		{
			this._tempDiv.style.height = this._owner.get_imageHeight() + "px";
			this._tempDiv.style.top = (-3 * this._owner.get_imageHeight()) + "px";
		}
		else
		{
			this._tempDiv.style.width = this._owner.get_imageWidth() + "px";
		}
		var span = document.createElement("span");
		span.style.height = this._owner.get_imageHeight() + "px";
		span.style.width = this._owner.get_imageWidth() + "px";
		var css = "";
		for (var x = 0; x < this._owner._hoveredDiv.childNodes.length; ++x)
		{
			if (this._owner._hoveredDiv.childNodes[x].style)
			{
				css = this._owner._hoveredDiv.childNodes[x].className;
				break;
			}
		}
		span.className = css;
		this._tempDiv.appendChild(span);
		this._tempDiv.style.display = "none";
		this._owner._element.appendChild(this._tempDiv);
	}
};

$IG.KeyBoardFadeAnimation.prototype =
{
	play: function(oldLength, endLength, oldOffset, endOffset, newMargin, newVal)
	{
		this._endLength = endLength;
		this._endOffset = endOffset;
		this._endMargin = newMargin;
		var css = "";

		// set up temp item over the new spot
		if (this._owner.__isHor)
		{
			this._tempDiv.style.width = endLength + "px";
			this._tempDiv.style.left = endOffset + "px";
		}
		else
		{
			this._tempDiv.style.height = endLength + "px";
			this._tempDiv.style.top = (endOffset - oldLength) + "px";
		}
		this._tempDiv.style.display = "";
		var setMargin = newMargin;
		while (this._owner.__isCustom && setMargin + this._owner.__critLength <= 0)
			setMargin += this._owner.__critLength;
		if (this._owner.__isCustom)
		{
			var count = 0;
			var index = Math.ceil(newVal) - 1;
			for (var x = 0; x < this._owner._hoveredDiv.childNodes.length; ++x)
			{
				if (this._owner._hoveredDiv.childNodes[x].style)
				{
					//if (count == index)
					if (index == this._owner._hoveredDiv.childNodes[x].getAttribute('adr'))
					{
						css = this._owner._hoveredDiv.childNodes[x].className;
						break;
					}
					++count;
				}
			}

		}
		for (var x = 0; x < this._tempDiv.childNodes.length; ++x)
		{
			if (this._tempDiv.childNodes[x].style)
			{
				if (this._owner.__isHor)
					this._tempDiv.childNodes[x].style.marginLeft = setMargin + "px";
				else
					this._tempDiv.childNodes[x].style.marginTop = setMargin + "px";
				if (this._owner.__isCustom)
					this._tempDiv.childNodes[x].className = css;
				break;
			}
		}
		$IG.KeyBoardFadeAnimation.callBaseMethod(this, "play");
	},

	_next: function()
	{

		var opacFade = this._calc(this._equationType, this._time, this._hoverOpacity, 0, this._duration);
		var opacShow = this._hoverOpacity - opacFade;

		$util.setOpacity(this._element, opacFade);
		$util.setOpacity(this._tempDiv, opacShow);

		if (opacShow >= this._hoverOpacity)
		{
			this.stop();
		}
	},

	stop: function()
	{
		if (this._endLength != undefined && this._endOffset != undefined && this._endMargin != undefined)
		{
			var elem = this._element;
			if (this._owner.__isHor)
			{
				this._element.style.width = this._endLength + "px";
				this._element.style.left = this._endOffset + "px";
			}
			else
			{
				this._element.style.height = this._endLength + "px";
				this._element.style.top = this._endOffset + "px";
			}
			this._owner._adjustMargin(this._element, this._endMargin);
		}
		if (this._element)
			$util.setOpacity(this._element, this._hoverOpacity);
		if (this._tempDiv)
			this._tempDiv.style.display = "none";
		$IG.KeyBoardFadeAnimation.callBaseMethod(this, "stop");
	}
};

$IG.KeyBoardFadeAnimation.registerClass("Infragistics.Web.UI.KeyBoardFadeAnimation", $IG.AnimationBase);


/*
* igWebDataGridRowSelectors.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


$IG.RowSelectors = function(obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowSelectors">
	/// Row selectors behavior object of the grid. 
	/// </summary>
	$IG.RowSelectors.initializeBase(this, [obj, objProps, control, parentCollection]);
	control._incrementCellIndexOffset();

	this._hierarchical = hierarchical;
	this._rowSelIndex = this._grid._cell_index_offset - 1;

	// Set up properties
	this._rowNumbering = this._get_clientOnlyValue("rn");
	this._rowSelectorClass = this._get_clientOnlyValue("rsc");
	this._container = control._elements["container"];
	this._header = control._elements["header"];
	this._footer = control._elements["footer"];

	this._rowSelectedCellCount = [];
	// Hook up events
	this._grid.get_rows().addRowCreatedEventHandler(this._onRowCreated);
	this._addElementEventHandler(this._container, "click", this._onContainerClickHandler);
	this._addElementEventHandler(this._header, "click", this._onHeaderClickHandler);
	this._addElementEventHandler(this._footer, "click", this._onFooterClickHandler);

	this._gridElementSelectStartHandler = Function.createDelegate(this, this._onSelectstartHandler);
	this._grid._gridUtil._registerEventListener(this._grid, "SelectStartContainer", this._gridElementSelectStartHandler);
	
	if (this._grid.get_enableClientRendering())
	{
		this._onDataBoundHandler = Function.createDelegate(this, this._applyRowNumbering);
		this._grid._gridUtil._registerEventListener(this._grid, "DataBound", this._onDataBoundHandler);
	}	
    
    this._insertRowSelectorIntoAddedRowHandler = Function.createDelegate(this, this._insertRowSelectorIntoAddedRow);
	this._grid._gridUtil._registerEventListener(this._grid, "NewBatchRowBeforeCells", this._insertRowSelectorIntoAddedRowHandler);
    this._onBatchUpdateUndoneHandler = Function.createDelegate(this, this._onBatchUpdateUndone);
	this._grid._gridUtil._registerEventListener(this._grid, "BatchUpdateUndone", this._onBatchUpdateUndoneHandler);
};

$IG.RowSelectors.prototype =
{
	

	get_rowNumbering: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowSelectors.rowNumbering">
		/// Returns whether row numbering is enabled or not.
		/// </summary>
		/// <value type="Boolean"></value>
		/// <remarks>
		/// <p class="body">This property is read-only on the client. It can only be set on the server.</p>
		/// </remarks>
		return this._rowNumbering;
	},

	

	

	_initializeComplete: function ()
	{
		this._selection = this._parentCollection.getBehaviorFromInterface($IG.ISelectionBehavior);
		this._paging = this._grid.get_behaviors().get_paging();
		if (this._grid.get_enableClientRendering())
			this._applyRowNumbering();
	},

	_applyRowNumbering: function ()
	{
		if (this._rowNumbering && this._grid.get_rows().get_length() > 0)
		{
			var ind = 1;
			var vsOffset = 0;
			var pgOffset = 0;

			var virtualScrolling = this._grid.get_behaviors().get_virtualScrolling();
			if (virtualScrolling)
				vsOffset = virtualScrolling._get_rowCacheOffsetIndex();
			if (this._paging)
				pgOffset = this._paging.get_pageIndex() * this._paging.get_pageSize();
			if (this._grid._elements["dataTbl"])
			{
				ind += vsOffset + pgOffset;
				var rows = this._grid._elements["dataTbl"].rows;
				var rowSelectors = this;
				$(rows).each(function (index)
				{					
					$($(this).children().get(rowSelectors._rowSelIndex)).html(index + ind);
				});				
			}
		}
	},

	_onContainerClickHandler: function (evnt)
	{
		var row = this._grid._gridUtil.getRowFromCellElem(evnt.target);
		var selector = this.getSelectorFromElement(evnt.target);
		




		if (row == null)
		{
			if (evnt.target.tagName == "DIV")
			{
				if (evnt.target.parentNode.getAttribute("type") == "selector")
				{
					row = this._grid._gridUtil.getRowFromCellElem(evnt.target.parentNode);
					selector = this.getSelectorFromElement(evnt.target.parentNode);
				}
			}
		}
		if (row && selector && selector.getAttribute("type") == "selector")
		{
			// raise before event
			var args = this.__raiseClientEvent("RowSelectorClicking", $IG.RowSelectorClickingEventArgs, [selector, row]);
			if (args !== null && args.get_cancel())
				return;

			// pass the event information to anyone who is interested
			this._grid._gridUtil._fireEvent(this, "RowSelectorClicked", { "row": row, "evnt": evnt });

			// raise after event
			this.__raiseClientEvent("RowSelectorClicked", $IG.RowSelectorClickedEventArgs, [selector, row]);
		}
	},

	_onHeaderClickHandler: function (evnt)
	{
		this._marginClicked(evnt.target, "HeaderRowSelectorClicked");
	},

	_onFooterClickHandler: function (evnt)
	{
		this._marginClicked(evnt.target, "FooterRowSelectorClicked");
	},

	_onRowCreated: function (row)
	{
		
		var elem = row.get_element();
		var index = row.get_index();
		//debugger;
		var selector = null;
		if (elem)
		{
			var rowElementChildren = elem.cells;
			var count = rowElementChildren.length;
			for (var i = 0; i < count; i++)
			{
				var obj = rowElementChildren[i];
				if (obj && obj.tagName == "TH")
				{
					selector = obj;
					break;
				}
			}
		}
		if (!selector)
			return;
		




		selector.setAttribute("adr", 0);
		selector.setAttribute("type", "selector");
	},

	_onSelectstartHandler: function (evnt)
	{
		if (this._selection)
		{
			var selector = this.getSelectorFromElement(evnt.target);
			if (selector)
				$util.cancelEvent(evnt);
		}
	},

	

	
	_reInitializeSelectedCellCount: function ()
	{
		this._rowSelectedCellCount = [];
	},
	
	_incrementSelectedCellCount: function (row, imageCss, cssClass)
	{
		var rowIndex = row.get_index();
		if (this._rowSelectedCellCount[rowIndex] == null || this._rowSelectedCellCount[rowIndex] == "undefined")
			this._rowSelectedCellCount[rowIndex] = 0;

		this._rowSelectedCellCount[rowIndex]++;
		if (this._rowSelectedCellCount[rowIndex] == 1)
		{
			this.addSelectorImage(row, imageCss);
			this.addSelectorClass(row, cssClass);
		}

	},
	
	_decrementSelectedCellCount: function (row, imageCss, cssClass)
	{
		

		if (!row)
			return;
		var rowIndex = row.get_index();
		if (this._rowSelectedCellCount[rowIndex] == null || this._rowSelectedCellCount[rowIndex] == "undefined")
			this._rowSelectedCellCount[rowIndex] = 0;

		this._rowSelectedCellCount[rowIndex]--;
		if (this._rowSelectedCellCount[rowIndex] == 0)
		{
			this.removeSelectorImage(row, imageCss);
			this.removeSelectorClass(row, cssClass);
		}

	},
	_marginClicked: function (target, clientEvent)
	{
		if (target && target.tagName == "TH" && target.cellIndex === this._rowSelIndex)
		{
			// raise the event
			var selector = target;
			this.__raiseClientEvent(clientEvent, $IG.MarginRowSelectorClickedEventArgs, [selector]);
		}
	},

	_addElementEventHandler: function (element, eventName, handler)
	{
		if (!element) return;
		if (!this.eventHandlers) this.eventHandlers = [];

		var eventDelegate = Function.createDelegate(this, handler);
		this._grid._addElementEventHandler(element, eventName, eventDelegate);
		this.eventHandlers.push({ "element": element, "eventName": eventName, "handler": eventDelegate });
	},

	_removeEventHandlers: function ()
	{
		// unhook any event listeners
		if (!this.eventHandlers || this.eventHandlers.length === 0) return;
		for (var x = 0; x < this.eventHandlers.length; x++)
		{
			var eventHandler = this.eventHandlers[x];
			this._grid._removeElementEventHandler(eventHandler.element, eventHandler.eventName, eventHandler.handler);
		}
	},

    _insertRowSelectorIntoAddedRow: function (args)
    {
        if (args.row)
        {
            var newRowSelector = document.createElement('th');
            newRowSelector.className = this._rowSelectorClass;
            var rowNumber = '';
            if (this._rowNumbering)
            {
                if (args.index == 0)
                    rowNumber = '1';
                else
                {
                    var rowSelector = this.getSelectorFromRow(this._grid.get_rows().get_row(args.index - 1));
                    rowNumber = rowSelector ? parseInt(rowSelector.firstChild && rowSelector.firstChild.tagName == "DIV" ? rowSelector.firstChild.innerHTML : rowSelector.innerHTML) + 1 : args.index + 1;
                }
            }
            
            newRowSelector.setAttribute("type", "selector");
            newRowSelector.setAttribute("adr", "0");
            newRowSelector.appendChild(document.createTextNode(rowNumber));
            args.row.appendChild(newRowSelector);
        }
    },
    
    _onBatchUpdateUndone: function (args)
    {
        if (this._rowNumbering && args.type == $IG.RowUpdateType.Add && args.row)
        {
            var rows = this._get_owner().get_rows();
            var rowCount = rows.get_length();
            var startRow = rows.get_row(args.row.get_index() - 1);
            var rowSelector = startRow ? this.getSelectorFromRow(startRow) : null;
            var startIndex = args.row.get_index();
            var prevNum = rowSelector ? parseInt(rowSelector.firstChild && rowSelector.firstChild.tagName == "DIV" ? rowSelector.firstChild.innerHTML : rowSelector.innerHTML) : 0;
            var gridUtil = this._grid._gridUtil;
            for (var i = startIndex; i < rowCount; ++i)
            {
                var row = rows.get_row(i);
                var rowEl = row.get_element();

                var rowSelector = this.getSelectorFromRow(row);
                var num = parseInt(rowSelector.firstChild && rowSelector.firstChild.tagName == "DIV" ? rowSelector.firstChild.innerHTML : rowSelector.innerHTML);
                if (prevNum != null)
                {
                    if (num != prevNum + 1)
                    {
                        num = prevNum + 1;
                        if (rowSelector.firstChild && rowSelector.firstChild.tagName == "DIV")
                            rowSelector.firstChild.innerHTML = num;
                        else
                            rowSelector.innerHTML = num;
                    }
                }
                prevNum = num;

            }
        }
    },

	

	

	getSelectorFromRow: function (row)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.getSelectorFromRow">
		/// Returns the th element for a row selector for particular row.
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">The row to get the selector for.</param>
		/// <returns domElement="true"></returns>
		









		
		var elem = row.get_element();
		if (!elem)
			return null;
		var rowElementChildren = elem.childNodes;
		var count = rowElementChildren.length;
		for (var i = 0; i < count; i++)
		{
			var obj = rowElementChildren[i];
			if (obj && obj.tagName == "TH")
			{
				return obj;
			}
		}
		return null;
		
	},

	getSelectorFromElement: function (elem)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.getSelectorFromElement">
		/// Searches for a parent row selector element from a child element of the row selector.
		/// </summary>
		/// <param name="elem" domElement="true">A child element inside the row selector.</param>
		/// <returns domElement="true"></returns>
		if (elem.getAttribute && elem.getAttribute("chkState") != null)
			return null;
		var obj = $util.resolveMarkedElement(elem);
		if (obj !== null)
		{
			elem = obj[0];
			if (elem.getAttribute("type") == "selector")
				return elem;
		}
		return null;
	},

	addRowSelectorClickedEventHandler: function (handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.addRowSelectorClickedEventHandler">
		/// Listen for when the grid's row selectors are clicked. For internal use only. 
		/// </summary>
		/// <param name="handler" type="Function">Reference to the event handler.</param>
		/// <remarks>
		/// Handle the RowSelectorClicking or RowSelectorClicked clientside events on the control instead. 
		/// </remarks>
		this._grid._gridUtil._registerEventListener(this, "RowSelectorClicked", handler);
	},

	addSelectorImage: function (row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.addSelectorImage">
		/// Add a css class containing a new image to the row selector's image area. 
		/// </summary>
		/// <param name="row" type="GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
		/// <remarks>
		/// <p class="body">
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// </p>
		/// <p class="body">
		/// The images on the row selector are set using CSS classes. The classes will be applied to
		/// a div element inside the row selector. It's recommended that you don't set padding or borders in 
		/// your css or it will distort the width and height of the row selector. Your style will need to set an
		/// appropriate width and height to display the image.
		/// </p>
		/// <p class="body">
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </p>
		/// </remarks>
		//
		var selector = this.getSelectorFromRow(row);
		
		var selectorImage = selector ? selector.firstChild : null;
		if (!selectorImage || selectorImage.tagName != "DIV")
		{
			// create the image element
			selectorImage = document.createElement("div");

			// reparent all of selector's children
			while (selector.childNodes.length > 0)
				selectorImage.appendChild(selector.childNodes[0]);

			// add image to the selector
			selector.appendChild(selectorImage);
		}
		$util.addCompoundClass(selectorImage, cssClass);
	},

	removeSelectorImage: function (row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.removeSelectorImage">
		/// Remove a css class containing image information from the row selector's image area. 
		/// </summary>
		/// <param name="row" type="GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
		/// <remarks>
		/// <p class="body">
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// </p>
		/// </remarks>
		// 
		var selector = this.getSelectorFromRow(row);
		
		if (selector && selector.firstChild && selector.firstChild.tagName == "DIV")
			$util.removeCompoundClass(selector.firstChild, cssClass);
	},

	addSelectorClass: function (row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.addSelectorClass">
		/// Add a new css class to the row selector element.
		/// </summary>
		/// <param name="row" type="GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
		/// <remarks>
		/// <p class="body">
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// </p>
		/// <p class="body">
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </p>
		/// </remarks>
		//
		var selector = this.getSelectorFromRow(row);
		$util.addCompoundClass(selector, cssClass);
	},

	removeSelectorClass: function (row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.removeSelectorClass">
		/// Removes a css class from the row selector element
		/// </summary>
		/// <param name="row" type="GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
		/// <remarks>
		/// <p class="body">
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// </p>
		/// <p class="body">
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </p>
		/// </remarks>
		//
		var selector = this.getSelectorFromRow(row);
		$util.removeCompoundClass(selector, cssClass);
	},

	

	
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowSelectors.dispose">
		/// Disposes of the Row Selectors behavior.
		/// </summary>
		if (!this._grid)
			return;
		delete this._rowSelectedCellCount;
		delete this._rowNumbering;
		delete this._rowSelectorClass;
		this._owner._decrementCellIndexOffset();
		this._removeEventHandlers();
		this._grid._gridUtil._unregisterEventListener(this._grid, "SelectStartContainer", this._gridElementSelectStartHandler);
		this._gridElementSelectStartHandler = null;

		if (this._onDataBoundHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "DataBound", this._onDataBoundHandler);
			delete this._onDataBoundHandler;
		}
        
        if (this._insertRowSelectorIntoAddedRowHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "NewBatchRowBeforeCells", this._insertRowSelectorIntoAddedRowHandler);
		    this._insertRowSelectorIntoAddedRowHandler = null;
        }
        if (this._onBatchUpdateUndoneHandler)
        {
            this._grid._gridUtil._unregisterEventListener(this._grid, "BatchUpdateUndone", this._onBatchUpdateUndoneHandler);
		    this._onBatchUpdateUndoneHandler = null;
        }

		$IG.RowSelectors.callBaseMethod(this, "dispose");
	}
	

};
$IG.RowSelectors.registerClass('Infragistics.Web.UI.RowSelectors', $IG.GridBehavior, $IG.IRowSelectorsBehavior);



$IG.GridRowSelectorsProps = new function()
{
	this.Count = $IG.GridBehaviorProps.Count + 1;
};





$IG.RowSelectorClickingEventArgs = function(params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowSelectorClickingEventArgs">
	/// Event arguments object passed into the RowSelectorClicking event handler.
	/// </summary>
	$IG.RowSelectorClickingEventArgs.initializeBase(this);
	this._rowSelectorElement = params[0];
	this._row = params[1];
};
$IG.RowSelectorClickingEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowSelectorClickingEventArgs.row">
		/// Returns the row that the row selector belongs to.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_rowSelectorElement: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowSelectorClickingEventArgs.rowSelectorElement">
		/// Returns the row selector element that was clicked.
		/// </summary>
		/// <returns domElement="true"></returns>
		return this._rowSelectorElement;
	}
};
$IG.RowSelectorClickingEventArgs.registerClass('Infragistics.Web.UI.RowSelectorClickingEventArgs', $IG.CancelEventArgs);

$IG.RowSelectorClickedEventArgs = function(params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowSelectorClickedEventArgs">
	/// Event arguments object passed into the RowSelectorClicked event handler.
	/// </summary>
	$IG.RowSelectorClickedEventArgs.initializeBase(this);
	this._rowSelectorElement = params[0];
	this._row = params[1];
};
$IG.RowSelectorClickedEventArgs.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowSelectorClickedEventArgs.row">
		/// Returns the row that the row selector belongs to.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridRow"></value>
		return this._row;
	},
	get_rowSelectorElement: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowSelectorClickedEventArgs.rowSelectorElement">
		/// Returns the row selector element that was clicked.
		/// </summary>
		/// <returns domElement="true"></returns>
		return this._rowSelectorElement;
	}
};

$IG.RowSelectorClickedEventArgs.registerClass('Infragistics.Web.UI.RowSelectorClickedEventArgs', $IG.EventArgs);




$IG.MarginRowSelectorClickedEventArgs = function(params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.MarginRowSelectorClickedEventArgs">
	/// Event arguments object passed into the HeaderRowSelectorClicked and FooterRowSelectorClicked event handler.
	/// </summary>
	$IG.MarginRowSelectorClickedEventArgs.initializeBase(this);
	this._rowSelectorElement = params[0];
};
$IG.MarginRowSelectorClickedEventArgs.prototype =
{
	get_rowSelectorElement: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.MarginRowSelectorClickedEventArgs.rowSelectorElement">
		/// Returns the row selector element that was clicked.
		/// </summary>
		/// <returns domElement="true"></returns>
		return this._rowSelectorElement;
	}
};

$IG.MarginRowSelectorClickedEventArgs.registerClass('Infragistics.Web.UI.MarginRowSelectorClickedEventArgs', $IG.EventArgs);



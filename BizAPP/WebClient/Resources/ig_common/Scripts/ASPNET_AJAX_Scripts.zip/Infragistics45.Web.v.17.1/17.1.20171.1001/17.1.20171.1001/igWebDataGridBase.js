/*
* igWebDataGridBase.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/



$IG.BehaviorCollectionBase = function(control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.BehaviorCollectionBase">
	/// Base object for the behavior collections used in the grid.
	/// </summary>
	/// <param name="control" type="Infragistics.Web.UI.WebDataGrid">Reference to the owner control.</param>

	this._grid = control;
	this._behaviors = [];
}

$IG.BehaviorCollectionBase.prototype =
{
	get_grid: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.BehaviorCollectionBase.grid">
		///Returns the grid the collection belongs to.
		///</summary>
		/// <value type="Infragistics.Web.UI.WebDataGrid" />

		return this._grid;
	},

	add: function(behavior)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.BehaviorCollectionBase.add">
		/// Adds a behavior to the collection.
		/// </summary>
		/// <param name="behavior" type="Infragistics.Web.UI.GridBehavior">Behavior to add to the collection.</param>
		this._behaviors.push(behavior);
	},

	_initializeBehaviors: function()
	{
		if (!this._behaviors)
			return;

		for (var i = 0; i < this._behaviors.length; i++)
		{
			var behavior = this._behaviors[i];
			if (behavior)
			{
				behavior._parentCollection = this;
				if ($IG.IGridBehaviorContainer.isInstanceOfType(behavior))
				{
					var subBehCollection = behavior.get_behaviors();
					if (subBehCollection)
						subBehCollection._initializeBehaviors();
				}
			}
		}
	},

	getBehaviorByName: function(behaviorName)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.BehaviorCollectionBase.getBehaviorByName">
		/// Returns a behavior object with the name specified.
		/// </summary>
		/// <param name="behaviorName" type="String">Name of the behavior to get.</param>
		/// <returns type="Infragistics.Web.UI.GridBehavior"></returns>
		if (!behaviorName)
			return null;

		var behavior = null;
		for (var i = 0; i < this._behaviors.length; i++)
		{
			if (this._behaviors[i].get_name() == behaviorName)
			{
				behavior = this._behaviors[i];
				break;
			}
			if ($IG.IGridBehaviorContainer.isInstanceOfType(this._behaviors[i]))
			{
				behavior = this._behaviors[i].get_behaviors().getBehaviorByName(behaviorName);
				if (behavior != null)
					break;
			}
		}

		//if(behavior == null)
		//   behavior = new behaviorInterface();

		return behavior;
	},
	getBehaviorFromInterface: function(behaviorInterface)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.BehaviorCollectionBase.getBehaviorFromInterface">
		/// Returns a behavior object that implements provided interface.
		/// </summary>
		/// <param name="behaviorInterface">Reference to the interface type that a behavior implements.</param>
		/// <returns type="Infragistics.Web.UI.GridBehavior"></returns>
		if (!behaviorInterface)
			return null;

		var behavior = null;
		for (var i = 0; i < this._behaviors.length; i++)
		{
			if (behaviorInterface.isInstanceOfType(this._behaviors[i]))
			{
				behavior = this._behaviors[i];
				break;
			}
			if ($IG.IGridBehaviorContainer.isInstanceOfType(this._behaviors[i]))
			{
				behavior = this._behaviors[i].get_behaviors().getBehaviorFromInterface(behaviorInterface);
				if (behavior != null)
					break;
			}
		}

		//if(behavior == null)
		//   behavior = new behaviorInterface();

		return behavior;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.BehaviorCollectionBase.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		this._grid = null;
		$IG.BehaviorCollectionBase.callBaseMethod(this, "dispose");
	}

}
$IG.BehaviorCollectionBase.registerClass('Infragistics.Web.UI.BehaviorCollectionBase', $IG.ObjectBase);



$IG.GridBehavior = function(obj, objProps, control, parentCollection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridBehavior">
	/// Base object for the behaviors used in the grid.
	/// </summary>
	var props = objProps[0];
	var clientEvents = objProps[3];
	var csm = obj ? new $IG.ObjectClientStateManager(props) : null;
	$IG.GridBehavior.initializeBase(this, [obj, control._element, props, control, csm]);
	this._grid = this._owner;
	this._parentCollection = parentCollection;
	this._owner._initClientEventsForObject(this, clientEvents);
	this.__raiseClientEvent('Initialize');
}

$IG.GridBehavior.prototype =
{
	_initializeComplete: function()
	{

	},
	get_name: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehavior.name">
		/// Gets the name of the behavior.
		/// </summary>
		/// <value type="String" />
		return this._get_value($IG.GridBehaviorProps.Name);
	},

	









	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridBehavior.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		this._grid = null;
		this._parentCollection = null;
		$IG.GridBehavior.callBaseMethod(this, "dispose");
	},

	__raiseClientEvent: function(clientEventName, evntArgs, eventArgsParams)
	{
		var args = null;
		var grid = this._owner;
		var clientEvent = this._clientEvents[clientEventName];
		if (clientEvent != null)
		{
			if (evntArgs == null)
				args = new $IG.EventArgs();
			else
				args = new evntArgs(eventArgsParams);
			args = grid._raiseSenderClientEvent(this, clientEvent, args);
		}
		return args;
	},
	
	getEditingOn: function (exitEditing, update, getBehavior)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.getEditingOn">Gets flag which represents current editing behavior in progress with option to exit edit mode.</summary>
		/// <param name="exitEditing" type="Boolean" mayBeNull="true">Request to exit edit mode</param>
		/// <param name="update" type="Boolean" mayBeNull="true">Request to update data from editor(s) on exit edit mode</param>
		/// <param name="getBehavior" type="Boolean" mayBeNull="true">Request to return reference to behavior (instead of number-flag), which is still in edit mode</param>
		/// <returns type="Number" integer="true" mayBeNull="true">List of possible values: 1 - row-editing is on, 2 - row-edit-template is on, 3 - cell-editing is on, 4 - row-adding is on, 5 - filtering is on</returns>
		return this._grid && this._grid._gridUtil ? this._grid._gridUtil._checkEditing(exitEditing, update, getBehavior) : null;
	},

	_responseComplete: function(callbackObject, responseOptions)
	{
	}
}
$IG.GridBehavior.registerClass('Infragistics.Web.UI.GridBehavior', $IG.ObjectBase);



$IG.GridBehaviorProps = new function()
{
	var count = $IG.ObjectBaseProps.Count;
	this.Name = [count++, ''];
	//this.Enable = [count++, 0];
	this.Count = count;
};



$IG.IGridBehaviorContainer = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.IGridBehaviorContainer">
	/// Interface that indicates that the implementing object contains child behaviors.
	/// </summary>
};

$IG.IGridBehaviorContainer.prototype =
{
	_initializeBehaviors: function(behaviorProps, control, parentCollection, behaviorCount, behaviorStartIndex)
	{
		//
		if (!behaviorProps)
			return;
		
		var count = isNaN(parseInt(behaviorCount)) ? behaviorProps.length : behaviorCount;
		var startIndex = isNaN(parseInt(behaviorStartIndex)) ? 0 : behaviorStartIndex;
		count += startIndex;
		for (var i = startIndex; i < count; i++)
		{

			var objProps = behaviorProps[i];
			if (!objProps[0] || !objProps[0][0])
				continue;

			var objName = objProps[0][0][0];
			var propName = objName;

			if (propName == null || !propName.indexOf)
				continue;

			propName = "_" + propName.substr(0, 1).toLowerCase() + propName.substr(1, propName.length - 1);
			var behaviorCollection = this.get_behaviors();
			var behavior = behaviorCollection[propName] = this._createBehaviorObject(objName, i, objProps, control, parentCollection, this._hierarchical);
			behaviorCollection.add(behavior);
			this._objectsManager.register_object(i, behavior);
		}
		//this.get_behaviors()._initializeBehaviors();
	},
	_createBehaviorObject: function(objName, i, objProps, control, parentCollection)
	{
		/// <summary>
		/// Creates the beahvior object
		/// </summary>		
	},
	get_behaviors: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IGridBehaviorContainer.behaviors">
		/// Gets the child behavior collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.BehaviorCollectionBase" />
		throw "Not implemented: get_behaviors()!"
	}
};

$IG.IGridBehaviorContainer.registerInterface("Infragistics.Web.UI.IGridBehaviorContainer");



$IG.GridBehaviorContainer = function(obj, objProps, control, parentCollection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.GridBehaviorContainer">
	/// Base object for the behaviors that contain other child behaviors.
	/// </summary>
	this._initializeBehaviors = $IG.IGridBehaviorContainer.prototype._initializeBehaviors;	
	$IG.GridBehaviorContainer.initializeBase(this, [obj, objProps, control, parentCollection]);
}

$IG.GridBehaviorContainer.prototype =
{
	_createBehaviorObject: function(objName, i, objProps, control, parentCollection)
	{
		/// <summary>
		/// Gets the child behavior collection.
		/// </summary>
		return new $IG[objName]((objName + i), objProps, control, parentCollection, this._hierarchical);
	},
	_createObjects: function(objectsManager)
	{
		this._objectsManager = objectsManager;
		this._initializeBehaviors(objectsManager._objects, this._owner, this._owner.get_behaviors());
	},
	_behaviors: null,
	get_behaviors: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridBehaviorContainer.behaviors">
		/// Gets child behavior collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.BehaviorCollectionBase" />
		if (this._behaviors == null)
			this._behaviors = this._createBehaviorCollection();
		return this._behaviors;
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridBehaviorContainer.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		if (this._behaviors && this._behaviors._behaviors)
		{
			var behaviors = this._behaviors._behaviors;
			for (var i = 0; i < behaviors.length; i++)
			{
				behaviors[i].dispose();
			}
			this._behaviors.dispose();
		}
		this._objectsManager = null;
		$IG.GridBehaviorContainer.callBaseMethod(this, "dispose");
	},
	_createBehaviorCollection: function()
	{
		return null;
	}
}
$IG.GridBehaviorContainer.registerClass('Infragistics.Web.UI.GridBehaviorContainer', $IG.GridBehavior, $IG.IGridBehaviorContainer);



$IG.GridAction = function(type, ownerName, object, value, tag)
{
	///<summary locid="T:J#Infragistics.Web.UI.GridAction">Object contains info about an action that the grid is passing back to the server.</summary>
	///<param name="type" type="String">Type of the action.</param>
	///<param name="ownerName" type="String">Name of the object taht owns the action.</param>
	///<param name="object">Object that is associated with the action.</param>
	///<param name="value">A value that is associated with the action.</param>
	///<param name="tag">A tag that is associated with the action.</param>

	this.type = type;
	this.ownerName = ownerName;
	this._object = object;
	if (value)
		this._value = value;
	if (tag)
		this._tag = tag;
};

$IG.GridAction.prototype =
{
	type: "", 	// Type of action that is being performed
	ownerName: "", // Name of behavior, or empty if an action is performed by the grid itself
	_object: null, // Object the action is being performed on
	_value: null, 	// A value associated with the action
	_tag: null, 	// An extra value associated with the action
	_transactionList: null, // Reference back to the transaction list that owns the action
	_index: -1, 	// Index of the action inside of the transaction list
	get_action: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridAction.action">Returns the action as an array for serialization</summary>
		return { ownerName: this.ownerName, type: this.type, id: (this._object.get_idPair ? this._object.get_idPair() : null), value: this.get_value(), tag: this.get_tag() };
	},
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridAction.value">Returns a value associated with the action</summary>
		return this._value;
	},
	get_tag: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.GridAction.tag">Returns a tag associated with the action</summary>
		return this._tag;
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridAction.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		this._object = null;
		this._value = null;
		this._tag = null;
	}
}

$IG.GridAction.registerClass('Infragistics.Web.UI.GridAction');





$IG.GridActionTransactionList = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.GridActionTransactionList">List of grid transactions to pass back to the server.</summary>
	$IG.GridActionTransactionList.initializeBase(this);
	this._nextSlot = 0;
}
$IG.GridActionTransactionList.prototype =
{
	add_transaction: function(action, keepPrevious)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridActionTransactionList.add_transaction">Adds a transaction to the transaction list</summary>
		///<param name="action" type="Infragistics.Web.UI.GridAction">Action to add</param>
		///<param name="keepPrevious" type="Boolean" optional="true">Optional. Directs the list to keep previous action of the same type. If omitted previous action is removed.</param>

		if (typeof (keepPrevious) == "undefined")
			keepPrevious = false;
		if (!keepPrevious)
		{
			var prevAction = action._object["_action" + action.type]; // Previous action of the same type with the object
			if (prevAction && prevAction._transactionList == this)
				this.remove_transaction(prevAction); // Get rid of old action
		}

		action._transactionList = this;
		action._object["_action" + action.type] = action; // Let the object know of the action for future reference
		action._index = this._nextSlot;
		this._orderedList[this._nextSlot] = action;
		this._count++;
		





		this._nextSlot++;
	},

	remove_transaction: function(action)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridActionTransactionList.remove_transaction">Removes a transaction from the transaction list</summary>
		///<param name="action" type="Infragistics.Web.UI.GridAction">Action to remove</param>
		




		if (action)
		{
			delete action._object["_action" + action.type];
			delete this._orderedList[action._index];
			this._count--;
		}
	},

	clear: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridActionTransactionList.clear">Clears the transaction list</summary>
		for (var i in this._orderedList)
			if (!isNaN(parseInt(i)))
				this.remove_transaction(this._orderedList[i]);
	},

	get_value: function(action)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridActionTransactionList.value">Gets serialized object of the action.</summary>
		///<param name="action">Action get value of.</param>
		return action.get_action();
	},

	get_list: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridActionTransactionList.list">Converts the list into a flat array of serialized objects.</summary>
		///<returns type="Array"></returns>
		var list = [];
		var i = 0;
		for (var action in this._orderedList)
		{
			if (!isNaN(parseInt(action)))
				list[i++] = this._orderedList[action].get_action();
		}
		return list;
	},
	get_actionListForType: function(type)
	{
		///<summary locid="P:J#Infragistics.Web.UI.GridActionTransactionList.actionListForType">Selects only actions of specified type.</summary>
		///<param name="type" type="String">Type of the actions to select.</param>
		///<returns type="Array" elementType="Infragistics.Web.UI.GridAction">Array of the actions of specified type.</returns>
		var list = [];
		var i = 0;
		for (var action in this._orderedList)
		{
			if (!isNaN(parseInt(action)))
			{
				if (this._orderedList[action].type == type)
					list[i++] = this._orderedList[action];
			}
		}
		return list;
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridActionTransactionList.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		for (var i in this._orderedList)
		{
			if (!isNaN(parseInt(i)))
			{
				var action = this._orderedList[i];
				action._transactionList = null;
				if (action._object)
					action._object["_action" + action.type] = null;
				action.dispose();
			}
		}
	}
}

$IG.GridActionTransactionList.registerClass('Infragistics.Web.UI.GridActionTransactionList', $IG.TransactionListBase);




$IG.CancelBehaviorEventArgs = function(behavior)
{
	///<summary locid="T:J#Infragistics.Web.UI.CancelBehaviorEventArgs">
	///Base object for cancelable event arguments used in the grid behaviors.
	///</summary>
	$IG.CancelBehaviorEventArgs.initializeBase(this);
	this._context["behavior"] = behavior.get_name();
}
$IG.CancelBehaviorEventArgs.prototype =
{
	_context: {}
}
$IG.CancelBehaviorEventArgs.registerClass('Infragistics.Web.UI.CancelBehaviorEventArgs', $IG.CancelEventArgs);




$IG.IActivationBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IActivationBehavior">
	///Interface that identifies the activation behavior.
	///</summary>
};

$IG.IActivationBehavior.prototype =
{
	get_activeCell: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IActivationBehavior.activeCell">
		/// Returns/sets the Active cell in the WebDataGrid.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell" />
	},
	set_activeCell: function(cell, fireEvent)
	{
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell to activate.</param>
		///<param name="fireEvent" type="Boolean" optional="true">Optional. Indicates whether client events should be fired.</param>
	},
	_addActiveCellChangedEventHandler: function(handler)
	{
		/// <summary>
		/// Adds a listener to the active cell changed event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
	},
	_addActiveCellChangingEventHandler: function(handler)
	{
		/// <summary>
		/// Adds a listener to the active cell changing event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
	}
};

$IG.IActivationBehavior.registerInterface("Infragistics.Web.UI.IActivationBehavior");




$IG.IColumnMovingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IColumnMovingBehavior">
	///Interface that identifies the column moving.
	///</summary>
};

$IG.IColumnMovingBehavior.prototype =
{

};

$IG.IColumnMovingBehavior.registerInterface("Infragistics.Web.UI.IColumnMovingBehavior");


$IG.IColumnResizingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IColumnResizingBehavior">
	///Interface that identifies the column resizing.
	///</summary>
};

$IG.IColumnResizingBehavior.prototype =
{
};

$IG.IColumnResizingBehavior.registerInterface("Infragistics.Web.UI.IColumnResizingBehavior");




$IG.IEditingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IEditingBehavior">
	///Interface that identifies the editing behavior.
	///</summary>
};

$IG.IEditingBehavior.prototype =
{
	commit: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IEditingBehavior.commit">
		/// Causes the grid to commit changes to the server.
		/// </summary>
	}
};

$IG.IEditingBehavior.registerInterface("Infragistics.Web.UI.IEditingBehavior");





$IG.IUpdatingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IUpdatingBehavior">
	///Interface that identifies the updating behavior.
	///</summary>
};

$IG.IUpdatingBehavior.prototype =
{
	enterEditMode: function(cell)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IUpdatingBehavior.enterEditMode">
		/// Causes the grid to enter edit mode.
		/// </summary>
		/// <param name="cell" type="Infragistics.Web.UI.GridCell">The cell to enter edit mode.</param>
	},
	exitEditMode: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IUpdatingBehavior.exitEditMode">
		/// Causes the grid to exit edit mode.
		/// </summary>
	},
	get_isInEditMode: function(cell)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IUpdatingBehavior.isInEditMode">
		/// Gets a value that indicates whether the cell is in edit mode.
		/// </summary>
		/// <param name="cell" type="Infragistics.Web.UI.GridCell">WebDataGrid cell object.</param>
	},
	_addExitKeyHandledEventListener: function(handler)
	{
		/// <summary>
		/// Listen for when the grid leaves edit mode. For internal use only. 
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
	},
	_registerEditableRow: function(rowElement)
	{
	},

	_addEnteringEditEventListener: function(handler)
	{
		/// <summary>
		/// Adds a listener to the entering edit event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
	},
	_addExitedEditEventListener: function(handler)
	{
		/// <summary>
		/// Adds a listener to the exited edit event.
		/// </summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>
	}
};

$IG.IUpdatingBehavior.registerInterface("Infragistics.Web.UI.IUpdatingBehavior");





$IG.IRowAddingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IRowAddingBehavior">
	///Interface that identifies the editing behavior.
	///</summary>
};

$IG.IRowAddingBehavior.prototype =
{
	get_row: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IRowAddingBehavior.row">
		/// Gets a reference to the add new row object.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AddNewGridRow" />
	}
};

$IG.IRowAddingBehavior.registerInterface("Infragistics.Web.UI.IRowAddingBehavior");






$IG.IRowDeletingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IRowDeletingBehavior">
	///Interface that identifies the RowDeleting behavior.
	///</summary>
};

$IG.IRowDeletingBehavior.prototype =
{
	deleteRows: function(rows)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowDeletingBehavior.deleteRows">
		/// Takes a collection of rows and stores their row id pairs in an array
		/// which is handed off to the _deleteRows method for deletion.
		/// </summary>
		///<param name="rows" type="Array" elementType="Infragistics.Web.UI.GridRow">Collection of rows to be deleted.</param>
	}
};

$IG.IRowDeletingBehavior.registerInterface("Infragistics.Web.UI.IRowDeletingBehavior");





$IG.ISelectionBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.ISelectionBehavior">
	///Interface that identifies the selection behavior.
	///</summary>
};

$IG.ISelectionBehavior.prototype =
{
	get_selectedCells: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ISelectionBehavior.selectedCells">
		/// A collection of cells that are currently selected in the WebDataGrid. 
		/// To select a cell, use the Add method off of the Collection.
		/// To unselect a cell, use the Remove method off of the Collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridSelectedCellCollection" />
	},
	get_selectedRows: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ISelectionBehavior.selectedRows">
		/// A collection of rows that are currently selected in the WebDataGrid. 
		/// To select a row, use the Add method off of the Collection.
		/// To unselect a row, use the Remove method off of the Collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridSelectedRowCollection" />
	},
	get_selectedColumns: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ISelectionBehavior.selectedColumns">
		/// A collection of columns that are currently selected in the WebDataGrid. 
		/// To select a column, use the Add method off of the Collection.
		/// To unselect a column, use the Remove method off of the Collection.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridSelectedColumnCollection" />
	},
	addInternalColumnSelectionChangingHandler: function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ISelectionBehavior.addInternalColumnSelectionChangingHandler">An pre column selection changing event, for use by the column resizing so that I can stop the selection behavior
		/// from removing my selected columns when doing a resize
		///</summary>
		/// <param name="handler" type="Function">
		/// Reference to the new event handler.
		/// </param>

	}
};

$IG.ISelectionBehavior.registerInterface("Infragistics.Web.UI.ISelectionBehavior");





$IG.IRowSelectorsBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IRowSelectorsBehavior">
	///Interface that identifies the row selectors behavior.
	///</summary>
};

$IG.IRowSelectorsBehavior.prototype =
{
	addRowSelectorClickedEventHandler: function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowSelectorsBehavior.addRowSelectorClickedEventHandler">
		/// Listen for when the grid's row selectors are clicked. For internal use only. 
		/// </summary>
		/// <param name="handler" type="Function">Reference to the event handler.</param>
		/// <remarks>
		/// Handle the RowSelectorClicking or RowSelectorClicked clientside events on the control instead. 
		/// </remarks>
	},
	addSelectorImage: function(row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowSelectorsBehavior.addSelectorImage">
		/// Add a css class containing a new image to the row selector's image area. 
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// The images on the row selector are set using CSS classes. The classes will be applied to
		/// a div element inside the row selector. It's recommended that you don't set padding or borders in 
		/// your css or it will distort the width and height of the row selector. Your style will need to set an
		/// appropriate width and height to display the image.
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
	},
	removeSelectorImage: function(row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowSelectorsBehavior.removeSelectorImage">
		/// Remove a css class containing image information from the row selector's image area. 
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
	},
	addSelectorClass: function(row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowSelectorsBehavior.addSelectorClass">
		/// Add a new css class to the row selector element.
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
	},
	removeSelectorClass: function(row, cssClass)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.IRowSelectorsBehavior.removeSelectorClass">
		/// Removes a css class from the row selector element
		/// This method is designed for other behaviors to use. It shouldn't be necessary to use it 
		/// otherwise. 
		/// If mutiple css classes are applied, the resolution will be up to the browser depending on
		/// the order that the classes are declared in. 
		/// </summary>
		/// <param name="row" type="Infragistics.Web.UI.GridRow">Reference to the row.</param>
		/// <param name="cssClass" type="String">CSS class name.</param>
	}
};

$IG.IRowSelectorsBehavior.registerInterface("Infragistics.Web.UI.IRowSelectorsBehavior");





$IG.IPagingBehavior = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IPagingBehavior">
	///Interface that identifies the paging behavior.
	///</summary>
};

$IG.IPagingBehavior.prototype =
{
	get_pageIndex: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IPagingBehavior.pageIndex">
		/// Gets current page index. 
		/// </summary>
		/// <value type="Number" integer="true" />
	},
	get_pageSize: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.IPagingBehavior.pageSize">
		/// Gets page size. 
		/// </summary>
		/// <value type="Number" integer="true" />
	}
};

$IG.IPagingBehavior.registerInterface("Infragistics.Web.UI.IPagingBehavior");





$IG.IColumnSettings = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.IColumnSettings">
	///Interface that identifies a behavior with column settings collection.
	///</summary>
};

$IG.IColumnSettings.prototype =
{
	get_columnSettings: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.IColumnSettings.columnSettings">
		///Gets a reference to the column settings collection.
		///</summary>
		///<value type="Infragistics.Web.UI.ObjectCollection" elementType="Infragistics.Web.UI.ColumnSetting" />
	}
};

$IG.IColumnSettings.registerInterface("Infragistics.Web.UI.IColumnSettings");




$IG.ColumnSetting = function(adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnSetting">
	/// Object that defines a column setting for a grid behavior.
	/// </summary>
	$IG.ColumnSetting.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.ColumnSetting.prototype =
{
	get_columnKey: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ColumnSetting.columnKey">
		/// Gets the key of the column the setting is attached to.
		/// </summary>
		/// <value type="String" />
		return this._get_clientOnlyValue('ck');
	}
}
$IG.ColumnSetting.registerClass('Infragistics.Web.UI.ColumnSetting', $IG.ObjectBase);



$IG.ColumnSettingProps = new function()
{
	this.Count = $IG.ObjectBaseProps.Count;
};



$IG.IDPair = function(index, key)
{
	///<summary locid="T:J#Infragistics.Web.UI.IDPair">Uniquely identifies a data object in the grid</summary>
	///<field name="index" type="Number" integer="true">Index of a data object within its collection.</field>
	///<field name="key" type="Array">Data key of the object.</field>

	if (typeof (index) != "undefined")
		this.index = index;
	if (typeof (key) != "undefined" && key !== null)
	{// Make the key an array even if it's a single value
		// That is to always account for the compound data key
		if (typeof (key) == "string")
			this.key = key.split(",");
		else if (key.length)
			this.key = key;
		else
			this.key = [key];
	}
};

$IG.IDPair.prototype =
{
	index: -1,
	key: []//Key is always presumed to be compound
}

//$IG.IDPair.registerClass('Infragistics.Web.UI.IDPair');



$IG.GridUtility = function(gridObj)
{
	///<summary locid="T:J#Infragistics.Web.UI.GridUtility">
	///Grid's utility object. Contains helper methods to work with the grid.
	///</summary>
	this._grid = gridObj;
};

$IG.GridUtility.prototype =
{
	scrollCellIntoViewIE: function (cell, noFocus, extraLeft)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.scrollCellIntoViewIE">Scrolls a cell into view in the Internet Explorer browser.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell to bring into view.</param>
		///<param name="noFocus" type="Boolean" optional="true" mayBeNull="true">True: do not set focus to cell</param>

		var elem = cell.get_element();
		var row = cell.get_row();
		var scrollContainer = this._grid._elements["container"];
		var scrollLeft = scrollContainer.scrollLeft, contWidth = scrollContainer.offsetWidth;
		var oldLeft = scrollLeft;
		var left = elem.offsetLeft, width = elem.offsetWidth;

	    
	    // N.R. April 2nd, 2015 Bug #186547: When the grid is scrolled down by tab( or Enter) key the grid scrolls some lines and sometimes the focus leaves from the grid with Google Chrome.
		if ($util.IsOpera || $util.IsChrome)
		{
			var topFix = this._grid._marginTop;
			var scrollTop = scrollContainer.scrollTop - topFix;
			var height = scrollContainer.offsetHeight;
			var bottom = scrollTop + height;
			var cellBottom = elem.offsetTop + elem.offsetHeight;
			var vScrBar = this._grid._elements["vScrBar"];
			
			

			if (!this._grid._isAuxRow(row) && vScrBar && (elem.offsetHeight > bottom ||
						cellBottom < scrollTop ||
						elem.offsetTop <= bottom && cellBottom > bottom ||
						elem.offsetTop <= scrollTop && cellBottom >= scrollTop
						))
			{
				scrollTop = cellBottom - height + topFix;
				vScrBar.scrollTop = scrollTop;
			}
		}
		
		if (left + width > scrollLeft + contWidth)
		{
			scrollLeft = left + width - contWidth;
			
			if ($util.IsSafari)
				scrollLeft += width;
		}
		
		if (left < scrollLeft)
		{
			scrollLeft = left;
			
			if ($util.IsSafari) if ((scrollLeft -= width) < 0)
				scrollLeft = 0;
		}
		
		var cont = row ? row._container : null;
		
		if (!$util.IsIE11Plus)
		{
			
			
			this._noScrollTime = (new Date()).getTime();
			this._noScrollLeft = scrollLeft;
		}

		
		if ($util.IsIE7 && extraLeft)
			this._noScrollLeft += extraLeft;

		
		if (oldLeft != scrollLeft)
		{
			scrollContainer.scrollLeft = scrollLeft;
			

			if (($util.IsIE || $util.IsFireFox) && this._grid.get_rows().get_length() == 0)
			{
				if (this._grid._hScrBar)
					this._grid._hScrBar.scrollLeft = scrollLeft;
			}
		}
		if (!noFocus) try
		{
			if (document.hasFocus && !document.hasFocus())
			{
				setTimeout(function ()
				{
					try
					{
						elem.focus();
					} catch (ex) { }
				}, 0);
			}
			else
				elem.focus();
		}
		catch (row) { }
		
		if (cont && cont.scrollLeft > 0)
			cont.scrollLeft = 0;
		
		
		if ($util.IsSafari && oldLeft != scrollLeft)
			scrollContainer.scrollLeft = scrollLeft;
	},

	findRowIndexByCellElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.findRowIndexByCellElem">Returns a row's index from an element.</summary>
		///<param name="elem" domElement="true">Dom element that corresponds to a row.</param>
		///<returns type="Number" integer="true" mayBeNull="true">Index of the row that corresponds to the element, or Null.</returns>

		var obj = $util.resolveMarkedElement(elem.parentNode);
		if (obj)
		{
			var type = obj[0].getAttribute("type");
			if (type == "row")
				return obj[1];
		}
		return null;
	},

	getRowFromCellElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getRowFromCellElem">Returns a row object from a cell element.</summary>
		///<param name="elem" domElement="true">Dom element that corresponds to a grid cell.</param>
		///<returns type="Infragistics.Web.UI.GridRow" mayBeNull="true">Row object that correspond to the cell element, or null.</returns>

		var parentRow = elem.parentNode;
		while (parentRow && (parentRow.tagName != "TR" || !$util._getXAttr(parentRow) || ($util._isXAttrContains(parentRow, "filterRowLeft") || $util._isXAttrContains(parentRow, "filterRowRight") ||
			$util._isXAttrContains(parentRow, "addNewRowLeft") || $util._isXAttrContains(parentRow, "addNewRowRight"))))
			parentRow = parentRow.parentNode;
		var obj = null;
		if (parentRow)
			obj = $util.resolveMarkedElement(parentRow);
		if (obj)
		{
			var elem = obj[0];
			var type = elem.tagName; //.getAttribute("type");
			return this._getRowFromCellElem(obj, elem, type);
		}
		return null;
	},
	_convertServerDateStringToClientObject: function (dateValue)
	{
		if (dateValue)
		{
			var dateParams = dateValue.split("~");
			if (dateParams.length == 7)
				return dateValue = new Date(parseInt(dateParams[0]), parseInt(dateParams[1]) - 1, parseInt(dateParams[2]), parseInt(dateParams[3]), parseInt(dateParams[4]), parseInt(dateParams[5]), parseInt(dateParams[6]));
		}
		return null;
	},
	_convertClientDateToServerString: function (date)
	{
		var dateString = "";
		
		if (date != null && typeof (date) == "string" && date != "")
			date = new Date(date);
		
		if (date != null && !isNaN(date) && typeof (date) == "object" && typeof (date.getMonth) != "undefined")
		{
			dateString += date.getFullYear().toString();
			dateString += "~" + (date.getMonth() + 1).toString();
			dateString += "~" + date.getDate().toString();
			dateString += "~" + date.getHours().toString();
			dateString += "~" + date.getMinutes().toString();
			dateString += "~" + date.getSeconds().toString();
			dateString += "~" + date.getMilliseconds().toString();
		}
		return dateString;
	},
	_addTimeToDateObjectIfMissing: function (textEditorValue, dateEditorValue) {
	    var result = textEditorValue;

	    // Compare if date values are equal, if so just move on and do nothing
	    if (!this._valuesAreEqual(textEditorValue, dateEditorValue)) {
	        // Compare if only the date values (without hours, minutes and seconds) are equal, if so go ahead and return the date editor value
	        // Date editor value is returned because it contains the whole date object, with the hours, minutes and seconds
	        if (textEditorValue instanceof Date && dateEditorValue instanceof Date && this._valuesAreEqual(textEditorValue.format("d"), dateEditorValue.format("d"))) {
	            if (this._valuesAreEqual(textEditorValue.format("HH:mm:ss"), "00:00:00")) {
	                result = dateEditorValue;
	            }
	        }
	    }
        
	    return result;
	},
	_getRowFromCellElem: function (obj, elem, type)
	{
		if (type == "TR")
		{
			var index = parseInt(obj[1]);
			if (!isNaN(index))
			{
				var auxRow = elem.getAttribute("auxRow");
				if (auxRow !== null)
					return this._grid._get_auxRows(auxRow)[index];
				else
					return this._grid.get_rows().get_row(index);
			}
			else
			{

				if (elem._object != null)
				{
					return elem._object;
				}
			}
		}
	},
	getCellFromElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getCellFromElem">Resolvse a TD element and returns corresponding grid cell object.</summary>
		///<param name="elem" domElement="true">TD element to resolve.</param>
		///<returns type="Infragistics.Web.UI.GridCell" mayBeNull="true" />
		
		var args = { "elem": elem };
		this._fireEvent(this._grid, "ResolvingCellElem", args);
		elem = args.elem;
		var obj = $util.resolveMarkedElement(elem);
		if (obj != null)
		{
			elem = obj[0];
			var type = elem.getAttribute("type");
			if (type == "cell")
			{
				var row = this.getRowFromCellElem(elem);
				if (row)
					return row.get_cell(obj[1]);
			}
		}
		return null;
	},

	getCellIndexFromElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getCellIndexFromElem">Resolvse a TD element and returns corresponding grid cell index.</summary>
		///<param name="elem" domElement="true">TD element to resolve.</param>
		///<returns type="Number" integer="true">Index of the grid cell that corresponds to the passed in TD.</returns>
		return this.getCellIndex(elem) - this._grid._get_cellIndexOffset();
	},

	getCellIndex: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getCellIndex">Returns DOM cell index. The method is browser independent.</summary>
		///<param name="elem" domElement="true">TD element to resolve.</param>
		///<returns type="Number" integer="true">Index of the DOM cell.</returns>
		var cellIndex = elem.cellIndex;
		if ($util.IsIE && !$util.IsIEStandards)
		{
			var parentNode = elem.parentNode;
			cellIndex = 0;
			while (cellIndex < parentNode.childNodes.length && parentNode.childNodes[cellIndex] != elem) cellIndex++;
		}
		return cellIndex;
	},

	getCellElemFromIndex: function (row, index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getCellElemFromIndex">Returns DOM cell element by its row and index.</summary>
		///<param name="row" type="Infragistics.Web.UI.GridRow">Row object to get a cell off.</param>
		///<param name="index" type="Number" integer="true">Index of the cell to seek.</param>
		///<returns domElement="true" mayBeNull="true">DOM cell that corresponds to the passed index.</returns>
		return row._get_cellElementByIndex(row.get_element(), index + this._grid._get_cellIndexOffset());
	},

	isVisibleCell: function (cell)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.isVisibleCell">Determines whether a cell is in a visible container.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell object to determine visibility of.</param>
		///<returns type="Boolean">True if the cell is in a visible container.</returns>
		if (cell)
		{
			var elem = cell.get_element();
			
			var currentStyle = elem ? $util.getRuntimeStyle(elem) : null;
			if (elem && currentStyle && currentStyle.display != "none" && currentStyle.visibility != "hidden" && elem.offsetWidth > 0)
				return true;
		}
		return false;
	},

	getFirstVisualRow: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getFirstVisualRow">Gets first visible row in the grid. This row may be an add new row, filter row, or a regular data row.</summary>
		///<returns type="Infragistics.Web.UI.GridRow" mayBeNull="true"></returns>
		var rows = this._grid._get_auxRows($IG.GridAuxRows.Top);
		var row = null;
		if (rows && rows.length > 0)
		{
			row = rows[0];
		}
		else
		{
			rows = this._grid.get_rows();
			row = (rows.get_length() > 0) ? rows.get_row(0) : null;
		}

		if (!row)
		{

			rows = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
			row = (rows && rows.length > 0) ? rows[0] : null;
		}
		return row;
	},
	getLastVisualRow: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getLastVisualRow">Gets last visible row in the grid. This row may be an add new row, filter row, or a regular data row.</summary>
		///<returns type="Infragistics.Web.UI.GridRow" mayBeNull="true"></returns>
		var rows = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
		var row = null;
		if (rows && rows.length > 0)
		{
			row = rows[rows.length - 1];
		}
		else
		{
			rows = this._grid.get_rows();
			row = (rows.get_length() > 0) ? rows.get_row(rows.get_length() - 1) : null;
		}

		if (!row)
		{

			rows = this._grid._get_auxRows($IG.GridAuxRows.Top);
			row = (rows && rows.length > 0) ? rows[rows.length - 1] : null;
		}
		return row;
	},

	getNextCell: function (cell)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getNextCell">Gets next cell object in the tab order.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell object to get the next one of.</param>
		///<returns type="Infragistics.Web.UI.GridCell" mayBeNull="true">Next cell object or null if no cells are available after the current one.</returns>
		if (!cell)
			return cell;
		var cellIndex = cell.get_index();
		var visibleIndex = this._grid.get_columns().get_column(cellIndex).get_visibleIndex();
		var row = cell.get_row();
		




		if (visibleIndex == row.get_cellCount() - 1)
		{
			var visCol = this._findFirstVisibleColumn();
			var rows = this._grid.get_rows();
			if (this._grid._isAuxRow(row))
			{
				var auxAlign = (this._grid._isAuxRow(row, $IG.GridAuxRows.Top) ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom);
				var auxRows = this._grid._get_auxRows(auxAlign);
				var index = this._grid._get_auxRowIndex(row, auxAlign);
				if (!visCol)
					return null;
				if (index < auxRows.length - 1)
				{
					
					var nextCell = auxRows[index + 1].get_cell(visCol.get_index());
					if (this.isVisibleCell(nextCell))
						return nextCell;
					return this.getNextCell(nextCell);
				}
				else if (auxAlign == $IG.GridAuxRows.Top)
				{
					if (rows.get_length() > 0)
					{
						
						var nextCell = rows.get_row(0).get_cell(visCol.get_index());
						if (this.isVisibleCell(nextCell))
							return nextCell;
						return this.getNextCell(nextCell);
					}
					else
					{
						

						var auxRowsBottom = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
						if (auxRowsBottom && auxRowsBottom.length > 0)
						{
							
							var nextCell = auxRowsBottom[0].get_cell(visCol.get_index());
							if (this.isVisibleCell(nextCell))
								return nextCell;
							return this.getNextCell(nextCell);
						}
					}
				}

			}
			else
			{
				var rowIndex = row.get_index();
				if (rowIndex != rows.get_length() - 1)
				{
					var nextRow = rows.get_row(rowIndex + 1);
					if (nextRow != null && visCol)
					{
						
						var nextCell = nextRow.get_cell(visCol.get_index());
						if (this.isVisibleCell(nextCell))
							return nextCell;
						return this.getNextCell(nextCell);
					}
				}
				else
				{
					var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
					if (auxRows && auxRows.length && visCol)
					{
						
						var nextCell = auxRows[0].get_cell(visCol.get_index());
						if (this.isVisibleCell(nextCell))
							return nextCell;
						return this.getNextCell(nextCell);
					}
				}
			}
		}
		else
		{
			var nextCell = row.get_cell(this._getColumnAdrFromVisibleIndex(visibleIndex + 1));
			if (this.isVisibleCell(nextCell))
				return nextCell;
			return this.getNextCell(nextCell);
		}
	},
	getNextCellVert: function (cell)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getNextCellVert">Gets the cell object below.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell object to get the next one of.</param>
		///<returns type="Infragistics.Web.UI.GridCell" mayBeNull="true">Cell object that is below the current one or null if no cells are available below.</returns>
		var row = cell.get_row();
		var rowIndex = row.get_index();
		var rows = this._grid.get_rows();
		if (this._grid._isAuxRow(row))
		{
			var auxAlign = (this._grid._isAuxRow(row, $IG.GridAuxRows.Top) ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom);
			var auxRows = this._grid._get_auxRows(auxAlign);
			var index = this._grid._get_auxRowIndex(row, auxAlign);
			if (index < auxRows.length - 1)
				return auxRows[index + 1].get_cell(cell.get_index());
			else if (auxAlign == $IG.GridAuxRows.Top)
			{
				if (rows.get_length() > 0)
					return rows.get_row(0).get_cell(cell.get_index());
				else
				{
					

					var auxRowsBottom = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
					if (auxRowsBottom && auxRowsBottom.length > 0)
						return auxRowsBottom[0].get_cell(cell.get_index());
				}
			}
		}
		else
		{
			if (rowIndex < rows.get_length() - 1)
			{
				var nextRow = rows.get_row(rowIndex + 1)
				if (nextRow != null)
					return nextRow.get_cell(cell.get_index());
			}
			else
			{
				var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Bottom);
				if (auxRows && auxRows.length)
					return auxRows[0].get_cell(cell.get_index());
			}
		}

	},
	getPrevCell: function (cell)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getPrevCell">Gets previous cell object in the tab order.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell object to get the previous one of.</param>
		///<returns type="Infragistics.Web.UI.GridCell" mayBeNull="true">Previous cell object or null if no cells are available before the current one.</returns>
		if (!cell)
			return cell;
		var cellIndex = cell.get_index();
		var visibleIndex = this._grid.get_columns().get_column(cellIndex).get_visibleIndex();
		var row = cell.get_row();
		if (visibleIndex == 0)
		{
			var rows = this._grid.get_rows();
			var nextRow = null;
			if (this._grid._isAuxRow(row))
			{
				var auxAlign = (this._grid._isAuxRow(row, $IG.GridAuxRows.Top) ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom);
				var auxRows = this._grid._get_auxRows(auxAlign);
				var index = this._grid._get_auxRowIndex(row, auxAlign);
				if (index > 0)
					nextRow = auxRows[index - 1];
				else if (auxAlign == $IG.GridAuxRows.Bottom)
				{
					if (rows.get_length() > 0)
						nextRow = rows.get_row(rows.get_length() - 1);
					else
					{
						

						var auxRowsTop = this._grid._get_auxRows($IG.GridAuxRows.Top);
						if (auxRowsTop && auxRowsTop.length > 0)
							nextRow = auxRowsTop[auxRowsTop.length - 1];
					}

				}
			}
			else
			{
				var rowIndex = row.get_index();
				if (rowIndex != 0)
					nextRow = rows.get_row(rowIndex - 1)
				else
				{
					var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Top);
					if (auxRows && auxRows.length)
						nextRow = auxRows[auxRows.length - 1];
				}
			}
			if (nextRow != null)
			{
				




				
				var prevCell = nextRow.get_cell(this._findLastVisibleColumn().get_index());
				if (this.isVisibleCell(prevCell))
					return prevCell;
				return this.getPrevCell(prevCell);
			}
		}
		else
		{
			var prevCell = row.get_cell(this._getColumnAdrFromVisibleIndex(visibleIndex - 1)); ;
			if (this.isVisibleCell(prevCell))
				return prevCell;
			return this.getPrevCell(prevCell);
		}
	},
	getPrevCellVert: function (cell)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getPrevCellVert">Gets the cell object above.</summary>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">Cell object to get the previous one of.</param>
		///<returns type="Infragistics.Web.UI.GridCell" mayBeNull="true">Cell object that is above the current one or null if no cells are available above.</returns>
		var row = cell.get_row();
		var rowIndex = row.get_index();
		var rows = this._grid.get_rows();
		if (this._grid._isAuxRow(row))
		{
			var auxAlign = (this._grid._isAuxRow(row, $IG.GridAuxRows.Top) ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom);
			var auxRows = this._grid._get_auxRows(auxAlign);
			var index = this._grid._get_auxRowIndex(row, auxAlign);
			if (index > 0)
				return auxRows[index - 1].get_cell(cell.get_index());
			else if (auxAlign == $IG.GridAuxRows.Bottom)
			{
				if (rows.get_length() > 0)
					return rows.get_row(rows.get_length() - 1).get_cell(cell.get_index());
				else
				{
					

					var auxRowsTop = this._grid._get_auxRows($IG.GridAuxRows.Top);
					if (auxRowsTop && auxRowsTop.length > 0)
						return auxRowsTop[auxRowsTop.length - 1].get_cell(cell.get_index());
				}
			}
		}
		else
		{
			if (rowIndex != 0)
			{
				var nextRow = this._grid.get_rows().get_row(rowIndex - 1)
				if (nextRow != null)
					return nextRow.get_cell(cell.get_index());
			}
			else
			{
				var auxRows = this._grid._get_auxRows($IG.GridAuxRows.Top);
				if (auxRows && auxRows.length)
					return auxRows[auxRows.length - 1].get_cell(cell.get_index());
			}
		}
	},

	getCellIDPairFromElem: function (element)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getCellIDPairFromElem">Gets Infragistics.Web.UI.CellIDPair identificator of the cell that corresponds to the cell DOM element.</summary>
		///<param name="element" domElement="true">Cell element to get the ID of.</param>
		///<returns type="Infragistics.Web.UI.CellIDPair" mayBeNull="true">Cell ID or null if the element does not belong to the grid.</returns>
		var row = this.getRowFromCellElem(element);
		if (row)
		{
			var column = this._grid.get_columns().get_column(this.getCellIndexFromElem(element));
			if (column)
				return new $IG.CellIDPair(row.get_idPair(), column.get_idPair());
		}
		return null;
	},

	getNextRow: function (element)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getNextRow">Gets next DOM element row.</summary>
		///<param name="element" domElement="true" optional="true">DOM element of a row in the grid. This is an optional parameter. If no parameters are passed in the first row element is returned.</param>
		///<returns domElement="true" mayBeNull="true">Next row element or nul if no more rows available.</returns>
		var rows = this._grid._elements.dataTbl.rows;
		if (!element)
			return rows[0];

		if (element.rowIndex == rows.length - 1)
			return null;

		return rows[element.rowIndex + 1];
	},

	getPrevRow: function (element)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getPrevRow">Gets previous DOM element row.</summary>
		///<param name="element" domElement="true" optional="true">DOM element of a row in the grid. This is an optional parameter. If no parameters are passed in the last row element is returned.</param>
		///<returns domElement="true" mayBeNull="true">Previous row element or nul if no more rows available.</returns>
		var rows = this._grid._elements.dataTbl.rows;
		if (!element)
			return rows[rows.length - 1];

		if (element.rowIndex == 0)
			return null;

		return rows[element.rowIndex - 1];
	},
	_getPreviousRenderedHeaderLayoutColumn: function (column)
	{
		var index = column.get_visibleIndex() - 1;
		if (index < 0)
			return null;
		var columns = this._get_HeaderLayoutCollection(this._grid.get_headerColumnsLayout(), column);
		for (var i = 0; columns && i < columns.length; i++)
		{
			var column = columns[i];
			if (column.get_visibleIndex() == index)
				return column;
		}
		return null;

	},
	_get_topLevelHeaderLayoutColumn: function (key)
	{
		var headerLayoutColumn = this._get_HeaderLayoutColumnFromKey(key);
		var columnOwner = headerLayoutColumn;
		while (columnOwner._get_parent() != this._grid)
			columnOwner = columnOwner._get_parent();
		return columnOwner;
	},
	_get_HeaderLayoutCollection: function (columns, column)
	{
		for (var i = 0; i < columns.length; i++)
		{
			if (column == columns[i])
				return columns;
			if (columns[i].get_isGroupField())
			{
				var foundCollection = this._get_HeaderLayoutCollection(columns[i].get_columns(), column);
				if (foundCollection)
					return foundCollection;
			}
		}
		return null;
	},
	
	_get_HeaderLayoutColumnFromElem: function (elem)
	{
		var e = elem;
		while (e && e.tagName && (e.tagName != "TH" || !e.getAttribute("key")))
			e = e.parentNode;
		if (e && e.tagName && e.tagName == "TH" && e.getAttribute("key"))
			return this._get_HeaderLayoutColumnFromKey(e.getAttribute("key"));
		return null;
	},

	_isTopLevelHeaderLayoutColumn: function (key)
	{
		var columns = this._grid.get_headerColumnsLayout();
		for (var i = 0; i < columns.length; i++)
		{
			if (key == columns[i].get_key())
				return true;
		}
		return false;
	},
	_get_HeaderLayoutColumnFromKey: function (key)
	{
		return this.__get_HeaderLayoutColumnFromKey(this._grid.get_headerColumnsLayout(), key);
	},
	__get_HeaderLayoutColumnFromKey: function (columns, key)
	{
		for (var i = 0; i < columns.length; i++)
		{
			if (key == columns[i].get_key())
				return columns[i];
			if (columns[i].get_isGroupField())
			{
				var foundCol = this.__get_HeaderLayoutColumnFromKey(columns[i].get_columns(), key);
				if (foundCol)
					return foundCol;
			}
		}
		return null;
	},

	__get_firstVisibleDataColumn: function (groupedField, accountForHidden)
	{
		var dataColumns = groupedField._get_allDataColumn();
		var dataColumn = dataColumns[0];
		if (!accountForHidden && dataColumn.get_hidden())
		{
			var j = 0;
			while (dataColumn.get_hidden() && j < dataColumns.length)
			{
				j++;
				dataColumn = dataColumns[j];
			}
		}
		var vsIndex = dataColumn.get_visibleIndex();
		for (var i = 0; i < dataColumns.length; i++)
		{
			if (dataColumns[i].get_visibleIndex() < vsIndex && (accountForHidden || !dataColumns[i].get_hidden()))
			{
				vsIndex = dataColumns[i].get_visibleIndex();
				dataColumn = dataColumns[i];
			}
		}
		return dataColumn;
	},
	__get_lastVisibleDataColumn: function (groupedField, accountForHidden)
	{
		var dataColumns = groupedField._get_allDataColumn();
		var dataColumn = dataColumns[0];
		if (!accountForHidden && dataColumn.get_hidden())
		{
			var j = 0;
			while (dataColumn.get_hidden() && j < dataColumns.length)
			{
				j++;
				dataColumn = dataColumns[j];
			}
		}
		var vsIndex = dataColumn.get_visibleIndex();
		for (var i = 0; i < dataColumns.length; i++)
		{
			if (dataColumns[i].get_visibleIndex() > vsIndex && (accountForHidden || !dataColumns[i].get_hidden()))
			{
				vsIndex = dataColumns[i].get_visibleIndex();
				dataColumn = dataColumns[i];
			}
		}
		return dataColumn;
	},
	getHeaderFromElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getHeaderFromElem">Gets header object from a TH DOM element.</summary>
		///<param name="elem" domElement="true">DOM element of a column header.</param>
		///<returns type="Infragistics.Web.UI.GridColumnCaption" mayBeNull="true">Header object for the passed in TH DOM element.</returns>
		var e = elem;
		while (e && e.tagName && (e.tagName != "TH" || !e.getAttribute("adr")))
			e = e.parentNode;
		if (e && e.tagName && e.tagName == "TH" && e.getAttribute("adr"))
		{
			var columns = this._grid.get_columns();
			for (var i = 0; i < columns.get_length(); i++)
			{
				var column = columns.get_column(i);
				var headerElement = column.get_headerElement();
				if (!headerElement)
					return null;
				if (e == headerElement)
					return column.get_header();
			}
		}
		return null;
	},

	getFooterFromElem: function (elem)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.getFooterFromElem">Gets footer object from a TH DOM element.</summary>
		///<param name="elem" domElement="true">DOM element of a column footer.</param>
		///<returns type="Infragistics.Web.UI.GridColumnCaption" mayBeNull="true">Footer object for the passed in TH DOM element.</returns>
		var e = elem;
		while (e && e.tagName && (e.tagName != "TH" || !e.getAttribute("adr")))
			e = e.parentNode;
		if (e && e.tagName && e.tagName == "TH" && e.getAttribute("adr"))
		{
			var columns = this._grid.get_columns();
			for (var i = 0; i < columns.get_length(); i++)
			{
				var column = columns.get_column(i);
				var footerElement = column.get_footerElement();
				if (!footerElement)
					return null;
				if (e == footerElement)
					return column.get_footer();
			}
		}
		return null;
	},

	_getVisibleIndexOfLastVisibleColumn: function ()
	{
		var columns = this._grid.get_columns();
		var index = -1;
		for (var i = 0; i < columns.get_length(); i++)
		{
			var column = columns.get_column(i);
			if (column && !column.get_hidden() && index < column.get_visibleIndex())
				index = column.get_visibleIndex();
		}
		return index;
	},

	_getVisibleIndexOfFirstVisibleColumn: function ()
	{
		var columns = this._grid.get_columns();
		var index = columns.get_length(); ;
		for (var i = 0; i < columns.get_length(); i++)
		{
			var column = columns.get_column(i);
			if (column && !column.get_hidden() && index > column.get_visibleIndex())
				index = column.get_visibleIndex();
		}
		return index;
	},

	_registerEventListener: function (obj, evntName, listener, priority)
	{
		if (obj._internalEventListeners == null)
			obj._internalEventListeners = {};
		if (obj._internalEventListeners[evntName] == null)
			obj._internalEventListeners[evntName] = [];

		if (priority)
			obj._internalEventListeners[evntName].unshift(listener);
		else
			obj._internalEventListeners[evntName].push(listener);
	},

	_fireEvent: function (obj, evntName, args)
	{
		if (obj._internalEventListeners == null)
			return;

		var listeners = obj._internalEventListeners[evntName];
		if (listeners != null && listeners.length > 0)
		{
			for (var i = 0; i < listeners.length; i++)
				if (listeners[i](args))
					return true;
		}
		return false;
	},

	_unregisterEventListener: function (obj, evntName, listener)
	{
		if (obj._internalEventListeners == null)
			return;

		var listeners = obj._internalEventListeners[evntName];
		if (listeners != null && listeners.length > 0)
		{
			for (var i = 0; i < listeners.length; i++)
			{
				if (listeners[i] == listener)
				{
					Array.removeAt(obj._internalEventListeners[evntName], i);
					return;
				}
			}
		}
	},

	areIdPairsEqual: function (idPair1, idPair2)
	{
		///<summary locid="M:J#Infragistics.Web.UI.GridUtility.areIdPairsEqual">Determines whether two IDPairs are equal.</summary>
		///<param name="idPair1" type="Infragistics.Web.UI.IDPair">First IDPair to compare.</param>
		///<param name="idPair2" type="Infragistics.Web.UI.IDPair">Second IDPair to compare.</param>
		///<returns type="Boolean">True if the IDPairs are equal.</returns>
		if (!idPair1 || !idPair2)
			return false;

		if (!(idPair1.key == null && idPair2.key == null))
		{
			if (idPair1.key.length != idPair2.key.length)
				return false;

			for (var i = 0; i < idPair1.key.length; i++)
				if (idPair1.key[i] != idPair2.key[i])
					return false;
		}

		if (idPair1.index != idPair2.index)
			return false;

		return true;
	}
	,
	_get_gridWidth: function ()
	{
		return $util.getRuntimeStyle(this._grid._element).width;
	},
	_get_containerTableWidth: function ()
	{
		return $util.getRuntimeStyle(this._grid._elements.dataTbl).width;
	},
	_get_containerTableWidthResolved: function ()
	{
		return this._grid._elements.dataTbl.offsetWidth;
	},
	_set_containerTableWidth: function (value)
	{
		this._grid._elements.dataTbl.style.width = value;
	},
	_getColumnFromHeader: function (headerElem)
	{
		if (!headerElem)
			return null;
		var adr = headerElem.getAttribute("adr");
		var isGroupFields = headerElem.getAttribute("grpFld");
		if (isGroupFields || adr < 0 || adr >= this._grid.get_columns().get_length()) return null;
		return this._grid.get_columns().get_column(adr);
	},
	_getColumnFromVisibleIndex: function (index)
	{
		var column = null;
		var columns = this._grid.get_columns();
		for (var i = 0; i < columns.get_length() && !column; i++)
		{
			if (columns._items[i]._visibleIndex == index)
				column = columns.get_column(i);
		}
		return column;
	},
	_getColumnAdrFromVisibleIndex: function (index)
	{
		var column = null;
		var columns = this._grid.get_columns();
		for (var i = 0; i < columns.get_length() && !column; i++)
		{
			if (columns._items[i]._visibleIndex == index)
				column = columns.get_column(i);
		}
		if (column)
			return column.get_index();
		return null;
	},
	_findLastVisibleColumn: function ()
	{
		var column = null;
		var index = null;
		var columns = this._grid.get_columns();
		for (var i = 0; i < columns.get_length(); i++)
		{
			if (index == null || columns._items[i]._visibleIndex > index)
			{
				var col = columns.get_column(i);
				if (!col.get_hidden())
				{
					index = col._visibleIndex;
					column = col;
				}
			}
		}
		return column;
	},
	_findFirstVisibleColumn: function ()
	{
		var column = null;
		var index = null;
		var columns = this._grid.get_columns();
		for (var i = 0; i < columns.get_length(); i++)
		{
			if (index == null || columns._items[i]._visibleIndex < index)
			{
				var col = columns.get_column(i);
				if (!col.get_hidden())
				{
					index = col._visibleIndex;
					column = col;
				}
			}
		}
		return column;
	},
	_getPreviousRenderedColumn: function (column)
	{
		var index = column.get_visibleIndex() - 1;
		if (index < 0)
			return null;
		var columns = this._grid.get_columns();
		for (var i = 0; i < columns.get_length(); i++)
		{
			var column = columns.get_column(i);
			if (column.get_visibleIndex() == index)
				return column;
		}

	},
	_getGridCellFromElement: function (element)
	{
		while (element && (element.tagName != "TD" && element.tagName != "TH" || !$util._isXAttrContains(element.parentNode, "adr") && element.parentNode.getAttribute("adr") === null)) //TH for row selectors
			element = element.parentNode;
		return element;
	},
	_appendCssClasses: function (styleString)
	{
		if (!styleString) return;
		var styleSheet = this._grid.__findIgStyleSheet(); ;
		
		if (!styleSheet)
			return;
		



		this._grid._removeExistingStyleRules(styleSheet, styleString);

		if (typeof (styleSheet.insertRule) != "undefined")
		{
			var styles = styleString.split("\r\n");
			for (var i = 0; i < styles.length; i++)
			{
				

				var styleSheetLength = styleSheet.cssRules ? styleSheet.cssRules.length : styleSheet.rules.length;
				if (styles[i]) styleSheet.insertRule(styles[i], styleSheetLength);
			}
		}
		else
			styleSheet.cssText += styleString;
	},

	_addStyleToRow: function (rowElem, cssClass)
	{
		$util.addCompoundClass(rowElem, cssClass);
	},
	_removeStyleFromRow: function (rowElem, cssClass)
	{
		$util.removeCompoundClass(rowElem, cssClass);
	},

	_valuesAreEqual: function (val1, val2)
	{
		return val1 && val2 && val1.valueOf && val2.valueOf ? val1.valueOf() == val2.valueOf() : val1 == val2;
	},
	_adjustMergingCellValueChanged: function (cell, mergeClassBase)
	{
		var mergedSpot;
		if (mergedSpot = cell._mergedSpot)
		{
			var row = cell.get_row(), index = row.get_index(), thisVal = cell.get_value(), nextRow, nextCell, nextVal, merge = -1;
			if (mergedSpot != "top")
			{
				nextCell = this._grid.get_rows().get_row(index - 1).get_cell(cell.get_index());
				nextVal = nextCell.get_value();
				if (this._valuesAreEqual(thisVal, nextVal))
					merge++;
			}
			nextRow = this._grid.get_rows().get_row(index + 1);
			if (nextRow)
			{
				nextCell = nextRow.get_cell(cell.get_index());
				nextVal = nextCell.get_value();
				if (this._valuesAreEqual(thisVal, nextVal))
					merge += 2;
			}
			if (merge > -1)
				this._reMergeForCell(cell, mergeClassBase, merge);
		}
		else
			this._splitMergingForCell(cell, mergeClassBase);
	},
	_splitMergingForCell: function (cell, mergeClassBase)
	{
		var rowObj = cell.get_row(), index = rowObj.get_index(), isTop, isBottom, otherCell;
		isTop = cell.get_element().className.indexOf(mergeClassBase + "Top") > -1;
		isBottom = cell.get_element().className.indexOf(mergeClassBase + "Bottom") > -1;
		if (isTop)
			cell._mergedSpot = "top";
		else if (isBottom)
			cell._mergedSpot = "bottom";
		else
			cell._mergedSpot = "middle";
		if (!isTop)
		{
			$util.addCompoundClass(cell.get_element(), mergeClassBase + "Top");
			if (index > 0)
			{
				var prevRow = this._grid.get_rows().get_row(index - 1);
				otherCell = prevRow.get_cell(cell.get_index());
				if (otherCell.get_element().className.indexOf(mergeClassBase + "Top") == -1)
					$util.addCompoundClass(otherCell.get_element(), mergeClassBase + "Bottom");
			}
		}
		if (!isBottom && index < this._grid.get_rows().get_length() - 1)
		{
			var nextRow = this._grid.get_rows().get_row(index + 1);
			otherCell = nextRow.get_cell(cell.get_index());
			if (otherCell.get_element().className.indexOf(mergeClassBase + "Top") == -1)
			{
				$util.addCompoundClass(otherCell.get_element(), mergeClassBase + "Top");
				if (otherCell.get_element().className.indexOf(mergeClassBase + "Bottom") > -1)
				{
					$util.removeCompoundClass(otherCell.get_element(), mergeClassBase + "Bottom");
					otherCell._removedBottom = true;
				}
			}
		}
		else
			$util.removeCompoundClass(cell.get_element(), mergeClassBase + "Bottom");
	},
	_reMergeForCell: function (cell, mergeClassBase, direction)
	{
		var rowObj = cell.get_row(), index = rowObj.get_index(), isTop, isBottom, otherCell;
		if (direction == undefined)
			direction = 2;
		isTop = cell._mergedSpot == "top";
		isBottom = cell._mergedSpot == "bottom";
		delete cell._mergedSpot;
		if (direction % 2 == 0)
		{
			$util.removeCompoundClass(cell.get_element(), mergeClassBase + "Top");
			if (index > 0)
			{
				var prevRow = this._grid.get_rows().get_row(index - 1);
				otherCell = prevRow.get_cell(cell.get_index());
				$util.removeCompoundClass(otherCell.get_element(), mergeClassBase + "Bottom");
			}
		}
		if (direction > 0)
		{
			var nextRow = this._grid.get_rows().get_row(index + 1);
			otherCell = nextRow.get_cell(cell.get_index());
			$util.removeCompoundClass(otherCell.get_element(), mergeClassBase + "Top");
			if (otherCell._removedBottom)
			{
				$util.addCompoundClass(otherCell.get_element(), mergeClassBase + "Bottom");
				delete otherCell._removedBottom;
			}
		}
		else
			$util.addCompoundClass(cell.get_element(), mergeClassBase + "Bottom");
	},
	_checkEditing: function (exitEditing, update, getBehavior)
	{
	    // K.D. September 5th, 2014 Bug #180040 When moving a column in child grid for second time the column doesn't move
	    if (!this._grid) {
	        return false;
	    }
		var flag, grid = this._grid, main = (grid._get_mainGrid ? grid._get_mainGrid() : null) || grid, editing = grid._re_obj || main._re_obj;
		if (editing)
			flag = 1;
		else
		{
			editing = grid._lastRETGridBehavior || main._lastRETGridBehavior;
			if (editing)
				flag = 2;
		}
		if (!flag && grid._cellInEditMode)
		{
			var behaviors = grid.get_behaviors();
			editing = behaviors.get_filtering();
			if (editing && editing.get_cellInEditMode())
				flag = 5;
			else
			{
				behaviors = behaviors.get_editingCore();
				behaviors = behaviors ? behaviors.get_behaviors() : null;
				if (behaviors)
				{
					editing = behaviors.get_cellEditing();
					if (editing && editing.get_cellInEditMode())
						flag = 3;
					else
					{
						editing = behaviors.get_rowAdding();
						if (editing && editing.get_cellInEditMode())
							flag = 4;
					}
				}
			}
		}
		if (!flag)
			return;
		if (exitEditing)
		{
			editing.exitEditMode(!!update);
			return this._checkEditing(null, null, getBehavior);
		}
		return getBehavior ? editing : flag;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.GridUtility.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		this._grid = null;
	}
};
$IG.GridUtility.registerClass("Infragistics.Web.UI.GridUtility");




$IG.EditorProvider = function(adr, elem, props, owner, csm, dataType)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EditorProvider">
	/// Base class for all editor providers in the grid.
	/// </summary>
	var input = elem;
	var grid = owner;
	if (!elem)
	{
		if (grid._editorProvidersPool)
		{
			var id = grid._element.id + "_" + adr;
			elem = document.getElementById(id);
			var nodes = elem ? elem.childNodes : null;
			for (var i = 0; nodes && i < nodes.length; i++)
			{
				input = nodes[i];
				if (input.nodeName == "INPUT")
					break;
			}
			if (input)
				this._dataType = input._dataType;
			else
			{
				elem = document.createElement('DIV');
				

				grid._editorProvidersPool.appendChild(elem);
				elem.id = id;
				if ($util.IsSafari)
					elem.style.position = "absolute";
				$util.display(elem, true);
				input = document.createElement('INPUT');
				input.alt = 'grid editor';
				elem.appendChild(input);
				input.style.outline = 'none';
				
				if (dataType == 14)
					input.maxLength = 1;
				input._dataType = this._dataType = dataType;
			}
		}
	}
	else
	{
		

		if ($util.IsSafari && elem.nodeName == 'DIV')
			elem.style.position = "absolute";
		
		
		var nodes = elem.childNodes;
		var i = -1, len = nodes ? nodes.length : 0;
		if (len > 5)
			len = 5;
		while (++i < len)
		{
			var n = nodes[i];
			if (n.nodeName == 'TEXTAREA' || (n.nodeName == 'INPUT' && n.type == 'text'))
				input = n;
		}
	}
	$IG.EditorProvider.initializeBase(this, [adr, elem, props, owner, csm]);
	if (elem)
	{
		elem.control = this;
		this._input = input;
	}
}
$IG.EditorProvider.prototype =
{
	get_inputElement: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditorProvider.inputElement">
		/// Gets a reference to the input HTML element if it exists in the editor. 
		/// Returns first child of the main element.
		/// Can be overriden by the inherited provider if the input element is not the first child.
		/// </summary>
		return this._input;
	},
	get_value: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditorProvider.value">
		/// Gets/sets value to/from the editor. 
		/// </summary>
		/// <value type="Object"></value>
		var elem = this.get_inputElement();
		return elem ? elem.value : null;
	},
	set_value: function (val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditorProvider.value">Sets initial value in editor.</summary>
		/// <param name="val" type="Object">Value for editor.</param>

		this._input.value = (val == null ? '' : val);
		
		this._defEditor = true;
	},
	get_text: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.EditorProvider.text">
		/// Gets formatted text from the editor. 
		/// </summary>
		/// <value type="String">Current text in editor.</value>

		

	},
	showEditor: function (top, left, width, height, cssClass, parent, cell)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditorProvider.showEditor">
		/// Shows and positions the editor. 
		/// </summary>
		///<param name="top" type="Number" integer="true">
		///Top coordinate of the editor in pixels.
		///</param>
		///<param name="left" type="Number" integer="true">
		///Left coordinate of the editor in pixels.
		///</param>
		///<param name="width" type="Number" integer="true">
		///Width of the editor in pixels.
		///</param>
		///<param name="height" type="Number" integer="true">
		///Height of the editor in pixels.
		///</param>
		///<param name="cssClass" type="String">
		///Optional. CSS class to apply to the editor's main HTML element.
		///</param>
		///<param name="parent" domElement="true">
		///Parent HTML element if the editor needs to be reparented.
		///</param>
		///<param name="cell" type="Infragistics.Web.UI.GridCell">
		///Cell object of grid.
		///</param>

		var fix = 0, cont = this._owner, holder = parent;
		
		if (parent == cont._container)
		{
			if (!(holder = cont._poolHolder))
			
				holder = parent;
			
			else if (cont._get_level && $util.IsIE)
			{
				var dad = holder.parentNode;
				dad.removeChild(holder);
				dad.insertBefore(holder, dad.firstChild);
			}
		}
		
		var rowEditing = this._owner ? this._owner._re_obj : null;
		if (rowEditing)
		{
			rowEditing._showEditor(this, top, left, width, height, cssClass, parent, cell);
			return;
		}
		
		var x = parent.scrollLeft, y = parent.scrollTop, cWidth = parent.clientWidth, cHeight = parent.clientHeight;
		
		
		if (cell && cell._row && cell._row._container == parent)
		{
			
			if (cont)
				cont = cont._container;
			if (cont)
				fix = cont.scrollLeft;
			
			
			if (fix == 0)
			{
				cont = cell._element;
				if (cont)
					cont = cont.parentNode.parentNode.parentNode;
				
				
				if (cont && !($util.IsFireFox || $util.IsOpera))
					fix = -cont.offsetLeft;
			}
			
			if ($util.IsIE && !$util.IsIEStandards)
				x = fix;
			else
				left -= fix;
		}
		else
		{
			
			top += this._owner._marginTop - y;
		}
		if (!x) x = 0;
		if (!y) y = 0;
		if (!cWidth || cWidth < 5)
			cWidth = parent.offsetWidth;
		if (!cHeight || cHeight < 5)
			cHeight = parent.offsetHeight;
		
		
		
		
		var i = 0, tr = parent;
		
		while (i++ < 4 && tr && tr.nodeName != 'TR')
			tr = tr.parentNode;
		
		this._offsetTop = (tr && i < 4) ? tr.offsetTop : 20;
		
		this._x = x;
		
		this._cWidth = cWidth;
		
		this._cHeight = cHeight;
		
		i = this._owner._element.offsetHeight - this._offsetTop - cHeight;
		
		if (i > 1)
			this._cHeight += i;
		
		if (x > left)
		{
			width += left - x;
			
			if (width < 5)
				width = 5;
			left = x;
		}
		
		if (left + width > x + cWidth)
		{
			width = x + cWidth - left;
			
			if (width < 5)
			{
				left += width - 5;
				width = 5;
			}
		}
		
		cont = this._owner._level && this._owner._get_mainGrid ? this._owner._get_mainGrid() : null;
		if (cont)
		{
			// right edge of main grid
			// cell._leftShift is calculated within $IG.Filtering._enteringEditMode()
			// (cell._leftShift ? 2 : 1) adjust for borders
			var right = $util.getLocation(cont._element).x + cont._element.offsetWidth + (cell._leftShift ? 2 : 1);
			// left edge of cell/editor
			x = $util.getLocation(cell._element).x + (cell._leftShift || 0);
			if (x + width > right)
				width = Math.max(right - x, 5);
		}
		
		if (top < 0)
		{
			height += top;
			
			if (height < 5)
				height = 5;
			top = 0;
		}
		
		if (top + height > cHeight)
		{
			height = cHeight - top;
			
			if (height < 5)
			{
				top += height - 5;
				height = 5;
			}
		}
		this._show(top, left, width, height, cssClass, holder, cell);
	},
	_show: function (top, left, width, height, cssClass, parent, cell)
	{
		var input = this.get_inputElement();
		this._setBounds(top, left, height, this._element.style, parent, cell);
		this._setCss(input, cssClass);
		var style = input.style;
		style.height = height + 'px';
		style.width = width + 'px';
		var diff = input.offsetWidth - width;
		if (diff != 0) if ((width -= diff) > 2)
			style.width = width + 'px';
		diff = input.offsetHeight - height;
		if (diff != 0) if ((height -= diff) > 2)
			style.height = height + 'px';
		this._focus(input);
		if (this._defEditor)
			this._firstKey(this._charKey);
		this._addHandlers();
	},
	
	_firstKey: function (key)
	{
		var elem = this._input, tr = this._tr;
		if (!key || !elem)
			return;
		if (!tr)
		{
			try
			{
				if (elem.selectionStart != null)
					tr = 1;
			} catch (val) { }
			if (tr != 1)
				tr = (elem.createTextRange != null) ? elem.createTextRange() : null;
			this._tr = tr;
			if (!tr)
				return;
		}
		elem.value = String.fromCharCode(key);
		if (tr == 1)
		{
			elem.selectionStart = elem.selectionEnd = 1;
			return;
		}
		tr.move('textedit', -1);
		tr.move('character', 1);
		tr.moveEnd('character', 1);
		tr.select();
	},
	_focus: function (elem, rowEdit)
	{
		
		if (!rowEdit && this._owner && this._owner._re_obj)
			return;
		
		
		
		
		
		var tb = elem.nodeName == 'TEXTAREA';
		if (($util.IsIE && !$util.IsIE11Plus) || !this._charKey) try
		{
			if (elem.type == 'text' || tb)
				elem.select();
		} catch (e) { }
		if (!$util.IsIE || $util.IsIE11Plus || !tb) try
		{
			elem.focus();
			
			
			if ($util.IsIE11Plus && !this._charKey)							
				window.setTimeout(function () { try { elem.focus(); elem.select(); } catch (e) { } }, 0);			
		} catch (e) { }
	},
	_getWrapper: function (elem, css)
	{
		
		var wrapper = this._shared ? this._element : this._wrapper;
		if (!wrapper)
		{
			
			if (elem.parentNode && elem.parentNode.hasAttribute && elem.parentNode.hasAttribute("_wrapper"))
				wrapper = this._wrapper = elem.parentNode;
			else
			{
				wrapper = this._wrapper = document.createElement('DIV');
				var container = elem.parentNode;
				container.removeChild(elem);
				container.appendChild(wrapper);
				wrapper.setAttribute("_wrapper", 1);
				wrapper.appendChild(elem);
			}
		}
		this._setCss(wrapper, css);
		return wrapper;
	},
	_setCss: function (elem, css)
	{
		var css0 = elem.className;
		if (css && css0.indexOf(css) < 0)
		{
			if (css0 && css0.length > 0)
				css += ' ' + css0;
			elem.className = css;
		}
	},
	
	_addHandlers: function ()
	{
		var input = this.get_inputElement();
		if (!input || this._hasLsnr)
			return;
		if (!this._onBlurFn)
		{
			this._onBlurFn = Function.createDelegate(this, this._onBlurHandler);
			this._onKeyFn = Function.createDelegate(this, this._onKeyDownHandler);
		}
		this._hasLsnr = true;
		$addHandler(input, 'blur', this._onBlurFn);
		$addHandler(input, 'keydown', this._onKeyFn);
	},
	
	_removeHandlers: function ()
	{
		if (this._hasLsnr)
		{
			var input = this.get_inputElement();
			
			
			
			if (input._events)
			{
				



				try
				{
					if (this._onBlurFn)
						$removeHandler(input, 'blur', this._onBlurFn);
					if (this._onKeyFn)
						$removeHandler(input, 'keydown', this._onKeyFn);
				}
				catch (ex) { }
			}
		}
		this._hasLsnr = false;
	},
	_rtl: function (grid, parent)
	{
		if (!grid || !grid._rtl)
			return;
		var td, n, i, fix, nodes, pool = grid._editorProvidersPool, par = pool.parentNode;
		// find TD container of DIV-pool and TABLE-edit-target
		if (par.nodeName == "TD")
			td = par;
		else if (par.parentNode.nodeName == "TD")
			td = par.parentNode;
		else
			return;
		// find container/table for cell-editors
		nodes = td.childNodes;
		i = nodes.length;
		while (i-- > 0)
		{
			n = nodes[i];
			if (n != pool && n != par)
			// restore rtl, because parent TD will lose it
				fix = n.style.direction = "rtl";
		}
		// find container/table for add-row-editors
		nodes = parent.childNodes;
		i = nodes.length;
		if (i < 3) while (i-- > 0)
		{
			n = nodes[i];
			if (n != pool && n != par)
			// restore rtl, because parent TD will lose it
				fix = n.style.direction = "rtl";
		}
		if (fix)
		{
			// disable rtl for TD parent of pool/editors and TABLE of grid
			td.style.direction = "ltr";
			// find all actual elements used by editor
			nodes = this._element.childNodes;
			i = nodes.length;
			while (i-- > 0)
				if (nodes[i].style)
				// restore rtl for actual editors
					nodes[i].style.direction = "rtl";
		}
	},
	
	
	
	
	
	
	
	_setBounds: function (top, left, height, style, parent, cell, elem)
	{
		
		var cellObj = cell, rowEditing = this._owner ? this._owner._re_obj : null;
		if (this._owner && !rowEditing)
			this._owner._ensureEditorProvidersPool(parent);
		this._rtl(this._owner, parent);
		
		style.display = '';
		style.visibility = 'visible';
		
		var tblHeight = 0, tblWidth = 0, editorHeight = height;
		if (cell)
			cell = cell._element;
		if (cell)
		{
			
			tblHeight = this._cHeight;
			
			tblWidth = this._x + this._cWidth;
		}
		
		var aboveBelow = 0;
		if (elem)
		{
			editorHeight = elem.offsetHeight;
			var tr = cell ? cell.parentNode : null;
			
			
			if (tr)
				aboveBelow = tr.getAttribute('mkr');
			
			
			if (aboveBelow == 'addNewRow')
				aboveBelow = (tr.className.indexOf('RowTop') > 0) ? 1 : -1;
			else if (aboveBelow == 'filterRow')
				aboveBelow = (tr.className.indexOf('RowBottom') > 0) ? -1 : 1;
			
			else
				aboveBelow = 0;
			
			if (aboveBelow < 0)
				top -= editorHeight;
			
			else
				top += height;
			if (!rowEditing && tblHeight > 9)
			{
				
				var shiftBot = tblHeight - top - editorHeight;
				
				if (aboveBelow == 0 && shiftBot < 0)
				{
					
					var y = -this._offsetTop;
					
					var shiftTop = top - y - height - editorHeight;
					
					if (shiftTop > shiftBot)
						top = shiftTop + y;
					else
						top += shiftBot;
					
					if (top < y)
						top = y;
				}
				
				var editorWidth = elem.offsetWidth;
				if (editorWidth < 5)
					if ((editorWidth = elem.firstChild.offsetWidth) < 5)
						editorWidth = 5;
				
				if (left + editorWidth > tblWidth)
				
					left = tblWidth - editorWidth;
				
				if (left < this._x)
					left = this._x;
			}
		}
		this._fixValidator(top, editorHeight, tblHeight, rowEditing ? rowEditing._validatorPos : null);
		
		
		
		var div = true;
		
		if (Sys.Browser.agent == Sys.Browser.Safari || $util.IsIEStandards || $util.IsOpera)
		
			while (true)
			{
				if (div)
				{
					top -= parent.scrollTop;
					left -= parent.scrollLeft;
				}
				if (!(parent = parent.parentNode))
					break;
				var tag = parent.nodeName;
				if (tag == 'BODY' || tag == 'FORM' || tag == 'HTML')
					break;
				div = tag == 'DIV';
				if (div || tag == 'TABLE' || tag == 'SPAN')
				{
					var pos = $util.getStyleValue(null, 'position', parent);
					if (pos == 'relative' || pos == 'absolute')
						break;
				}
			}

		style.marginTop = top + 'px';
		style.marginLeft = left + 'px';
		
		style.zIndex = 1000;
		
		style.color = 'black';
		this._element.className = "";
		if (cellObj && rowEditing)
			rowEditing._setBounds(this, cellObj, height);
	},
	
	
	
	_fixValidator: function (top, height, tblHeight, pos)
	{
		var validator = this._validator, elem = this._element;
		var style = validator ? validator.style : null;
		if (!style)
			return;
		var nodes = elem.childNodes, i = -1;
		
		while (++i < nodes.length)
			if (nodes[i] == validator)
				break;
		
		if (i == nodes.length)
		{
			validator.parentNode.removeChild(validator);
			elem.insertBefore(validator, elem.firstChild);
			style.position = 'absolute';
			style.left = style.top = style.marginTop = '';
		}
		
		
		
		var mt = pos == -2 ? 0 : validator.offsetHeight;
		if (pos == 1 || pos == -1 || (!pos && (tblHeight < 10 || top + height + mt < tblHeight || top < mt)))
			mt = height + 1 + (pos == -1 ? -mt : 1);
		else
			mt = -(mt + 2);
		style.marginTop = mt + 'px';
		
		//if (pos && pos < 0 && $util.toInt($util.getStyleValue(null, 'zIndex', validator), 0) < 1)
		//	style.zIndex = 10000;
	},
	
	_areEqual: function (val1, val2)
	{
		if (val1 == val2)
			return true;
		if (val1 && val2 && val1.getTime && val2.getTime)
			return val1.getTime() == val2.getTime();
		return false;
	},
	notifyLostFocus: function (e)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditorProvider.notifyLostFocus">
		/// The method is called whenever the editor loses focus. 
		/// </summary>
		/// <param name="e" type="Sys.UI.DomEvent">
		/// Event object associated with the event that triggered losing focus by the editor.
		/// </param>
	},
	hideEditor: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditorProvider.hideEditor">
		/// Hides the editor. 
		/// </summary>
		var elem = this._element;
		if (!elem)
			return;
		this._removeHandlers();
		$util.display(elem, true);
		var parent = elem._oldParent;
		if (parent && parent != elem.parentNode)
		{
			
			
			
			
			
			
			
			
			elem._oldParent_IEBug = true;
			this._owner = null;
		}
	},
	dispose: function (edit)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EditorProvider.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		






		this.hideEditor();
		var elem = this._element;
		
		
		
		
		var parent = elem ? elem._oldParent : null;
		if (parent)
		{
			
			this._element = null;
			
			
			if (edit != 2)
				return;
		}
		
		else if (this._editor && typeof this._editor.dispose == "function")
		{
			
			this._input = null;
			if (elem)
				elem.control = null;
			this._editor.dispose();
		}
		this._tr = this._input = this._editor = this._wrapper = null;
		$IG.EditorProvider.callBaseMethod(this, 'dispose');
	},
	_getExitEditModeOnEnter: function ()
	{
		return this._get_value([1, 1]) !== 0;
	},
	_onKeyDownHandler: function (e)
	{
		var key = e.keyCode;
		if (key == Sys.UI.Key.tab || key == Sys.UI.Key.esc || (key == Sys.UI.Key.enter && !e.shiftKey && !e.ctrlKey && this._getExitEditModeOnEnter()))
			this.notifyLostFocus(e);
	},
	_onBlurHandler: function (e)
	{
		
		
		var start = this._startTime;
		
		var rowEditing = this._owner ? this._owner._re_obj : null;
		if (rowEditing)
			rowEditing._validate(this);
		
		if (!e || e.type != 'blur' || !start || start + ($util.IsIE8 ? 200 : 100) < new Date().getTime())
			this.notifyLostFocus(e);
	},
	_get_outOfBouns: function ()
	{
		return false;
	}
}
$IG.EditorProvider.registerClass('Infragistics.Web.UI.EditorProvider', $IG.ObjectBase);




$IG.IHeaderButton = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.IHeaderButton">
	///Interface that identifies the behavior a behavior with header button.
	///</summary>
};

$IG.IHeaderButton.prototype =
{
};

$IG.IHeaderButton.registerInterface("Infragistics.Web.UI.IHeaderButton");





$IG.RowUpdateType = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.RowUpdateType">The type of row update operation.</summary>
	///<field name="Edit" type="Number" integer="true" static="true">The update operation was editing of cell values.</field>
	///<field name="Delete" type="Number" integer="true" static="true">The update operation was deletion of a row.</field>
	///<field name="Add" type="Number" integer="true" static="true">The udpate operation was addition of a row.</field>
};
$IG.RowUpdateType.prototype =
{
	Edit: 0,
	Delete: 1,
	Add: 2
};
$IG.RowUpdateType.registerEnum("Infragistics.Web.UI.RowUpdateType");

$IG.RowUpdateStatus = function ()
{
	///<summary locid="T:J#Infragistics.Web.UI.RowUpdateType">The update status assigned to a row.</summary>
	///<field name="Edited" type="Number" integer="true" static="true">A row has updated values.</field>
	///<field name="Deleted" type="Number" integer="true" static="true">A row is marked for deletion.</field>
	///<field name="Added" type="Number" integer="true" static="true">Marks a row as to be added to the DataSource.</field>
	///<field name="AddedButDeleted" type="Number" integer="true" static="true">Marks a row as deleted that was newly added.</field>
};
$IG.RowUpdateStatus.prototype =
{
	Edited: 1,
	Deleted: 2,
	Added: 3,
	AddedButDeleted: 4
};
$IG.RowUpdateStatus.registerEnum("Infragistics.Web.UI.RowUpdateStatus");


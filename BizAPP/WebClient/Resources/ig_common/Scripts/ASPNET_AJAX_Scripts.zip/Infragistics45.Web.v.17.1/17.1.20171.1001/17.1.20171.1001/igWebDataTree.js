/*
* igWebDataTree.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/




Type.registerNamespace('Infragistics.Web.UI');


$IG.DataTreeProps = new function()
{
	this.CollapsedIndicatorImageUrl     =[$IG.NavControlProps.Count + 0, ""];
	this.DataLoadingMessage             =[$IG.NavControlProps.Count + 1, ""];
	this.EnableAjax                     =[$IG.NavControlProps.Count + 2, ""];
	this.EnableConnectorLines           =[$IG.NavControlProps.Count + 3, 0];
	this.Enabled                        =[$IG.NavControlProps.Count + 4, 0];
	this.EnableExpandImages             =[$IG.NavControlProps.Count + 5, true];
	this.EnableExpandOnClick            =[$IG.NavControlProps.Count + 6, false];
	this.ExpandedIndicatorImageUrl      =[$IG.NavControlProps.Count + 7, ""];
	this.NodeDataMessage                =[$IG.NavControlProps.Count + 8, ""];
	this.EnableDropInsertion            =[$IG.NavControlProps.Count + 9, true];
	this.DragDropMode                   =[$IG.NavControlProps.Count + 10, 3];
	this.NodeSelectionType              =[$IG.NavControlProps.Count + 11, 0];
	this.EnableWordWrapping             =[$IG.NavControlProps.Count + 12, false];
	this.ActiveNodeAddress				= [$IG.NavControlProps.Count + 13, ""];
	this.DataLoadingMessageCssClass		= [$IG.NavControlProps.Count + 14, ""];
	this.EnableHotTracking              = [$IG.NavControlProps.Count + 15, false];
	this.AnimationEquationType          = [$IG.NavControlProps.Count + 16, 0];
	this.AnimationDuration              = [$IG.NavControlProps.Count + 17, 1000];
	this.ControlFocused                 = [$IG.NavControlProps.Count + 18, false];
	this.EnableAutoChecking             = [$IG.NavControlProps.Count + 19, true];
	this.EnableClientRendering          = [$IG.NavControlProps.Count + 20, false];
	this.EnableSingleBranchExpand       = [$IG.NavControlProps.Count + 21,false];
	this.SingleBranchExpandLevel        = [$IG.NavControlProps.Count + 22, -1];
	this.IsClientStateDirty             = [$IG.NavControlProps.Count + 23, false];
	this.Count                          = $IG.NavControlProps.Count + 24;
};



$IG.NodeSettingsProps = new function()
{
	this.CssClass					= [0, ""];
	this.DisabledCssClass			= [1, ""];
	this.ActiveCssClass				= [2, ""];
	this.HoverCssClass				= [3, ""];
	this.ImageUrl					= [4, ""];
	this.LeafNodeImageUrl			= [5, ""];
	this.Target						= [6, ""];
	this.NavigateUrl				= [7, ""];
	this.ParentNodeImageUrl			= [8, ""];
	this.SelectedCssClass			= [9, ""];
	this.SelectedImageUrl			= [10, ""];
	this.SelectedLeafNodeImageUrl	= [11, ""];
	this.SelectedParentNodeImageUrl	= [12, ""];
	this.ImageCssClass				= [13, ""];
	this.AnchorCssClass				= [14, ""];
	this.HolderCssClass				= [15, ""];
	this.GroupCssClass				= [16, ""];
	this.ImageToolTip				= [17, ""];
	this.LeafNodeImageToolTip		= [18, ""];
	this.ParentNodeImageToolTip		= [19, ""];
	this.NodeParentCssClass			= [20, ""];
	this.Count						= 21;
};



$IG.NodeEditingProps = new function()
{
	this.Enabled                    = [0, false];
	this.EnableOnF2                 = [1, false];
	this.EnableOnDoubleClick        = [2, false];
	this.InternalEditorCssClass     = [3, ""];
	this.EnableOnSingleClickWhenActive = [4, false];
	this.Count                      = 5;
};


$IG.WebDataTree = function(element)
{
	///<summary locid="T:J#Infragistics.Web.UI.WebDataTree">
	/// Creates WebDataTree client-side object.
	///</summary>
	/// <param name="element" domElement="true">Tree's HTML element.</param>
	$IG.WebDataTree.initializeBase(this, [element]);
	element.style.visibility = "visible";

	this._bindings = this._getPropertyBindings();

	$IG.WebDataTree.find = $find;
	$IG.WebDataTree.from = $IG._from;
}

$IG.WebDataTree.prototype =
{
	_thisType: 'tree',
   
	_supportsClientRendering: true,
	_usesCollectionsClientState: true,
	_parentBinding: 'Nodes',
	/// Add on behalf of WebExplorerBar, to be able to
	/// customize the tree behaviour for disabled nodes.
	_disableNodeCollapseExpand: false,
	// Added on behalf of WebExplorerBar, we need to be
	// able to navigate when the user click anywhere on
	// the item area. While this is not applicable for
	// the tree. In the tree it navigates when clicked
	// on the link.
	_web: false,
	_navigateOnAreaClick: false,
	_dragDropSettings: null,
	_addressGenerator: null,
	_dragScrollArea: 15,
	_dropInsertBoundary: 5,
	_dragMarkup: null,
	_controlStylePrefix: null,
	_fireExpandEventsOnPopulate: false,
	_initCollections: false,
	// OVERRIDES
	initialize: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.initialize">
		///Initializes the WebDataTree object.
		///</summary>
		this._loadImages(this.get_element());
		this._nodeSettings = new $IG.NodeSettings("nodeSettings", null, this._objectsManager.get_objectProps(0), this, "nodeSettings");
		this._objectsManager.register_object(0, this._nodeSettings);
		
		this._nodeEditing = new $IG.NodeEditing("nodeEditing", null, this._objectsManager.get_objectProps(1), this, "nodeEditing");
		this._objectsManager.register_object(1, this._nodeEditing);

		this._controlActiveCssClass = this._get_clientOnlyValue("cssControlActive");
		this._nodeCssClass = this._get_clientOnlyValue("cssNode");
		this._nodeGroupCssClass = this._get_clientOnlyValue("cssNodeGroup");
		this._nodeRootCssClass = this._get_clientOnlyValue("cssNodeRoot");
		this._nodeParentCssClass = this._get_clientOnlyValue("cssNodeParent");
		this._nodeHoverCssClass = this._get_clientOnlyValue("cssNodeHover");
		this._nodeActiveCssClass = this._get_clientOnlyValue("cssNodeActive");
		this._nodeSelectedCssClass = this._get_clientOnlyValue("cssNodeSelected");
		this._nodeDisabledCssClass = this._get_clientOnlyValue("cssNodeDisabled");
		this._internalNodeEditorCssClass = this._get_clientOnlyValue("cssInternalNodeEditor");
		this._collapseImageToolTip = this._get_clientOnlyValue("collapseImageToolTip");
		this._expandImageToolTip = this._get_clientOnlyValue("expandImageToolTip");
		
		this._uncheckedImageURL = this._get_clientOnlyValue("uncheckedImageURL");
		this._checkedImageURL = this._get_clientOnlyValue("checkedImageURL");
		this._partialImageURL = this._get_clientOnlyValue("partialImageURL");
		this._parentNodeImageURL = this._get_clientOnlyValue("ns_parentImg");
		this._leafNodeImageURL = this._get_clientOnlyValue("ns_leafImg");
		this._nodeSettingsImageURL = this._get_clientOnlyValue("ns_img");
		this._nodeIndent = this._get_clientOnlyValue("nodeIndent");

		this._awaitingData = false;
		
		if (this._selectedNodes == null)
			this._selectedNodes = [];
			
		this._newSelectedNodes = [];
		this._contSelStartNode = null;
		this._contSelDir = 0; 
		this._selectionType = this._get_value($IG.DataTreeProps.NodeSelectionType);

		this._checkedNodes = [];
		this._checkBoxMode = this._get_clientOnlyValue("checkBoxMode");
		
		if (this._get_enableClientRendering())
		{
			if (typeof (jQuery) === "undefined") {
				throw new Error("The Infragistics WebDataTree Client Rendering requires jQuery to be loaded");
			}

			// we need to store the original template, because it is reused for every tree level
			var rootList = $('#' + this._element.id + ' > ul');
			this.originalTemplate = rootList[0].cloneNode(true);
			this.originalTemplate.id = this._id +"_orig";

			rootList.empty();

			// fire the DataBinding event
			var args = this._raiseClientEvent("DataBinding", "DataBinding", null, null);
			if (args == null || !args.get_cancel())
			{
				// hash table of Sys.UI.DataView objects
				this.__childTemplates = [];
				this.__flagsObject = new $IG.FlagsObject(null, null);
				this._dataBind();
			}
			else
			{
				// This case is when the client rebinds to data that is coming from an external data source/service
				// We have to defer initialization and complete it once the data is available which is done in the 
				// public dataBind() method
				this._awaitingData = true;
				return;
			}
		}

		this._initialSelection = true;         
		$IG.WebDataTree.callBaseMethod(this, 'initialize');
		this._initialSelection = false;
		
		var selectedNodesAdr = this._get_clientOnlyValue("selectedNodesAdr");
		var checkedNodesAdr = this._get_clientOnlyValue("checkedNodesAdr");

		if(selectedNodesAdr && selectedNodesAdr.length > 0)
			this._initializeNodes(selectedNodesAdr.split(','));
			
		if(checkedNodesAdr && checkedNodesAdr.length > 0)
			this._initNodesClientside(checkedNodesAdr.split(','));

		this._itemCollection._owner = this;

		this._element._address = "main";

		this._activeNode = null;
		var activeNodeAddr = this._get_value($IG.DataTreeProps.ActiveNodeAddress);
		if (activeNodeAddr != null && activeNodeAddr.length > 0)
		{
			var actNode = this._itemCollection._getObjectByAdr(activeNodeAddr); 
			if (actNode != null)
			{
				this._activeNode = actNode;
			}
		}
		
		
		this._nodeEditor = new $IG.TreeInternalEditor(this.get_element());
		if (this._nodeEditor._originalNotifyLostFocus == null)
		{
			this._nodeEditor._originalNotifyLostFocus = this._nodeEditor.notifyLostFocus;
			this._nodeEditor.notifyLostFocus = Function.createDelegate(this, this.__editorLostFocus);
		}
		this._currentEditor = null;
		this._nodeInEditMode = null;
		
		
		
		var treeElement = this.get_element();
		  this._addEvtHandlers(treeElement);

		this.__controlActive = false;
		this.__scrollbarWidth = null;
		this.__isPopulating = false;
		this._controlAnimations = new Array();
		this._controlAnimationsCount = 0;

		this._initalizeDragDrop();

		// K. D. Bug #58713 This extracts the scrolling of the tree element from the client state
		// so that the scrolling can persist through postback
		var scrollTop = this._get_clientOnlyValue('scrollTop');
		if(scrollTop)
		{
			treeElement.scrollTop = scrollTop;
			treeElement.scrollLeft = this._get_clientOnlyValue('scrollLeft');
		}
		
		var aa = this._element.getElementsByTagName('A');
		for (var i = aa ? aa.length : 0; i > 0; i--)
		{
			var a = aa[i - 1], css = a.className;
			// exclude possible custom A in item template
			if (css && (css.indexOf("igeb_") == 0 || css.indexOf("igdt_") == 0))
				this._fixA(a);
		}

		if (this._thisType == 'tree' && !this.preventInitEvent)
			this._raiseClientEvent('Initialize');
		
		// M.H. 28 Nov. 2011 Fix for bug 82018
		// K.D. February 21st, 2012 Bug #102107 Removing the previous fix as it was a workaround. I'm fixing the bug
		// directly in the selection logic as there there was no API branch for single and multiple selection
//		var activeNode = this.get_activeNode();
//        if (activeNode != null && activeNode !== undefined
//				&& this._selectionType == 1) {
//			// on init if there is active node(selected node) set its flag to selected
//			var nodeFlags = activeNode._getFlags();
//			nodeFlags.setSelected(true);
//		}
	},
	
	_addEvtHandlers: function (elem)
	{
		if (elem._hasHandlers)
			return;
		elem._hasHandlers = true;
		$addHandlers(elem, {
			'mousedown': this._onMouseDownHandler,
			'mouseover': this._onMouseOverHandler,
			'mouseout': this._onMouseOutHandler,
			// base-class _onEventHandler utility provides extra parameters in _onXxxHandler handlers
			'mouseup': this._onEventHandler,
			'dblclick': this._onEventHandler,
			'click': this._onClickHandler,
			
			'scroll': this._onScrollHandler
		}, this);
		var focusElement = this.get_focusElement();
		if (!focusElement)
			return;
		$addHandlers(focusElement, {
			'keypress': this._onKeypressHandler,
			'keydown': this._onKeydownHandler,
			'keyup': this._onKeyupHandler,
			'focus': this._onFocusHandler,
			'blur': this._onBlurHandler
		}, this);
		var wasFocused = this._get_value($IG.DataTreeProps.ControlFocused, true);
		if (wasFocused)
		{
			//A.T. 28 April 2010 - Fix for bugs #29940 and #30611
			try
			{
				focusElement.blur();
				focusElement.focus();
			} catch(e) {}    
		}
	},
	_isMy: function (e)
	{
		if (!e)
			return;
		var ul, xID = this._xID, id = e.id;
		if (!xID)
		{
			var myID = this._uniqueID;
			var nodes = this._element.childNodes, i = nodes.length;
			while (i-- > 0 && !this._xID)
			{
				xID = nodes[i].id;
				if (xID && xID.indexOf('x:') == 0)
					this._xID = xID.substring(0, xID.indexOf('.'));
			}
			xID = this._xID;
		}
		if (e._xID == xID)
			return true;
		if (id && id.indexOf(xID) == 0)
		{
			e._xID = xID;
			return true;
		}
		if (id && id.indexOf(xID) == 0)
		{
			e._xID = xID;
			return true;
		}
		ul = e.parentNode;
		if (ul.nodeName == 'DIV')
			ul = ul.parentNode;
		if (ul._xID == xID)
		{
			e._xID = xID;
			return true;
		}
		id = ul.id;
		if (id && id.indexOf(xID) == 0)
		{
			ul._xID = e._xID = xID;
			return true;
		}
	},
	
	_fixA: function (a)
	{
		a.onclick = function ()
		{
			var css1 = this.className, css2 = this.parentNode;
			css2 = css2 ? css2.className : null;
			
			return !(!this.href || this.href.indexOf("#") == this.href.length-1 || (css1 && css1.indexOf('Disabled') > 0) || (css2 && css2.indexOf('Disabled') > 0));
		};
		
		
		a.ontouchstart = function(){};
	},
	_saveAdditionalClientState: function()
	{
		// K. D. Bug #58713 This pushes the scrolling of the tree element to the client state
		// so that the scrolling can persist through postback
		var treeElement = this.get_element();
		var state = [{scrollTop: treeElement.scrollTop, scrollLeft: treeElement.scrollLeft}];
		state.push(this._itemCollection._csm.getChangeLog());
		return state;
	},

	_onIgSubmit: function()
	{
		
		this._stopAnimations();
		$IG.WebDataTree.callBaseMethod(this, '_onIgSubmit');
	},

	_stopAnimations: function()
	{
		var ca = this._controlAnimations;
		for(var i in ca)
		{
			if (ca.hasOwnProperty(i)) {
				






				var animation = ca[i];
				// M.H. 3 June 2011 - fix bug 77935 - check whether animation.get_isAnimating is defined
				if(animation && animation.get_isAnimating && animation.get_isAnimating())
				{
					animation.stop();
				}
			}
		}
		
		this._controlAnimations = new Array();
	},

	_registerAnimationObject: function(obj)
	{
		this._controlAnimations[this._controlAnimationsCount] = obj;
		obj._animationID = this._controlAnimationsCount;
		this._controlAnimationsCount++; // do not decrease this, else objects can be overwritten!
	},

	_unregisterAnimationObject: function(obj)
	{
		if(obj)
		{
			delete this._controlAnimations[obj._animationID];
			delete obj._animationID;
		}
	},

	_get_isClientStateDirty: function()
	{
		///<summary>
		/// Get whether the tree client state is dirty. Which means that the Nodes collection has been edited.
		///</summary>
		return this._get_value($IG.DataTreeProps.IsClientStateDirty, true);
	},

	_set_isClientStateDirty: function(value)
	{
		///<summary>
		/// Set that the client state is dirty and the tree needs to regenerate its collections on the server.
		///</summary>
		///<param type="Boolean"></param>
		this._set_value($IG.DataTreeProps.IsClientStateDirty, value);
	},
	
	_loadDragDropClientOnlyProperties: function()
	{
		




		var dragMarkupCssClass = this._get_clientOnlyValue("dragMarkupCssClass");
		var dropIndicatorCssClass = this._get_clientOnlyValue("dropIndicatorCssClass");
		var dropTargetCssClass = this._get_clientOnlyValue("dropTargetCssClass");
		var dropInsertLineCssClass = this._get_clientOnlyValue("dropInsertLineCssClass");
		var expandDelay = this._get_clientOnlyValue("dd_expandDelay");
		var dropImageMove = this._get_clientOnlyValue("dropImageMove");
		var dropImageCopy = this._get_clientOnlyValue("dropImageCopy");
		var enableExpandOnDrop = this._get_clientOnlyValue("enableExpandOnDrop");

		var diVisible = this._get_clientOnlyValue("dd_divisible");
		var diInsertBeforeFS = this._get_clientOnlyValue("dd_diibfs");
		var diInsertAfterFS = this._get_clientOnlyValue("dd_diiafs");
		var diInsertBetweenFS = this._get_clientOnlyValue("dd_diibetfs");
		var diMoveToFS = this._get_clientOnlyValue("dd_dimttfs");
		var diCopyToFS = this._get_clientOnlyValue("dd_dicttfs");

		var dropIndicator = new $IG.DropIndicator(diVisible, dropIndicatorCssClass, diInsertBeforeFS, diInsertAfterFS, diInsertBetweenFS, diMoveToFS, diCopyToFS);

		this._dragDropSettings = new $IG.DragDropSettings(null, null, null,
														  dragMarkupCssClass,
														  dropTargetCssClass, dropInsertLineCssClass, expandDelay,
														  dropImageMove, dropImageCopy, enableExpandOnDrop, dropIndicator);
	},

	_initalizeDragDrop: function()
	{
		this._addressGenerator = new $IG.AddressGenerator(this);

		if((this.get_enableDragDrop() || this.get_allowDrop()) && $IG.DragDropBehavior)
		{
			this._enterCache = new Array();
			this._dragLeaveRegisteredQueue = new Array();

			this._loadDragDropClientOnlyProperties();

			if(this.get_enableConnectorLines())
				this._dropInsertBoundary = 4;

			if (this.get_enableDropInsertion())
			{
				this.__createInsertLine();
			}
		}
	},

	__loadClientBindingObjects: function()
	{
		this._clientBindingDataContext = new $IG.ClientBindingDataContext("clientBindingDataContext", null, this._objectsManager.get_objectProps(2), this, "clientBindingDataContext");
		this._objectsManager.register_object(2, this._clientBindingDataContext);
		this._clientBindings = [];
		
		var clientBindingsCount=0;
		for (i=3;i<this._objectsManager.get_count();i++)
		{
			this._clientBindings[clientBindingsCount] = new $IG.ClientDataBinding("clientBinding", null, this._objectsManager.get_objectProps(i), this, "clientBinding");
			this._objectsManager.register_object(i, this._clientBindings[clientBindingsCount]);
			clientBindingsCount++;
		}
		
	},
	
	_get_enableClientRendering: function()
	{
		return this._get_value($IG.DataTreeProps.EnableClientRendering, false);
	},
	
	get_dataSource: function()
	{
		return this._dataStore[4];
	}, 
	
	set_dataSource: function(dataSourceJSON)
	{
		this._dataStore[4] = dataSourceJSON;
	},
	
	_getPropertyBindings: function()
	{
		var bindings = [];
		
		this._addPropertyBindings(bindings, $IG.ObjectBaseProps);
		this._addPropertyBindings(bindings, $IG.ControlObjectProps);
		this._addPropertyBindings(bindings, $IG.DataItemProps);
		this._addPropertyBindings(bindings, $IG.NavItemProps);
		this._addPropertyBindings(bindings, $IG.DataTreeNodeProps);

		return bindings;
	},
	
	_addPropertyBindings: function(bindingsArray, object)
	{
		for(var property in object) {
			if (object.hasOwnProperty(property)) {
				if(property != "Count") {
					bindingsArray.push(property);
				}
			}
		}
	},

	__generateJSONAddresses: function(json, parentAddress)
	{
		// K.D. May 4th, 2011 Bug #74426 Have to check that json address exists first
		if (json && json.length > 0 && json[0].FullAddress)
			return;

		for (var i = 0; i < json.length; i++)
		{
			json[i].FullAddress = parentAddress + i;
			if (json[i].Nodes && json[i].Nodes.length > 0)
				this.__generateJSONAddresses(json[i].Nodes, parentAddress + i + '.');
		}    
	},
	
	// The public dataBind method is to be used after canceling the DataBinding event
	dataBind: function()
	{
		// Finishing initialization
		this._awaitingData = false;
		//this.__loadClientBindingObjects();
		this.__childTemplates = [];
		this.__flagsObject = new $IG.FlagsObject(null, null);

		var json = this.get_dataSource();
		// we must check whether FullAddress exists as a property in the JSON, and if not, generate it ourselves
		this.__generateJSONAddresses(json, '');

		// we need to store the original template, because it is reused for every tree level
		var rootList = $('#' + this._element.id + ' > ul');

		var dataSourceObject = eval(json);

		// parent collection, dataSourceObject (child nodes), rootList el, template
		var args = this._raiseClientEvent("NodeCollectionRendering", "NodeCollectionRendering", null, null);
		this.__bindNodes(dataSourceObject, rootList, this.originalTemplate);
		this._raiseClientEvent("NodeCollectionRendered", "NodeCollectionRendered", null, null);

		// Initialization completes after binding the nodes
		this._initialSelection = true; 
		$IG.WebDataTree.callBaseMethod(this, 'initialize');
		this._initialSelection = false;

		var selectedNodesAdr = this._get_clientOnlyValue("selectedNodesAdr");
		var checkedNodesAdr = this._get_clientOnlyValue("checkedNodesAdr");

		
		if (selectedNodesAdr && selectedNodesAdr.length > 0)
			this._initializeNodes(selectedNodesAdr.split(','));

		if (checkedNodesAdr && checkedNodesAdr.length > 0)
			this._initNodesClientside(checkedNodesAdr.split(','));

		this._itemCollection._owner = this;

		this._element._address = "main";
		
		this._activeNode = null;
		var activeNodeAddr = this._get_value($IG.DataTreeProps.ActiveNodeAddress);
		if (activeNodeAddr != null && activeNodeAddr.length > 0) {
			var actNode = this._itemCollection._getObjectByAdr(activeNodeAddr); 
			if (actNode != null) {
				this._activeNode = actNode;
			}
		}

		
		this._nodeEditor = new $IG.TreeInternalEditor(this.get_element());
		if (this._nodeEditor._originalNotifyLostFocus == null) {
			this._nodeEditor._originalNotifyLostFocus = this._nodeEditor.notifyLostFocus;
			this._nodeEditor.notifyLostFocus = Function.createDelegate(this, this.__editorLostFocus);
		}
		this._currentEditor = null;
		this._nodeInEditMode = null;
		
		

		var treeElement = this.get_element();
		  this._addEvtHandlers(treeElement);

		this.__controlActive = false;
		this.__scrollbarWidth = null;
		this.__isPopulating = false;
		this._controlAnimations = new Array();
		this._controlAnimationsCount = 0;

		this._initalizeDragDrop();

		// K. D. Bug #58713 This extracts the scrolling of the tree element from the client state
		// so that the scrolling can persist through postback
		var scrollTop = this._get_clientOnlyValue('scrollTop');
		if (scrollTop) {
			treeElement.scrollTop = scrollTop;
			treeElement.scrollLeft = this._get_clientOnlyValue('scrollLeft');
		}

		if (this._thisType == 'tree' && !this.preventInitEvent)
			this._raiseClientEvent('Initialize');

		// fire DataBound event
		this._raiseClientEvent("DataBound", "DataBound", null, null);
	},

	_dataBind: function()
	{
		var json = this.get_dataSource();
		// we must check whether FullAddress exists as a property in the JSON, and if not, generate it ourselves
		this.__generateJSONAddresses(json,'');
		
		// we need to store the original template, because it is reused for every tree level
		var rootList = $('#'+this._element.id+' > ul');

		
		var dataSourceObject = eval(json);

		// parent collection, dataSourceObject (child nodes), rootList el, template
		var args = this._raiseClientEvent("NodeCollectionRendering", "NodeCollectionRendering", null, null);
		this.__bindNodes(dataSourceObject, rootList, this.originalTemplate);
		this._raiseClientEvent("NodeCollectionRendered", "NodeCollectionRendered", null, null);

		// fire DataBound event
		this._raiseClientEvent("DataBound", "DataBound", null, null);
	},

	__bindNodes: function(dataSourceObject, rootList, template)
	{
		for (var i = 0, len = dataSourceObject.length; i < len; i++)
		{
			this._raiseClientEvent("NodeRendering", "NodeRendering", null, null);
			var item = dataSourceObject[i];
			var hashCode = this._getHashCode();
			var fullAddress = item.FullAddress;

			this.__flagsObject._flags = item.Flags;
			$(template).tmpl(item).appendTo(rootList[0]);
			var rootItem = rootList[0].lastChild;
			$(rootItem).attr('adr', fullAddress);
			$(rootItem).attr($util._xAttr, hashCode + ':adr:' + fullAddress);

			// Display Image if Url is specified
			if(item.ImageUrl && item.ImageUrl.length > 0)
			{
				var image = rootItem.insertBefore(document.createElement("IMG"), rootItem.firstChild);
				image.src = item.ImageUrl;
				if(item.ImageToolTip && item.ImageToolTip.length > 0)
					image.alt = item.ImageToolTip;
			}

			// Displays checkboxes
			if(this.get_checkBoxMode() != $IG.CheckBoxMode.Off)
			{
				var checkBoxImage = rootItem.insertBefore(document.createElement('IMG'), rootItem.firstChild);
				checkBoxImage.src = this._uncheckedImageURL;
				$util._setXAttr(checkBoxImage, hashCode + ':mkr:check');
				$(checkBoxImage).attr('mkr', 'check');
			}

			//element, index, parentCollection, dataitem
			this._renderNodeExpandImage(rootItem, i, dataSourceObject, item);
		
			if (this.get_enableConnectorLines())
				this._renderNodeSpace(item, rootItem);
		
			var nodeAnchor = rootItem.getElementsByTagName("A")[0];
			nodeAnchor.setAttribute("mkr", "dtnContent");
			$util._setXAttr(nodeAnchor, hashCode + ":mkr:dtnContent");
			this._setNodeClass(item, nodeAnchor);
		
			
			this._fixA(nodeAnchor);
			nodeAnchor.href = item.NavigateUrl || "#";

			//nodeElement._dataItem = e.dataItem;
			rootItem._dataItem = item;
			
			this._raiseClientEvent("NodeRendered", "NodeRendered", null, null);

			if (item.Nodes && item.Nodes.length > 0)
			{
				this._dataBindChildren(item, rootItem);
			}
		}
	},
	
	itemRenderingHandler: function(sender, e)
	{
		var dataItem = e.get_dataItem();
		this.__flagsObject._flags = dataItem.Flags;
	},
	
	itemRenderedHandler: function(sender, e)
	{
		var nodeElement = e.template._element.children[e.index];
		nodeElement._dataItem = e.dataItem;
		nodeElement.setAttribute("adr", e.dataItem.FullAddress);
		// generate address for child element
		$util._setXAttr(nodeElement, this._getHashCode() + ':adr:' + e.dataItem.FullAddress);

		if(e.dataItem.ImageUrl != null && e.dataItem.ImageUrl.length > 0)
		{
			//var image = nodeElement.insertAdjacentElement("afterBegin", document.createElement("IMG"));
			var image = nodeElement.insertBefore(document.createElement("IMG"), nodeElement.firstChild);
			image.src = e.dataItem.ImageUrl;
			if(e.dataItem.ImageToolTip != null && e.dataItem.ImageToolTip.length > 0)
			{
				image.alt = e.dataItem.ImageToolTip;
			}
		}
		
		this._renderNodeExpandImage(sender, e);
		
		if (this.get_enableConnectorLines())
			this._renderNodeSpace(e.dataItem, nodeElement);
		
		var nodeAnchor = nodeElement.getElementsByTagName("A")[0];
		nodeAnchor.setAttribute("mkr", "dtnContent");
		this._setNodeClass(e.dataItem, nodeAnchor);
		
		
		this._fixA(nodeAnchor);
		nodeAnchor.href = e.dataItem.NavigateUrl || "#";
		
		





		// recursively create child Sys.UI.DataView
		if (e.dataItem.Nodes && e.dataItem.Nodes.length > 0)
		{
			this._dataBindChildren(e.dataItem, nodeElement);
		}
	},
	
	_dataBindChildren: function(parentDataItem, parentNodeElement)
	{
		
		// child template must be instnatiated from the original copy for every sub level
		var childTemplate = this.originalTemplate.cloneNode(true);

		this.__childTemplates[parentDataItem.FullAddress] = childTemplate;
		childTemplate.id = "childTemplate" + parentDataItem.FullAddress;
		
		var ul = document.createElement("ul");
		ul.className = this._nodeGroupCssClass;
		
		if (!this.get_enableConnectorLines())
			ul.style.paddingLeft = "20px";
		
		ul.style.margin = "0px";
		if(!parentDataItem.Expanded)
			ul.style.display = 'none';
	  //  ul.appendChild(childTemplate);
		parentNodeElement.appendChild(ul);

		this.__bindNodes(parentDataItem.Nodes,$(ul), childTemplate);
		//var childView = Sys.create.dataView(childTemplate);
		//this.__treeDataViews[parentDataItem.FullAddress] = childView;

	   // this.itemRenderingDelegate = Function.createDelegate(this, this.itemRenderingHandler);
	   // this.itemRenderedDelegate = Function.createDelegate(this, this.itemRenderedHandler);

	   // childView.add_itemRendering(this.itemRenderingDelegate);
	   // childView.add_itemRendered(this.itemRenderedDelegate);

	   // childView.set_data(parentDataItem.Nodes);
	},
	
	_setNodeClass: function(dataItem, nodeAnchorElement, childTemplate)
	{
		var className = dataItem.CssClass;
		className = this._nodeCssClass + (className ? " " + className : "");
		if (dataItem.FullAddress.indexOf(".") == -1)
			className += " " + this._nodeRootCssClass;

		if (dataItem.Nodes && dataItem.Nodes.length > 0 || dataItem.IsEmptyParent)
			className += " " + this._nodeParentCssClass;

		if (dataItem.Selected)
			className += " " + this._nodeSelectedCssClass;
		
		if (!this.__flagsObject.getEnabled(this))
			className += " " + this._nodeDisabledCssClass;

		$util.addCompoundClass(nodeAnchorElement, className);
	},
	
	_renderNodeSpace: function(dataItem, nodeElement)
	{
		var adrItems = dataItem.FullAddress.split(".");
		if (adrItems.length == 1)
			return;
		
		var chain = "";
		var dataItems = this.get_dataSource();
		for (var i = 0; i < adrItems.length - 1; i++)
		{
			var itemIndex = parseInt(adrItems[i]);
			var chainItemValue = (dataItems.length - 1 > itemIndex) ? "1" : "0";
			chain = chainItemValue + chain;
			
			dataItems = dataItems[itemIndex].Nodes;
		}
		
		var length = chain.length;
		for (var j = 0; j < length; j++)
		{
			var index = 0;
			if(chain[j] == "1")
				index = 16;

			//var spaceImage = nodeElement.insertAdjacentElement("afterBegin", document.createElement("IMG"));
			var spaceImage = nodeElement.insertBefore(document.createElement("IMG"), nodeElement.firstChild);
			spaceImage.src = this._imageList[index].src;
			spaceImage.alt = "";
			
			//L.A. 21 March 2012 Fixed bug #79859 When using Drag and Drop in WebDataTree with Client rendering and connector lines the margin of the dropped node is double what it should be
			spaceImage.setAttribute("idx", index);
			spaceImage.setAttribute("nidx", index);
		}
	},
	
	_renderNodeExpandImage: function(element, index, parentCollection, dataItem)
	{
		if (!this.get_enableExpandImages() && !this.get_enableConnectorLines())
			return;
		
		var index = this._getNodeImageIndex(index,parentCollection, dataItem);
		//var expandImage = element.insertAdjacentElement("afterBegin", document.createElement("IMG"));
		var expandImage = element.insertBefore(document.createElement("IMG"), element.firstChild);
		expandImage.src = this._imageList[index].src;
		expandImage.setAttribute("idx", index);
		expandImage.setAttribute("nidx", index);
		
		//if ((node.Nodes.length > 0 || node.get_isEmptyParent()) && this.get_enableExpandImages())
		if (dataItem.Nodes && dataItem.Nodes.length > 0 && this.get_enableExpandImages())
		{
			if (dataItem.Expanded && this._collapseImageToolTip && this._collapseImageToolTip.length > 0)
			{
				var tooltip = this._collapseImageToolTip;
				tooltip = tooltip.replace(/\{0\}/, dataItem.Text);
				dataItem.Alt = tooltip;
				expandImage.setAttribute("title", tooltip);

			}
			else if (!dataItem.Expanded && this._expandImageToolTip && this._expandImageToolTip.length > 0)
			{
				var tooltip = this._expandImageToolTip;
				tooltip = tooltip.replace(/\{0\}/, dataItem.Text);
				dataItem.Alt = tooltip;
				expandImage.setAttribute("title", tooltip);
			}
		}
	},
	
	_getNodeImageIndex: function(index,parentCollection,dataItem)
	{
		if (this.get_enableConnectorLines())
		{
			var level = dataItem.FullAddress.split(".").length - 1;
			if (level == 0)
			{
				if (this.get_dataSource().length == 1)
				{
					if (!this.get_enableExpandImages())
						return 13;
					if (dataItem.Nodes && dataItem.Nodes.length > 0 || dataItem.IsEmptyParent)
					{
						if(dataItem.Expanded)
							return 15;

						return 14;
					}
					return 13;
				}
			}

			switch (this._getNodePosition(index, parentCollection, dataItem)) // -1 - Top, 0 - Middle, 1 - Bottom
			{
				case -1:
					index = 2;
					break;
				case 0:
					index = 5;
					break;
				case 1:
					index = 8;
					break;
			}

			if (((dataItem.Nodes && dataItem.Nodes.length > 0) || dataItem.IsEmptyParent) &&  this.get_enableExpandImages())
			{
				if (dataItem.Expanded)
					index += 2;
				else
					index++;
			}
			return index;
		}
		if (dataItem.IsEmptyParent && !dataItem.Expanded)
			return 1;
		if (dataItem.Nodes == null || dataItem.Nodes.length == 0)
			return 0;
		if (dataItem.Expanded)
			return 2;
		
		return 1;
	},
	
	_getNodePosition: function(index, parentCollection, dataItem)
	{
		if (index + 1 == parentCollection.length)
			return 1;
		if (index == 0)
		{
			if (dataItem.FullAddress.split(".").length == 1)
				return -1;
		}
		return 0;
	},
	
	_initializeNodes: function(nodesAddress)
	{
		for (var i = 0; i < nodesAddress.length; i++)
		{
			var node = this._itemCollection._getObjectByAdr(nodesAddress[i]);

			// K.D. July 15, 2011 Bug #79858 The selectedNodes remains empty so bringing it back to normal
			if (this._get_enableClientRendering() && node)
			{
				this._selectNode(node, true, null);
			}
		}
	},

	_initNodesClientside: function(nodesAddress)
	{
		for (var i = 0; i < nodesAddress.length; i++)
		{
			var node = this._itemCollection._getObjectByAdr(nodesAddress[i]);
			
			// Checks the nodes on the client side when clientside rendering is enabled
			if(this._get_enableClientRendering() && node)
			{
				node.set_checkState($IG.CheckBoxState.Checked);
			}
		}
	},
	
	getNodeEditing: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.getNodeEditing">
		/// Returns the node editing object for the tree.
		///</summary>
		///<returns type="Infragistics.Web.UI.NodeEditing">Reference to the WebDataTree NodeEditing object.</returns>
		return this._nodeEditing;
	},
	
	_get_childrenCount: function(rootElement) 
	{
		///<summary>
		/// Returns the subnodes count of the given root element.
		///</summary>
		var count = 0;
		var child = rootElement.firstChild;
		while (child) 
		{
			if (child.tagName == "UL") 
			{
				child = child.firstChild;
				while (child) 
				{
					if (child.tagName == "LI") 
						count++;
					child = child.nextSibling;
				}
				break;
			}
			child = child.nextSibling;
		}
		return count;
	},
	
	_get_childNodeElement: function(rootElement, index) 
	{
		///<summary>
		/// Returns the child node element of the given root element at the specified index.
		///</summary>
		var isClientRendering = this._get_enableClientRendering();
		var counter = 0;
		var child = rootElement.firstChild;
		while (child) 
		{
			if (child.tagName == "UL") 
			{
				child = child.firstChild;
				while (child) 
				{
					if (child.tagName == "LI" || (isClientRendering && child.tagName == "SPAN"))
					{
						if (index == counter)
						{
					//	if (isClientRendering)
					//			return child.firstChild;
					//		else
								return child;
						}
						counter++;
					}
					child = child.nextSibling;
				}
				break;
			}
			child = child.nextSibling;
		}
		return null;
	},
	
	_initElemAttr: function(elem)
	{
		if (elem.getAttribute("adr") == null)
		{
			$util._initAttr(elem);
		}
	},

	_uiBehaviorsObject_initElemAttr: function(elem)
	{
		this._control._initElemAttr(elem);
	},
	_isUserElem: function (e)
	{
		var name = e ? e.nodeName : null;
		if (!name && e && e.target)
			name = e.target.nodeName;
		// K.D. November 11th, 2013 Bug #156674 Under Webkit the SELECT target is actually an OPTION
		return name == "INPUT" || name == "TEXTAREA" || name == "SELECT" || name == "BUTTON" || name == "OPTION";
	},
	
	
	_uiBehaviorsObject_select: function(item, e)
	{
		// In this context (method), "this" means the UIBeaviorObject (not the WebDataTree object)
		var clickedOnDTN = false; 
		
		if (e != null)
		{
			if (this._control._isUserElem(e))
				return;
			//I.I 95975: When node is in edit mode and click on it edit mode closes
			if (this._control._nodeInEditMode != null && this._control._nodeInEditMode != item)
			{
				this._control._exitNodeEditing(true);
			}
			var mainEl = this._control.get_element();
			var parent = e.target;
			// A.T. Feb 16 2010 - Fix for bug #27360 - (WebExplorerBar) Groups collapsing when clicking the vertical scrollbar for the group 
			while (parent && parent != mainEl && (parent.nodeName != "UL" || (parent.nodeName=="UL" && parent.parentNode && parent.parentNode.nodeName!="LI") || (parent.nodeName=="UL" && parent.parentNode && parent.parentNode.nodeName=="LI" && parent.parentNode.getAttribute && !parent.parentNode.getAttribute("adr"))))
			{
				if (parent.getAttribute("mkr") == "dtnIcon" || parent.getAttribute("mkr") == "dtnContent" ||  (parent.nodeName=="LI" && parent.childNodes[0] && parent.childNodes[0].nodeName=="DIV" && parent.getAttribute("adr")))
				{
					clickedOnDTN = true;
					this._control.__cancelBlur = true;
					break;
				}
				parent = parent.parentNode;
			}
		}
		
		// this case is for API calls
		if (e == null)
		{
			this._control._nodeClick(item, e);
		}
		else
		// this case is only when left mouse button is pressed
		if (e.button == 0)
		{
			if (parseInt(e.target.getAttribute("idx")) > 0)
			{
				// clicked on expand/collapse image, so toggle the node expansion.
				var node = this._control._ensureNode(e.target.parentNode);
				if(item.get_enabled() && !this._disableNodeCollapseExpand)
					item.toggle(true);
			}
			if (e.target.getAttribute("mkr") == "check")
			{
				// clicked on check box image
				var node = this._control._ensureNode(e.target.parentNode);
				
				if (node.get_enabled())
				{
					var args = this._control._raiseClientEvent('NodeChecking', 'DataTreeNode', null, null, node);
					if (args && args.get_cancel()) return;
					var oldSelection = this._control.get_checkedNodes();
					this._control._toggleNodeCheckState(node);
					var newSelection = this._control.get_checkedNodes();
					this._control._raiseClientEvent('CheckBoxSelectionChanged', 'DataTreeCheckBoxSelection', null, null, oldSelection, newSelection);
				}
			}
			else if (clickedOnDTN)
			{
				// clicked on the node icon or content
				if (this._control.get_enableExpandOnClick() && (item.get_enabled() && !this._control._disableNodeCollapseExpand))
				{
					item.toggle(true);
				}
				if (item == this._control._activeNode && this._control._nodeEditing.get_enableOnSingleClickWhenActive())
					this._control._enterNodeEditing(item);
				this._control.set_activeNode(item, true);
				if(!(this._control.get_enableDragDrop() &&
					 this._control._selectedNodes.length > 1 &&
					 item.get_selected()) || e.ctrlKey)
				{
					this._control._nodeClick(item, e);
				}
			}
		}
		if (e)
		{
			this._mouseDown = true;
			//I.I. 95975: When node is in edit mode and click on it edit mode closes
			// VS 04/16/2012 Bug 109179: INPUT does not focus when node has template
			if (this._control._nodeInEditMode === null && e.target && e.target.nodeName != "INPUT" && e.target.nodeName != "TEXTAREA" && e.target.nodeName != "BUTTON")
			{
				//I.I. 101576: The tree scrolls down when a node is clicked
				$util.cancelEvent(e);
			}
		}
	},
	
	
	















	
	_checkNode: function(node, state) 
	{	
		if(state == $IG.CheckBoxState.Checked)
		{
			this._checkedNodes.push(node);
		}
		else
		{
			for (var i = 0, len = this._checkedNodes.length; i < len; i++)
			{
				if (this._checkedNodes[i] == node) 
				{
					this._checkedNodes.splice(i, 1); 
					break;
				}
			}
		}
	},
	
	_toggleNodeCheckState: function(node) 
	{
		/// <summary>
		/// Toggles the CheckBoxState of the node.
		/// In tri-state mode if the current state is partial sets the state to unchecked.
		/// </summary>
		if(node.get_checkState() == $IG.CheckBoxState.Unchecked)
		{
			node.set_checkState($IG.CheckBoxState.Checked);	
		}
		else
		{
			node.set_checkState($IG.CheckBoxState.Unchecked);
		}
		
		if(this.get_enableAutoChecking())
		{
			this._applyCheckStateToChildren(node);
			this._applyCheckStateToParent(node);
		}
	},
	
	_applyCheckStateToChildren: function(node)
	{
		var state = node.get_checkState();
		var count =  node.get_childrenCount();
		for(var i = 0; i < count; i++)
		{
			var childNode = node.get_childNode(i);
			
			if(childNode)
			{
				childNode.set_checkState(state);
				this._applyCheckStateToChildren(childNode);
			}
		}
	},
	
	_applyCheckStateToParent: function(node)
	{
		var parentNode = node ? node.get_parentNode() : null;
		if(!parentNode)
			return;
		var childrenCount = parentNode.get_childrenCount(); 
		var checkedCount = 0;
		var partialCount = 0;
		for(var i = 0; i < childrenCount; i++)
		{
			var childState = parentNode.get_childNode(i).get_checkState();
			if(childState == $IG.CheckBoxState.Checked)
				checkedCount++;
			else if(childState == $IG.CheckBoxState.Partial)
				partialCount++;
		}
		
		if(partialCount > 0)
		{
			parentNode.set_checkState($IG.CheckBoxState.Partial);
		}
		else if(checkedCount == 0)
		{
			parentNode.set_checkState($IG.CheckBoxState.Unchecked);
		}
		else if(checkedCount == childrenCount)
		{
			parentNode.set_checkState($IG.CheckBoxState.Checked);
		}
		else if(this._checkBoxMode == $IG.CheckBoxMode.TriState)
		{
			parentNode.set_checkState($IG.CheckBoxState.Partial);
		}
		else
		{
			parentNode.set_checkState($IG.CheckBoxState.Unchecked);
		}
		
		this._applyCheckStateToParent(parentNode);
	},
	
	_nodeClick: function(node, browserEvent)
	{
		





		if (this._initialSelection)
		{
			this._selectedNodes.push(node);
		}
		else
		{
			if (this._selectionType == 1 || this._selectionType == 2)
			{
				this._selectNode(node, true, browserEvent);
			}
		}
	},
	
	_selectNode: function(node, value, browserEvent)
	{
		if (!node) return;
		if (!node.get_enabled())
		{
			if(!this._disableNodeCollapseExpand)
			{
				this._newSelectedNodes = [];
				this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
			}
			return;
		}
	
		
		if (browserEvent == null)
		{
			// A.T. 19 Sept. 2010 - Fix for bug #36698 - When node is unselected by client code it is added to array with selected nodes.
			// K.D. February 21st, 2012 Bug #102107 The logic for API calls for selection needs to be branched into single
			// and multiple selection cases, otherwise it was acting as always being multiple selection
			if (value === false && node.get_selected() === false)
				return;

			if (value != node.get_selected())
			{
				if (this._selectionType == 1) {
					this._newSelectedNodes = [];
					if (value) {
						this._newSelectedNodes.push(node);
					}
					this._setNodeSelectionState(node, value);
					this._changeSelection(this._selectedNodes, this._newSelectedNodes, false);
					this._contSelStartNode == null;
				} else if (this._selectionType == 2) {
					this._newSelectedNodes = Array.clone(this._selectedNodes);
					if (value)
					{ 
						this._newSelectedNodes.push(node);
						this._setNodeSelectionState(node, true);
					}
					else
					{ 
						for (i=0; i<this._newSelectedNodes.length; i++)
						{
							if (this._newSelectedNodes[i]._get_address() == node._get_address())
							{
								this._newSelectedNodes.splice(i, 1);
								break;
							}
						}
						this._setNodeSelectionState(node, false);
					}
					this._selectedNodes = this._newSelectedNodes;
				}
			}
			else
			{
				// if the value == node.get_selected(), this means the control is being initialized on 
				// the client and we need to adjust the selected nodes that come from the server.
				var foundAtIndex = -1;
				for (i=0; i<this._selectedNodes.length; i++)
				{
					if (this._selectedNodes[i]._get_address() == node._get_address())
					{
						foundAtIndex = i;
						break;
					}
				}
				if (foundAtIndex == -1) this._selectedNodes.push(node);
				else this._selectedNodes[foundAtIndex] = node;
			}
		}
		else
		{
			
			if (this._selectionType == 1)
			{
				if (!node.get_selected())
				{
					this._newSelectedNodes = [];
					if (value) this._newSelectedNodes.push(node);
					this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
				}
				else
				if (node.get_selected() && browserEvent.ctrlKey)
				{
					this._newSelectedNodes = [];
					this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
				}
				this._contSelStartNode == null;
			}
			else
			if (this._selectionType == 2)
			{
				if (browserEvent.shiftKey)
				{ 
					if (this._selectedNodes.length == 0 || this.get_activeNode() == null)
					{
						this._newSelectedNodes = Array.clone(this._selectedNodes);
						this._newSelectedNodes.push(node);
						this._addRemoveSelection(this._selectedNodes, this._newSelectedNodes, node, true, true);
					}
					else
					{
						if (browserEvent.ctrlKey)
						{
							this._newSelectedNodes = Array.clone(this._selectedNodes);
						}
						else
						{
							this._newSelectedNodes = [];
						}
						var selectionBeginNode = null;
						if (this._selectedNodes.length > 0)
						{
							selectionBeginNode = this._selectedNodes[this._selectedNodes.length - 1];
						}
						else
						{
							selectionBeginNode = this.get_activeNode();
						}
						if (selectionBeginNode != node)
						{
							if (selectionBeginNode && !browserEvent.ctrlKey)
							{
								this._newSelectedNodes.push(selectionBeginNode);
							}
							if (node.isAfter(selectionBeginNode))
							{   // select direction: down
								var nextNode = selectionBeginNode._get_navigationDownNode();
								while (nextNode != null)
								{
									if (nextNode.get_enabled()) this._newSelectedNodes.push(nextNode);
									if (nextNode == node) break;
									nextNode = nextNode._get_navigationDownNode();
								}
							}
							else
							{   // select direction: up
								var nextNode = selectionBeginNode._get_navigationUpNode();
								while (nextNode != null)
								{
									if (nextNode.get_enabled()) this._newSelectedNodes.push(nextNode);
									if (nextNode == node) break;
									nextNode = nextNode._get_navigationUpNode();
								}
							}
							this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
						}
					}
				} else
				if (browserEvent.ctrlKey || ($util.IsMac && browserEvent.rawEvent && browserEvent.rawEvent.metaKey))
				{ 
					this._newSelectedNodes = Array.clone(this._selectedNodes);
					if (node.get_selected())
					{
						for (i=0; i<this._newSelectedNodes.length; i++)
						{
							if (this._newSelectedNodes[i]._get_address() == node._get_address())
							{
								this._newSelectedNodes.splice(i, 1);
								break;
							}
						}
					}
					else
					{
						this._newSelectedNodes.push(node);
					}
					this._addRemoveSelection(this._selectedNodes, this._newSelectedNodes, node, !node.get_selected(), true);
				}
				else
				{
					if (!(this._selectedNodes.length == 1 && this._selectedNodes[0] == node))
					{
						this._newSelectedNodes = [];
						this._newSelectedNodes.push(node);
						this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
					}
					this._contSelStartNode == null;
				}
			}
		}
	},
	
	_addRemoveSelection: function(oldSelection, newSelection, aNode, select, fireEvents)
	{
		if (fireEvents)
		{
			var args = this._raiseClientEvent('SelectionChanging', 'DataTreeSelection', null, null, oldSelection, newSelection);
			if (args && args.get_cancel()) return;
		}        
		this._setNodeSelectionState(aNode, select);
		this._selectedNodes = newSelection;
		if (fireEvents)
		{
			this._raiseClientEvent('SelectionChanged', 'DataTreeSelection', null, null, oldSelection, newSelection);
		}
	},
	
	_changeSelection: function(oldSelection, newSelection, fireEvents)
	{
		if (fireEvents)
		{
			var args = this._raiseClientEvent('SelectionChanging', 'DataTreeSelection', null, null, oldSelection, newSelection);
			if (args && args.get_cancel()) return;
		}        
		var i;
		for (i=0; i<oldSelection.length; i++)
		{
			this._setNodeSelectionState(oldSelection[i], false);
		}
		for (i=0; i<newSelection.length; i++)
		{
			this._setNodeSelectionState(newSelection[i], true);
		}
		this._selectedNodes = newSelection;
		if (fireEvents)
		{
			this._raiseClientEvent('SelectionChanged', 'DataTreeSelection', null, null, oldSelection, newSelection);
		}
	},
	
	_setNodeSelectionState: function(node, value)
	{
		if (node == null) return;
		var nodeFlags = node._getFlags();
		if (nodeFlags.getSelected() == value) return;
		nodeFlags.setSelected(value);
		styleElement = node.get_styleElement();
		if (styleElement)
		{
			
			







			var cssClass = this._selectedCssClassResolved(node);
			
			if (this._cssDelay && value)
				setTimeout(function(){ Infragistics.Utility.toggleCompoundClass(styleElement, cssClass, value); }, 0);
			else
				Infragistics.Utility.toggleCompoundClass(styleElement, cssClass, value);
		}    
	},
	
	get_focusElement: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.focusElement">Returns the focus HTML element of the tree.</summary>
		///<returns domElement="true"></returns>
		
		if (this._fe)
			return this._fe;
		var inputs = this._element.getElementsByTagName("INPUT"), i = inputs ? inputs.length : 0;
		while(i-- > 0)
			if (inputs[i].className == "_tree_f_e_")
				return (this._fe = inputs[i]);
	},

	get_activeNode: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.activeNode">Gets the current active node.</summary>
		///<value type="Infragistics.Web.UI.Node" mayBeNull="true"/>
		return this._activeNode;
	},

	_toggleCss: function (elem, css, add)
	{
		if (elem && elem.get_styleElement)
			elem = elem.get_styleElement();
		if (elem)
			Infragistics.Utility.toggleCompoundClass(elem, css, add);
	},

	set_activeNode: function(node, fireEvent)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.activeNode">Sets the current active node.</summary>
		/// <param name="node" type="Infragistics.Web.UI.Node">Node object to be activated.</param>
		/// <param name="fireEvent" type="Boolean">Determines if activation changing event should be fired.</param>
		if(!this.__controlActive && this._activeNode)
			this._toggleCss(this._activeNode, this._activeCssClassResolved(this._activeNode), true);

		// K.D. May 31st, 2011 Bug #76399 Whenever we have a context menu that appears on right click for the tree,
		// the element given to the set_activeNode function is actually a menu item. So we have to check for the type
		// of the owner of the node. I also am not making it to compare the ID for the owner and this' ID because
		// this may cause problems when doing drag and drop between different trees
		// K.D. July 7th, 2011 Bug #80778 After my fix it was not possible to remove activation so reworking the logic
		if(node && node._owner && node._owner._thisType && node._owner._thisType !== 'tree')
		{
			return;
		}
		
		if(node && this._activeNode && node._get_address() == this._activeNode._get_address())
			return;

		if(node && (!node.get_visible() || (!node.get_enabled() && this._disableNodeCollapseExpand)))
			return;
		// if _activeNode is null enter here or if we already have _activeNode
		// make sure we enter only when the new node is different.
		if (fireEvent)
		{
			var args = this._raiseClientEvent('ActivationChanging', 'DataTreeActivation', null, null, this._activeNode, node);
			if (args && args.get_cancel()) return;
		}
		// M.H. 7 June 2011. Fix bug 76408 - first add css class to active node, then remove css class of previous active node
		var oldElement = this._activeNode;

		this._activeNode = node;

		if (this._activeNode)
		{
			this._set_value($IG.DataTreeProps.ActiveNodeAddress, this._activeNode._get_address());
			this._toggleCss(this._activeNode, this._activeCssClassResolved(this._activeNode), true);
			this._scrollToNode(this._activeNode, this.get_element());
		}
		else
		{
			this._set_value($IG.DataTreeProps.ActiveNodeAddress, "");
		}
		
		// M.H. 7 June 2011. Fix bug 76408 - remove css class of previous active node
		if (oldElement)
		{
			this._toggleCss(oldElement, this._activeCssClassResolved(oldElement));
		}

		if (fireEvent)
		{
			this._raiseClientEvent('ActivationChanged', 'DataTreeActivation', null, null, this._activeNode, this._activeNode);
		}
	},
	
	_scrollToNode: function(node, scrollElement)
	{
		var styleEl = node.get_styleElement();
		if (styleEl == null) return;
		
		var bounds = Sys.UI.DomElement.getBounds(styleEl);
		
		var scrollElementBounds = Sys.UI.DomElement.getBounds(scrollElement);
		var el_x1 = bounds.x;
		var el_y1 = bounds.y;
		var el_x2 = el_x1 + bounds.width;
		var el_y2 = el_y1 + bounds.height;
		
		var va_x1 = scrollElementBounds.x; 
		var va_y1 = scrollElementBounds.y; 
		var va_x2 = va_x1 + scrollElementBounds.width - 1; 
		if (scrollElement.scrollWidth > scrollElement.offsetWidth)
			va_x2 = va_x2 - this.__get_scrollbarWidth();
		var va_y2 = va_y1 + scrollElementBounds.height - 1; 
		if (scrollElement.scrollHeight > scrollElementBounds.height) 
			va_y2 = va_y2 - this.__get_scrollbarWidth();
		
		var dx = 0;
		if (el_x1 < va_x1) dx = el_x1 - va_x1;
		else if (el_x2 > va_x2) dx = el_x2 - va_x2;
		
		var dy = 0;
		if (el_y1 < va_y1) dy = el_y1 - va_y1;
		else if (el_y2 > va_y2) dy = el_y2 - va_y2;
        // K.D. March 10th, 2014 Bug #156164 The WebExplorerBar shouldn't be handling scrollLeft.
		if (!this._web) {
		    scrollElement.scrollLeft += dx;
		}
		scrollElement.scrollTop += dy;
	},
	// adjust location of focus-INPUT
	// if mouse is true, then that is mouseup, but not scroll event: adjust vertical shift for location of mouse,
	// otherwise, browser will scroll itself to make focused INPUT visible and clicked element/node will go out of view
	_onScrollHandler: function(evt, mouse)
	{
		var i, ul, top,
			elem = this._element,
			height = elem ? elem.offsetHeight : 0,
			fe = this.get_focusElement();
		if (!elem || !height || !fe)
			return;
		top = elem.scrollTop;
		// situation when height of tree is very large and browser is scrolled: top of tree is not visible
		// adjust for location of clicked element/node
		if (mouse)
		{
			mouse = evt.target;
			if (mouse)
				mouse = mouse.offsetTop;
			// find UL (container of mouse-element) in order to verify offsetTop
			ul = this._element.childNodes;
			i = ul.length;
			while(i-- > 0)
				if (ul[i].nodeName == "UL")
					break;
			if (i >= 0)
			{
				// real offset of element/node within tree
				mouse -= ul[i].offsetTop;
				// verify that value is in range
				if (mouse < top)
					mouse = top + 10;
				else if (mouse > top + height)
					mouse = top + height - 20;
			}
			else
				// failure to find UL
				mouse = top + 10;
			this._focusTopShift = mouse - top;
		}
		fe.style.marginTop = (top + (this._focusTopShift || 10)) + 'px';
		fe.style.marginLeft = (elem.scrollLeft + 10) + 'px';
	},
	_updateNarratorInfo: function()
	{
		
		var activeNodeAnchor = this._activeNode ? this._activeNode.get_anchorElement() : null;
		var fe = this.get_focusElement();
		if(fe && activeNodeAnchor)
			fe.title = activeNodeAnchor.innerHTML;
	},
	
	_focusEventElement: function(evt)
	{
		
		var fe = this.get_focusElement();
		if (fe && !this._element.disabled) try
		{
			if (evt)
				this._onScrollHandler(evt, true);
			// L.T. 7-APR-2011 71133 Input focus is not give to the control, when address bar is focused.
			if ($util.IsIE && document.hasFocus && !document.hasFocus())
				document.focus();
			fe.focus();
		} catch (ex) {}
	},
	
	__get_scrollbarWidth: function()
	{
		if ($util.isNullOrUndefined(this.__scrollbarWidth))
		{
			var scr = null;
			var inn = null;
			var wNoScroll = 0;
			var wScroll = 0;

			// Outer scrolling div
			scr = document.createElement('div');
			scr.style.position = 'absolute';
			scr.style.top = '-1000px';
			scr.style.left = '-1000px';
			scr.style.width = '100px';
			scr.style.height = '50px';
			// Start with no scrollbar
			scr.style.overflow = 'hidden';

			// Inner content div
			inn = document.createElement('div');
			inn.style.width = '100%';
			inn.style.height = '200px';

			// Put the inner div in the scrolling div
			scr.appendChild(inn);
			// Append the scrolling div to the doc
			document.body.appendChild(scr);

			// Width of the inner div sans scrollbar
			wNoScroll = inn.offsetWidth;
			// Add the scrollbar
			scr.style.overflow = 'auto';
			// Width of the inner div width scrollbar
			wScroll = inn.offsetWidth;

			// Remove the scrolling div from the doc
			document.body.removeChild(document.body.lastChild);

			// Pixel width of the scroller
			this.__scrollbarWidth = wNoScroll - wScroll;
		}
		return this.__scrollbarWidth;
	},
	
	get_collapseImageToolTip: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataTree.collapseImageToolTip">
		/// Gets the collapse image alt text.
		/// </summary>
		/// <value type="String" />
		return this._collapseImageToolTip;
	},

	get_expandImageToolTip: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataTree.expandImageToolTip">
		/// Gets the expand image alt text.
		/// </summary>
		/// <value type="String" />
		return this._expandImageToolTip;
	},
	_onClickHandler: function(evt)
	{
		if (this._cancelClick)
			$util.cancelEvent(evt);
		delete this._cancelClick;
	},
	_onMouseupHandler: function(elem, adr, browserEvent)
	{
		delete this._cancelClick;
		if (this._isUserElem(browserEvent))
			return;
		if (this._nodeInEditMode)
			return;
		var node = this._itemCollection._getUIBehaviorsObj().getItemFromElem(elem);
		// K.D. May 4th, 2011 Bug #70220 Implementing suggested fix by V.S. He is right about having to check
		// whether the node mouse up is fired on is the same as the one mouse down is fired on
		



		var mouseDownNode = this._correctNode;
		delete this._correctNode;
		// K.D. August 26th, 2011 Bug #84896 When we have EnableExpandOnClick and the tree is scrolled
		// we have a different target on mouse down and mouse up because the tree has collapsed
		// before the mouse up.
		if((!mouseDownNode || !node || node != mouseDownNode) && !this.get_enableExpandOnClick())
			return; 
		// K.D. August 26th, 2011 Bug #84896 When we have EnableExpandOnClick and the tree is scrolled
		// we have a different target on mouse down and mouse up because the tree has collapsed
		// before the mouse up.
		if(this.get_enableExpandOnClick())
			node = mouseDownNode;
		if (node && browserEvent)
		{
			var clickedOnDTN = false; 
			var mainEl = this.get_element();
			var parent = browserEvent.target;
			//L.T. March 18, 2010 29837 Apply the fix for 27360 to be applied here too.
			while (parent && parent != mainEl && (parent.nodeName != "UL" || (parent.nodeName=="UL" && parent.parentNode && parent.parentNode.nodeName!="LI") || (parent.nodeName=="UL" && parent.parentNode && parent.parentNode.nodeName=="LI" && parent.parentNode.getAttribute && !parent.parentNode.getAttribute("adr"))))
			{
				if (parent.getAttribute("mkr") == "dtnIcon" || parent.getAttribute("mkr") == "dtnContent" || (parent.nodeName=="LI" && parent.childNodes[0] && parent.childNodes[0].nodeName=="DIV" && parent.getAttribute("adr")))
				{
					clickedOnDTN = true;
					break;
				}
				parent = parent.parentNode;
			}
			// raising NodeClick event no matter what button is pressed
			if (clickedOnDTN && node.get_enabled())
			{
				
				var leftButton = browserEvent.button === '0' || browserEvent.button === 0;
				// K.D. February 27th, 2012 Bug #102908 Node click flag needs to be toggled only if it's clicked with
				// left mouse button
				if (leftButton)
					
					node._toggleClicked();
				// K.D. December 4th, 2013 Bug #158108 NodeClick event is always raised with left mouse button (0 hardcoded). Changing to actually pass the event button.
				var evntArgs = this._raiseClientEvent('NodeClick', 'DataTreeNode', browserEvent, null, node, node._get_address(), browserEvent.button);
				
				if (!leftButton)
					return;
				if (evntArgs && evntArgs.get_cancel && evntArgs.get_cancel())
				{
					
					node._toggleClicked();
					this._cancelClick = true;
				}
				else
				{
					if (this._navigateOnAreaClick && browserEvent.target.nodeName != "SPAN" && browserEvent.target.nodeName != "A") {
						node._navigateOnClick();
					} else {
						// K.D. September 2nd, 2013 Bug #150523 When using LOD after populating an item and then clicking on any item the # is added to the address bar.
						var href = node.get_navigateUrl();
						if (!node.get_enabled() || (href && href.lastIndexOf('#') + 1 === href.length)) {
							this._cancelClick = true;
						}
					}
				}
			}
			// L.T. March 18, 2010 29837 Group headers are not scrolling when pressing the scrollbar arrows in Firefox
			if($util.IsFireFox && !clickedOnDTN)
			{
				var container = browserEvent.target;
				if(container.nodeName == "UL" &&
					container.parentNode &&
					container.parentNode.nodeName == "LI" &&
					container.parentNode.getAttribute &&
					container.parentNode.getAttribute("adr") &&
					container.style.overflowX == "hidden" &&
					container.style.overflowY == "auto")
				{   //We are clicking on the scrollbar, in case of WebExplorerBar
					var containerBounds = Sys.UI.DomElement.getBounds(container);
					var isNavigatingUp = browserEvent.clientY - containerBounds.y < containerBounds.height / 2;
					if(isNavigatingUp)
					{
						container.scrollTop -= 10;
					}
					else
					{
						container.scrollTop += 10;
					}
				}
			}
			if(this._web)
			{
				
				var parentFirstChild = parent ? $util.skipTextNodes(parent.firstChild) : null;
				var firstChild = parentFirstChild ? $util.skipTextNodes(parentFirstChild.firstChild) : null;
				if (parentFirstChild && parentFirstChild.nodeName == "DIV" && firstChild && (firstChild.nodeName == "A" || firstChild.nodeName == "IMG"))
				{
					this._focusEventElement(browserEvent);
				}
				// K.D. Oct. 13, 2010 Bug #57126 
				// An input element inside ExplorerBar isnt focused on click thus focus is forced
				if (elem.nodeName == "INPUT")
				{
					try
					{
						elem.focus();
					}
					catch (err) { }
				}
			}
			else
			{
				
				if (parent && parent.nodeName != "TD")
				{
					this._focusEventElement(browserEvent);
				}
			}
			if (!parent)
			{
				this._focusEventElement(browserEvent);
			}
			this._updateNarratorInfo(elem);
		}
	},
	
	_onDblclickHandler: function(elem, adr, browserEvent)
	{
		if (!this._nodeEditing.get_enableOnDoubleClick()) return;
		//I.I. 95975: When node is in edit mode and click on it edit mode closes
		if (this._currentEditor != null && browserEvent.target == this._currentEditor._element) return;
		if (browserEvent.target.tagName == "A" && browserEvent.button == 0)
		{
			var activeNode = this.get_activeNode();
			if (activeNode != null)
			{
				var nodeEditable = activeNode.get_editable();
				if (nodeEditable == 2 || (nodeEditable == 0 && this._nodeEditing.get_enabled()))
				{
					
					var activeNodeEl = activeNode.get_styleElement();
					if (activeNodeEl)
					{
						Infragistics.Utility.toggleCompoundClass(activeNodeEl, this._hoverCssClassResolved(activeNode), false);
					}
					
					this._newSelectedNodes = [];
					this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
					
					this._enterNodeEditing(activeNode);
				}
			}
		}
	},

	
	







	_setupCollections: function()
	{
		if (!this._initCollections) {
			this._itemCollection = this._collectionsManager.register_collection(0, $IG.NodeCollection);

			if (this._usesCollectionsClientState && !this._get_enableClientRendering())
			{
				this._collectionsManager._clientStateManagers[0] = new $IG.WebDataTreeCollectionClientStateManager(this._collectionsManager.get_collection(0), this._id);
			}
			else if (this._usesCollectionsClientState && this._get_enableClientRendering())
			{
				// The current collection has a different format than the one the CSM initializes from, but carries the same data,
				// thus the collection is temporarily transformed in order to initialize the manager
				var currentCollection = this._dataStore[4];
				var tempCollection = [];

				tempCollection = this._getTemporaryCollection(currentCollection, tempCollection);

				this._collectionsManager._clientStateManagers[0] = new $IG.WebDataTreeCollectionClientStateManager(tempCollection, this._id);
			}

			this._itemCollection._csm = this._collectionsManager._clientStateManagers[0];
		
			var treeBehavior = new $IG.DataTreeUIBehaviorsObject(this, this._itemCollection);
			this._collectionsManager.registerUIBehaviorsEx(this._itemCollection, treeBehavior);

			var uiBehaviorsObj = this._itemCollection._getUIBehaviorsObj();
			uiBehaviorsObj.select = this._uiBehaviorsObject_select;
			uiBehaviorsObj.initElemAttr = this._uiBehaviorsObject_initElemAttr;
			this._initCollections = true;
		}
	},
	// END OVERRIDES

	// Creates a temporary collection in order to initialize the ClientStateManager and use it
	_getTemporaryCollection: function(currentCollection, newCollection)
	{
		for(var i = 0, len = currentCollection.length; i < len; i++)
		{
			var fullAddress = currentCollection[i].FullAddress;
			newCollection[fullAddress] = [];
			newCollection[fullAddress][0] = [];
			newCollection[fullAddress][0][$IG.NavItemProps.Text[0]] = currentCollection[i].Text;

			if(currentCollection[i].NavigateUrl && currentCollection[i].NavigateUrl.length > 0)
				newCollection[fullAddress][0][$IG.NavItemProps.NavigateUrl[0]] = currentCollection[i].NavigateUrl;

			if(currentCollection[i].Target)
				newCollection[fullAddress][0][$IG.NavItemProps.Target[0]] = currentCollection[i].Target;

			if(currentCollection[i].Value && currentCollection[i].Value.length > 0)
				newCollection[fullAddress][0][$IG.NavItemProps.Value[0]] = currentCollection[i].Value;

			if(currentCollection[i].Expanded)
				newCollection[fullAddress][0][$IG.DataTreeNodeProps.Expanded[0]] = currentCollection[i].Expanded;

			//newCollection[fullAddress][0][$IG.DataTreeNodeProps.Editable[0]] = $IG.DataTreeNodeProps.Editable[1];
			//newCollection[fullAddress][0][$IG.DataTreeNodeProps.NodeEdited[0]] = $IG.DataTreeNodeProps.NodeEdited[1];

			if(currentCollection[i].Selected)
				newCollection[fullAddress][0][$IG.DataTreeNodeProps.Selected[0]] = currentCollection[i].Selected;

			if(currentCollection[i].Nodes)
				this._getTemporaryCollection(currentCollection[i].Nodes, newCollection);
		}

		return newCollection;
	},

	// PROTECTED METHODS
	_loadImages: function(element)
	{
		var imageContainer = $get(this.get_id() + "_Images");
		this._imageList = imageContainer.getElementsByTagName("IMG");
		var images = element.getElementsByTagName("IMG");
		for (var i = 0, len = images.length; i < len; i++)
		{
			var image = images[i];
			this._resolveImage(image);
		}
	},

	_ensureNode: function(e)
	{
		this._initElemAttr(e);
		var adr = e.getAttribute("adr");
		
		if (!adr && adr !== 0)
			return null;
		var node = this._itemCollection._getObjectByAdr(adr);
		if (!node && e)
			node = this._itemCollection._addObject($IG.Node, e, adr);
		return node;
	},

	_resolveImage: function(image)
	{
		var index = image.className;
		
		if (!$util.isEmpty(index) && !isNaN(index))
		{
			
			
			image.className = "";
			image.parentNode._expImage = image;
			if (this._imageList.length < 4)
			{
				if (index == "1" || index == "2")
				{
					image.setAttribute("idx", index);
				}
				image.setAttribute("nidx", index);
			}
			else
			{
				if (index == "3" || index == "4" || index == "6" || index == "7" || index == "9" || index == "10" || index == "14" || index == "15")
				{
					image.setAttribute("idx", index);
				}
				// tag, the rest of connector lines images
				image.setAttribute("cidx", index);
			}
		}
	},

	



















	_populateItem: function(node)
	{
		
		if(this.__isPopulating)
			return;
			
		var args = this._raiseClientEvent('NodePopulating', 'DataTreeNode', null, null, node);
		if (args && args.get_cancel())
			return;

		this.__showDataLoadingMessage(node);

		var adr = node._get_address();
		var cbo = this._callbackManager.createCallbackObject();
		var nodeDisplayChain = this._getDisplayChain(node, adr);

		cbo.serverContext.type = cbo.clientContext.type = "populate";
		cbo.serverContext.parent = adr;
		cbo.serverContext.dataPath = node.get_dataPath();
		cbo.serverContext.displayChain = nodeDisplayChain;
		cbo.clientContext.currentLoadingNodeText = node.get_text();
		cbo.clientContext.parentNode = node;
		this.__isPopulating = true;
		this._callbackManager.execute(cbo);
	},

	__showDataLoadingMessage: function(node)
	{
		var msgBox = this._elements["DataLoadingMessage"];
		
		if(!msgBox || msgBox == null)
			return;
			
		var e = node._element;
		
		e.appendChild(msgBox);
		
		msgBox.style.display = "";
		msgBox.style.visibility = "visible";
		msgBox.style.position = "relative";
	},
	
	__hideDataLoadingMessage: function()
	{
		var msgBox = this._elements["DataLoadingMessage"];
		
		if(!msgBox || msgBox == null)
			return;
			
		msgBox.parentNode.removeChild(msgBox);
			
		msgBox.style.display = "none";
		msgBox.style.visibility = "hidden";
		msgBox.style.position = "absolute";
	},
	
	_getDisplayChain: function(node, adr)
	{
		var level = adr.split(".").length;
		var nodeDisplayChain = "";
		if (this.get_enableConnectorLines())
		{
			var parent = node;
			while (parent != null)
			{
				var next;
				next = parent.get_nextVisibleNode();
				nodeDisplayChain += (next != null) ? "1" : "0";
				parent = parent.get_parentNode();
			}
		}
		return nodeDisplayChain;
	},

	_asyncPostbackTriggered: function()
	{
		






		if (this.get_enableDragDrop())
		{
			this._itemCollection._csm.clearLog();
		}
	},

	_notifyTreeControlsForAsyncPostback: function()
	{
		for(var c in ig_controls) {
			if (ig_controls.hasOwnProperty(c)) {
				var ctrl = ig_controls[c];
				if (ctrl._thisType == 'tree' && ctrl._id !== this._id) {
					ctrl._asyncPostbackTriggered();
				}
			}
		}
	},

	_responseComplete: function(callbackObject, responseObject, obj)
	{
		
		$IG.WebDataTree.callBaseMethod(this, '_responseComplete', [callbackObject, responseObject, obj]);
		var type = callbackObject.serverContext.type;
		if($util.isNullOrUndefined(type))
			type = callbackObject.serverContext.eventName;

		if (type == "populate")
		{
			this.__hideDataLoadingMessage();
			
			var i, parentNode = callbackObject.clientContext.parentNode;
			var e = parentNode ? parentNode._element : null;
			if (!e)
				return;
			var addTransAct, csm = this._itemCollection;
			if (csm)
				csm = csm._csm;
			if (csm)
			{
				
				addTransAct = csm.addTransAct = csm.addTransAct || {};
				addTransAct[parentNode._address] = true;
			}
			if (!this._get_enableClientRendering())
			{
				// K.D. July 15th 2013 Bug #144549 When the UL already exists a new UL is created after it
				// and if add operations are performed then the nodes are not visible as they are added
				// to the old UL
				var ul = $adrutil.getImmediateElementsByTagName(e, "UL");
				if (!ul || ul.length <= 0) {
					e.innerHTML += responseObject.context[0];
				} else {
					var temp = document.createElement('div');
					temp.innerHTML = responseObject.context[0];
					e.replaceChild(temp.firstChild, ul[0]);
				}
				var nodeCount = responseObject.context.length;
				for (i = 1; i < nodeCount; i++)
				{
					var response = eval(responseObject.context[i]);
					var adr = response[0];
					var props = response[1];
					
					if (addTransAct)
						addTransAct[adr] = true;
					csm.set_itemProps(adr, props);
				}
			}
			else
			{
				var parentDataItem = parentNode._element._dataItem;
				parentDataItem.Nodes = eval(responseObject.context[0]);
				this._dataBindChildren(parentDataItem, parentNode._element);
			}
			
			i = parentNode.get_checkState() == 1 ? parentNode.get_childrenCount() : 0;
			while (i-- > 0)
			{
				var n = parentNode.get_childNode(i);
				if (n)
					// save checked state as transaction, but not property
					n._set_value($IG.DataTreeNodeProps.CheckState, n.get_checkState());
			}
			
			var img = parentNode._get_expandCollapseElement();

			
			
			
			






			this._loadImages(e);
			parentNode.set_populated(true);
			this._raiseClientEvent('NodePopulated', 'DataTreeNode', null, null, parentNode);
			
			
			parentNode.set_expanded(true, this._fireExpandEventsOnPopulate);
			this.__isPopulating = false;
		}
		else
		{
			var save1 = null; if (this._contSelStartNode != null) save1 = this._contSelStartNode._get_address();
			var save2 = this._contSelDir;
			var save3 = this._selectionType;
			var save4 = null; if (this._activeNode != null) save4 = this._activeNode._get_address();
			var save5 = this._currentEditor;
			
			
			var save8 = this.__controlActive;
			var save9 = this.__scrollbarWidth;
			this._soft_dispose();
			var props = eval(responseObject.context[0]);
			this.set_props(props);
			// we need to call setupCollections here, because if the code below is about to execute this._itemCollection._csm must be != null.
			this._setupCollections();
			// L.T. 23/12/2010 58734 Dragged child node throw error after click when AutoPostBackFlags NodeClick="Async"
			// There are situations like when we have two trees, we drag from tree A, to tree B
			// we click on the dragged child in tree B, but tree B has auto postback for NodeClick=Async
			// then a callback happens, collections are updated from the D&D event log and we need to 
			// send the updates for the node addresses, so this should be always done on async postback!
			// before it was only on NodeDropped event.
			var len = responseObject.context.length;
			// load the additional state if any the updated nodes addresses.
			for (var i = 1; i < len; i++)
			{
				
				if (responseObject.context[i].indexOf("{customResponse") == 0)
					continue;     
				var responsePart = eval(Sys.Serialization.JavaScriptSerializer.deserialize(responseObject.context[i]));
				this._itemCollection._csm.set_itemProps(responsePart.newAddress, eval(responsePart.state));
				var domNode = this._findInsertLocation(responsePart.initialAddress);
				$adrutil.buildNodeLiId(domNode, responsePart.newAddress);
			}
			
			this._itemCollection._csm.clearLog();
			this._notifyTreeControlsForAsyncPostback();
			this.preventInitEvent = true;
			this.initialize();
			this._contSelStartNode = save1 != null ? this.resolveItem(save1) : null;
			this._contSelDir = save2;
			this._selectionType = save3;
			this._activeNode = save4 != null ? this.resolveItem(save4) : null;
			this._currentEditor = save5;
			
			
			this.__controlActive = save8;
			this.__scrollbarWidth = save9;
			
			if ($IG.WebExplorerBar) for (var eb in ig_controls)
			{
				eb = ig_controls[eb];
				if (eb && eb._dtID && eb._tree == this)
				{
					try
					{
						$IG.WebExplorerBar.callBaseMethod(eb, '_responseComplete', [callbackObject, responseObject, obj]);
					}catch(ex){}
					try
					{
						eb.initialize();
					}catch(ex){}
					break;
				}
			}
		}
	},

	_onKeypressHandler: function(browserEvent)
	{
		var aNode = this.get_activeNode();
		var args = this._raiseClientEvent('KeyPress', 'DataTreeNode', window.event, null, aNode);
		if (args && args.get_cancel())
		{
			$util.cancelEvent(window.event);
			return;
		}
		if (this._nodeInEditMode == null)
		{
			if ($util.IsOpera)
			{
				this.__internalKeyHandler(window.event);
			}
		}
	},

	_onKeyupHandler: function(browserEvent)
	{
		var aNode = this.get_activeNode();
		var args = this._raiseClientEvent('KeyUp', 'DataTreeNode', browserEvent, null, aNode);
		if (args && args.get_cancel())
		{
			$util.cancelEvent(browserEvent);
			return;
		}
		
		if (this._nodeInEditMode == null && aNode != null)
		{
			this._updateNarratorInfo(aNode.get_element());
		}
	},

	_onKeydownHandler: function(browserEvent)
	{
		var aNode = this.get_activeNode();
		var args = this._raiseClientEvent('KeyDown', 'DataTreeNode', browserEvent, null, aNode);
		if (args && args.get_cancel())
		{
			$util.cancelEvent(browserEvent);
			return;
		}
		if (this._nodeInEditMode == null)
		{
			if (!$util.IsOpera)
			{
				this.__internalKeyHandler(browserEvent);
			}
		}
	},
	
	


	__internalKeyHandler: function(browserEvent)
	{
		var key = browserEvent.keyCode;
		switch (key)
		{
			case Sys.UI.Key.up:
			case Sys.UI.Key.down:
				this._newSelectedNodes = [];
				var oldNode = this.get_activeNode();
				if (oldNode == null)
				{
					oldNode = this.getNode(0);
					this.set_activeNode(oldNode, true);
					$util.cancelEvent(browserEvent);
					return;
				}
				else
				if (this._selectionType == 1 || this._selectionType == 2)
				{
					var beginOfContSel = this._contSelStartNode == null;
					if (browserEvent.shiftKey)
					{
						if (oldNode.get_enabled())
						{
							if (this._contSelStartNode == null)
							{
								this._contSelStartNode = oldNode;
							}
						}
						if ((this._contSelDir == 1 && key == Sys.UI.Key.down) ||
							(this._contSelDir == 2 && key == Sys.UI.Key.up))
						{
							if (oldNode == this._contSelStartNode)
							{
								this._contSelDir = 0;
							}
							else
							{
								if (oldNode.get_enabled())
								{
									this._newSelectedNodes = Array.clone(this._selectedNodes);
									var aNode = this._newSelectedNodes.pop();
									this._addRemoveSelection(this._selectedNodes, this._newSelectedNodes, aNode, false, true);
								}
							}
						}
					}
				}
				var newNode = null;
				if (key == Sys.UI.Key.up)
				{
					if (browserEvent.shiftKey && this._contSelDir == 0) this._contSelDir = 1;
					newNode = oldNode._get_navigationUpNode();
				}
				if (key == Sys.UI.Key.down)
				{
					if (browserEvent.shiftKey && this._contSelDir == 0) this._contSelDir = 2;
					newNode = oldNode._get_navigationDownNode();
				}

				if(newNode != null && !newNode.get_enabled() && this._disableNodeCollapseExpand)
				{
					
					while(newNode != null && !newNode.get_enabled())
					{
						if(key == Sys.UI.Key.up)
						{
							newNode = newNode._get_navigationUpNode();
						}
						else if(key == Sys.UI.Key.down)
						{
							newNode = newNode._get_navigationDownNode();
						}
					}
				}

				if (newNode != null)
				{
					this.set_activeNode(newNode, true);

					//A.T. handling scrollbar automatic update when navigating with keyboard
					this.__updateScrollbar(newNode, key == Sys.UI.Key.down);
					
					if (this._selectionType == 1 || this._selectionType == 2)
					{
						if (browserEvent.shiftKey && this._selectionType == 2)
						{
							if ((this._contSelDir == 1 && key == Sys.UI.Key.up) ||
								(this._contSelDir == 2 && key == Sys.UI.Key.down))
							{
								if (newNode.get_enabled())
								{
									if (beginOfContSel)
									{
										this._newSelectedNodes = [];
										this._newSelectedNodes.push(oldNode);
										this._newSelectedNodes.push(newNode);
										this._changeSelection(this._selectedNodes, this._newSelectedNodes, newNode, true);
									}
									else
									{
										this._newSelectedNodes = Array.clone(this._selectedNodes);
										this._newSelectedNodes.push(newNode);
										this._addRemoveSelection(this._selectedNodes, this._newSelectedNodes, newNode, true, true);
									}
								}
							}                        
						}
						else
						if (!browserEvent.ctrlKey)
						{
							this._contSelDir = 0;
							this._contSelStartNode = null;
							this._newSelectedNodes = [];
							if (newNode.get_enabled())
							{
								this._newSelectedNodes.push(newNode);
							}

							if(newNode.get_enabled() && !this._disableNodeCollapseExpand)
							{
								this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
							}
						}
					}
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.space:
				var aNode = this.get_activeNode();
				if (aNode != null && aNode.get_enabled())
				{
					if (this._selectionType == 1 || this._selectionType == 2)
					{
						
						this._cssDelay = true;
						this._selectNode(aNode, true, browserEvent);
						delete this._cssDelay;
					}
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.left:
				var aNode = this.get_activeNode();
				if (aNode != null)
				{
					if(aNode.get_expanded() && (aNode.get_enabled() && !this._disableNodeCollapseExpand))
					{
						aNode.set_expanded(false, true);
					}
					else
					{
						var parentNode = aNode.get_parentNode();
						if(parentNode && (parentNode.get_enabled() && !this._disableNodeCollapseExpand))
						{
							this.set_activeNode(parentNode, true);
							if (this._selectionType == 1 || this._selectionType == 2)
							{
								if (!browserEvent.ctrlKey)
								{
									this._newSelectedNodes = [];
									this._newSelectedNodes.push(parentNode);
									this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
								}
							}
						}                        
					}
				}
				else
				{
					this.set_activeNode(this.getNode(0), true);
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.right:
				var aNode = this.get_activeNode();
				if (aNode != null && (aNode.get_isEmptyParent() || aNode.hasChildren()))
				{
					if(aNode.get_expanded() && (aNode.get_enabled() && !this._disableNodeCollapseExpand))
					{
						var firstChild = aNode.get_childNode(0);
						if (firstChild)
						{
							this.set_activeNode(firstChild, true);
							if (this._selectionType == 1 || this._selectionType == 2)
							{
								if (!browserEvent.ctrlKey)
								{
									this._newSelectedNodes = [];
									this._newSelectedNodes.push(firstChild);
									this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
								}
							}
						}
					}
					else if(aNode.get_enabled() && !this._disableNodeCollapseExpand)
					{
						aNode.set_expanded(true, true);
					}
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.enter:
				var aNode = this.get_activeNode();
					 var evt = !aNode || !aNode.get_enabled() ? null : this._raiseClientEvent('NodeClick', 'DataTreeNode', browserEvent, null, aNode, aNode._get_address(), -1);
					 if (!evt || !evt.get_cancel || !evt.get_cancel())
					 {
					aNode._navigateOnClick();
					aNode._toggleClicked();
					this._focusEventElement();
				}
				$util.cancelEvent(browserEvent);
				break;
			case 113: // F2
				if (this._nodeEditing.get_enableOnF2())
				{
					var activeNode = this.get_activeNode();
					if (activeNode != null)
					{
						var nodeEditable = activeNode.get_editable();
						if (nodeEditable == 2 || (nodeEditable == 0 && this._nodeEditing.get_enabled()))
						{
							this._enterNodeEditing(activeNode);
						}
					}
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.home:
				var firstNode = this.getNode(0);
				if(firstNode != null &&
				   firstNode != this.get_activeNode() &&
				   (firstNode.get_enabled() && !this._disableNodeCollapseExpand))
				{
					this.set_activeNode(firstNode, true);
					if (this._selectionType == 1 || this._selectionType == 2)
					{
						this._newSelectedNodes = [];
						this._newSelectedNodes.push(firstNode);
						this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
					}
				}
				$util.cancelEvent(browserEvent);
				break;
			case Sys.UI.Key.end:
				var aNode = this.getNode(0);
				if (aNode != null)
				{
					var nextNode = null;
					while (true)
					{
						nextNode = aNode.get_nextNode();
						if (nextNode == null) break;
						aNode = nextNode;
					}
					nextNode = null;
					while (true)
					{
						nextNode = aNode._get_navigationDownNode();
						if (nextNode == null) break;
						aNode = nextNode;
					}

					if(aNode.get_enabled() && !this._disableNodeCollapseExpand)
					{
						this.set_activeNode(aNode, true);
						if (this._selectionType == 1 || this._selectionType == 2)
						{
							this._newSelectedNodes = [];
							this._newSelectedNodes.push(aNode);
							this._changeSelection(this._selectedNodes, this._newSelectedNodes, true);
						}
					}
				}
				$util.cancelEvent(browserEvent);
				break;
		}
	},
	
	__updateScrollbar: function (nextItem, isNavigatingDown)
	{
		//A.T. if we have scrollbar for the nodes container (WebExplorerBar case) , we need to change scrollTop as well
		var groupNode = nextItem;
		// When going up/donw on child node find the parent
		// root node that is the scrollable area.
		while(groupNode != null && groupNode.get_level() > 0)
		{
			groupNode = groupNode.get_parentNode();
		}

		// The scrollable UL container area
		var parentContainer = groupNode.get_element().childNodes[1];
		if(parentContainer != null && parentContainer != 'undefined')
		{
			var pos = $util.getPosition(nextItem.get_element());
			var container_pos = $util.getPosition(parentContainer);

			var nextItemHeight = Sys.UI.DomElement.getBounds(nextItem.get_element()).height;
			if(nextItem.hasChildren() && nextItem.get_expanded())
			{
				nextItemHeight = Sys.UI.DomElement.getBounds(nextItem.get_element().childNodes[0]).height;
			}
			
			if (!isNavigatingDown)
			{
				if (pos.y < container_pos.y + parentContainer.scrollTop) 
				{
					if(parentContainer.scrollTop - nextItemHeight >= 0)
					{
						parentContainer.scrollTop = parentContainer.scrollTop - nextItemHeight;
					}
					else 
					{
						parentContainer.scrollTop = 0;
					}
				}
			} 
			else
			{
				if(pos.y + nextItemHeight > container_pos.y + parentContainer.scrollTop + Sys.UI.DomElement.getBounds(parentContainer).height)
				{
					parentContainer.scrollTop = (pos.y + nextItemHeight) - (container_pos.y + Sys.UI.DomElement.getBounds(parentContainer).height);
				}
			}
		}
	},

	_onMouseDownHandler: function(browserEvent)
	{
		delete this._cancelClick;
		
		// K.D. May 4th, 2011 Bug #70220 Implementing suggested fix by V.S. He is right about having to check
		// whether the node mouse up is fired on is the same as the one mouse down is fired on
		//if (this.get_enableSingleBranchExpand()) {
		this._correctNode = this._itemCollection._getUIBehaviorsObj().getItemFromElem(browserEvent.target);
		//}
	},

	_onMouseOverHandler: function(browserEvent)
	{
		this.__cancelBlur = true;
		this.__x = browserEvent.clientX;
		this.__y = browserEvent.clientY;
	},

	_onMouseOutHandler: function(browserEvent)
	{
		this.__cancelBlur = false;
	},

	_onFocusHandler: function(browserEvent)
	{
		if(!this.__controlActive)
		{
			var el = this.get_element();
			Sys.UI.DomElement.toggleCssClass(el, this._controlActiveCssClass);
			this.__controlActive = true;
			var aNode = this.get_activeNode();
			if(!aNode)
			{
				// We can focus the control if we click on the + of some node.
				// Then we should focus this element, not the first one.
				if($util.IsFireFox)
				{
					if(!$util.isNullOrUndefined(browserEvent.rawEvent.explicitOriginalTarget))
					{
						aNode = this._itemCollection._getUIBehaviorsObj().getItemFromElem(
							browserEvent.rawEvent.explicitOriginalTarget);
					}
				}

				if(!aNode)
				{
					var elemAtPoint = document.elementFromPoint(this.__x, this.__y);
					aNode = this._itemCollection._getUIBehaviorsObj().getItemFromElem(elemAtPoint);
				}

				if(!aNode)
					aNode = this.getNode(0);

				if(aNode != null && !aNode.get_enabled() && this._disableNodeCollapseExpand)
				{
					
					while(aNode != null && !aNode.get_enabled())
					{
						aNode = aNode._get_navigationDownNode();
					}
				}

				this.set_activeNode(aNode, true);
			}
			else
			{
				this._toggleCss(aNode, this._activeCssClassResolved(aNode), true);
			}
			this._set_value($IG.DataTreeProps.ControlFocused, true);
		}
	},
	
	_onBlurHandler: function(browserEvent)
	{
		if(!this.__cancelBlur)
			setTimeout(this.__createDelegate(this, this._onBlurHandlerFinal, [browserEvent]), 10);
	},
	
	_onBlurHandlerFinal: function(browserEvent)
	{
		
		if(this.__isPopulating)
			return;

		var el = this.get_element();
		Infragistics.Utility.toggleCompoundClass(el, this._controlActiveCssClass, false);
		this.__controlActive = false;
		var aNode = this.get_activeNode();
		if (aNode && aNode.get_styleElement)
		{
			this._toggleCss(aNode, this._activeCssClassResolved(aNode));
		}
		this._set_value($IG.DataTreeProps.ControlFocused, false);
	},

	
	_hoverItem: function(node, val)
	{
		if (this.get_enableHotTracking() && node.get_enabled())
		{
			var elem = node.get_styleElement();
			if (elem)
				Infragistics.Utility.toggleCompoundClass(elem, this._hoverCssClassResolved(node), val);
			if (val)
				this._raiseClientEvent('NodeHovered', 'DataTreeNode', null, null, node);
			else
				this._raiseClientEvent('NodeUnhovered', 'DataTreeNode', null, null, node);
		}
	},

	_shouldSelect: function(item, e)
	{
		return true;
	},

	_shouldHover: function(item, e)
	{
		if (e != null)
		{
			var mainEl = this.get_element();
			var parent = e.target;
			while (parent && parent != mainEl)
			{
				var liChild = $util.skipTextNodes(parent.childNodes[0]);
				if(parent.nodeName == "UL" && liChild && liChild.nodeName == "LI" &&
					$util.skipTextNodes(liChild.childNodes[0]) &&
					$util.skipTextNodes(liChild.childNodes[0]).nodeName == "DIV")
				{
					// If you hover the scroll bar of expanded group in WebExplorerBar,
					// the group header should not be hovered.
					return false;
				}

				if(parent.getAttribute("mkr") == "dtnIcon" ||
				   parent.getAttribute("mkr") == "dtnContent" ||
				   (parent.nodeName == "LI" && parent.childNodes[0] &&
					parent.childNodes[0].nodeName=="DIV" && parent.getAttribute("adr")))
				{
					if(parent.nodeName == "LI" && parent.childNodes[0] &&
					   parent.childNodes[0].nodeName == "DIV" && parent.getAttribute("adr"))
					{
						// we are here only if WebExplorerBar is rendered. The tree does not contain DIV inside the LI.
						return this.__ebarCheckShouldHover(e);
					}
					else
					{
						return true;
					}
				}
				parent = parent.parentNode;
			}
		}
		return false;
	},
	
	__ebarCheckShouldHover: function(e)
	{
		if($util.isNullOrUndefined(e))
			return true;

		var relTarget;
		if(e.type == "mouseover")
		{
			relTarget = e.rawEvent.relatedTarget || e.rawEvent.fromElement;
		}
		else if(e.type == "mouseout")
		{
			relTarget = e.rawEvent.relatedTarget || e.rawEvent.toElement;
		}

		









		if(!$util.isNullOrUndefined(relTarget))
		{
			var parentLi = this._getNearestParentLi(e.target);
			var relTargetParentLi = this._getNearestParentLi(relTarget);

			if($util.isNullOrUndefined(parentLi) ||
			   this._isControlDiv(parentLi) ||
			   $util.isNullOrUndefined(relTargetParentLi) ||
			   parentLi != relTargetParentLi)
				return true;

			// Check whether we are moving inside the elements of the LI, if so return false.
			var currentNodeElement = relTarget;
			var nodeElement = parentLi;
			var isRelatedTargetContainedInLi;
			if ($util.IsIE6 || $util.IsIE7 || $util.IsIE8)
			{
				isRelatedTargetContainedInLi = nodeElement.contains(currentNodeElement) || nodeElement == currentNodeElement;
			}
			else
			{
				if (nodeElement.compareDocumentPosition)
				{
					// if currentNodeElement follows (4) and is contained by (16) nodeElement, the method returns 20.
					// convert it to bool ! and then again ! to return the correct bool value.
					isRelatedTargetContainedInLi = !!(nodeElement.compareDocumentPosition(currentNodeElement) & 16) || nodeElement == currentNodeElement;
				}
			}
			return !isRelatedTargetContainedInLi; // then do not hover/unhover, because we are moving in the LI.
		}
		return true;
	},

	_getNearestParentLi: function(parentLi)
	{
		while(!$util.isNullOrUndefined(parentLi) &&
			  (parentLi.nodeName != "LI" && (!parentLi.getAttribute || $util.isNullOrUndefined(parentLi.getAttribute("adr")))) &&
			  !this._isControlDiv(parentLi))
		{
			parentLi = parentLi.parentNode;
		}
		return parentLi;
	},

	_isControlDiv: function(domNode)
	{
		if(!$util.isNullOrUndefined(domNode) && domNode.nodeName == "DIV")
		{
			// all Aikido IG controlls have this type of CSS class applied.
			var regex = new RegExp("ig_\\w*Control");
			var controlClass = $util.getCssClass(domNode);
			return (!$util.isNullOrUndefined(controlClass) && regex.test(controlClass));
		}
		return false;
	},

	_selectedCssClassResolved: function(node)
	{
		return node.get_selectedCssClass() || this._nodeSelectedCssClass;
	},

	_activeCssClassResolved: function(node)
	{
		return node.get_activeCssClass() || this._nodeActiveCssClass;
	},

	_hoverCssClassResolved: function(node)
	{
		return node.get_hoverCssClass() || this._nodeHoverCssClass;
	},

	_disabledCssClassResolved: function(node)
	{
		return node.get_disabledCssClass() || this._nodeDisabledCssClass;
	},

	_keyPressed: function(uiBehaviorsObj, key, currentElem, currentADR, item, evnt)
	{
		//alert("_keyPressed");
		if (!item)
			return;
		var nextItem = null;
		//A.T.
		var isNavigatingDown=true;
		switch (key)
		{
			case Sys.UI.Key.up:
				nextItem = this._itemCollection._getPreviousItem(item, true, true, true);
				isNavigatingDown=false;
				break;
			case Sys.UI.Key.down:
				nextItem = this._itemCollection._getNextItem(item, true, true, true);
				break;
		}
		if (nextItem)
		{
			uiBehaviorsObj.focus(nextItem, nextItem.get_anchorElement(), nextItem.get_element().getAttribute("adr"));
			this._cancelEvent(evnt);
		}
	},
	
	_ensureActiveVisible: function(parentNode)
	{
		var aNode = this.get_activeNode();
		if (aNode != null && !aNode.get_visible())
		{
			this.set_activeNode(parentNode, true);
		}
	},
	// END PROTECTED METHODS

	// PROPERTIES
	
	get_checkedNodes: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.checkedNodes">
		/// Returns an array holding all checked nodes.
		///</summary>
		///<value type="Array" elementType="Infragistics.Web.UI.Node"/>
		return Array.clone(this._checkedNodes);
	},
	
	get_checkBoxMode: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.checkBoxMode">
		/// Returns the current CheckBoxMode.
		/// 0-Off, 1-BiState, 2-TriState mode.
		///</summary>
		///<value type="Number" integer="true"/>
		return this._checkBoxMode;
	},
	
	get_enableAutoChecking: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableAutoChecking">
		/// Gets a boolean value that determines if auto checking is enabled.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableAutoChecking, true);
	},

	set_enableAutoChecking: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableAutoChecking">
		/// Enable or disable the auto checking feature.
		///</summary>
		///<param name="value" type="Boolean"></param>
		this._set_value($IG.DataTreeProps.EnableAutoChecking, value);
	},

	get_selectedNodes: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.selectedNodes">
		/// Returns an array holding all selected nodes.
		///</summary>
		///<value type="Array" elementType="Infragistics.Web.UI.Node"/>
		return Array.clone(this._selectedNodes);
	},
	
	get_selectionType: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.selectionType">
		/// Returns the UI selection type specified.
		/// 0-None, 1-Single, 2-multiple selection
		///</summary>
		///<value type="Number" integer="true"/>
		return this._selectionType;
	},
	
	set_selectionType: function(newType)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.selectionType">
		/// Sets the UI selection type.
		/// 0-None, 1-Single, 2-multiple selection
		///</summary>
		///<param name="newType" type="Number" integer="true">Selection type.</param>
		if (newType < 0 || newType > 2) return;
		this._selectionType = newType;
		this._set_value($IG.DataTreeProps.NodeSelectionType, this._selectionType);
	},

	getNode: function(index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.getNode">
		/// Returns the root node specified by the index parameter.
		///</summary>
		///<param name="index" type="Number" integer="true">Index of the node in the collection.</param>
		///<returns type="Infragistics.Web.UI.Node"/>
		return this._itemCollection.getNode(index);
	},

	getNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.getNodes">
		/// Returns the collection of root nodes for the datatree.
		///</summary>
		///<returns type="Infragistics.Web.UI.NodeCollection" elementType="Infragistics.Web.UI.Node"/>
		return this._itemCollection;
	},

	get_enableAjax: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableAjax">
		/// Returns a boolean value that indicates whether or not Ajax load on demand is enabled for the tree.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableAjax, true);
	},

	get_enableConnectorLines: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableConnectorLines">
		/// Returns a boolean value which indicates whether connector lines are displayed between nodes of the tree.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableConnectorLines, true);
	},

	










	get_enableExpandImages: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableExpandImages">
		/// Returns a boolean value which indicates whether expand images are displayed for nodes of the tree.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableExpandImages, true);
	},

	











	get_enableExpandOnClick: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableExpandOnClick">
		/// Returns a boolean value which indicates whether nodes can be expanded or collapsed when clicked with the mouse.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableExpandOnClick, true);
	},

	set_enableExpandOnClick: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableExpandOnClick">
		/// Sets a boolean value that determines whether nodes can be expanded or collapsed when clicked with the mouse.
		///</summary>
		return this._set_value($IG.DataTreeProps.EnableExpandOnClick, value);
	},

	get_enableDropInsertion: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableDropInsertion">
		/// Returns a boolean value which indicates whether nodes can be inserted between other nodes in a drag and drop operation.
		///</summary>
		return this._get_value($IG.DataTreeProps.EnableDropInsertion, true);
	},

	set_enableDropInsertion: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableDropInsertion">
		/// Sets a boolean value that determines whether nodes can be inserted between other nodes in a drag and drop operation.
		///</summary>
		this._set_value($IG.DataTreeProps.EnableDropInsertion, value);
	},

	get_dragDropMode: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.dragDropMode">
		/// Get a DragDropMode value which indicates whether nodes can be moved or copied or both during a drag and drop operation.
		///</summary>
		///<value type="Infragistics.Web.UI.DragDropMode">Get a value which indicates whether nodes can be moved or copied or both during a drag and drop operation.</value>
		return this._get_value($IG.DataTreeProps.DragDropMode, false);
	},

	set_dragDropMode: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.dragDropMode">
		/// Sets a DragDropMode value that determines whether nodes can be moved or copied or both during a drag and drop operation.
		///</summary>
		///<param type="Infragistics.Web.UI.DragDropMode">Specify drag drop mode preference.</param>
		this._set_value($IG.DataTreeProps.DragDropMode, value);
		this._itemCollection._getUIBehaviorsObj()._ddb.set_dragDropMode(value);
	},
	
	get_enableDragDrop: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableDragDrop">
		/// Get whether drag & drop is enabled for this control.
		///</summary>
		///<value type="Boolean">Get whether drag & drop is enabled for this control.</value>
		return this._getFlags().getDraggable();
	},
	
	get_allowDrop: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.allowDrop">
		/// Get whether the tree accepts nodes to be dragged to it from other trees on the page.
		///</summary>
		///<value type="Boolean">Get whether the tree accepts nodes to be dragged to it from other trees on the page.</value>
		return this._getFlags().getDroppable();
	},

	get_dataLoadingMessage: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.dataLoadingMessage">
		/// Returns a string value containing the text message to display when nodes are being fetched in an Ajax callback.
		///</summary>
		///<value type="String"/>
		return this._get_value($IG.DataTreeProps.DataLoadingMessage);
	},
	
	get_enableHotTracking: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableHotTracking">
		/// Gets a boolean value that determines if hot tracking if enabled.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableHotTracking, true);
	},

	set_enableHotTracking: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableHotTracking">
		/// Enable or disable the hot tracking feature.
		///</summary>
		///<param name="value" type="Boolean"></param>
		this._set_value($IG.DataTreeProps.EnableHotTracking, value);
	},

	get_animationEquationType: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.animationEquationType">
		/// Gets the animation equation type, which will be used for expanding or collapsing tree nodes.
		///</summary>
		///<value type="Number" integer="true"/>
		return this._get_value($IG.DataTreeProps.AnimationEquationType, false);
	},

	set_animationEquationType: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.animationEquationType">
		/// Sets the animation equation type, which will be used for expanding or collapsing tree nodes.
		///</summary>
		///<param name="value" type="Number" integer="true">Animation equation type.</param>
		this._set_value($IG.DataTreeProps.AnimationEquationType, value);
	},

	get_animationDuration: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.animationDuration">
		/// Gets the animation duration, which will be used for expanding or collapsing tree nodes.
		///</summary>
		///<value type="Number" integer="true"/>
		return this._get_value($IG.DataTreeProps.AnimationDuration, false);
	},

	set_animationDuration: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.animationDuration">
		/// Sets the animation duration, which will be used for expanding or collapsing tree nodes.
		///</summary>
		///<param name="value" type="Number" integer="true">Animation duration.</param>
		this._set_value($IG.DataTreeProps.AnimationDuration, value);
	},
	
	get_enableSingleBranchExpand: function() {
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableSingleBranchExpand">
		/// Gets a boolean value that determines if single branch expand is on.
		///</summary>
		///<value type="Boolean"/>
		return this._get_value($IG.DataTreeProps.EnableSingleBranchExpand, true);
	},

	set_enableSingleBranchExpand: function(value) {
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableSingleBranchExpand">
		/// Enable or disable the single branch expand feature.
		///</summary>
		///<param name="value" type="Boolean"></param>
		this._set_value($IG.DataTreeProps.EnableSingleBranchExpand, value);
	},

	get_singleBranchExpandLevel: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.singleBranchExpandLevel">
		/// Gets an integer value that determines up to which sub level single branch expand is done.
		///</summary>
		///<value type="Number" integer="true"/>
		return this._get_value($IG.DataTreeProps.SingleBranchExpandLevel, -1);
	},

	set_singleBranchExpandLevel: function(value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.singleBranchExpandLevel">
		/// Sets an integer value that determines up to which sub level single branch expand is done.
		///</summary>
		///<param name="value" type="Number" integer="true">Expand level.</param>
		this._set_value($IG.DataTreeProps.SingleBranchExpandLevel, value);
	},

	// END PROPERTIES

	
	
	__dragStart: function(uiBehavior, item, ddb, evntArgs)
	{
		
		if (this._nodeInEditMode || this._posted)
		{
			evntArgs.set_cancel(true)
			return;
		}

		var ddm = evntArgs.get_manager();
		var src = ddm.get_sourceElement();
		
		if(!$util.isNullOrUndefined(src) && !$util.isNullOrUndefined(src.getAttribute("idx")))
			evntArgs.set_cancel(true); // drag operation is started on expander image, cancel it.

		if(this.__saveDragData(ddm))
		{
			ddb.set_dragMarkup(this.__createInitialDragMarkup(ddm.get_dataObject()));
			var args = this._raiseClientEvent("DragStart", "DataTreeDragMove", null, null, evntArgs);
			this._enterCache[item._get_address()] = true;
			if(!$util.isNullOrUndefined(args) && args.get_cancel())
			{
				evntArgs.set_cancel(true);
				this._enterCache[item._get_address()] = false;
				// K.D. May 30th, 2011 Bug #74703 The drag markup has to be reset when DragStart is canceled
				// because otherwise if we change selection after innitial attempt to drag the markup would
				// be of the old selection
				this._dragMarkup = null;
				return;
			}
		}
		else
		{
			evntArgs.set_cancel(true);
		}
	},

	__saveDragData: function(ddm)
	{
		var result = false;
		var nodes = new Array();
		var source = this._selectedNodes; // if selection type is multiple get the nodes from here.

		if(this._selectionType == 0 || this._selectionType == 1)
		{
			// selection: none or single
			source = new Array();
			

			source.push(ddm.get_dataObject());
		}

		for(var i = 0; i < source.length; i++)
		{
			var flags = source[i]._getFlags();
			if(source[i].get_enabled() &&
			   flags.getDraggable())
				nodes.push(source[i]);
		}

		if(nodes.length > 0)
		{
			var dragData = new $IG.DragData(this._id, nodes, ddm);
			ddm.set_dataObject(dragData);
			result = true;
		}

		return result;
	},

	__createInitialDragMarkup: function(dragData)
	{
		// Create a container div, so that we are able to change its contenta while dragging.
		// Because D&D framework does not allow to change the drag markup after the drag start event.
		var mainDiv = document.createElement("div");
		mainDiv.appendChild(this.__createDragMarkup(dragData));
		return mainDiv;
	},

	__createDragMarkup: function(dragData)
	{
		if(!this._dragMarkup)
		{
			if($util.isNullOrUndefined(dragData))
				return null;

			var div = document.createElement("div");
			div.setAttribute("id", "dragMarkup");

			var ul = document.createElement("UL");
			this._toggleCss(ul, this._resolveClass("NodeGroup"), true);

			var nodes = dragData.get_nodes();
			var len = dragData.get_length();
			for(var i = 0; i < len; i++)
			{
				var childElem = nodes[i].get_element();
				if(!$util.isNullOrUndefined(childElem))
				{
					var child = childElem.cloneNode(true);
					if(this.get_enableConnectorLines())
						this._clearConnectorImages(child);
					// remove the UL if any.
					var childUL = $util.skipTextNodes(this._getNodeULTag(child));
					if(childUL && childUL.nodeName == "UL")
					{
						child.removeChild(childUL);
					}
					ul.appendChild(child);
				}
			}
			div.appendChild(ul);
			this._toggleCss(div, this._dragDropSettings.get_dragMarkupCssClass(), true);
			this._dragMarkup = div;
		}
		return this._dragMarkup;
	},
	
	__createDropIndicatorMarkup: function(toolTipText, itemText, isMove)
	{
		if($util.isNullOrUndefined(toolTipText) || $util.isNullOrUndefined(itemText))
			return null;

		var div = document.createElement("div");
		div.setAttribute("id", "dropIndicator");

		var img = document.createElement("img");
		img.setAttribute("src", (isMove ? this._dragDropSettings.get_indicatorMoveImageUrl() : this._dragDropSettings.get_indicatorCopyImageUrl()));
		if($util.IsQuirks)
		{
			img.style.display = "inline";
		}
		div.appendChild(img);

		var idx = toolTipText.indexOf(itemText);

		var toolTipTextSpan = document.createElement("span");
		toolTipTextSpan.innerHTML = toolTipText.substring(0, idx);

		var itemTextSpan = document.createElement("span");
		itemTextSpan.innerHTML = toolTipText.substring(idx);

		div.appendChild(toolTipTextSpan);
		div.appendChild(itemTextSpan);

		if($util.IsQuirks)
		{
			div.style.width = (toolTipText.length + itemText.length).toString() + "ex";
		}

		this._toggleCss(div, this._dragDropSettings.get_dropIndicator().get_cssClass(), true);
		return div;
	},
	
	__createDropInsertIndicatorMarkup: function(item, isBefore, isMove)
	{
		if($util.isNullOrUndefined(item))
			return null;

		var di = this._dragDropSettings.get_dropIndicator();

		return this.__createDropIndicatorMarkup((isBefore ? di.get_insertBeforeText(item.get_text()) : di.get_insertAfterText(item.get_text())), item.get_text(), isMove);
	},

	__createDropInsertBetweenIndicatorMarkup: function(item1, item2, isMove)
	{
		if($util.isNullOrUndefined(item1) || $util.isNullOrUndefined(item2))
			return null;

		// K.D. April 21, 2011 Bug #73064 We have to check whether the nodes are visible and if not search for 
		// the visible ones the null check underneath takes care of no previous or next visible nodes
		if(!item1.get_visible())
			item1 = item1.get_previousVisibleNode();

		if(!item2.get_visible())
			item2 = item2.get_nextVisibleNode();
		
		if($util.isNullOrUndefined(item1) || $util.isNullOrUndefined(item2))
			return null;

		var di = this._dragDropSettings.get_dropIndicator();

		return this.__createDropIndicatorMarkup(di.get_insertBetweenText(item1.get_text(), item2.get_text()), item1.get_text(), isMove);
	},

	__showDropOnIndicator: function(ddb, ddm, item)
	{
		if($util.isNullOrUndefined(ddb) || $util.isNullOrUndefined(ddm) || $util.isNullOrUndefined(item))
			return;

		        
		var dragData = ddm.get_dataObject();
		
		var isValidDrop = this.__validateDropLocation(dragData, item, false);
		if(isValidDrop)
		{
			var di = this._dragDropSettings.get_dropIndicator();
			var isMove = this._isMove(dragData);
			var itemText = item.get_text();
			var indicatorMarkup = this.__createDropIndicatorMarkup(isMove ? di.get_moveToText(itemText) : di.get_copyToText(itemText), itemText, isMove);
		}
		this.__displayMarkup(ddb, ddm, indicatorMarkup, isValidDrop);
	},
	
	__createInsertLine: function()
	{
		if($util.isNullOrUndefined(this.__getInsertLine()))
		{
			var insertDiv = document.createElement("div");
			insertDiv.setAttribute("id", "insertDiv");
			this._setCssClass(insertDiv, this._dragDropSettings.get_dropInsertLineCssClass());
			insertDiv.style.position = "absolute";
			insertDiv.style.zIndex = "100";
			insertDiv.style.width = this.get_element().clientWidth + "px";
			insertDiv.style.display = "none";
			this.get_element().appendChild(insertDiv);
		}
	},
	
	__getInsertLine: function()
	{
		var divs = this.get_element().getElementsByTagName("div");
		for(var i = 0, len=divs.length; i < len; i++)
		{
			if(divs[i].getAttribute("id") == "insertDiv")
			{
				return divs[i];
			}
		}

		return null;
	},
	
	__showInsertLine: function(top, left, width, firstObj, lastObj)
	{
		var insertDiv = this.__getInsertLine();
		if(!$util.isNullOrUndefined(insertDiv))
		{
			insertDiv.style.top = top + "px";
			insertDiv.style.left = left + "px";
			insertDiv.style.width = width + "px";
			insertDiv._nodeBefore = firstObj;
			insertDiv._nodeAfter = lastObj;
			insertDiv._borderColor = insertDiv.style.borderColor;

			if($util.isNullOrUndefined(firstObj) ^ $util.isNullOrUndefined(lastObj))
			{
				if($util.isNullOrUndefined(firstObj))
				{
					insertDiv.style.borderBottomColor = "white";
					insertDiv.style.borderTopColor = insertDiv._borderColor;
					insertDiv.style.borderLeftColor = insertDiv._borderColor;
					insertDiv.style.borderRightColor = insertDiv._borderColor;
				}
				else if($util.isNullOrUndefined(lastObj))
				{
					insertDiv.style.borderTopColor = "white";
					insertDiv.style.borderBottomColor = insertDiv._borderColor;
					insertDiv.style.borderLeftColor = insertDiv._borderColor;
					insertDiv.style.borderRightColor = insertDiv._borderColor;
				}
			}
			else
			{
				insertDiv.style.borderTopColor = insertDiv._borderColor;
				insertDiv.style.borderBottomColor = "white";
				insertDiv.style.borderLeftColor = "white";
				insertDiv.style.borderRightColor = "white";
			}
			insertDiv.style.display = "";
		}
	},
	
	__isInsertLineShown: function()
	{
		var insertDiv = this.__getInsertLine();
		if(!$util.isNullOrUndefined(insertDiv))
		{
			return insertDiv.style.display == "";
		}
		return false;
	},

	__hideInsertLine: function()
	{
		var insertDiv = this.__getInsertLine();
		if(!$util.isNullOrUndefined(insertDiv))
		{
			if(insertDiv.style.display.indexOf("none") == -1)
				insertDiv.style.display = "none";
		}
	},
	
	__getInsertLineWidth: function(item)
	{
		if(!$util.isNullOrUndefined(item))
		{
			return Sys.UI.DomElement.getBounds(item.get_textElement()).width;
		}
		return 0;
	},
	
	__getInsertLineTop: function(item0, item1)
	{
		// K.D. April 21, 2011 Bug #73064 We have to check whether the nodes are visible and if not search for 
		// the visible ones the null check underneath takes care of no previous or next visible nodes
		if(!$util.isNullOrUndefined(item0) && !item0.get_visible())
			item0 = item0.get_previousVisibleNode();

		if(!$util.isNullOrUndefined(item1) && !item1.get_visible())
			item1 = item1.get_nextVisibleNode();

		if(!$util.isNullOrUndefined(item0) && !$util.isNullOrUndefined(item1))
		{
			var i0pos = Sys.UI.DomElement.getBounds(item0.get_element());
			var i1pos = Sys.UI.DomElement.getBounds(item1.get_element());
			var item0bottom = i0pos.y + i0pos.height;
			var item1top = i1pos.y;
			// bottom of item0 + (top of item1 - bottom of item0) / 2
			return item0bottom  + ((item1top - item0bottom) / 2);
		}
		else if(!$util.isNullOrUndefined(item0) && $util.isNullOrUndefined(item1))
		{
			var i0pos = Sys.UI.DomElement.getBounds(item0.get_element());
			var item0bottom = i0pos.y + i0pos.height;

			var parent = item0.get_parentNode();
			if(!$util.isNullOrUndefined(parent))
			{
				var parentPos = Sys.UI.DomElement.getBounds(parent.get_element());
				return item0bottom + ((parentPos.y + parentPos.height - item0bottom) / 2);
			}

			// insert the line on 2px after the item0 bottom.
			return item0bottom + 2;
		}
		else if($util.isNullOrUndefined(item0) && !$util.isNullOrUndefined(item1))
		{
			var i1pos = Sys.UI.DomElement.getBounds(item1.get_element());
			// insert the line on 2px befre the item1 top.
			return i1pos.y - 3;
		}
	},

	__getInsertLineLeft: function(item)
	{
		if($util.isNullOrUndefined(item))
			return -1;
		return Sys.UI.DomElement.getBounds(item.get_textElement()).x;
	},

	__fireRealDragLeave: function(itemAdr, evntArgs, ddb)
	{
		if($util.isNullOrUndefined(evntArgs) ||
		   $util.isNullOrUndefined(ddb))
			return;

		clearTimeout(this._realDragLeaveTimeoutId);

		while(this._dragLeaveRegisteredQueue.length > 0)
		{
			var itemLeft = this._dragLeaveRegisteredQueue.pop();
			var itemLeftAdr = itemLeft._get_address();

			if(itemAdr != itemLeftAdr)
			{
				this._enterCache[itemLeftAdr] = false;

				this._raiseClientEvent("DragLeave", "DataTreeDragDrop", null, null, evntArgs, itemLeft);

				this.__displayMarkup(ddb, evntArgs.get_manager(), null, false);

				this._toggleCss(itemLeft.get_textElement(), this._dragDropSettings.get_dropTargetCssClass());
			}
		}  
	},

	__dragEnter: function(uiBehavior, item, ddb, evntArgs)
	{
		if (!item || !this._isMy(item._element))
			return;

		this.__fireRealDragLeave(item._get_address(), evntArgs, ddb);

		var flags = item._getFlags();
		if(!flags.getDroppable())
		{
		   evntArgs.set_cancel(true);
		   return;
		}

		if($util.isNullOrUndefined(this._enterCache[item._get_address()]) ||
		   !this._enterCache[item._get_address()])
		{
			this._enterCache[item._get_address()] = true;

			var args = this._raiseClientEvent("DragEnter", "DataTreeDragDrop", null, null, evntArgs, item);
			if(!$util.isNullOrUndefined(args) && args.get_cancel())
			{
				evntArgs.set_cancel(true);
				this._enterCache[item._get_address()] = false;
				return;
			}
		}        
	},

	__dragLeave: function(uiBehavior, item, ddb, evntArgs)
	{
		if (!item || !this._isMy(item._element))
			return;
		if(this._enterCache[item._get_address()])
		{
			this._dragLeaveRegisteredQueue.push(item);
			this._realDragLeaveTimeoutId = setTimeout($util.createDelegate(this, this.__fireRealDragLeave, ["", evntArgs, ddb]), 200);
		}
	},

	__applyDropTargetClass: function(item, ddm)
	{
		if (!item || !this._isMy(item._element))
			return;
		var textElem = item.get_textElement();
		if(!item.get_selected() && textElem)
		{
			if(this.__validateDropLocation(ddm.get_dataObject(), item))
				this._toggleCss(textElem, this._dragDropSettings.get_dropTargetCssClass(), true);
		}
	},

	__dragMove: function(uiBehavior, item, ddb, evntArgs)
	{
		if (!item || !this._isMy(item._element))
			return;
		this.__scrollOnDragMove(evntArgs);

		if(this.__isOverNode(evntArgs, item))
		{
			this.__hideInsertLine();
			var ddm = evntArgs.get_manager();
			this.__applyDropTargetClass(item, ddm);
			this.__showDropOnIndicator(ddb, ddm, item);
		}
		else if(this.get_enableDropInsertion())
		{
			this.__showDropInsertIndicator(item, ddb, evntArgs);
		}
		else
		{
			if($util.isNullOrUndefined(item) ||
			  (!$util.isNullOrUndefined(item) && !this.__isDropTargetCssClassApplied(item)))
			{
				evntArgs.get_manager()._updateCursor($IG.DragDropEffects.None);
			}
		}

		this._raiseClientEvent("DragMove", "DataTreeDragMove", null, null, evntArgs, item);

		if($util.isNullOrUndefined(item))
			return;

		// set a timeout of 1 sec to expand the node under which we are over.
		if(item.hasChildren() && !item.get_expanded())
		{
			if(item != this.__expandItemContext)
			{
				clearTimeout(this.__expandTimeoutID);
				this.__expandItemContext = item;
				this.__expandTimeoutID = setTimeout(Function.createDelegate(this, this.__expandNode), this._dragDropSettings.get_expandDelay());
			}
		}
		else
		{
			clearTimeout(this.__expandTimeoutID);
		}
	},

	__scrollOnDragMove: function(evntArgs)
	{
		if($util.isNullOrUndefined(evntArgs))
			return;

		var control = this.get_element();
		var controlBounds = Sys.UI.DomElement.getBounds(control);
		if(evntArgs.get_y() < controlBounds.y + this._dragScrollArea)
		{
			// scroll to top
			control.scrollTop -= this._dragScrollArea;
		}
		else if(evntArgs.get_y() > controlBounds.y + control.offsetHeight - this._dragScrollArea)
		{
			// scroll to botoom
			control.scrollTop += this._dragScrollArea;
		}

		if(evntArgs.get_x() < controlBounds.x + this._dragScrollArea)
		{
			// scroll to left
			control.scrollLeft -= this._dragScrollArea;
		}
		else if(evntArgs.get_x() > controlBounds.x + control.offsetWidth - this._dragScrollArea)
		{
			// scroll to botoom
			control.scrollLeft += this._dragScrollArea;
		}
	},
	
	__expandNode: function()
	{
		if(!$util.isNullOrUndefined(this.__expandItemContext) && !this.__expandItemContext.get_expanded())
		{
			this.__expandItemContext.set_expanded(true,true);
			this.__expandItemContext = null;
		}
	},

	__isOverNode: function(evntArgs, item)
	{
		if (!item || !this._isMy(item._element) || !evntArgs)
			return;

		var itemElement = item.get_element();
		var itemBounds = Sys.UI.DomElement.getBounds(itemElement);
		var mouseX = evntArgs.get_x();

		if(mouseX > itemBounds.x && mouseX < itemBounds.x + itemBounds.width)
		{
			var mouseY = evntArgs.get_y();
			
			var ulElement = itemElement.getElementsByTagName("UL")[0];

			if(item.get_expanded() && !$util.isNullOrUndefined(ulElement))
			{
				var ulBounds = Sys.UI.DomElement.getBounds(ulElement);
				return (mouseY > itemBounds.y + this._dropInsertBoundary &&
						mouseY < ulBounds.y);
			} else {
				return (mouseY > itemBounds.y + this._dropInsertBoundary &&
						mouseY < itemBounds.y + itemBounds.height - this._dropInsertBoundary);
			}
		}
		return false;
	},

	__showDropInsertIndicator: function(item, ddb, evntArgs)
	{
		var controlBounds = Sys.UI.DomElement.getBounds(this.get_element());

		//I.I. 87081: It is not possible to move root node after last root node
		if(!item)
		{
			var rootNodes = this.getNodes();
			if (!rootNodes) return;

			var len = rootNodes.get_length();
			if (len == 0) return;

			var firstRootNode = rootNodes.getNode(0);
			var firstRootNodeBounds = Sys.UI.DomElement.getBounds(firstRootNode.get_element());
			var lastRootNode = rootNodes.getNode(len - 1);
			var lastRootNodeBounds = Sys.UI.DomElement.getBounds(lastRootNode.get_element());

			if(evntArgs.get_y() > controlBounds.y &&
			   evntArgs.get_y() < controlBounds.y + controlBounds.height &&
			   evntArgs.get_x() > controlBounds.x &&
			   evntArgs.get_x() < controlBounds.x + controlBounds.width)
			   {
					if (evntArgs.get_y() < firstRootNodeBounds.y)
						item = firstRootNode;

					if (evntArgs.get_y() > lastRootNodeBounds.y)
						item = lastRootNode;
			   }
		}
		if (!item || !this._isMy(item._element))
			return;

		var ddm = evntArgs.get_manager();
		var dragData = ddm.get_dataObject();

		var previous = item.get_previousNode();
		var next = item.get_nextNode();
		var parent = item.get_parentNode();

		var isValidDropLocation = this.__validateDropLocation(dragData, item, true, evntArgs.get_y());
		var dropIndicatorMarkup;

		var itemBounds = Sys.UI.DomElement.getBounds(item.get_element());

		if(evntArgs.get_y() > controlBounds.y &&
		   evntArgs.get_y() < controlBounds.y + controlBounds.height &&
		   evntArgs.get_x() > controlBounds.x &&
		   evntArgs.get_x() < controlBounds.x + controlBounds.width)
		{
			if ($util.isNullOrUndefined(parent) && $util.isNullOrUndefined(previous))
			{
				//insert as first root node
				dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(item, true, this._isMove(dragData));
				if(isValidDropLocation)
				{
					this.__showInsertLine(this.__getInsertLineTop(null, item),
													this.__getInsertLineLeft(item),
													this.__getInsertLineWidth(item),
													null, item);
				}
			}

			else if ($util.isNullOrUndefined(parent) && $util.isNullOrUndefined(next))
			{
				//insert as last root node
				dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(item, false, this._isMove(dragData));
				if(isValidDropLocation)
				{
					this.__showInsertLine(this.__getInsertLineTop(item),
												this.__getInsertLineLeft(item),
												this.__getInsertLineWidth(item),
												item, null);
				}
			}

			if(!$util.isNullOrUndefined(previous))
			{
				var previousBounds = Sys.UI.DomElement.getBounds(previous.get_element());
				if(previousBounds.y + previousBounds.height - this._dropInsertBoundary < evntArgs.get_y() &&
				   evntArgs.get_y() < itemBounds.y + this._dropInsertBoundary)
				{
					// insert between item and previous
					dropIndicatorMarkup = this.__createDropInsertBetweenIndicatorMarkup(previous, item, this._isMove(dragData));
					if(isValidDropLocation)
					{
						this.__showInsertLine(this.__getInsertLineTop(previous, item),
											  this.__getInsertLineLeft(item),
											  this.__getInsertLineWidth(item),
											  previous, item);
					}
				}
			}

			if($util.isNullOrUndefined(dropIndicatorMarkup) && item.hasChildren() && item.get_expanded())
			{
				var itemTextBounds = Sys.UI.DomElement.getBounds(item.get_textElement());
				
				var firstChild = item.get_childNode(0);
				
				var firstChildBounds = firstChild ? Sys.UI.DomElement.getBounds(firstChild.get_element()) : null;
				if(firstChildBounds && itemTextBounds.y + itemTextBounds.height < evntArgs.get_y() &&
				   evntArgs.get_y() < firstChildBounds.y + this._dropInsertBoundary)
				{
					// insert before child
					dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(firstChild, true, this._isMove(dragData));
					if(isValidDropLocation)
					{
						this.__showInsertLine(this.__getInsertLineTop(null, firstChild),
											  this.__getInsertLineLeft(firstChild),
											  this.__getInsertLineWidth(firstChild),
											  null, firstChild);
					}
				}
			}

			if($util.isNullOrUndefined(dropIndicatorMarkup) && !$util.isNullOrUndefined(next))
			{
				var nextBounds = Sys.UI.DomElement.getBounds(next.get_element());
				if(itemBounds.y + itemBounds.height - this._dropInsertBoundary < evntArgs.get_y() &&
				   evntArgs.get_y() < nextBounds.y + this._dropInsertBoundary)
				{
					// insert between item and next
					dropIndicatorMarkup = this.__createDropInsertBetweenIndicatorMarkup(item, next, this._isMove(dragData));
					if(isValidDropLocation)
					{
						this.__showInsertLine(this.__getInsertLineTop(item, next),
											  this.__getInsertLineLeft(next),
											  this.__getInsertLineWidth(next),
											  item, next);
					}
				}
			}

			if($util.isNullOrUndefined(dropIndicatorMarkup) && !$util.isNullOrUndefined(parent))
			{
				var parentBounds = Sys.UI.DomElement.getBounds(parent.get_element());
				var parentTextBounds = Sys.UI.DomElement.getBounds(parent.get_textElement());
				if(parentTextBounds.y + parentTextBounds.height < evntArgs.get_y() &&
				   evntArgs.get_y() < itemBounds.y + this._dropInsertBoundary)
				{
					// insert before item
					dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(item, true, this._isMove(dragData));
					if(isValidDropLocation)
					{
						this.__showInsertLine(this.__getInsertLineTop(null, item),
													  this.__getInsertLineLeft(item),
													  this.__getInsertLineWidth(item),
													  null, item);
					}
				}
				else if(parentBounds.y + parentBounds.height > evntArgs.get_y() &&
						evntArgs.get_y() > itemBounds.y + itemBounds.height - this._dropInsertBoundary)
				{
					//insert after item
					dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(item, false, this._isMove(dragData));
					if(isValidDropLocation)
					{
						this.__showInsertLine(this.__getInsertLineTop(item),
												  this.__getInsertLineLeft(item),
												  this.__getInsertLineWidth(item),
												  item, null);
					}
				}
			}
		}
		this.__displayMarkup(ddb, ddm, dropIndicatorMarkup, isValidDropLocation);
	},

//    __showDropInsertIndicator2: function(item, ddb, evntArgs)
//    {
//        if($util.isNullOrUndefined(item) || item.get_expanded())
//        {
//            var ddm = evntArgs.get_manager();
//            var dragData = ddm.get_dataObject();
//            var mouseY = evntArgs.get_y();
//            var isValidDropLocation = true;
//            var dropIndicatorMarkup;
//            var ulElement;

//            if($util.isNullOrUndefined(item))
//            {
//                ulElement = this.get_element().getElementsByTagName("UL")[0];
//            } else {
//                ulElement = item.get_element().getElementsByTagName("UL")[0];
//                isValidDropLocation = this.__validateDropLocation(dragData, item);
//            }

//            if(isValidDropLocation)
//            {
//                var ulBounds = Sys.UI.DomElement.getBounds(ulElement);
//                var lastChild = $util.skipTextNodes(ulElement.lastChild, true);
//                var lastChildBounds = Sys.UI.DomElement.getBounds(lastChild);
//                if(mouseY < ulBounds.y + ulBounds.height && mouseY > lastChildBounds.y + lastChildBounds.height)
//                {
//                    // insert after last elem
//                    var curItem = this._itemCollection._getUIBehaviorsObj().getItemFromElem(lastChild);
//                    dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(curItem, false, this._isMove(dragData));
//                    this.__showInsertLine(this.__getInsertLineTop(curItem),
//                                          this.__getInsertLineLeft(curItem),
//                                          this.__getInsertLineWidth(curItem),
//                                          curItem, null);
//                } 
//                else
//                {
//                    var lastElemBounds;
//                    var lastElem;
//                    for(var i=0, len = ulElement.childNodes.length; i < len; i++)
//                    {
//                        var childLi = ulElement.childNodes[i];
//                        if(childLi.nodeName == "LI")
//                        {
//                            var itemBounds = Sys.UI.DomElement.getBounds(childLi);

//                            if(mouseY < itemBounds.y)
//                            {
//                                if(i == 0)
//                                {
//                                    // insert before
//                                    var curItem = this._itemCollection._getUIBehaviorsObj().getItemFromElem(childLi);
//                                    dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(curItem, true, this._isMove(dragData));
//                                    this.__showInsertLine(this.__getInsertLineTop(null, curItem),
//                                                          this.__getInsertLineLeft(curItem),
//                                                          this.__getInsertLineWidth(curItem),
//                                                          null, curItem);
//                                    break;
//                                }
//                                else
//                                {
//                                    if(mouseY > lastElemBounds.y + lastElemBounds.height)
//                                    {
//                                        var beh = this._itemCollection._getUIBehaviorsObj();
//                                        var previous = beh.getItemFromElem(lastElem);
//                                        var item = beh.getItemFromElem(childLi);
//                                        // insert between last and current item
//                                        dropIndicatorMarkup = this.__createDropInsertBetweenIndicatorMarkup(previous, item, this._isMove(dragData));
//                                        this.__showInsertLine(this.__getInsertLineTop(previous, item),
//                                                              this.__getInsertLineLeft(item),
//                                                              this.__getInsertLineWidth(item),
//                                                              previous, item);
//                                        break;
//                                    }
//                                }
//                            }
//                            else if(mouseY < itemBounds.y + itemBounds.height)
//                            {
//                                // insert after last.
//                                var curItem = this._itemCollection._getUIBehaviorsObj().getItemFromElem(lastChild);
//                                dropIndicatorMarkup = this.__createDropInsertIndicatorMarkup(curItem, false, this._isMove(dragData));
//                                this.__showInsertLine(this.__getInsertLineTop(curItem),
//                                                      this.__getInsertLineLeft(curItem),
//                                                      this.__getInsertLineWidth(curItem),
//                                                      curItem, null);
//                                break;
//                            }

//                            lastElemBounds = itemBounds;
//                            lastElem = childLi;
//                        }
//                    }
//                }
//            }
//            this.__displayMarkup(ddb, ddm, dropIndicatorMarkup, isValidDropLocation);
//        }
//    },

	__displayMarkup: function(ddb, ddm, dropIndicatorMarkup, isValidDropLocation)
	{
		var currentDragMarkup = ddb.get_dragMarkup(), dragData = ddm.get_dataObject();
		
		if (!dragData || !dragData.get_sourceTreeId())
		{
			return;
		}

		if($util.isNullOrUndefined(dropIndicatorMarkup) || !isValidDropLocation)
		{
			// We are over the node. Show the default drag markup
			
			dropIndicatorMarkup = this.__createDragMarkup(dragData);
			this.__hideInsertLine();

			if(!isValidDropLocation)
			{
				// change the cursor to invalid.
				ddm._updateCursor($IG.DragDropEffects.None);
			}
		}
		
		// K.D. November 26, 2010 Bug #60397 We need to create the drag markup from the tree that is the source of the D&D
		// because otherwise tooltips arent displayed when D&D is performed from one tree onto another
		if(!$util.isNullOrUndefined(dragData) && !this.__isSourceTree(dragData))
		{
			var sourceTree = $find(dragData.get_sourceTreeId());
			currentDragMarkup = sourceTree.__createDragMarkup(dragData);
		}

		// update the drag markup
		if(!$util.isNullOrUndefined(currentDragMarkup) &&
		   !$util.isNullOrUndefined(dropIndicatorMarkup) &&
		   this._dragDropSettings.get_dropIndicator().get_visible() &&
		   !$util.isNullOrUndefined(currentDragMarkup.firstChild))
		{
			if(currentDragMarkup.style.display.indexOf("none") != -1)
				currentDragMarkup.style.display = "";
			
			currentDragMarkup.replaceChild(dropIndicatorMarkup, currentDragMarkup.firstChild);
		}
	},
	
	_isMove: function(dragData)
	{
		if($util.isNullOrUndefined(dragData))
			return;

		var ddm = dragData._get_dragDropManager(); // manager of the source tree!!
		var effect = ddm.get_dragDropEffect(); // effect of the source tree!!

		return (effect == $IG.DragDropEffects.Move ||
				(effect == $IG.DragDropEffects.Default && !ddm.isCtrlKey()));
	},

	__dragEnd: function(uiBehavior, item, ddb, evntArgs)
	{
		clearTimeout(this.__expandTimeoutID);
		this.__fireRealDragLeave("", evntArgs, ddb);
		this._enterCache = new Array();
		this._dragMarkup = null;
		this.__hideInsertLine();

		this._raiseClientEvent("DragEnd", "DataTreeDragDrop", null, null, evntArgs);
	},

	__dragCancel: function(uiBehavior, ddb, evntArgs)
	{
		clearTimeout(this.__expandTimeoutID);
		this._dragMarkup = null;
		this.__hideInsertLine();
		this._raiseClientEvent("DragCancel", "DataTreeDragDrop", null, null, evntArgs);
	},

	__drop: function(uiBehavior, item, ddb, evntArgs)
	{
		clearTimeout(this.__expandTimeoutID);
		var isInsertLineShown = this.__isInsertLineShown();
		this.__hideInsertLine();

		var nodeBefore, nodeAfter;
		if(isInsertLineShown)
		{
			var insertLine = this.__getInsertLine();
			if (insertLine)
			{
				nodeBefore = insertLine._nodeBefore;
				nodeAfter = insertLine._nodeAfter;
			}
		}

		var ddm = evntArgs.get_manager();
		var dragData = ddm.get_dataObject();
		
		// M.H. 13 Oct 2011 - fix bug 87083 - get tree id where the node is dropped
		this._currentTreeId = dragData.get_sourceTreeId();
		if(!this.__validateDrop(dragData, item, isInsertLineShown, nodeBefore, nodeAfter))
			return;

		if(!dragData._get_dropInProgress())
		{
			var pair = this._getDropPoint(item, isInsertLineShown, nodeBefore, nodeAfter);
			var destNode = pair[0];
			var point = pair[1];

			var args = this._raiseClientEvent('NodeDropping', 'DataTreeDragDrop', null, null, evntArgs, destNode, point);
			if(!$util.isNullOrUndefined(args) && args.get_cancel())
			{
				dragData.dispose();
				return;
			}

			dragData._set_dropInProgress(true);

			this._addressGenerator.set_operation(4);

			if(this._isMove(dragData))
			{
				this._addressGenerator.set_operation(3);
				// remove the nodes from the source tree.
				this.__removeFromSource(dragData);
			}

			// add the nodes to this tree.
			this.__addToTarget(dragData, item, isInsertLineShown, nodeBefore, nodeAfter);

			// Create fake event args class to use its _getPostArgs method, to properly log the data for the event.
			var fakeEventArgs = new $IG.DataTreeDragDropEventArgs("NodeDropped");
			fakeEventArgs._props[2] = evntArgs;
			fakeEventArgs._props[3] = destNode;
			fakeEventArgs._props[4] = point;
			this._itemCollection._csm.logDropData("NodeDropped" + fakeEventArgs._getPostArgs());

			// Dropped nodes should be removed from this._selectedNodes;
			this._changeSelection(this._selectedNodes, [], false);
			
			if(destNode && point == $IG.DragDropPoint.On)
			{
				var elem = destNode.get_textElement();
				this._toggleCss(elem, this._dragDropSettings.get_dropTargetCssClass());
				if(this._dragDropSettings.get_enableExpandOnDrop() && !destNode.get_expanded())
				{
					destNode.set_expanded(true, true);
				}
			}

			this._raiseClientEvent("NodeDropped", 'DataTreeDragDrop', null, null, evntArgs, destNode, point);

			dragData.dispose();
			// K.D. April 27th, 2012 Bug #110705 This data was not correctly disposed previously
			this._currentTreeId = null;
		}
	},
	
	_getDropPoint: function(item, isInsertLineShown, nodeBefore, nodeAfter)
	{
		var pair = new Array();
		if(isInsertLineShown)
		{
			if($util.isNullOrUndefined(nodeBefore) && !$util.isNullOrUndefined(nodeAfter))
			{
				pair.push(nodeAfter);
				pair.push($IG.DragDropPoint.Before);
			}
			else if(!$util.isNullOrUndefined(nodeBefore) && $util.isNullOrUndefined(nodeAfter))
			{
				pair.push(nodeBefore);
				pair.push($IG.DragDropPoint.After);
			}
			else if(!$util.isNullOrUndefined(nodeBefore) && !$util.isNullOrUndefined(nodeAfter))
			{
				pair.push(nodeAfter);
				pair.push($IG.DragDropPoint.Before);
			}
		}
		else
		{
			pair.push(item);
			pair.push($IG.DragDropPoint.On);
		}
		return pair;
	},
	
	__validateDrop: function(dragData, item, isInsertLineShown, nodeBefore, nodeAfter)
	{
		if (!item || !this._isMy(item._element) || !dragData || dragData.isDisposed())
			return false;

		if(!this.get_enableDropInsertion() && !this.__isDropTargetCssClassApplied(item))
			return false;

		if(!this.__isSourceTree(dragData))
			return true;
		// validation is applicable onle if the data is from the same tree
		// if address the address of the location we are dropping starts with the address 
		// of any of the nodes in drag data then the user is trying to drag parent into its child.
		if(isInsertLineShown && nodeBefore && nodeAfter)
		{
			// item is not null and we are inserting as first child in the item
			return this.__validateDropLocation(dragData, nodeAfter, null, null, nodeBefore, item);
		}
		return this.__validateDropLocation(dragData, item, null, null, nodeBefore, nodeAfter);
	},

	__validateDropLocation: function(dragData, item, isInsert, mouseY, n1, n2)
	{
		if (!dragData || !item || !this._isMy(item._element) || !dragData)
			return false;

		if(!this.__isSourceTree(dragData))
			return true;

		var enabledDropInsertion = this.get_enableDropInsertion();
		var nodes = dragData.get_nodes();
		var len = dragData.get_length();
		var itemElem = item.get_element();
		n1 = n1 ? n1.get_element() : null;
		n2 = n2 ? n2.get_element() : null;
		for(var i=0; i < len; i++)
		{
			var nodeElem = nodes[i].get_element();
			if(nodeElem == n1 || nodeElem == n2 || itemElem == nodeElem || $adrutil.isDescendantOf(itemElem, nodeElem))
			{
				return false;
			}
			if(enabledDropInsertion && isInsert)
			{
				var itemBounds = Sys.UI.DomElement.getBounds(itemElem);

				if((nodeElem.previousSibling == itemElem && mouseY > (itemBounds.y + itemBounds.height - this._dropInsertBoundary)) ||
				   (nodeElem.nextSibling == itemElem && mouseY < itemBounds.y + this._dropInsertBoundary))
				{
					// forbid dropping inserting a node before/after itself
					return false;
				}
			}
		}
		return true;
	},

	__isDropTargetCssClassApplied: function(item)
	{
		if (!item || !this._isMy(item._element))
			return false;
		return $util.getCssClass(item.get_textElement()).indexOf(this._dragDropSettings.get_dropTargetCssClass()) != -1;
	},

	__addToTarget: function(dragData, item, isInsertLineShown, nodeBefore, nodeAfter)
	{
		if(!dragData || $util.isNullOrUndefined(isInsertLineShown))
		   return;
		var fireEvents = false;
		var nodes = dragData.get_nodes();
		if(!this.__isSourceTree(dragData))
		{
			// if the data is coming from other tree, then use the public addRange so that events are fired.
			fireEvents = true;
			this._addressGenerator.set_operation(1);
		}
		
		if(isInsertLineShown)
		{
			// we dropped somewhere between child nodes of the item.
			if($util.isNullOrUndefined(nodeBefore) && !$util.isNullOrUndefined(nodeAfter))
			{
				// insert at index 0, as first item in the parent item.
				// K. D. January 21, 2011 Bug #62571 We need to get the root element address using the node after
				// if those nodes have been previously dragged and dropped at their places
				var adr = nodeAfter.get_element();
				if ($adrutil.isRootLevelNodeElement(adr)) 
					adr = $adrutil.stripLastAddressSlot($adrutil.getLocationFromDomElement(adr));
				else 
				{
					adr = nodeAfter.get_parentNode();
					if (adr)
						adr = adr._get_address();
				}
				// when inserting before root level item, stripAddressSlot returns ""
				this._addRange(nodes, (adr == "" ? null : adr), 0, fireEvents);
			}
			else if(nodeBefore && nodeAfter)
			{
				// M.H. 30 May 2011 Bug #76384. We should set the address of the element we inserted, not address in the tree after insert
				var currentLocation = nodeAfter._get_address();
				// L.A. 21 March 2012 Bug #103163. Nodes dissapears when move from 1 tree to another
				//var adr = $adrutil.stripLastAddressSlot($adrutil.getLocationFromDomElement(nodeAfter.get_element()));
				
				var adr = dragData._sourceTreeId != this._id ? $adrutil.stripLastAddressSlot($adrutil.getLocationFromDomElement(nodeAfter.get_element())) : $adrutil.stripLastAddressSlot(currentLocation);

				// M.H. 16 Aug 2011 Bug #83515. Add parameter nodeAfter - nodeElem should be inserted before nodeAfter
				// This is done because it is not updated the address attribute of nodes after drag and drop
				this._addRange(nodes, (adr == "" ? null : adr), $adrutil.getNodeLocation(currentLocation), fireEvents, nodeAfter);
			}
			else if(nodeBefore && !nodeAfter)
			{
				// K.D. December 21, 2010 #59746 We need to get the address of a non-root element from the nodeBefore,
				// because otherwise the address of the parent element is calculated wrong if the parent node has been dropped
				// using drag and drop
				var adr = nodeBefore.get_element();
				if ($adrutil.isRootLevelNodeElement(adr))
					adr = $adrutil.stripLastAddressSlot($adrutil.getLocationFromDomElement(adr));
				else
				{
					adr = nodeBefore.get_parentNode();
					if (adr)
						adr = adr._get_address();
				}
				this._addRange(nodes, (adr == "" ? null : adr), -1, fireEvents);
			}
		}
		else if(item)
		{
			// we dropped over the item.
			this._addRange(nodes, item._get_address(), -1, fireEvents);
			this.set_activeNode(item, true);
		}
		else
		{
			// we dropped on the tree area, then add the node as last.
			this._addRange(nodes, null, -1, fireEvents);
		}
	},

	__removeFromSource: function(dragData)
	{
		var ddm = dragData._get_dragDropManager();
		var effect = ddm.get_dragDropEffect();

		if(effect == $IG.DragDropEffects.Move ||
		   (effect == $IG.DragDropEffects.Default && !ddm.isCtrlKey()))
		{
			// remove nodes only when we are doing move or default without Ctrl pressed.
			if(!this.__isSourceTree(dragData))
			{
				this.__removeIfDifferentSourceTree(dragData);
			}
			else
			{
				// remove from the current tree, without firing the NodeRemoving/ed events.
				var nodes = dragData.get_nodes();
				var len = dragData.get_length();
				for(var i = 0; i < len; i++)
				{
					this._remove(nodes[i], false, false);
				}
			}
		}
	},
	
	__removeIfDifferentSourceTree: function(dragData)
	{
		if(!this.__isSourceTree(dragData))
		{
			var sourceTree = $find(dragData.get_sourceTreeId());
			if(!$util.isNullOrUndefined(sourceTree))
			{
				var nodes = dragData.get_nodes();
				var len = dragData.get_length();
				for(var i = 0; i < len; i++)
				{
					sourceTree.remove(nodes[i], false);
				}
			}
		}
	},
	
	__isSourceTree: function(dragData)
	{
		// returns true if drag data is from the same tree we are dropping onto.
		return dragData.get_sourceTreeId() == this._id;
	},
	
	__isMultiDrag: function(dragData)
	{
		return dragData.get_length() > 1;
	},

	

	_ensureFlags: function()
	{
		$IG.WebDataTree.callBaseMethod(this, "_ensureFlag");
		this._ensureFlag($IG.ClientUIFlags.Enabled, $IG.DefaultableBoolean.True);
		this._ensureFlag($IG.ClientUIFlags.Hoverable, $IG.DefaultableBoolean.True);
		this._ensureFlag($IG.ClientUIFlags.Draggable, $IG.DefaultableBoolean.False);
		this._ensureFlag($IG.ClientUIFlags.Droppable, $IG.DefaultableBoolean.False);
		this._ensureFlag($IG.ClientUIFlags.Selectable, $IG.DefaultableBoolean.True);
	},

	_get_maingroup: function()
	{
		return this._element.firstChild;
	},
	
	
	
	_enterNodeEditing: function(node)
	{
		/// <summary>
		/// Causes the tree to enter edit mode.
		/// </summary>
		/// <param name="node">The node to enter edit mode.</param>
		if (!node) return; // if node is null ot undefined - exit
		if (!node.get_enabled()) return; // if node is disabled - exit
		if (!node.get_visible()) return; // if node is not visible (collapsed) - exit
		if (this._nodeInEditMode != null)
			this._exitNodeEditing(true);

		

		setTimeout(this.__createDelegate(this, this.__internalEnterEditMode, [node]), 1);
	},

	_exitNodeEditing: function(update)
	{
		/// <summary>
		/// Causes the tree to exit edit mode.
		/// </summary>
		/// <param name="update">Request to update value.</param>
		var node = this._nodeInEditMode, editor = this._nodeEditor;
		var nodeElem = node.get_element();
		if (!node || !editor || !editor.get_value)
			return;
		var args = this._raiseClientEvent("NodeEditingExiting", "CancelNodeEditing", null, null, node);
		if (args == null || !args.get_cancel())
		{
			




			if (update)
			{
				var newValue = editor.get_value();
				var args = this._raiseClientEvent("NodeEditingTextChanging", "TextChange", null, null, node, newValue);
				if (args == null || !args.get_cancel())
				{
					node.set_text(newValue);
					this._raiseClientEvent("NodeEditingTextChanged", "TextChange", null, null, node, newValue);
					
					
					






				}
			}
			editor.hideEditor();

			node.get_textElement().style.display = '';

			this._raiseClientEvent("NodeEditingExited", "NodeEditing", null, null, node);
			//this.set_activeNode(node);
			this._nodeInEditMode = null;
			this._currentEditor = null;
			this._focusEventElement();
		}
	},

	_get_isInNodeEditing: function(node)
	{
		/// <summary>
		/// Gets a value that indicates whether the node is in edit mode.
		/// </summary>
		/// <param name="node">WebDataTree node object.</param>
		if (node == null || !node || !node._get_address) return false;
		if (this._nodeInEditMode == null) return false;
		return (this._nodeInEditMode._get_address() == node._get_address());
	},

	

	__internalEnterEditMode: function(node)
	{
		// This means that the user has canceled exiting edit mode.
		if (this._nodeInEditMode != null) return;
		var nodeElem = node.get_element();
		if (!nodeElem) return;
		var editor = this._nodeEditor;
		if (editor == null) return;
		var elm = node.get_textElement();
		if (elm == null || elm.tagName != "A") return;
		var args = this._raiseClientEvent("NodeEditingEntering", "CancelNodeEditing", null, null, node);
		if (args == null || !args.get_cancel())
		{
			var container = nodeElem;
			

			this._nodeInEditMode = node;
			this._currentEditor = editor;
			//var point = $util.getPosition(elm);
			
			
			var relativePosition = this.__getRelativePosition(elm);
			var top = relativePosition.y;
			var left = relativePosition.x;
			var height = elm.offsetHeight;
			var width = elm.offsetWidth;
			editor.set_value(node.get_text());
			var css = this._nodeEditing.get_internalEditorCssClass();
			css = this._internalNodeEditorCssClass + (css ? " " + css : "");
			elm.style.display = 'none';
			editor.showEditor(left, top, width, height, css, container, elm);
			this._raiseClientEvent("NodeEditingEntered", "NodeEditing", null, null, node);
		}
	},

	__getRelativePosition: function(element)
	{
		var left = element.offsetLeft - this._element.scrollLeft;
		var top = element.offsetTop - this._element.scrollTop;

		var parent = element.offsetParent;
	   
		while (parent != null)
		{
			var style = $util.getRuntimeStyle(parent);

			if (!style)
				break;

			if (style.position != "static" && style.position != "")
			{
				if ($util.IsIE)
				{
					left -= $util.toIntPX(style, 'borderLeftWidth');
					top -= $util.toIntPX(style, 'borderTopWidth');
				}
				break;
			}
			
			left += parent.offsetLeft;
			top += parent.offsetTop;
			
			parent = parent.offsetParent;
		}
		
		return new Sys.UI.Point(left, top);
	},

	__createDelegate: function(instance, method, args)
	{
		return function()
		{
			return method.apply(instance, args);
		}
	},

	__editorLostFocus: function(evnt)
	{
		if (this._currentEditor != null)
		{
			this._currentEditor._originalNotifyLostFocus(evnt);
			if (evnt != null && evnt.type == "keydown")
			{
				var key = evnt.keyCode;
				var node = this._nodeInEditMode;
				if (key == Sys.UI.Key.tab)
				{
					this._exitNodeEditing(true);
				}
				else if (key == Sys.UI.Key.esc)
				{
					this._exitNodeEditing(false);
				}
				else if (key == Sys.UI.Key.enter)
				{
					this._exitNodeEditing(true);
					$util.cancelEvent(evnt);
				}
				if (this._activation)
				{
					var activeCell = this._activation.get_activeCell();
					if (activeCell)
						activeCell.get_element().focus();
				}
			}
			else
				this._exitNodeEditing(true);
		}
	},

	
	
	
	dispose: function()
	{
		this._disposeFocusElement();
		this._initCollections = false;
		$IG.WebDataTree.callBaseMethod(this, 'dispose');
	},

	_disposeFocusElement: function()
	{
		var focusElement = this.get_focusElement();
		if (focusElement)
		{
			$clearHandlers(focusElement);
		}
	},

	_soft_dispose: function()
	{
		
		
		this._disposeFocusElement();

		if(this._nodeEditor)
		{
			this._nodeEditor.dispose();
		}

		this._elements = []; // clear markers
		this._events._list = []; // it's very important to clear the events !
		this._initCollections = false;

		if (this._objectsManager)
			this._objectsManager.dispose();
		if (this._collectionsManager)
			this._collectionsManager.dispose();

		$clearHandlers(this._element);
		  this._element._hasHandlers = null;
	},
	
	
	
	addText: function(text)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addText">Add a new node with the specifed text to the tree.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the added node.</returns>
		var node = this.createNode(text);
		return this._insert(node, null, -1, true);
	},
	
	addText: function(text, navigateUrl)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addText">Add a new node with the specifed text and navigate url to the collection.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<param name="navigateUrl" type="String" mayBeNull="true">Specify the node navigate URL.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the added node.</returns>
		var node = this.createNode(text, navigateUrl);
		return this._insert(node, null, -1, true);
	},
	
	add: function(node)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.add">Add a node to the tree.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be added.</param>
		this.add(node, null);
	},
	
	add: function(node, level)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.add">Add a node to the tree at the specified level.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be added.</param>
		///<param name="level" type="String">Specify node location. Format "0.1.2"</param>
		return this.insert(node, level, -1);
	},
	
	addRange: function(nodeArray, level, index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addRange">Add an array of nodes to the tree at the specified level at the specified index.</summary>
		///<param name="nodeArray" type="Array" elementType="Infragistics.Web.UI.Node">Array of nodes that will be added.</param>
		///<param name="level" type="String" mayBeNull="true">Specify node location. Format "0.1.2" Specify null and index for adding root level node.</param>
		///<param name="index" type="int">Specify index in the nodes collection.</param>
		if(!$util.isNullOrUndefined(level))
		{
			var domNode = this._findInsertLevel(level);
			level = $adrutil.getAddressFromDomElement(domNode); // level is now equal to the adr of the item.
		}
		this._addressGenerator.set_operation(1);
		this._addRange(nodeArray, level, index, true);
	},
	
	_addRange: function(nodeArray, adr, index, fireEvents, nodeAfter)
	{
		// M.H. 16 Aug 2011 Bug #83515. Add parameter nodeAfter - if it is specified and index > -1 then nodeElem should be inserted before nodeAfter
		if((adr && !$adrutil.isAppendAddress(adr)) || index < -1)
			return;

		var arrayLen = nodeArray.length;

		if($util.isNullOrUndefined(nodeArray) || arrayLen == 0)
			return;

		if(fireEvents)
		{
			if(this._raiseNodeAddingEvent(nodeArray))
				return; // event was cancelled.
		}

		var ctrlStylePrefix = this._getStylePrefix();
		


		var i = (index === -1 ? 0 : arrayLen - 1);
		var hasMore;
		
		do
		{
			// update the control DOM tree
			var htmlElem = nodeArray[i].get_element().cloneNode(true);
			htmlElem._oldLocation = nodeArray[i].get_element()._oldLocation; // under FF, non standard attributes are not copied.
			htmlElem._object = null;
			// M.H. 16 Aug 2011 Bug #83515. Add parameter nodeAfter - if it is specified and index > -1 then nodeElem should be inserted before nodeAfter
			this._internalInsert(htmlElem, adr, index, nodeAfter);

			this._replaceTheme(nodeArray[i]._stylePrefix, ctrlStylePrefix, htmlElem);

			this._addressGenerator.set_element(htmlElem);
			this._addressGenerator.set_node(nodeArray[i]);

			if(this._addressGenerator.__operation == 3 ||
			   this._addressGenerator.__operation == 4)
			{
				if($util.isNullOrUndefined(htmlElem._oldLocation) && this._addressGenerator.__operation == 4)
					// M.H. 3 June 2011 fix bug 76952 - it shoule be set address of the current element, not the address that will be after drop - it is oldLocation
					htmlElem._oldLocation = nodeArray[i]._get_address();                

				this._addressGenerator.execute(htmlElem._oldLocation, $adrutil.getLocationFromDomElement(htmlElem));
			}
			else
			{
				this._addressGenerator.execute(null, $adrutil.getLocationFromDomElement(htmlElem));
			}

			(index === -1 ? i++ : i--);
			hasMore = (index === -1 ? i < arrayLen : i >= 0);

			
			
			if (!hasMore && this.get_checkBoxMode() != $IG.CheckBoxMode.Off && this.get_enableAutoChecking())
			{
				var nodeObj = this._itemCollection._getUIBehaviorsObj().getItemFromElem(htmlElem);
				this._applyCheckStateToParent(nodeObj);
			}
		} while(hasMore)
		
		this._set_isClientStateDirty(true);

		if(fireEvents)
		{
			this._raiseNodeAddedEvent(nodeArray);
		}
	},
	
	_remove: function(node, keepChildren, fireEvents)
	{
		var index, wasLast;
		if(!node)
			return false;
		var parentNode = node.get_parentNode();
		var nodeCollection = parentNode ? parentNode.getItems() : this._itemCollection;
		if(!nodeCollection || (index = nodeCollection.get_indexOf(node)) == -1)
			return false;
		wasLast = index == nodeCollection.get_length() - 1;
		if(fireEvents && this._raiseNodeRemovingEvent(node))
			return false; // event was cancelled
		var result = nodeCollection._remove(node, keepChildren, false);
		if(result)
		{
			if(parentNode)
			{
				if(!parentNode.hasChildren() && parentNode.get_expanded())
				{
					parentNode._set_value($IG.DataTreeNodeProps.Expanded, false);
					
					var ul = parentNode.get_element().getElementsByTagName("ul");
					if (ul && ul.length > 0)
						ul[0].style.display = "none";
				} else {
					// K.D. November 10th, 2011 Bug #85717 Updating the root item checkbox after D&D is performed
					if(this.get_enableAutoChecking())
						this._applyCheckStateToParent(parentNode.get_childNode(0));
				}
			}
			
			else if (wasLast)
			{
				
				wasLast = nodeCollection.getNode(index - 1);
				if (wasLast)
					this._updateNodeExpanderImage(wasLast.get_element(), null, wasLast.get_expanded());
			}
			this._set_isClientStateDirty(true);
			if(fireEvents)
				this._raiseNodeRemovedEvent(node);
		}
		return result;
	},

	_removeIfSelected: function(node)
	{
		var len = this._selectedNodes.length;
		for(var j = 0; j < len; j++)
		{
			if(this._selectedNodes[j]._get_address() == node._get_address())
			{
				this._setNodeSelectionState(node, false);
				this._selectedNodes.splice(j, 1);
				break;
			}
		}
	},

	_removeIfChecked: function(node)
	{
		if($util.isNullOrUndefined(node))
			return;

		for(var j = 0, len = this._checkedNodes.length; j < len; j++)
		{
			var currentNode = this._checkedNodes[j];
			if(!$util.isNullOrUndefined(currentNode) &&
				currentNode._get_address() == node._get_address())
			{
				if(this.get_enableAutoChecking())
				{
					this._applyCheckStateToParent(node);
				}
				this._checkedNodes.splice(j, 1);
				break;
			}
		}
	},

	remove: function(node, keepChildren)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.remove">Remove a node from the tree.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be removed.</param>
		///<param name="keepChildren" type="Boolean">If true node children will not be removed.</param>
		///<returns type="Boolean">Returns true if the node is succesfully removed.</returns>
		this._addressGenerator.set_operation(2);
		return this._remove(node, keepChildren, true);
	},
	
	removeAt: function(level, keepChildren)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.removeAt">Remove a node from the tree at the specified location.</summary>
		///<param name="level" type="String">Specify node location. Format: "0.0.1"</param>
		///<param name="keepChildren" type="Boolean">If true node children will not be removed.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the node that was removed from the tree</returns>
		if(!$adrutil.isAddress(level))
			return null;

		var nodeElem = this._findInsertLevel(level);

		if(!$util.isNullOrUndefined(nodeElem))
		{
			var nodeObj = this._itemCollection._getUIBehaviorsObj().getItemFromElem(nodeElem);
			if(this.remove(nodeObj, keepChildren))
			{
				return nodeObj;
			}
		}
		return null;
	},
	
	insert: function(node, level, index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.insert">Add a node to the tree at the specified location.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be added.</param>
		///<param name="level" type="String">Node location. Where 0 is the root level. Format: "0.0.1"</param>
		///<param name="index" type="int">Specify index in the nodes collection.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the node that was inserted in the tree.</returns>
		if(!$util.isNullOrUndefined(level))
		{
			var domNode = this._findInsertLevel(level);
			level = $adrutil.getAddressFromDomElement(domNode); // level is now equal to the adr of the item.
		}
		return this._insert(node, level, index, true);
	},

	_insert: function(node, adr, index, fireEvents)
	{
		if($util.isNullOrUndefined(node) || (adr && !$adrutil.isAppendAddress(adr)) || index < -1)
			return;

		if(fireEvents)
		{
			if(this._raiseNodeAddingEvent(node))
				return; // event was cancelled.
		}

		// update the control DOM tree
		var htmlElem = node.get_element().cloneNode(true);
		// reset the object!!!
		htmlElem._object = null;

		this._internalInsert(htmlElem, adr, index);

		this._replaceTheme(node._stylePrefix, this._getStylePrefix(), htmlElem);

		this._addressGenerator.set_operation(1);
		this._addressGenerator.set_element(htmlElem);
		this._addressGenerator.set_node(node);
		this._addressGenerator.execute(null, $adrutil.getLocationFromDomElement(htmlElem));

		this._set_isClientStateDirty(true);

		var nodeObj = this._itemCollection._getUIBehaviorsObj().getItemFromElem(htmlElem);

		if(this.get_checkBoxMode() != $IG.CheckBoxMode.Off &&
		   this.get_enableAutoChecking())
		{
			this._applyCheckStateToParent(nodeObj);
		}

		if(fireEvents)
		{
			this._raiseNodeAddedEvent(nodeObj);
		}

		return nodeObj;
	},

	createNode: function(text)
	{
		//<summary locid="M:J#Infragistics.Web.UI.WebDataTree.createNode">Create a new node that can be added to the WebDataTree.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the created node.</returns>
		return this.createNode(text, null, null);
	},

	createNode: function(text, navigateUrl, target, value)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.createNode">Create a new node that can be added to the WebDataTree.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<param name="navigateUrl" type="String" mayBeNull="true">Specify the node navigate URL.</param>
		///<param name="target" type="String" mayBeNull="true">Specify the navigate URL target string.</param>
		///<param name="value" type="String" mayBeNull="true">Specify the node value string.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the created node.</returns>
		var props = new Array();
		var clientProps = new Array();
		var length = $IG.DataTreeNodeProps.Count;
		for(var i = 0; i < length; i++)
			clientProps.push(null);

		clientProps[$IG.NavItemProps.Text[0]] = (!$util.isNullOrUndefined(text) ? text : "NewNode");
		clientProps[$IG.NavItemProps.NavigateUrl[0]] = $util.isNullOrUndefined(navigateUrl) ? "#" : navigateUrl;
		clientProps[$IG.NavItemProps.Target[0]] = $util.isNullOrUndefined(target) ? "" : target;
		clientProps[$IG.NavItemProps.Value[0]] = $util.isNullOrUndefined(value) ? "" : value;
		clientProps[$IG.DataTreeNodeProps.CheckState[0]] = $IG.DataTreeNodeProps.CheckState[1];
		clientProps[$IG.DataTreeNodeProps.Editable[0]] = $IG.DataTreeNodeProps.Editable[1];

		props.push(clientProps);
		var elem = this._createNodeElement(text, navigateUrl, target);
		var col = new Array();
			col.push(props);
		var csm = new $IG.WebDataTreeCollectionClientStateManager(col);
		var coll = new $IG.NodeCollection(null, csm, null, null);
		var item = new $IG.Node("0", elem, props, null, csm, coll, null);
		item._stylePrefix = this._getStylePrefix();

		return item;
	},
	
	_internalInsert: function(nodeElem, adr, index, nodeAfter)
	{
		// M.H. 16 Aug 2011 Bug #83515. Add parameter nodeAfter - if it is specified and index > -1 then nodeElem should be inserted before nodeAfter
		

		var isRootAddress = false;
		if($util.isNullOrUndefined(adr))
		{
			if(index != -1)
			{
				var domNode = this._findInsertLevel(index.toString());
				adr = $adrutil.getAddressFromDomElement(domNode);
			} else {
				adr = index.toString();
			}
			isRootAddress = true;
		}
		//I.I. 95976: When move a child node as a root node its style is not correct
		else if (!$util.isNullOrUndefined(nodeAfter))
		{
			isRootAddress = nodeAfter.get_level() == 0 || nodeAfter.get_parentNode() == null;
		}

		if($util.isNullOrUndefined(nodeElem) || !$adrutil.isAppendAddress(adr) || index < -1)
			return;

		var parentLi = this._findInsertLocation(adr);

		if($util.isNullOrUndefined(parentLi) && adr == "-1")
		{
			
			var control = this.get_element();
			var rootUlList = control.getElementsByTagName("UL");
			var ul;
			if(rootUlList.length > 0)
			{ 
			  ul = rootUlList[0];
			} else {
			  ul = this._createNodeGroup(true);
			  control.appendChild(ul);
			}
			ul.appendChild(nodeElem);
			this._updateNodeCssClass(nodeElem, isRootAddress);
			this._updateNodeExpanderImage(nodeElem, null, null);
			this._updateNodeImage(nodeElem);
			this._updateCheckBoxImage(nodeElem);
			return;
		}
		
		if(!parentLi)
			return;

		var isRealLeafParent = $adrutil.isRealLeafNode(parentLi);
		var isLeafParent = $adrutil.isLeafNode(parentLi);
		var nodesUl;
		if(isRealLeafParent && !isRootAddress)
		{
			var nodesUl = this._createNodeGroup();
			this._itemCollection._getUIBehaviorsObj().getItemFromElem(parentLi)._set_value($IG.DataTreeNodeProps.Expanded, false);
			parentLi.appendChild(nodesUl);
		}

		// if the node is root node, findInsertLocation will return the corresponding root node.
		// if adr is -1 it will return the first node LI, but we need the <UL>
		// K.D. July 23rd, 2013 Bug #147254 Changing to getImmediateElementsByTagName because the other function returned undefined for newly added nodes
		// Also caching the UL if it has just been created and reusing it.
		nodesUl = nodesUl || (isRootAddress ? parentLi.parentNode : $adrutil.getImmediateElementsByTagName(parentLi, "UL")[0]);
		
		// M.H. 16 Aug 2011 Bug #83515. When nodeAfter is specified and index is greater gte 0 then insert nodeElem before nodeAfter
		if (nodeAfter !== undefined && nodeAfter !== null && index >= 0) {
			nodeAfter.get_element().parentNode.insertBefore(nodeElem, nodeAfter.get_element());
			// K.D. July 15th 2013 Bug #144549 The length check should be performed against a filtered collection
			// because childNodes returns empty text nodes as well
		} else if (index >= 0 && index < $adrutil.getImmediateElementsByTagName(nodesUl, "LI").length) {
			// the index does not account the text nodes that are present in FF, Chrome and other browsers.
			// So get the real element after they are filtered.
			nodesUl.insertBefore(nodeElem, $adrutil.getImmediateElementsByTagName(nodesUl, "LI")[index]);
		} else {
			nodesUl.appendChild(nodeElem);
		}
		this._updateNodeCssClass(nodeElem, isRootAddress);

		// this._setMarginsIfDragDrop(nodeElem); No need to set margins since we have chosen another approach.
		if(isLeafParent && $adrutil.hasVisibleChildren(parentLi))
		{
			this._updateNodeExpanderImage(parentLi, true, null);
		}
		else
		{
			this._updateNodeExpanderImage(nodeElem, null, null);
		}
		
		if(this.get_enableConnectorLines())
		{
			var previousSibling = $util.skipTextNodes(nodeElem.previousSibling, true);
			var nextSibling = $util.skipTextNodes(nodeElem.nextSibling);
			var isLastSibling = $util.isNullOrUndefined(nextSibling);

			if(isLastSibling && !$util.isNullOrUndefined(previousSibling))
			{
				this._updateNodeExpanderImage(previousSibling, null, null);
			}
			if(!isLastSibling && !$util.isNullOrUndefined(nextSibling))
			{
				this._updateNodeExpanderImage(nextSibling, null, null);
			}

			//I.I. 85716: ConnectorLines are not correct after drag and drop
			// K.D. April 27th, 2012 Bug #110705 When you move from one tree onto another and back
			// there is a JS exception because adr attribute is already initialized and it wrongly tries
			// to retrieve the item from the item collection of the destination tree
			if (!$util.isNullOrUndefined(this._currentTreeId)
					&& this._currentTreeId !== this.get_id()) {
				nodeElem.setAttribute("adr", '');
			}
			var node = this._ensureNode(nodeElem);
			if (node)
			{
				var parentNode = node.get_parentNode();
				if (parentNode && parentNode.get_parentNode() == null)
				{
					//I.I. 97754: After moving a node the expand image of the node where it is moved dissapears
					
					this._updateNodeExpanderImage(parentNode.get_element(), true, parentNode.get_expanded());
				}
			}
		}

		this._updateNodeImage(parentLi, true);
		this._updateNodeImage(nodeElem);
		this._updateCheckBoxImage(nodeElem);
	},

	_createNodeGroup: function(visible)
	{
		var ul = document.createElement("ul");
		this._toggleCss(ul, this._resolveClass("NodeGroup"), true);
		var padding = this._nodeIndent + "px";
		if(!this.get_enableConnectorLines() && !$util.isNullOrUndefined(this._nodeIndent)) {
			ul.style.paddingLeft = padding;
		}
		if(!visible)
			ul.style.display = "none";
		return ul;
	},
	
	_updateNodeCssClass: function(nodeElem, isRootAddress)
	{
		var anchorElem = this._getNodeATag(nodeElem);

		if(isRootAddress)
		{
			this._toggleCss(anchorElem, this._resolveClass("NodeRoot"), true);
		}
		else
		{
			this._toggleCss(anchorElem, this._resolveClass("NodeRoot"));
		}

		// remove some css classes
		this._toggleCss(anchorElem, this._resolveClass("NodeActive"));
		this._toggleCss(anchorElem, this._resolveClass("NodeSelected"));
	},

	_internalRemove: function(nodeElem)
	{
		// K.D. September 30th, 2013 Bug #149478 When dragging a node to another tree and then 
		// drag it back to its original position - the node is replicated in the both trees
		if(!nodeElem)
			return;
		var isRootAddress = nodeElem.parentNode.parentNode.nodeName == "DIV";
		var parentLi = nodeElem.parentNode.parentNode.nodeName == "LI" ? nodeElem.parentNode.parentNode : null;
		var nodesUl = isRootAddress ? nodeElem.parentNode : $util.skipTextNodes(this._getNodeULTag(parentLi));
		var previousSibling = $util.skipTextNodes(nodeElem.previousSibling, true);
		var isLastSibling = $util.isNullOrUndefined($util.skipTextNodes(nodeElem.nextSibling));
		var isLeafParent = isRootAddress ? false : $adrutil.isLeafNode(parentLi);

		if(nodesUl)
		{
			nodesUl.removeChild(nodeElem);
		    // K.D. May 12th, 2014 Bug #170022 Including a check for the parent li to determine
            // whether this is not a root node.
			if (!nodesUl.hasChildNodes() && parentLi)
			{
				// hide the UL, when its empty and when it's not the root UL.
				nodesUl.style.display = "none";
			}
		}
		if(parentLi)
		{
			// if the node wasn't leaf and now is leaf,
			// update parent li image to minus if last child.
			if(!isLeafParent && !$adrutil.hasVisibleChildren(parentLi))
			{
				this._updateNodeExpanderImage(parentLi, false, false);
			}

			if(isLastSibling && !$util.isNullOrUndefined(previousSibling))
			{
				this._updateNodeExpanderImage(previousSibling, null, null);
			}

			this._updateNodeImage(parentLi);
		}
	},
	
	_isExpandedNodeElement: function(domNode)
	{
		if(!$util.isNullOrUndefined(domNode) && domNode.nodeName == "LI")
		{
			var ul = this._getNodeULTag(domNode);
			if(ul)
			{
				if($util.IsIE7)
				{
					return ul.style.getAttribute("display") != "none";
				}
				else
				{
					return ul.style.display != "none";
				}
			}
		}
		return false;
	},
	
	_updateNodeExpanderImage: function(nodeElem, hasVisibleChildren, isExpanded)
	{
		if(!this.get_enableExpandImages() && !this.get_enableConnectorLines())
			return;
			
		// clear any images left from before.
		this._clearImages(nodeElem, ["nidx", "cidx"]);

		var imageElem = $util.skipTextNodes(this._getExpanderImageTag(nodeElem));

		if($util.isNullOrUndefined(hasVisibleChildren))
			hasVisibleChildren = $adrutil.hasVisibleChildren(nodeElem);

		if($util.isNullOrUndefined(isExpanded))
			isExpanded = this._isExpandedNodeElement(nodeElem);

		// create the expander image and add it.
		if($util.isNullOrUndefined(imageElem))
		{
			imageElem = this._createExpanderImage("");
			nodeElem.insertBefore(imageElem,nodeElem.firstChild);
			imageElem.removeAttribute("width");
			imageElem.removeAttribute("height");
		}

		if(this.get_enableConnectorLines())
		{
			if(!$adrutil.isRootLevelNodeElement(nodeElem))
			{
				var displayChain = this._buildDisplayChain(nodeElem);

				for(var j = 0; j < displayChain.length; j++)
				{
					var index = displayChain[j] == "1" ? 16 : 0;
					var img = this._createExpanderImage(this._imageList[index].src);
				 this._toggleCss(img, index.toString(), true);
					nodeElem.insertBefore(img, nodeElem.firstChild);
					img.removeAttribute("width");
					img.removeAttribute("height");
					this._resolveImage(img);
				}
			}
		}

		var index = this._getDomNodeImageIndex(nodeElem, hasVisibleChildren, isExpanded);

		var src = this._imageList[index].src;
		if(src && src !== "")
		{
			imageElem.src = src;
		}
		this._setCssClass(imageElem, index.toString());
		this._resolveImage(imageElem);

		if(hasVisibleChildren && this.get_enableExpandImages())
		{
			// K.D. Bug #102347 When moving from different tree we should not be trying to access the node object
			// as it currently does not exist, so switching implementation to use the node element instead
			var text;
			for (var i = 0; i < nodeElem.children.length; i++) {
				if (nodeElem.children[i].nodeName === "A") {
					text = nodeElem.children[i].textContent;
				}
			}

			if(isExpanded && !$util.isNullOrUndefined(this.get_collapseImageToolTip()))
			{
				imageElem.title = this.get_collapseImageToolTip().replace("{0}", text);
			}
			else if(!isExpanded && !$util.isNullOrUndefined(this.get_expandImageToolTip()))
			{
				imageElem.title = this.get_expandImageToolTip().replace("{0}", text);
			}
		}

		if(this.get_enableConnectorLines() && hasVisibleChildren)
		{
			// update the children images, too
			var ul = this._getNodeULTag(nodeElem);
			var len = ul ? ul.childNodes.length : 0;
			for(var i=0; i < len; i++)
			{
				if(ul.childNodes[i].nodeName == "LI")
					this._updateNodeExpanderImage(ul.childNodes[i], null, null);
			}
		}
	},

	/////////////////////////////// CONNECTOR LINES /////////////////////////////////////////

	_clearNormalImages: function(domNode)
	{
		this._clearImages(domNode, ["nidx"]);
	},

	_clearConnectorImages: function(domNode)
	{
		this._clearImages(domNode, ["cidx"]);
	},

	_clearImages: function(domNode, tagNameArray)
	{
		if($util.isNullOrUndefined(domNode))
			return;

		for(var i = 0; i < domNode.childNodes.length; i++)
		{
			var child = domNode.childNodes[i];
			if(child.nodeName == "IMG")
			{
				for(var j=0; j < tagNameArray.length; j++)
				{
					var idx = child.getAttribute(tagNameArray[j]);
					if(!$util.isNullOrUndefined(idx) && parseInt(idx) > -1)
					{
						domNode.removeChild(child);
						i--;
						break;
					}
				}
			}
		}
	},

	_buildDisplayChain: function(domNode)
	{
		
		var displayChain = new Array();

		if(!$util.isNullOrUndefined(domNode) && !$util.isNullOrUndefined(domNode.parentNode))
		{
			var parent = domNode.parentNode.parentNode; // get parent LI.

			while(!$util.isNullOrUndefined(parent) && parent.nodeName == "LI")
			{
				displayChain.push((!$util.isNullOrUndefined($util.skipTextNodes(this._getNextVisibleSibling(parent)))) ? "1" : "0");
				parent = parent.parentNode.parentNode;
			}
		}

		return displayChain;
	},
	
	_getDomNodeImageIndex: function(domNode, hasVisibleChildren, isExpanded)
	{
		
		if($util.isNullOrUndefined(domNode))
			return;

		var index = 0;
		var adr = $adrutil.getAddressFromDomElement(domNode);
		var level = $adrutil.getLevelByAdr(adr);
		var isEmptyParent = false;

		if($util.isNullOrUndefined(hasVisibleChildren))
			hasVisibleChildren = $adrutil.hasVisibleChildren(domNode);

		if($util.isNullOrUndefined(isExpanded))
			isExpanded = this._isExpandedNodeElement(domNode);

		if(this.get_enableConnectorLines())
		{
			if ($adrutil.isRootLevelNodeElement(domNode))
			{
				if (this._itemCollection.get_length() == 1)
				{
					if(!this.get_enableExpandImages())
						return 13;
					if(hasVisibleChildren || isEmptyParent)
					{
						if(isExpanded)
							return 15;
						else
							return 14;
					}
					else {
						return 13;
					}
				}
			}

			switch(this._getDomNodePosition(domNode)) // -1 - Top, 0 - Middle, 1 - Bottom
			{
				case -1 :
					index = 2;
					break;
				case 0 :
					index = 5;
					break;
				case 1 :
					index = 8;
					break;
			}
			if((hasVisibleChildren || isEmptyParent) && this.get_enableExpandImages())
			{
				if (isExpanded)
					index += 2;
				else
					index++;
			}
		}
		else
		{
			if(isEmptyParent && !isExpanded)
			{
				index = 1;
			}
			else
			{
				if (!hasVisibleChildren)
					index = 0;
				else
					if (isExpanded)
						index = 2;
					else
						index = 1;
			}
		}
		return index;
	},
	
	_getDomNodePosition: function(domNode)
	{
		
		
		if($util.isNullOrUndefined($util.skipTextNodes(this._getNextVisibleSibling(domNode))))
			return 1;
		if($util.isNullOrUndefined($util.skipTextNodes(this._getPreviousVisibleSibling(domNode), true)))
		{
			if(domNode.parentNode.parentNode.nodeName != "LI")
				return -1;
			else
				return 0;
		}
		return 0;
	},

	_getNextVisibleSibling: function(domNode)
	{
		var nextSibling = domNode.nextSibling;
		while (nextSibling != null && nextSibling.tagName == "LI" && nextSibling.style.display == "none")
			nextSibling = nextSibling.nextSibling;

		return nextSibling;
	},
	
	_getPreviousVisibleSibling: function(domNode)
	{
		var previousSibling = domNode.previousSibling;
		while (previousSibling != null && previousSibling.tagName == "LI" && previousSibling.style.display == "none")
			previousSibling = previousSibling.previousSibling;

		return previousSibling;
	},

	///////////////////////////////////// END CONNECTOR LINES ////////////////////////////////

	_updateNodeImage: function(nodeElem, isParent)
	{
		var image = this._getNodeImageTag(nodeElem);
		var rootImgSrc = !$adrutil.hasVisibleChildren(nodeElem) ? this._leafNodeImageURL : this._parentNodeImageURL;
		var aTag = this._getNodeATag(nodeElem);
		// if we have templates, then do not apply node images.
		if(aTag.nodeName == "TD")
			return;

		if(!$util.isNullOrUndefined(rootImgSrc) && rootImgSrc.length > 0)
		{
			if($util.isNullOrUndefined(image))
			{
				// no such image, add it
				nodeElem.insertBefore(this._createNodeImage(rootImgSrc),
									  aTag);
			}
			else if(rootImgSrc && rootImgSrc !== "")
			{
				// child is now parent, replace src with parent image
				image.src = rootImgSrc;
			}
		}
		else if(!$util.isNullOrUndefined(this._nodeSettingsImageURL) && this._nodeSettingsImageURL.length > 0)
		{
			if($util.isNullOrUndefined(image))
			{
				// no such image, add it
				nodeElem.insertBefore(this._createNodeImage(this._nodeSettingsImageURL),
									  aTag);
			}
			else if(this._nodeSettingsImageURL && this._nodeSettingsImageURL !== "")
			{
				image.src = this._nodeSettingsImageURL;
			}
		} 
		// M.H. 26 Jul 2011 - fix bug 32654 - remove image when for the tree it is not specified _nodeSettingsImageURL or rootImgSrc
		// M.H. 13 Oct 2011 - fix bug 87083 - check whether current tree id is different then id of the control
		// Case when element is dropped in another tree
		// K.D. April 27th, 2012 Bug #110705 UpdateNodeImage is called for the new parent of the node in the destination
		// tree and the image of the parent is removed
		else if(!$util.isNullOrUndefined(image) 
				&& this._currentTreeId !== null 
				&& this._currentTreeId !== undefined
				&& this._currentTreeId !== this.get_id()
				&& !isParent)
		{
			// remove image because for the tree it is not specified _nodeSettingsImageURL or rootImgSrc
			nodeElem.removeChild(image);
		}
		
//        else /* can be chnged in the future to clear the image, or introduce some property to control this. */
//        {
//            if(!$util.isNullOrUndefined(image))
//            {
//                // remove it, because no parent image in place
//                nodeElem.removeChild(image);
//            }
//        }
	},
	
	_updateCheckBoxImage: function(nodeElem, isFromOtherTheme)
	{
		var image = this._getCheckBoxImageTag(nodeElem);
		if(this.get_checkBoxMode() != $IG.CheckBoxMode.Off)
		{
			var aTag = this._getNodeATag(nodeElem);
			// if we have templates, then do not apply node images.
			if(aTag.nodeName == "TD")
				return;
			
			if (!image)
			{
				image = document.createElement("IMG");
				$util._setXAttr(image, "x:1479222905.18:mkr:check");
				nodeElem.insertBefore(image, this._getNodeImageTag(nodeElem) || aTag);
			}
			aTag = image.src;
			if (aTag)
			{
					if (aTag.indexOf("partial") >= 0)
						aTag = "2";
					else if (aTag.indexOf("off") >= 0)
						aTag = "0";
					else
						aTag = aTag.indexOf("on") < 0 ? null : "1";
			}
			if (!aTag)
					aTag = "" + nodeElem.getAttribute("checked");
				aTag = aTag == "1" ? this._checkedImageURL : (aTag == "2" ? this._partialImageURL : this._uncheckedImageURL);
				if (aTag)
					image.src = aTag;
		}
		else if(image)
			// remove it, because check box mode is OFF
			nodeElem.removeChild(image);
	},
	
	_getNodeImageTag: function(nodeElem)
	{
		var len = nodeElem.childNodes.length;
		for(var i = 0; i < len; i++)
		{
			var child = nodeElem.childNodes[i];
			if(child.nodeName == "IMG")
			{
				var css = $util.getCssClass(child);
				if(!$util.isNullOrUndefined(css) && css.indexOf("NodeImage") != -1)
				{
					return child;
				}
			}
		}
		return null;
	},
	
	_getCheckBoxImageTag: function(nodeElem)
	{
		var len = nodeElem.childNodes.length;
		for(var i = 0; i < len; i++)
		{
			var child = nodeElem.childNodes[i];
			if(child.nodeName == "IMG")
			{
				var id = $util._getXAttr(child);
				if(!$util.isNullOrUndefined(id) && id.indexOf("check") != -1)
				{
					return child;
				}
			}
		}
		return null;
	},

	_getExpanderImageTag: function(nodeElem)
	{
		var len = nodeElem.childNodes.length;
		for(var i = 0; i < len; i++)
		{
			var child = nodeElem.childNodes[i];
			if(child.nodeName == "IMG")
			{
				var idx = child.getAttribute("idx");
				if(!$util.isNullOrUndefined(idx))
				{
					var nidx = parseInt(idx);
					if(nidx != NaN && ((nidx >= 1 && nidx <= 4) ||
										nidx == 6 || nidx == 7 ||
										nidx == 9 || nidx == 10 ||
										nidx == 14 || nidx == 15))
						return child;
				}
			}
		}
		return null;
	},
	
	_getNodeULTag: function(nodeElem)
	{
		// K.D. October 2nd, 2013 Bug #151710 The isMy() function returns wrong on multi-tree operations
		// The issue here was that all child elements and not just direct children were retrieved
		var i = -1, nodes = nodeElem.childNodes;
		while (++i < nodes.length)
			if (nodes[i] && nodes[i].tagName === "UL")
				return nodes[i];
	},
	
	_getNodeATag: function(nodeElem)
	{
		var a = nodeElem.getElementsByTagName("A");

		if($util.isNullOrUndefined(a) || a.length == 0)
		{
			var tds = nodeElem.getElementsByTagName("TD");
			for(var i = 0, len=tds.length; i < len; i++)
			{
				var td = tds[i];
				var id = $util._getXAttr(td);
				if(!$util.isNullOrUndefined(id) && id.indexOf("mkr") != -1)
					return td;
			}
		}
		else
		{
			return a[0];
		}
	},

//    _getNodeStyleTag: function(nodeElem)
//    {
//        var aTag = this._getNodeATag(nodeElem);
//        if(aTag.nodeName == "TD")
//        {
//            // skip back to the table elem.
//            aTag = aTag.parentNode.parentNode.parentNode;
//        }
//        return aTag;
//    },
	
	_createNodeImage: function(src)
	{
		var image = document.createElement("IMG");
		if(src && src !== "")
		{
			image.src = src;
		}
		this._setCssClass(image, this._resolveClass("NodeImage"));
		$util._setXAttr(image, "x:1479222905.19:mkr:dtnIcon");
		return image;
	},
	
	_createExpanderImage: function(src)
	{
		var image = document.createElement("IMG");
		if(src && src !== "")
		{
			image.src = src;
		}
		image.alt = "";
		return image;
	},
	
	_findInsertLevel: function(level)
	{
		if(!$adrutil.isAppendAddress(level))
			return null;

		var rootUl = this._element.getElementsByTagName("UL")[0];

		if($adrutil.isAddress(level))
		{
			var indexes = level.split(".");

			var i=0, j=0, k=0;
			var len=rootUl.childNodes.length;

			while(i < len)
			{
				var child = rootUl.childNodes[i];
				if(child.nodeName == "LI")
				{
					if(k == indexes[j])
					{
						j++;
						if(j < indexes.length)
						{
							rootUl = child.getElementsByTagName("UL")[0];
							k = -1;
							len = $util.isNullOrUndefined(rootUl) ? 0 : rootUl.childNodes.length;
							i = -1;
						}
						else
						{
							return child;
						}
					}
					k++;
				}
				i++;
			}
		}

		return null;
	},
	
	_findInsertLocation: function(adr)
	{
		var nodes = this._element.getElementsByTagName("li");

		if($adrutil.isAddress(adr))
		{
			
			adr = $adrutil.getOriginalAdr(adr);
			for(var i=0, len=nodes.length; i < len; i++)
			{
				var li = nodes[i];
				
				var nodeId = li ? $adrutil.getAdrFromId($util._getXAttr(li)) : null;
				if($adrutil.getOriginalAdr(nodeId) === adr)
				{
					return li;
				}
			}
		}
		else if (adr == "-1")
		{
			return nodes[0];
		}

		return null;
	},

	_createNodeElement: function(text, navigateUrl, target)
	{
		
		var nodeElem = document.createElement("li");
	   this._toggleCss(nodeElem, this._resolveClass("NodeHolder"), true);
		// must be generated on add to the DOM tree.
	   $util._setXAttr(nodeElem, "");

		var anchorElem = document.createElement("a");
		anchorElem.href = navigateUrl || "#";
		
		this._fixA(anchorElem);
		anchorElem.target = target || "";
	   this._toggleCss(anchorElem, this._resolveClass("Node"), true);
		anchorElem.setAttribute("tabindex", "-1");
		// must be generated on add to the DOM tree.
		$util._setXAttr(anchorElem, "x:1.1:mkr:dtnContent");
		anchorElem.appendChild(document.createTextNode(text));
		nodeElem.appendChild(anchorElem);
		return nodeElem;
	},
	
	_getStylePrefix: function()
	{
		if($util.isNullOrUndefined(this._controlStylePrefix))
		{
			var controlCss = $util.getCssClass(this.get_element());
			if (controlCss != null)
			{
				controlCss = controlCss.replace(/ig_\w*Control/, "");
				controlCss = controlCss.replace(" ", "");
				this._controlStylePrefix = controlCss.substring(0, controlCss.indexOf("Control"));
			}
		}
		return this._controlStylePrefix;
	},
	
	_replaceTheme: function(oldStylePrefix, newStylePrefix, domNode)
	{
		if($util.isNullOrUndefined(domNode) ||
		   $util.isNullOrUndefined(oldStylePrefix) ||
		   $util.isNullOrUndefined(newStylePrefix) ||
		   oldStylePrefix == "" ||
		   newStylePrefix == "")
			return;

		if(oldStylePrefix != newStylePrefix)
		{
			
			var cssClass = $util.getCssClass(domNode);
			if(!$util.isNullOrUndefined(cssClass) && cssClass != "")
			{
				// replace all occurences of oldStylePrefix
				var regex = new RegExp(oldStylePrefix, "g");
				cssClass = cssClass.replace(regex, newStylePrefix);
				this._setCssClass(domNode, cssClass);
			}
		}

		if(domNode.nodeName == "LI")
		{
			this._updateNodeImage(domNode);
			this._updateCheckBoxImage(domNode, oldStylePrefix != newStylePrefix);
			this._updateNodeExpanderImage(domNode, $adrutil.hasVisibleChildren(domNode), this._isExpandedNodeElement(domNode));
		}
		else if(domNode.nodeName == "UL")
		{
			this._updatedNodeHolderPadding(domNode);
		}

		this._updateHolderAndGroupCssClasses(domNode);

		if(domNode.hasChildNodes())
		{
			for(var i=0; i < domNode.childNodes.length; i++)
			{
				if(domNode.childNodes[i].nodeType != 3)
					this._replaceTheme(oldStylePrefix, newStylePrefix, domNode.childNodes[i]);
			}
		}
	},
	
	_updatedNodeHolderPadding: function(ul)
	{
		if(ul)
		{
			var padding = this._nodeIndent + "px";
			if(!this.get_enableConnectorLines() && !$util.isNullOrUndefined(this._nodeIndent))
			{
				ul.style.paddingLeft = padding;
			}
			else if(this.get_enableConnectorLines())
			{
				ul.style.paddingLeft = "";
			}
		}
	},

	_updateHolderAndGroupCssClasses: function(domNode)
	{
		if(!$util.isNullOrUndefined(domNode) &&
		   (domNode.nodeName == "UL" || domNode.nodeName == "LI"))
		{
			var cssClass = $util.getCssClass(domNode);
			if(!$util.isNullOrUndefined(cssClass) && cssClass != "")
			{
				var initialCssClass = cssClass;

				if(this.get_enableConnectorLines())
				{
					var regex = new RegExp("NodeHolderDragDrop", "g");
					cssClass = cssClass.replace(regex, "NodeHolder");
					regex = new RegExp("NodeGroupDragDrop", "g");
					cssClass = cssClass.replace(regex, "NodeGroup");
				}
				else
				{
					if(cssClass.indexOf("NodeHolderDragDrop") == -1)
					{
						var regex = new RegExp("NodeHolder", "g");
						cssClass = cssClass.replace(regex, "NodeHolderDragDrop");
					}

					if(cssClass.indexOf("NodeGroupDragDrop") == -1)
					{
						regex = new RegExp("NodeGroup", "g");
						cssClass = cssClass.replace(regex, "NodeGroupDragDrop");
					}
				}

				if(initialCssClass != cssClass)
					this._setCssClass(domNode, cssClass);
			}
		}
	},

	_resolveClass: function(styleClass)
	{
		


		return this._getStylePrefix() + styleClass;
	},

	_setCssClass: function(elem, value)
	{
		if(!$util.isNullOrUndefined(elem) && !$util.isNullOrUndefined(elem.setAttribute))
		{
			if (!elem.className) 
			{
				elem.className = value;
			} 
			else 
			{
				elem.className += ' ' + value;
			}
		}
	},
	
	_raiseNodeAddingEvent: function(node)
	{
		var argsName = 'DataTreeNode';
		if(typeof(node) == "Array")
		{
			argsName = "DataTreeNodeRange";
		}
		
		var args = this._raiseClientEvent('NodeAdding', argsName, null, null, node);
		if (args && args.get_cancel())
		{
			return true;
		}
		return false;
	},

	_raiseNodeAddedEvent: function(node)
	{
		var argsName = 'DataTreeNode';
		if(typeof(node) == "Array")
		{
			argsName = "DataTreeNodeRange";
		}

		this._raiseClientEvent('NodeAdded', argsName, null, null, node);
	},
	
	_raiseNodeRemovingEvent: function(node)
	{
		var args = this._raiseClientEvent('NodeRemoving', 'DataTreeNode', null, null, node);
		if (args && args.get_cancel())
		{
			return true;
		}
		return false;
	},
	
	_raiseNodeRemovedEvent: function(node)
	{
		this._raiseClientEvent('NodeRemoved', 'DataTreeNode', null, null, node);
	}
	
}
$IG.WebDataTree.registerClass('Infragistics.Web.UI.WebDataTree', $IG.NavControl);

$IG.WebDataTree.find = function (clientID)
{
	///<summary>Finds WebDataTree by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebDataTree">Reference to the WebDataTree control object that corresponds to specified client ID.</returns>
};

$IG.WebDataTree.from = function (obj)
{
	///<summary>Casts passed in object to the WebDataTree type.</summary>
	///<param name="obj">Object to convert to the WebDataTree type.</param>
	///<returns type="Infragistics.Web.UI.WebDataTree">Reference to the same object that is passed in, only type converted to the WebDataTree type.</returns>
};


$IG.NodeSettings = function(obj, element, props, control, mkrAttribute)
{
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;	
	$IG.NodeSettings.initializeBase(this, [obj, element, props, control, csm]);
	this._mkrAttribute = mkrAttribute;
}

$IG.NodeSettings.prototype =
{
	get_selectedCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.selectedCssClass">
		/// Returns a string value that specifies the Css class used for nodes when they are selected.
		///</summary>
		return this._get_value($IG.NodeSettingsProps.SelectedCssClass);
	},
	
	set_selectedCssClass:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.selectedCssClass">
		/// Sets a string value that specifies the Css class used for nodes when they are selected.
		///</summary>
		this._set_value($IG.NodeSettingsProps.SelectedCssClass, value);
	},
	
	get_hoverCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.hoverCssClass">
		/// Returns a string value that specifies the Css class used for nodes when they are hovered.
		///</summary>
		return this._get_value($IG.NodeSettingsProps.HoverCssClass);
	},
	
	set_hoverCssClass:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.hoverCssClass">
		/// Sets a string value that specifies the Css class used for nodes when they are hovered.
		///</summary>
		this._set_value($IG.NodeSettingsProps.HoverCssClass, value);
	}
}
$IG.NodeSettings.registerClass('Infragistics.Web.UI.NodeSettings', $IG.ObjectBase);














$IG.NodeEditing = function(obj, element, props, control, mkrAttribute)
{
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;	
	$IG.NodeEditing.initializeBase(this, [obj, element, props, control, csm]);
	this._mkrAttribute = mkrAttribute;
}

$IG.NodeEditing.prototype =
{
	
	enterNodeEditing: function(node)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDataTree.enterNodeEditing">
		/// Causes the tree to enter edit mode.
		/// </summary>
		/// <param name="node" type="Infragistics.Web.UI.Node">The node to enter edit mode.</param>
		this._owner._enterNodeEditing(node);
	},

	exitNodeEditing: function(update)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.WebDataTree.exitNodeEditing">
		/// Causes the tree to exit edit mode.
		/// </summary>
		/// <param name="update" type="Boolean">Request to update value.</param>
		this._owner._exitNodeEditing(update);
	},
	
	get_isInNodeEditing: function(node)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.WebDataTree.isInNodeEditing">
		/// Gets a value that indicates whether the node is in edit mode.
		/// </summary>
		/// <param name="node" type="Infragistics.Web.UI.Node">WebDataTree node object.</param>
		return this._owner._get_isInNodeEditing(node);
	},
	
	get_enabled:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enabled">
		/// Get the state of the node editing.
		///</summary>
		/// <value type="Boolean" />
		return this._get_value($IG.NodeEditingProps.Enabled, true);
	},
	
	set_enabled:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enabled">
		/// Enable or disable node editing.
		///</summary>
		/// <param name="value" type="Boolean"></param>
		return this._set_value($IG.NodeEditingProps.Enabled, value);
	},
	
	get_enableOnF2:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnF2">
		/// Returns true if node edit mode can be entered by pressing F2.
		///</summary>
		/// <value type="Boolean" />
		return this._get_value($IG.NodeEditingProps.EnableOnF2, true);
	},
	
	set_enableOnF2:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnF2">
		/// Enable or disable entering edit mode by pressing F2.
		///</summary>
		///<param name="value" type="Boolean"></param>
		return this._set_value($IG.NodeEditingProps.EnableOnF2, value);
	},
	
	get_enableOnDoubleClick:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnDoubleClick">
		/// Returns true if node edit mode can be entered by double clicking on a node.
		///</summary>
		/// <value type="Boolean" />
		return this._get_value($IG.NodeEditingProps.EnableOnDoubleClick, true);
	},

	set_enableOnDoubleClick:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnDoubleClick">
		/// Enable or disable entering edit mode by double clicking on a node.
		///</summary>
		/// <param name="value" type="Boolean"></param>
		return this._set_value($IG.NodeEditingProps.EnableOnDoubleClick, value);
	},

	get_enableOnSingleClickWhenActive: function () 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnActive">
		/// Returns true if node edit mode can be entered by a node becoming active.
		///</summary>
		/// <value type="Boolean" />
		return this._get_value($IG.NodeEditingProps.EnableOnSingleClickWhenActive, true);
	},

	set_enableOnSingleClickWhenActive: function (value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.enableOnActive">
		/// Enable or disable entering edit mode by making the node active.
		///</summary>
		/// <param name="value" type="Boolean"></param>
		return this._set_value($IG.NodeEditingProps.EnableOnSingleClickWhenActive, value);
	},
	
	get_internalEditorCssClass:function() 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.internalEditorCssClass">
		/// Returns a string value that specifies the CSS class used for the internal node editor.
		///</summary>
		/// <value type="String" />
		return this._get_value($IG.NodeEditingProps.InternalEditorCssClass);
	},
	
	set_internalEditorCssClass:function(value) 
	{ 
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.internalEditorCssClass">
		/// Sets the value of the CSS class used for the internal node editor.
		///</summary>
		/// <param name="value" type="String">CSS class</param>
		return this._set_value($IG.NodeEditingProps.InternalEditorCssClass, value);
	}
	
}
$IG.NodeEditing.registerClass('Infragistics.Web.UI.NodeEditing', $IG.ObjectBase);














$IG.NodeCollection = function(control, clientStateManager, index, manager)
{
	///<summary>
	///Used internally to construct the NodeCollections of the DataTree.
	///</summary>
	$IG.NodeCollection.initializeBase(this, [control, clientStateManager, index, manager]);
}

$IG.NodeCollection.prototype = 
{
	_createNewCollection:function()
	{
		var nodes = new $IG.NodeCollection(this._control, this._csm, this._index, this._manager);
		nodes._ownerNode = this;
		return nodes;
	},
	
	_createObject: function(adr, element)
	{
		return this._addObject($IG.Node, element, adr);
	},

	getNode:function(index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.getNode">
		///Returns the Node at the specified index. 
		///</summary>
		///<param name="index" type="Number" integer="true">Index of the node in the collection.</param>
		///<returns type="Infragistics.Web.UI.Node"/>
		if(index < 0)
			return null;

		var node = this._getObjectByIndex(index);
		if($util.isNullOrUndefined(node))
		{
			if ($util.isNullOrUndefined(this._owner))
				return null;

			var adr;
			if(this._owner._get_address)
				adr = this._owner._get_address() + "." + index;
			else
				adr = index.toString();

			node = this._getObjectByAdr(adr);
		}
		return node;
	},
	
	_addObject:function(navItemType, element, adr)
	{
		//if(!this._control._isMy(element)) return;
		var isRootNode = $adrutil.isRootLevelNodeElement(element);
		var object = null;
		var newCollection = this._createNewCollection();
		if(isRootNode)
		{
			var val = parseInt($adrutil.getLocationFromDomElement(element));
			if(val.toString() != "NaN")
			{
				object = new navItemType(adr, element, null, this._control, this._csm, newCollection, null);
				if(this._control._get_isClientStateDirty())
				{
					this._items.push(object);
				}
				else
				{
					this._items[val] = object;
				}
			}
		}
		else
		{
			var parent = this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(element.parentNode.parentNode);
			if(parent != null)
			{
				object = new navItemType(adr, element, null, this._control, this._csm, newCollection, parent);
				













				 if(this._control._get_isClientStateDirty())
				 {
					parent.getItems()._items.push(object);
				 }
				 else
				 {
					parent.getItems()._items[$adrutil.indexOfDomElement(element)] = object;
				 }
			}
		}
		this._manager.addObject(this._index, adr, object);

		if(object.get_checkState() == $IG.CheckBoxState.Checked)
			this._control._checkedNodes.push(object);

		return object;
	},

	_getObjectByIndex: function(index)
	{
		if(this._control._get_isClientStateDirty()) {
			var domNode;
			if (this._owner._get_address) {
				var nodesUl = this._control._getNodeULTag(this._owner.get_element());
				if (nodesUl && index < nodesUl.childNodes.length)
					domNode = $adrutil.getImmediateElementsByTagName(nodesUl, "LI")[index];
			} else {
				domNode = this._control._findInsertLevel(index.toString());
			}
			return this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(domNode);
		} else {
			return this._items[index];
		}
	},

	addText: function(text)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addText">Add a new node with the specifed text to the collection.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the added node.</returns>
		var node = this._control.createNode(text);
		return this._control._insert(node, this._get_address(), -1, true);
	},

	addText: function(text, navigateUrl)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addText">Add a new node with the specifed text and navigate url to the collection.</summary>
		///<param name="text" type="String" mayBeNull="true">Specify the node text.</param>
		///<param name="navigateUrl" type="String" mayBeNull="true">Specify the node navigate URL.</param>
		///<returns type="Infragistics.Web.UI.Node">Returns the added node.</returns>
		var node = this._control.createNode(text, navigateUrl);
		return this._control._insert(node, this._get_address(), -1, true);
	},

	add: function(node)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.add">Add a the specified node to the collection.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">Specify the node to add.</param>
		return this._control.add(node, this._get_address());
	},

	addRange: function(nodeArray, index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.addRange">Add an array of nodes to the nodes collection at the specified index.</summary>
		///<param name="nodeArray" type="Array">Array of DataTreeNodes.</param>
		///<param name="index" type="int">Specify the index at which the nodes will be added. If -1 they will be appended.</param>
		this._control.addRange(nodeArray, this._get_address(), index);
	},
	
	remove: function(node, keepChildren)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.remove">Remove a node from the nodes collection.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be removed.</param>
		///<param name="keepChildren" type="Boolean">If true the children will not be removed.</param>
		///<returns type="Boolean">True if the node was successfully removed. False otherwise.</returns>
		this._control._addressGenerator.set_operation(2);
		return this._remove(node, keepChildren, true);
	},
	
	_remove: function(node, keepChildren, fireEvents)
	{
		if($util.isNullOrUndefined(node))
			return false;

		if($util.isNullOrUndefined(keepChildren))
			keepChildren = false;

		var nodeIndex = this.get_indexOf(node);

		if(nodeIndex == -1) // not part of this collection
			return false;
		   
		if(fireEvents)
		{
			if(this._control._raiseNodeRemovingEvent(node))
				return false;
		}

		this._control._removeIfSelected(node);
		this._control._removeIfChecked(node);
		this._removeIfActiveNode(node);

		var element = node.get_element();

		// K.D. April 3rd, 2012 Bug #106376 A js error is previewed when move first and last tree node to other tree and hover nodes
		// Getting address from the element itself, because otherwise if another element has been previously removed
		// then the executed action is applied on the wrong element
		if(this._control._addressGenerator.__operation == 2) {
			this._control._addressGenerator.set_node(node);
			this._control._addressGenerator.execute(node._get_address(), null);
		}
		
		if(this._control._addressGenerator.__operation == 3)
			element._oldLocation = node._get_address();

		if(!keepChildren)
			this._removeChildren(node);
		// remove the node from the DOM tree
		this._control._internalRemove(element);

		if(!this._control._get_enableClientRendering())
			this._manager.removeObject(this._index, node._get_address());

		this._items.splice(nodeIndex, 1);

		// K.D. January 27, 2011 Bug #62773 clientStateDirty needs to be set to true when NodeRemove operation is 
		// performed in order for NodeRemoved server event to be fired
		this._control._set_isClientStateDirty(true);
		if(fireEvents)
		{
			this._control._raiseNodeRemovedEvent(node);
		}

		return true;
	},

	_removeChildren: function(node)
	{
		var nodeUL = node ? this._control._getNodeULTag(node.get_element()) : null;
		if(!nodeUL)
			return;
		for(var i=0, len = nodeUL.childNodes.length; i < len; i++)
		{
			var childElem = nodeUL.childNodes[i];
			if(!$util.isNullOrUndefined(childElem._object))
			{
				var child = this._control._itemCollection._getUIBehaviorsObj().getItemFromElem(childElem);
				if(!$util.isNullOrUndefined(child))
				{
					this._control._removeIfSelected(child);
					this._removeIfActiveNode(child);
					if(!this._control._get_enableClientRendering())
						this._manager.removeObject(this._index, child._get_address());

					var childItems = child.getItems();
					if(!$util.isNullOrUndefined(childItems) && childItems.length > 0)
					{ 
						var childIndex = childItems.get_indexOf(child);
						if(childIndex != -1)
							childItems._items.splice(childIndex, 1);
					}
					childElem._object = null;

					if(child.hasChildren())
						this._removeChildren(child);
				}
			}
		}
	},

	_removeIfActiveNode: function(node)
	{
		var activeNode = this._control.get_activeNode();
		if(activeNode && activeNode._get_address() == node._get_address())
			this._control.set_activeNode(null, true);
	},
	
	removeAt: function(index, keepChildren)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.removeAt">Remove the node at the specified index.</summary>
		///<param name="index" type="int">The index of the node that will be removed.</param>
		///<param name="keepChildren" type="Boolean">If true the children will not be removed.</param>
		///<returns type="Infragistics.Web.UI.Node">The node that is removed from the collection.</returns>
		var node = this.getNode(index);
		this.remove(node, keepChildren);
		return node;
	},

	insert: function(node, index)
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.insert">Insert the specified node into the collection.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node">The node that will be inserted.</param>
		///<param name="index" type="int">Specify the index at which the node will be inserted between its siblings. Specify -1 to append the node.</param>
		return this._control.insert(node, this._get_address(), index);
	},
	
	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.WebDataTree.dispose">Disposes the object and all of its children.</summary>
		this._ownerNode = null;
		$IG.NodeCollection.callBaseMethod(this, "dispose");
	},
	
	_get_address: function()
	{
		return (this._owner._get_address ? $adrutil.getLocationFromDomElement(this._owner.get_element()) : null);
	},

	_getObjectByAdr: function(adr)
	{
		
		
		if (!(typeof adr == 'string' && adr.length > 0) && (isNaN(adr) || (!adr && adr !== 0)))
			return null;
		var node = $IG.NodeCollection.callBaseMethod(this, '_getObjectByAdr', [adr]);
		if(node != null)
			return node;
			
		// Lazy loading of nodes
		return this._findNodeByAdr(adr);
	},
	
	_findNodeByAdr: function(adr)
	{
		///<summary>
		/// Finds the Node at the specified address even if the Node object has not been yet initialized. 
		///</summary>
		
		if (!adr)
			return null;
		var indexes = adr.split('.');
		if (indexes.length < 1)
			return null;
		
		var collection = this._control.getNodes();
		var parentElement = this._control.get_element();
		var node = null;
		for(var i = 0; i < indexes.length; i++)
		{
			var currentIndex = indexes[i];
			node = collection._getObjectByIndex(currentIndex);
			if(node == null)
			{
				var nodeElement = this._control._get_childNodeElement(parentElement, currentIndex); //childElements[currentIndex];
				if(nodeElement == null)
					return null;
					
				this._control._initElemAttr(nodeElement);
				// K.D. February 23rd, 2012 Bug #102454 The node element has no attribute address if it's not attached to the DOM yet, and the address is actually passed into the function so I can just use it.
				var nodeAdr = nodeElement.getAttribute("adr");

				node = collection._addObject($IG.Node, nodeElement, nodeAdr ? nodeAdr : adr);
			}
			collection = node.getItems();
			parentElement = node.get_element();
		}
		
		return node;
	},
	
	
	get_length: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.WebDataTree.length">
		/// The amount of nodes in the collection.
		///</summary> 
		/// <value type="Number" integer="true" />
		return this._control._get_childrenCount(this._owner._element);
	}
}
$IG.NodeCollection.registerClass('Infragistics.Web.UI.NodeCollection', $IG.NavItemCollection);

















$IG.TreeInternalEditor = function(parentElement)
{
	///<summary locid="T:J#Infragistics.Web.UI.TreeInternalEditor">
	///The TreeInternalEditor is used when a tree node enters editing mode.
	///</summary>
	var input = document.createElement('INPUT');
	// K.D. July 12, 2013 Bug #145229 The HTML doesn't validate without an alt attribute
	input.setAttribute("alt", "Internal Tree Editor");
	//VS: is it already in showEditor?
	parentElement.appendChild(input);
	$IG.TreeInternalEditor.initializeBase(this, [input]);
	this.hideEditor();
}
$IG.TreeInternalEditor.prototype =
{
	get_value: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TreeInternalEditor.value">
		/// Gets/sets value to/from the editor. 
		/// </summary>
		return this._element.value;
	},

	set_value: function(val)
	{
		this._element.value = val;
	},

	showEditor: function(left, top, width, height, cssClass, parent, insertBeforeNode)
	{
		///<summary locid="M:J#Infragistics.Web.UI.TreeInternalEditor.showEditor">
		///Displays the editor in a specified location.
		///</summary>
		///<param name="left" type="Number" integer="true">
		///Left coordinate of the editor in pixels.
		///</param>
		///<param name="top" type="Number" integer="true">
		///Top coordinate of the editor in pixels.
		///</param>
		///<param name="width" type="Number" integer="true">
		///Width of the editor in pixels.
		///</param>
		///<param name="height" type="Number" integer="true">
		///Height of the editor in pixels.
		///</param>
		///<param name="cssClass" type="String">
		///Optional. CSS class to apply to the editor's main HTML element.
		///</param>
		///<param name="parent">
		///Optional. Parent HTML element if the editor needs to be reparented.
		///</param>
		var input = this._element;
		if (parent && input.parentNode != parent && insertBeforeNode)
		{
			// K.D. July 23rd 2013 Bug #147232 Node editing fails with an �input.parentNode is null� exception when attempting 
			// to edit the children of an edited parent with load on demand enabled.
			if (input.parentNode) {
				input.parentNode.removeChild(input);
			}
			//parent.appendChild(input);
			parent.insertBefore (input, insertBeforeNode);
		}
		
		









		style = input.style;
		//style.top = top + 'px';
		//style.left = left + 'px';
		style.display = '';
		//style.visibility = 'visible';
		if (cssClass)
			input.className = cssClass;
		style.width = width + 'px';
		style.height = height + 'px';
		
		if (!this._hasLsnr)
		{
			if (!this._onBlurFn)
			{
				this._onBlurFn = Function.createDelegate(this, this._onBlurHandler);
				this._onKeyFn = Function.createDelegate(this, this._onKeyDownHandler);
			}
			this._hasLsnr = true;
			$addHandler(input, 'blur', this._onBlurFn);
			$addHandler(input, 'keydown', this._onKeyFn);
		}
		try
		{
			input.focus();
			input.select();
		} catch (e) { }
	},

	notifyLostFocus: function(evnt)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TreeInternalEditor.notifyLostFocus">
		/// The method is called whenever the editor loses focus. 
		/// </summary>
		/// <param name="evnt">
		/// Event object associated with the event that triggered losing focus by the editor.
		/// </param>
	},

	get_displayText: function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.TreeInternalEditor.displayText">
		/// Gets formatted value from the editor. 
		/// </summary>
		return this._element.value;
	},

	hideEditor: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TreeInternalEditor.hideEditor">
		/// Hides the editor. 
		/// </summary>
		var input = this._element;
		//input.style.visibility = 'hidden';
		input.style.display = 'none';
		if (this._hasLsnr)
		{
			$removeHandler(input, 'blur', this._onBlurFn);
			$removeHandler(input, 'keydown', this._onKeyFn);
		}
		this._hasLsnr = false;
	},

	_onKeyDownHandler: function(evnt)
	{
		var key = evnt.keyCode;
		if (key == Sys.UI.Key.tab || key == Sys.UI.Key.esc || key == Sys.UI.Key.enter)
			this.notifyLostFocus(evnt);
	},
	
	_onBlurHandler: function(evnt)
	{
		this.notifyLostFocus(evnt);
	},
	
	dispose: function()
	{
		$clearHandlers(this.get_element());
		var parentEl = this.get_element().parentNode;
		parentEl.removeChild(this.get_element());
		$IG.TreeInternalEditor.callBaseMethod(this, 'dispose');
	}
	
}
$IG.TreeInternalEditor.registerClass('Infragistics.Web.UI.TreeInternalEditor', Sys.UI.Control);






$IG.DataTreeActivationEventArgs = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeActivationEventArgs">
	///Used internally to constuct event arguments to be passed to DataTree event activation handlers 
	///</summary>
	$IG.DataTreeActivationEventArgs.initializeBase(this);
}

$IG.DataTreeActivationEventArgs.prototype =
{
	
	getOldActiveNode: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeActivationEventArgs.getOldActiveNode">
		///Returns the old active tree node for this event. 
		///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
		return this._props[2];
	},
	
	getNewActiveNode: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeActivationEventArgs.getNewActiveNode">
		///Returns the new active tree node for this event. 
		///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
		return this._props[3];
	}
}
$IG.DataTreeActivationEventArgs.registerClass('Infragistics.Web.UI.DataTreeActivationEventArgs', $IG.CancelEventArgs);



$IG.DataTreeSelectionEventArgs = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeSelectionEventArgs">
	///Used internally to constuct event arguments to be passed to DataTree event selection handlers 
	///</summary>
	$IG.DataTreeSelectionEventArgs.initializeBase(this);
	this._noIndicator = true;
}

$IG.DataTreeSelectionEventArgs.prototype =
{
	
	getOldSelectedNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeSelectionEventArgs.getOldSelectedNodes">
		///Returns the old selected tree nodes array for this event. 
		///</summary>
		///<returns type="Array" elementType="Infragistics.Web.UI.Node"/>
		return this._props[2];
	},
	
	getNewSelectedNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeSelectionEventArgs.getNewSelectedNodes">
		///Returns the new selected tree nodes array for this event. 
		///</summary>
		///<returns type="Array" elementType="Infragistics.Web.UI.Node"/>
		return this._props[3];
	}
}
$IG.DataTreeSelectionEventArgs.registerClass('Infragistics.Web.UI.DataTreeSelectionEventArgs', $IG.CancelEventArgs);


$IG.DataTreeCheckBoxSelectionEventArgs = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeCheckBoxSelectionEventArgs">
	///Used internally to constuct event arguments to be passed to DataTree check box event selection handlers 
	///</summary>
	$IG.DataTreeCheckBoxSelectionEventArgs.initializeBase(this);
	this._noIndicator = true;
}

$IG.DataTreeCheckBoxSelectionEventArgs.prototype =
{
	
	getOldCheckedNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeCheckBoxSelectionEventArgs.getOldCheckedNodes">
		///Returns the old checked tree nodes array for this event. 
		///</summary>
		///<returns type="Array" elementType="Infragistics.Web.UI.Node"/>
		return this._props[2];
	},
	
	getNewCheckedNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeCheckBoxSelectionEventArgs.getNewCheckedNodes">
		///Returns the new checked tree nodes array for this event. 
		///</summary>
		///<returns type="Array" elementType="Infragistics.Web.UI.Node"/>
		return this._props[3];
	}
}
$IG.DataTreeCheckBoxSelectionEventArgs.registerClass('Infragistics.Web.UI.DataTreeCheckBoxSelectionEventArgs', $IG.EventArgs);


$IG.DataTreeNodeEventArgs = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeNodeEventArgs">
	///Used internally to constuct event arguments to be passed to DataTree event handlers 
	///</summary>
	$IG.DataTreeNodeEventArgs.initializeBase(this);
	this._noIndicator = true;
}

$IG.DataTreeNodeEventArgs.prototype =
{
	
	getNode: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeNodeEventArgs.getNode">
		///Returns the Node object for this event. 
		///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
		return this._props[2];
	},
	  
	_getPostArgs: function()
	{
		
		var node = this.getNode();
		//var _nodeAddr = this.getNode()._get_address();
		var _nodeAddr = node.length ? node[0]._get_address() : node._get_address();
		var _mouseButton =  this._props[4];
		return ':' + _nodeAddr + ":" + _mouseButton;
	}
}
$IG.DataTreeNodeEventArgs.registerClass('Infragistics.Web.UI.DataTreeNodeEventArgs', $IG.CancelEventArgs);

$IG.DataTreeNodeRangeEventArgs = function()
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeNodeRangeEventArgs">
	///Used internally to constuct event arguments to be passed to DataTree event handlers 
	///</summary>
	$IG.DataTreeNodeRangeEventArgs.initializeBase(this);
	this._noIndicator = true;
}

$IG.DataTreeNodeRangeEventArgs.prototype =
{
	
	getNodes: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DataTreeNodeRangeEventArgs.getNodes">Return an array of nodes.</summary>
		///<value type="Array" elementType="$IG.Node">Return an array of nodes.</value>
		return this._props[2];
	}
}
$IG.DataTreeNodeRangeEventArgs.registerClass('Infragistics.Web.UI.DataTreeNodeRangeEventArgs', $IG.CancelEventArgs);

$IG.DataTreeDragDropEventArgs = function(eventName)
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeDragDropEventArgs">
	///Used internally to constuct event arguments to be passed to Drag and Drop event handlers
	///</summary>
	if(!$util.isNullOrUndefined(eventName))
		this._name = eventName;
	$IG.DataTreeDragDropEventArgs.initializeBase(this);

	if(!$util.isNullOrUndefined(this._name) &&
	   this._name != "DragStart" &&
	   this._name != "DragEnter" &&
	   this._name != "NodeDropping")
	{
		delete this._cancel;
		delete this.get_cancel;
		delete this.set_cancel;
	}
}
$IG.DataTreeDragDropEventArgs.prototype =
{
	// [2] - eventArgs of D&D framework
	get_sourceNodes: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragDropEventArgs.sourceNodes">
		/// Get the nodes that are being dragged.
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.Node" />
		return this._props[2].get_manager().get_dataObject().get_nodes();
	},

	get_sourceTreeId: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragDropEventArgs.sourceTreeId">
		/// Get the id of the source tree for this drag operation.
		/// </summary>
		/// <value type="String" />
		return this._props[2].get_manager().get_dataObject().get_sourceTreeId();
	},

	get_dragDropEffect: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragDropEventArgs.dragDropEffect">
		/// Get the drop effect that will be applied.
		/// </summary>
		/// <value type="Infragistics.Web.UI.DragDropEffects" />
		return this._props[2].get_manager().get_dragDropEffect();
	},
	
	get_dragDropPoint: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragDropEventArgs.dragDropPoint">
		/// Get the drop point of object that is dropped in a drag & drop operation.
		/// </summary>
		/// <value type="Infragistics.Web.UI.DragDropPoint" />
		return this._props[4];
	},
	
	get_destNode: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragDropEventArgs.destNode">
		/// Get the destination node.
		/// </summary>
		/// <value type="Infragistics.Web.UI.Node" />
		return this._props[3];
	},

	_getPostArgs: function()
	{
		var sourceNodes = this.get_sourceNodes();
		var args = ":";
		for(var i = 0; i < sourceNodes.length; i++)
		{
			if(i > 0)
				args += ";";
			args += sourceNodes[i]._get_address();
		}
		args += ":" + this.get_sourceTreeId();
		args += ":" + ($util.isNullOrUndefined(this.get_destNode()) ? "none" : this.get_destNode()._get_address());
		args += ":" + this.get_dragDropEffect();
		args += ":" + this.get_dragDropPoint();
		args += ":";

		return args;
	}
}
$IG.DataTreeDragDropEventArgs.registerClass('Infragistics.Web.UI.DataTreeDragDropEventArgs', $IG.CancelEventArgs);

$IG.DataTreeDragMoveEventArgs = function(eventName)
{
	///<summary locid="T:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs">
	/// Used internally to constuct event arguments to be passed to Drag and Drop event handlers
	///</summary>
	if(!$util.isNullOrUndefined(eventName))
		this._name = eventName;
	$IG.DataTreeDragMoveEventArgs.initializeBase(this);
}
$IG.DataTreeDragMoveEventArgs.prototype =
{
	get_x: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs.x">
		/// Get the x mouse coordinate.
		/// </summary>
		/// <value type="int" />
		return this._props[2].get_x();
	},
	
	get_y: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs.y">
		/// Get the y mouse coordinate.
		/// </summary>
		/// <value type="int" />
		return this._props[2].get_y();
	},
	
	get_isCtrlKey: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs.isCtrlKey">
		/// Get whether Ctrl key is pressed during drag operation.
		/// </summary>
		/// <value type="Boolean" />
		return this._props[2].get_manager().isCtrlKey();
	},
	
	get_isShiftKey: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs.isShiftKey">
		/// Get whether Shift key is pressed during drag operation.
		/// </summary>
		/// <value type="Boolean" />
		return this._props[2].get_manager().isShiftKey();
	},

	get_isAltKey: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DataTreeDragMoveEventArgs.isAltKey">
		/// Get whether Alt key is pressed during drag operation.
		/// </summary>
		/// <value type="Boolean" />
		return this._props[2].get_manager().isAltKey();
	}
}
$IG.DataTreeDragMoveEventArgs.registerClass('Infragistics.Web.UI.DataTreeDragMoveEventArgs', $IG.DataTreeDragDropEventArgs);



// Node Editing Event Args Begin

$IG.CancelNodeEditingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.CancelNodeEditingEventArgs">
	/// Event arguments object that is passed into the NodeEditingEntering and NodeEditingExiting event handlers.
	/// Provides an option to cancel the events.
	/// </summary>
	$IG.CancelNodeEditingEventArgs.initializeBase(this);
}
$IG.CancelNodeEditingEventArgs.prototype =
{
	getNode: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CancelNodeEditingEventArgs.getNode">
		/// Returns the node that is about to enter edit mode.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Node"/>
		return this._props[2];
	}
}
$IG.CancelNodeEditingEventArgs.registerClass('Infragistics.Web.UI.CancelNodeEditingEventArgs', $IG.CancelEventArgs);

$IG.NodeEditingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.NodeEditingEventArgs">
	/// Event arguments object that is passed into the NodeEditingEntered and NodeEditingExited event handlers.
	/// </summary>
	$IG.NodeEditingEventArgs.initializeBase(this);
}
$IG.NodeEditingEventArgs.prototype =
{
	getNode: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.NodeEditingEventArgs.getNode">
		/// Returns the node that has entered edit mode.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Node"/>
		return this._props[2];
	}
}
$IG.NodeEditingEventArgs.registerClass('Infragistics.Web.UI.NodeEditingEventArgs', $IG.EventArgs);

$IG.TextChangeEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.TextChangeEventArgs">
	/// Event arguments object that is passed into the NodeEditingTextChanging and NodeEditingTextChanged event handlers.
	/// The "old value" can be obtained from the node itself.
	/// </summary>
	$IG.TextChangeEventArgs.initializeBase(this);
	this._noIndicator = true;
}
$IG.TextChangeEventArgs.prototype =
{
	getNode: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TextChangeEventArgs.getNode">
		/// Returns the node which value is about to be changed.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.Node"/>
		return this._props[2];
	},
	
	getNewText: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.TextChangeEventArgs.getNewText">
		/// Returns the new value.
		/// </summary>
		/// <returns type="String"/>
		return this._props[3];
	}
}
$IG.TextChangeEventArgs.registerClass('Infragistics.Web.UI.TextChangeEventArgs', $IG.CancelEventArgs);

// Node Editing Event Args End



$IG.DataBindingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.DataBindingEventArgs">
	/// Initializes data binding event arguments
	/// </summary>
	$IG.DataBindingEventArgs.initializeBase(this);
}
$IG.DataBindingEventArgs.prototype =
{
	
}
$IG.DataBindingEventArgs.registerClass('Infragistics.Web.UI.DataBindingEventArgs', $IG.CancelEventArgs);

$IG.DataBoundEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.DataBoundEventArgs">
	/// Initializes DataBoundEventArgs
	/// </summary>
	$IG.DataBoundEventArgs.initializeBase(this);
}
$IG.DataBoundEventArgs.prototype =
{
	getDataView: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DataBoundEventArgs.getDataView">
		/// Returns instance of data view
		/// </summary>
		return this._props[2];
	}
}
$IG.DataBoundEventArgs.registerClass('Infragistics.Web.UI.DataBoundEventArgs', $IG.EventArgs);

$IG.RenderingEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.RenderingEventArgs">
	/// Initializes RenderingEventArgs
	/// </summary>
	$IG.RenderingEventArgs.initializeBase(this);
}
$IG.RenderingEventArgs.prototype =
{
	getDataItem: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RenderingEventArgs.getDataItem">
		/// Get reference to data item
		/// </summary>
		return this._props[2];
	}
	
}
$IG.RenderingEventArgs.registerClass('Infragistics.Web.UI.RenderingEventArgs', $IG.CancelEventArgs);

$IG.RenderedEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.RenderedEventArgs">
	/// Initializes RenderedEventArgs
	/// </summary>
	$IG.RenderedEventArgs.initializeBase(this);
}
$IG.RenderedEventArgs.prototype =
{
	getDataItem: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RenderedEventArgs.getDataItem">
		/// Get reference to data item
		/// </summary>
		return this._props[2];
	},
	
	getElement: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RenderedEventArgs.getElement">
		/// Get reference to element
		/// </summary>
		return this._props[3];
	}
	
}
$IG.RenderedEventArgs.registerClass('Infragistics.Web.UI.RenderedEventArgs', $IG.EventArgs);



$IG.WebDataTreeCollectionClientStateManager = function(props, id)
{
	/// <summary locid="T:J#Infragistics.Web.UI.WebDataTreeCollectionClientStateManager">
	/// A ClientStateManager that handles any ObjectBase that belongs to an ObjectCollection.
	/// </summary>
	$IG.WebDataTreeCollectionClientStateManager.initializeBase(this,[props]);
	this._id = id;
	this._updating = false;
	this.clearLog();
}

$IG.WebDataTreeCollectionClientStateManager.prototype =
{
	isUpdatePending: function()
	{
		return this._updating;
	},
	
	begin_update: function(discardPendingUpdates)
	{
		if($util.isNullOrUndefined(discardPendingUpdates))
			discardPendingUpdates = false;

		if(!this.isUpdatePending() || discardPendingUpdates)
		{
			this._csmItems = [];
			this._transactionListItems = [];
			this._orderedListItems = [];
			this._oldAddressList = [];
			this._orderedIndexes = [];
			this._updating = true;
		}
	},

	logAdd: function(toAdr)
	{
		this._changeLog[0].push("a:"+ toAdr);
	},
	
	logRemove: function(fromAdr)
	{
		this._changeLog[0].push("r:"+ fromAdr);
	},
	
	logCopy: function(copyFromAdr, toAdr)
	{
		this._changeLog[0].push("c:"+ copyFromAdr + ":" + toAdr);
	},
	
	logMove: function(fromAdr, toAdr)
	{
		this._changeLog[0].push("m:"+ fromAdr + ":" + toAdr);
	},

	logDropData: function(dropData)
	{
		this._changeLog[0].push(dropData);
	},

	clearLog: function()
	{
		this._changeLog = new Array();
		this._changeLog.push(new Array()); // contains the change log commands
		this._changeLog.push({}); // contains the props of newly added nodes.
	},

	getChangeLog: function()
	{
		return this._changeLog;
	},

	deepCloneJSON: function(obj)
	{
		var outpurArr = null;
		for (var i in obj)
		{
			outpurArr = outpurArr || new Array();
			outpurArr[i] = typeof (obj[i]) == 'object' ? this.deepCloneJSON(obj[i]) : obj[i];
		}
		return outpurArr;
	},
	
	addState: function(adr, newAdr, csm)
	{
		if($util.isNullOrUndefined(csm))
			return;
		
		for(var it in csm._items)
		{
			if (csm._items.hasOwnProperty(it))
			{
				if(it == adr)
				{
					this._csmItems[newAdr] = this.deepCloneJSON(csm._items[it]);
					this._changeLog[1][newAdr] = this.deepCloneJSON(this._csmItems[newAdr]);

					if(!$util.isNullOrUndefined(csm._transactionList) &&
					   !$util.isNullOrUndefined(csm._transactionList._items))
					{
						var item = csm._transactionList._items[it];
						if(!$util.isNullOrUndefined(item))
						{
							for(var j in item)
							{
								if(!$util.isNullOrUndefined(item[j]))
								{
									// L.T. 36519 30-AUG-2010. for var j in item, fetches j as string, it should be passed as int!
									// because the value needs to be properly deserialized and in the NavBot there are calcultaions based on type of props index.
									this._transactionList.add_transaction(newAdr, item[j][1], parseInt(j));
								}
							}
						}
					}
				}
			}
		}
	},

	remove: function(adr, keepChildren)
	{
		for(var it in this._items)
		{
			if (this._items.hasOwnProperty(it)) {
				if(keepChildren)
				{
					if(it == adr)
					{
						this._oldAddressList.push(it);
					}
				} else {
					if(it.indexOf(adr + ".") == 0 || it == adr)
					{
						// everyting that starts with adr is children of adr,
						// so its data should be removed from the state.
						this._oldAddressList.push(it);
					}
				}
			}
		}
	},

	end_update: function(commit)
	{
		if(commit)
		{
			var trItems = this._transactionList._items;

			for(var j in this._oldAddressList)
			{
				if(!$util.isNullOrUndefined(j))
				{
					// part 1 - delete from _items
					delete this._items[this._oldAddressList[j]];
					// part 2 - find the item and get the index in the orderedList so that we can delete it from orderedList
					var item = trItems[this._oldAddressList[j]];
					if(!$util.isNullOrUndefined(item))
					{
						for(var p in item)
						{
							if(!$util.isNullOrUndefined(item[p]))
							{
								var orderedIndex = item[p][0];
								delete this._transactionList._orderedList[orderedIndex];
							}
						}
					}
					// part 3 delte from _transactionList._items
					delete trItems[this._oldAddressList[j]];
				}
			}

			for(var newAdr in this._csmItems)
			{
				if(!$util.isNullOrUndefined(newAdr))
				{
					this._items[newAdr] = this._csmItems[newAdr];
				}
			}

			var myTrlItems = this._transactionListItems;
			for(var newAdr in myTrlItems)
			{
				if(!$util.isNullOrUndefined(newAdr))
				{
					trItems[newAdr] = myTrlItems[newAdr];
				}
			}
			
			var len = this._orderedIndexes.length;
			for(var i=0; i < len; i++)
			{
				var idx = this._orderedIndexes[i];
				this._transactionList._orderedList[idx] = this._orderedListItems[idx];
			}
		}

		this._csmItems = null;
		this._transactionListItems = null;
		this._orderedListItems = null;
		this._oldAddressList = null;
		this._orderedIndexes = null;
		this._updating = false;
	}
}
$IG.WebDataTreeCollectionClientStateManager.registerClass('Infragistics.Web.UI.WebDataTreeCollectionClientStateManager',$IG.CollectionClientStateManager);



$IG.DragDropSettings = function(moveCursor, copyCursor, noneCursor,
								dragMarkupCssClass, dropTargetCssClass, dropInsertLineCssClass,
								expandDelay, indicatorMoveImageUrl, indicatorCopyImageUrl, enableExpandOnDrop, dropIndicator)
{
	/// <summary>
	/// Initializes the DragDropSettings object.
	/// </summary>
	




	this._dragMarkupCssClass = dragMarkupCssClass;
	this._dropTargetCssClass = dropTargetCssClass;
	this._dropInsertLineCssClass = dropInsertLineCssClass;
	this._expandDelay = expandDelay;
	this._indicatorMoveImageUrl = indicatorMoveImageUrl;
	this._indicatorCopyImageUrl = indicatorCopyImageUrl;
	this._enableExpandOnDrop = enableExpandOnDrop;
	this._dropIndicator = dropIndicator;
	$IG.DragDropSettings.initializeBase(this);
}
$IG.DragDropSettings.prototype =
{
	
























	get_dragMarkupCssClass: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.dragMarkupCssClass">
		/// Get the user defined drag markup CSS class.
		/// If the user does not specify this CSS class a default class is provided.
		/// </summary>
		return this._dragMarkupCssClass;
	},
	
	get_dropTargetCssClass: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.dropTargetCssClass">
		/// Get the user defined drop target CSS class.
		/// If the user does not specify this CSS class a default class is provided.
		/// </summary>
		return this._dropTargetCssClass;
	},

	get_dropInsertLineCssClass: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.dropInsertLineCssClass">
		/// Get the user defined drop insert line CSS class.
		/// If the user does not specify this CSS class a default class is provided.
		/// </summary>
		return this._dropInsertLineCssClass;
	},
	
	get_expandDelay: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.expandDelay">
		/// Get the delay after which a node should expand when draggind over it.
		/// </summary>
		return this._expandDelay;
	},

	get_enableExpandOnDrop: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings._enableExpandOnDrop">
		/// Gets a boolean value that determines if the node that you dropped over will auto expand after the drop operation is completed.
		/// </summary>
		return this._enableExpandOnDrop;
	},

	get_indicatorMoveImageUrl: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.indicatorMoveImageUrl">
		/// Get image of indicator used while move.
		/// </summary>
		return this._indicatorMoveImageUrl;
	},

	get_indicatorCopyImageUrl: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.indicatorCopyImageUrl">
		/// Get image of indicator used while copy.
		/// </summary>
		return this._indicatorCopyImageUrl;
	},

	get_dropIndicator: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragDropSettings.dropIndicator">
		/// Get drop indicator.
		/// </summary>
		return this._dropIndicator;
	}
}
$IG.DragDropSettings.registerClass('Infragistics.Web.UI.DragDropSettings');

$IG.DropIndicator = function(visible, cssClass, insertBeforeFS, insertAfterFS, insertBetweenFS, moveToFS, copyToFS)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DropIndicator">
	/// Initializes the DropIndicator object.
	/// </summary>
	this._visible = visible;
	this._cssClass = cssClass;
	this._insertBeforeFS = insertBeforeFS;
	this._insertAfterFS = insertAfterFS;
	this._insertBetweenFS = insertBetweenFS;
	this._moveToFS = moveToFS;
	this._copyToFS = copyToFS;
	$IG.DropIndicator.initializeBase(this);
}
$IG.DropIndicator.prototype =
{
	get_visible: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.visible">
		/// Checks if drop indicator is visible.
		/// </summary>
		return this._visible;
	},

	get_cssClass: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.cssClass">
		/// Get the user defined drop indicator CSS class.
		/// If the user does not specify this CSS class a default class is provided.
		/// </summary>
		return this._cssClass;
	},

	get_insertBeforeFormatString: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertBeforeFormatString">
		/// Get format string used for insert before.
		/// </summary>
		return this._insertBeforeFS;
	},

	get_insertAfterFormatString: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertAfterFormatString">
		/// Get format string used for insert after.
		/// </summary>
		return this._insertAfterFS;
	},

	get_insertBetweenFormatString: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertBetweenFormatString">
		/// Get format string used for insert between.
		/// </summary>
		return this._insertBetweenFS;
	},

	get_moveToFormatString: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.moveToFormatString">
		/// Get format string used for move.
		/// </summary>
		return this._moveToFS;
	},

	get_copyToFormatString: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.copyToFormatString">
		/// Get format string used for copy.
		/// </summary>
		return this._copyToFS;
	},

	get_insertBeforeText: function(itemText)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertBeforeText">
		/// Get insert before text.
		/// </summary>
		if($util.isNullOrUndefined(itemText))
			return this._insertBeforeFS;
		return this._insertBeforeFS.replace("{0}", itemText);
	},

	get_insertAfterText: function(itemText)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertAfterText">
		/// Get insert after text.
		/// </summary>
		if($util.isNullOrUndefined(itemText))
			return this._insertAfterFS;
		return this._insertAfterFS.replace("{0}", itemText);
	},

	get_insertBetweenText: function(item0Text, item1Text)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.insertBetweenText">
		/// Get insert between text.
		/// </summary>
		if($util.isNullOrUndefined(item0Text) || $util.isNullOrUndefined(item1Text))
			return this._insertBetweenFS;
		var tmp = this._insertBetweenFS.replace("{0}", item0Text);
		return tmp.replace("{1}", item1Text);
	},

	get_moveToText: function(itemText)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.moveToText">
		/// Get move-to text.
		/// </summary>
		if($util.isNullOrUndefined(itemText))
			return this._moveToFS;
		return this._moveToFS.replace("{0}", itemText);
	},

	get_copyToText: function(itemText)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DropIndicator.copyToText">
		/// Get copy-to text.
		/// </summary>
		if($util.isNullOrUndefined(itemText))
			return this._copyToFS;
		return this._copyToFS.replace("{0}", itemText);
	}
}
$IG.DropIndicator.registerClass('Infragistics.Web.UI.DropIndicator');

$IG.DragData = function(sourceTreeId, nodes, ddm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DragData">
	/// Initializes the DragData object.
	/// </summary>
	this._sourceTreeId = sourceTreeId;
	this._nodes = nodes;
	this._ddm = ddm;
	this._dropInProgress = false;
	this._disposed = false;
	$IG.DragData.initializeBase(this);
}
$IG.DragData.prototype =
{
	get_sourceTreeId: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragData.sourceTreeId">
		/// Get the id of the source tree for this drag operation.
		/// </summary>
		/// <value type="String" />
		return this._sourceTreeId;
	},

	get_nodes: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragData.nodes">
		/// Get the nodes that are being dragged.
		/// </summary>
		/// <value type="Array" elementType="Infragistics.Web.UI.Node" />
		return this._nodes;
	},

	get_length: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.DragData.length">
		/// Get the number of dragged nodes.
		/// </summary>
		/// <value type="int" />
		return this._nodes.length;
	},
	
	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DragData.dispose">Disposes the object.</summary>
		this._sourceTreeId = null;
		this._nodes = null;
		this._ddm = null;
		this._dropInProgress = true;
		this._disposed = true;
	},
	
	isDisposed: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.DragData.isDisposed">Checks if drag data was disposed.</summary>
		/// <returns type="bool">True: disposed.</returns>
		return this._disposed;
	},

	_get_dragDropManager: function()
	{
		return this._ddm;
	},
	
	_set_dropInProgress: function(val)
	{
		this._dropInProgress = val;
	},
	
	_get_dropInProgress: function()
	{
		return this._dropInProgress;
	}
}
$IG.DragData.registerClass('Infragistics.Web.UI.DragData');

$IG.AddressGenerator = function(control)
{
	/// <summary locid="T:J#Infragistics.Web.UI.AddressGenerator">
	/// Initializes the AddressGenerator object.
	/// </summary>
	this._control = control;
	this.__counter = 0;
	this.__startAddressElement = null; 
	this.__currentElement = null; 
	this.__lastElement = null; 
	this.__operation = 0; 
	this.__isFirstNodeManipulation = false; 
	this.__currentUpdateLevelFromStart = 0; 
	this._csm = this._control._itemCollection._csm;
	$IG.AddressGenerator.initializeBase(this);
}
$IG.AddressGenerator.prototype =
{
	set_operation: function(op)
	{
		/// <summary locid="T:J#Infragistics.Web.UI.AddressGenerator.operation">
		/// Internal use only.
		/// </summary>
		this.__operation = op;
	},
	
	set_element: function(elem)
	{
		/// <summary locid="T:J#Infragistics.Web.UI.AddressGenerator.element">
		/// Internal use only.
		/// </summary>
		this.__element = elem;
	},
	
	set_node: function(node)
	{
		/// <summary locid="T:J#Infragistics.Web.UI.AddressGenerator.node">
		/// Internal use only.
		/// </summary>
		this.__node = node;
	},
	
	execute: function(fromAdr, toAdr)
	{
		/// <summary locid="T:J#Infragistics.Web.UI.AddressGenerator.execute">
		/// Internal use only.
		/// </summary>
		switch(this.__operation)
		{
			case 1:
			{
				this._add();
				break;
			}

			case 2:
			{
				if(this.__node) 
				{
					// L.T. 23/11/2010 58734 Fix key not found exception.
					this._csm.begin_update();
					this.__node._csm = this._csm.deepCloneJSON(this._csm);
					this._csm.remove(fromAdr, false);
					this._csm.end_update(true);
				}
				this._csm.logRemove(fromAdr);
				break;
			}

			case 3:
			{
				this._csm.logMove(fromAdr, toAdr);
				break;
			}

			case 4:
			{
				this._csm.logCopy(fromAdr, toAdr);
				this._add();
				break;
			}
		}

		// reset the stuff
		this.__node = null;
		this.__element = null;
	},

	
	_add: function()
	{
		var elem = this.__element;
		var node = this.__node;

		this._startOperation(elem);

		var curElem = this.__currentElement;
		var isDescendent = $adrutil.isDescendantOf(curElem, elem);

		while(curElem == elem || isDescendent)
		{
			curElem._object = null;

			var adr = this._dispatchAddress();

			if(this.__operation == 1)
				this._csm.logAdd(adr);

			if(curElem == elem)
			{
				this._csm.addState(node._get_address(), adr, node._csm);
			}
			else if(isDescendent)
			{
				this._csm.addState($adrutil.getAddressFromDomElement(curElem), adr, node._csm);
			}
			$adrutil.buildNodeLiId(curElem, adr);
			this._control._updateNodeCssClass(curElem, adr.indexOf(".") == -1);
			curElem = this._getNextElement();
			isDescendent = curElem ? $adrutil.isDescendantOf(curElem, elem) : false;
		}
		this._completeOperation();
	},

	_startOperation: function(elem)
	{
		if(this.__operation != 0)
		{
			$adrutil._skipAddressCheck = true; // performance optimization
			this._setStartAddressElement(elem);
			this.__lastElement = this.__startAddressElement;
			this.__currentElement = elem;
			this._csm.begin_update();
		}
	},

	_completeOperation: function()
	{
		if(this.__operation != 0)
		{
			this._csm.end_update(true); // this is part of the operation.
			// from here down, the operation is considered ended.
			$adrutil._skipAddressCheck = false;
			this.__startAddressElement = null;
			this.__currentElement = null;
			this.__lastElement = null;
			this.__isFirstNodeManipulation = false;
			this.__currentUpdateLevelFromStart = 0;
		}
	},
	
	_dispatchAddress: function()
	{
		var adr;
		var adrSuffix = this._getAdrSuffix();
		var currentElemLevel = this.__currentUpdateLevelFromStart +
							   $adrutil.getLevelByAdr($adrutil.getLocationFromDomElement(this.__startAddressElement));
		var lastAdr = $adrutil.getLocationFromDomElement(this.__lastElement);
		var lastLevel = $adrutil.getLevelByAdr(lastAdr);

		if(this.__isFirstNodeManipulation)
		{
			this.__isFirstNodeManipulation = false;
			return  "0" + adrSuffix;
		}
		else if(currentElemLevel > lastLevel)
		{
			// one level down
			adr = $adrutil.getOriginalAdr(lastAdr);
			return adr + ".0" + adrSuffix;
		}
		else if(currentElemLevel < lastLevel)
		{
			// level up
			adr = $adrutil.getOriginalAdr($adrutil.stripAddressSlot(lastAdr, (lastLevel - currentElemLevel))) + adrSuffix;
			return $adrutil.increaseAddressSlot(adr, $adrutil.getLevelByAdr(adr), 1);
		}
		else
		{
			// siblings
			adr = $adrutil.getOriginalAdr(lastAdr) + adrSuffix;
			return $adrutil.increaseAddressSlot(adr, $adrutil.getLevelByAdr(adr), 1);
		}
	},

	_getAdrSuffix: function()
	{
		var suffix = ",";
		switch(this.__operation)
		{
			case 1:
				suffix += "a" + this.__counter;
				break;
			case 2:
				suffix += "r" + this.__counter;
				break;
			case 3:
				suffix += "m" + this.__counter;
				break;
			case 4:
				suffix += "c" + this.__counter;
				break;
		}
		this.__counter++;
		return suffix;
	},

	_getNextElement: function(skipChildren, updateLastElem)
	{
		if($util.isNullOrUndefined(updateLastElem))
			updateLastElem = true;
		if(updateLastElem)
			this.__lastElement = this.__currentElement;
		if(!$adrutil.isLeafNode(this.__currentElement) && !skipChildren)
		{
			// get the first child of the UL
			var e = this._control._getNodeULTag(this.__currentElement);
			this.__currentElement = e ? $util.skipTextNodes(e.firstChild) : null;
			this.__currentUpdateLevelFromStart++;
		}
		else
		{
			this.__currentElement = $util.skipTextNodes(this.__currentElement.nextSibling);
			var parent = this.__lastElement.parentNode.parentNode; // must go from one LI, to parent LI
			while(parent && !this.__currentElement && parent.nodeName != "DIV")
			{
				this.__currentElement = $util.skipTextNodes(parent.nextSibling);
				this.__currentUpdateLevelFromStart--;
				parent = parent.parentNode.parentNode; // must go from one LI, to parent LI
			}
		}

		return this.__currentElement;
	},
	
	_setStartAddressElement: function(nodeElem)
	{
		this.__startAddressElement = $util.skipTextNodes(nodeElem.previousSibling, true);
		if(!this.__startAddressElement && nodeElem.parentNode.parentNode.nodeName == "LI")
		{
			this.__startAddressElement = nodeElem.parentNode.parentNode;
			this.__currentUpdateLevelFromStart++;
		}

		if($util.isNullOrUndefined(this.__startAddressElement) && nodeElem.parentNode.parentNode.nodeName == "DIV")
		{
			this.__startAddressElement = nodeElem;
			this.__isFirstNodeManipulation = true;
		}
	}
}
$IG.AddressGenerator.registerClass('Infragistics.Web.UI.AddressGenerator');

////////////////////////////////////////// DEFINE CUSTOM UIBehaviorsObject ///////////////////////////////////////////

$IG.DataTreeUIBehaviorsObject = function(control, collection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.DataTreeUIBehaviorsObject">Class which implements behavior of WebDataTree.</summary>
	/// <param name="control">Reference to tree.</param>
	/// <param name="collection">Reference to collection.</param>
	$IG.DataTreeUIBehaviorsObject.initializeBase(this, [control, collection]);
}
$IG.DataTreeUIBehaviorsObject.prototype =
{
	_createDragDropBehavior: function()
	{
		var enableDragDrop = this._control.get_enableDragDrop();
		var allowDrop = this._control.get_allowDrop();
		if((enableDragDrop || allowDrop) && $IG.DragDropBehavior)
		{
			this._ddb = new $IG.DragDropBehavior();
			this._ddb.set_dragDropMode(this._control.get_dragDropMode());
			this._ddb.set_dragMarkupOpacity(95);

			var events = this._ddb.get_events();

			if(enableDragDrop)
				this._ddb.addSourceObject(this._control);

			this._ddb.addTargetObject(this._control, true);

			// Set the minimum pixel area that the mouse should be moved in order to start a D&D operation.
			this._ddb.set_minimumStartDragShiftX(10);
			this._ddb.set_minimumStartDragShiftY(10);
			this._ddb.set_dragMarkupAlignedToMouse(true);

			var controlID = this._control._id;
			this._ddb.addDragChannels([controlID, "anyIGTree"]);
			this._ddb.addDropChannels(allowDrop ? [controlID, "anyIGTree"] : [controlID]);

			










			if(enableDragDrop)
			{
				// allow drag start to fire only if enable drag drop is true.
				events.addDragStartHandler(Function.createDelegate(this, this.dragStart));
			}

			// the rest of events can be fired if a tree is not enabled for drag, but just for dropping
			events.addDropHandler(Function.createDelegate(this, this.drop));
			events.addDragCancelHandler(Function.createDelegate(this, this.dragCancel));
			events.addDragMoveHandler(Function.createDelegate(this, this.dragMove));
			events.addDragEnterHandler(Function.createDelegate(this, this.dragEnter));
			events.addDragLeaveHandler(Function.createDelegate(this, this.dragLeave));
			events.addDragEndHandler(Function.createDelegate(this, this.dragEnd));

			this.setDragDropNotification(true);
		}
	}
}
$IG.DataTreeUIBehaviorsObject.registerClass('Infragistics.Web.UI.DataTreeUIBehaviorsObject', $IG.UIBehaviorsObject);

////////////////////////////////////////// END CUSTOM UIBehaviorsObject ///////////////////////////////////////////

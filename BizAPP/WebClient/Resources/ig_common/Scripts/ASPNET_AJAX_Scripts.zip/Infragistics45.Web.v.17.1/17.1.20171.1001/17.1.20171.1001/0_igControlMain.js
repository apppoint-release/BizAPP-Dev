/*
* 0_igControlMain.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");

var $IG = Infragistics.Web.UI;

if (typeof ig_controls != "object")
	var ig_controls = {};


$IG.ControlMainProps = new function()
{
	/// <summary>For internal use only.</summary>
	this.Flags = [0, 0];
	this.Count = 1;
};



$IG.ControlMain = function (elem)
{
	///<summary locid="T:J#Infragistics.Web.UI.ControlMain">
	/// The client side base class for all Infragistics.Web.UI.Controls.
	///</summary>
	$IG.ControlMain.initializeBase(this, [elem]);
	this._elements = {};
	this._callbackManager = new $IG.ControlCallbackManager(this);
	this._callbackManager.setResponseComplete(this.__responseCompleteInternal, this);
}
$IG.ControlMain.prototype =
{
	
	initialize: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.ControlMain.initialize">
		/// For Internal Use Only.
		/// Called from the control's constructor, it sets up all information needed by the control.
		///</summary>	    
		this._setupCollections();
		//var now1  = new Date();

		this.__walkThrough(this._element, true);

		this._setupMarkerElements();
		$IG.ControlMain.callBaseMethod(this, 'initialize');
		this.__attachEvents();
		this.__attachOtherEvents();
		this._uniqueID = this._get_clientOnlyValue("uid");
		ig_controls[this._id] = this;
		
		if (!$util._skip_pi)
		{
			$util.get_ajaxIndicator(this._get_clientOnlyValue('_pi'));
			var pi = this._get_clientOnlyValue('pi');
			if (pi && !this._pi)
				this._pi = new $IG.AjaxIndicator(pi);
		}
		var rm = null;
		try
		{
			rm = Sys.WebForms.PageRequestManager.getInstance();
		} catch (e) { }
		
		if (!rm && document.forms)
			this._fixSubmit(document.forms[0]);
		if (rm && !rm._ig_onsubmit)
		{
			rm._ig_onsubmit = rm._onsubmit;
			if (!rm._ig_onsubmit)
				rm._ig_onsubmit = 2;
			this._fixSubmit(rm._form);
			rm._onsubmit = function ()
			{
				var ig = window.ig_controls;
				if (ig) for (var id in ig) try
				{
					
					ig[id].__onIgSubmit(2);
				} catch (e) { }
				var rm = this;
				
				if (!rm._ig_onsubmit)
					rm = Sys.WebForms.PageRequestManager.getInstance();
				if (typeof rm._ig_onsubmit == 'function') try
				{
					if (rm._ig_onsubmit() === false)
						return false;
				} catch (ex) { }
				
				if (!rm._postBackSettings)
					rm._postBackSettings = {};
				return true;
			}
		}
	},
	
	_fixSubmit: function (form)
	{
		if (form && window.theForm)
			form = window.theForm;
		if (form && !form._ig_submit)
		{
			form._ig_submit = form.submit;
			form.submit = function ()
			{
				var ig = window.ig_controls;
				if (ig) for (var id in ig) try
				{
					
					ig[id].__onIgSubmit(3);
				} catch (e) { }
				
				try
				{
					if (this._ig_submit)
						this._ig_submit();
				} catch (e) { }
			}
		}
	},
	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.ControlMain.dispose">
		/// For Internal Use Only.
		/// Disposes of all objects that belong to the control.
		///</summary>
		if (this._objectsManager)
			this._objectsManager.dispose();
		if (this._collectionsManager)
			this._collectionsManager.dispose();
		if (this._callbackManager)
			this._callbackManager.dispose();
		if (this._itemCollection)
			this._itemCollection.dispose();
		if (this.get_element())
			$clearHandlers(this.get_element());
		this.__clearOtherEvents();
		if (this._pi)
			this._pi.dispose();
		if (this._flags)
			this._flags.dispose();
		delete this._pi;
		delete this._flags;
		delete this._dataStore;
		delete this._props;
		delete this._handlers;
		delete this._callbackManager;
		delete this._objectsManager;
		delete this._collectionsManager;
		delete this._itemCollection;

		for (var p in this._elements)
			delete this._elements[p];

		
		delete ig_controls[this._id];
		var elem = this._element;
		$IG.ControlMain.callBaseMethod(this, 'dispose');
		if (elem && typeof (elem.control) != "undefined") 
			elem.control = undefined; 
	},
	

	
	__attachEvents: function ()
	{
		this._addHandlers();
		var handlers = this._handlers;
		var i = handlers ? handlers.length : 0;
		if (i > 0)
		{
			var evnts = {};
			while (i-- > 0)
			{
				var evnt = handlers[i];
				evnts[evnt] = this._onEventHandler;
			}
			$addHandlers(this.get_element(), evnts, this);
		}
	},

	__clearOtherEvents: function ()
	{
		var handlers = this._otherHandlers;
		var i = handlers ? handlers.length : 0;
		while (i-- > 0)
		{
			for (var evnt in handlers[i])
			{
				var element = handlers[i][evnt];
				if (element._events && element._events[evnt] && element._events[evnt].length > 0)
				{
					try
					{
						$removeHandler(element, evnt, this.__otherHandlerDelegate);
					}
					catch (exc) { }
				}
			}
		}
		delete this._otherHandlers;
	},

	__attachOtherEvents: function ()
	{
		this._addOtherHandlers();
		
		this.__otherHandlerDelegate = Function.createDelegate(this, this._onOtherEventHandler);
		var handlers = this._otherHandlers;
		var i = handlers ? handlers.length : 0;
		while (i-- > 0)
			for (var evnt in handlers[i])
				$addHandler(handlers[i][evnt], evnt, this.__otherHandlerDelegate);
	},

	_handleEvent: function (elem, adrElement, adr, e)
	{
		var func = this["_on" + e.type.substring(0, 1).toUpperCase() + e.type.substring(1) + "Handler"];
		if (func)
			func.apply(this, [e.target, adr, e]);
	},

	__walkThrough: function (elem, topItem)
	{
	    if ($util._initAttr(elem)) {
	        
	        if (!topItem) {
	            return;
	        }
	    }
		var adr = elem.getAttribute("adr");
		var mkr = elem.getAttribute("mkr");
		var obj = elem.getAttribute("obj");

		if (adr)
			this._createItem(elem, adr);
		else if (obj)
			this._createObject(elem, obj);
		else if (mkr)
		{
			
			
			var mkrAr = mkr.split('.');
			for (var i = 0; i < mkrAr.length; i++)
			{
				mkr = mkrAr[i];
				
				if (typeof (this._elements[mkr]) != "undefined")
				{
					var mkrElem = this._elements[mkr];
					if (typeof (mkrElem.length) == "undefined")
						mkrElem = this._elements[mkr] = [this._elements[mkr]];
					mkrElem[mkrElem.length] = elem;

				}
				else
					this._elements[mkr] = elem;
			}
		}

		// AK - moved down here. The element itself should be counted, but its children should not.
		// donp - added this check to ensure that we don't walk down into other controls using adr tags (as in templates)
		// control must define this attribute on an element that is not meant to be walked.
		var ctl = elem.getAttribute("nw");
		if (ctl)
			return;

		var children = elem.childNodes;
		for (var i = 0; i < children.length; i++)
		{
			var element = children[i];
			if (element.getAttribute)
				this.__walkThrough(element, false);
		}
	},

	__getViewStateEnabled: function ()
	{
		var vse = this._get_clientOnlyValue("vse");
		if (vse == null)
			return true;
		else if (vse == 0)
			return false;
		else if (vse == 1)
			return true;
	},

	__getOptimizeClientState: function ()
	{
		var ocs = this._get_clientOnlyValue("ocs");
		if (ocs == null || ocs == 0)
			return false;
		else if (ocs == 1)
			return true;
	},

	

	
	_onEventHandler: function (e)
	{
		var obj = $util.resolveMarkedElement(e.target, true);

		if (obj != null)
		{
			


			if (obj[2] == this)
				this._handleEvent(e.target, obj[0], obj[1], e);
		}
	},


	
	__onIgSubmit: function (flag)
	{
		
		var oldF = this._ig_submit_flag;
		if (oldF && oldF != flag && (new Date()).getTime() < this._ig_submit_time + 4000)
			return;
		this._ig_submit_flag = flag;
		this._onIgSubmit();
	},

	_onIgSubmit: function ()
	{
		
		var oldT = this._ig_submit_time, newT = (new Date()).getTime();
		if (oldT && newT < oldT + 99)
			return;
		this._ig_submit_time = newT;
		this._onSubmitOtherHandler();
	},

	_onOtherEventHandler: function (e)
	{
		var type = e ? e.type : null;
		if (type == 'submit')
			
			this.__onIgSubmit(1);
		else if (type)
		{
			var func = this["_on" + type.substring(0, 1).toUpperCase() + type.substring(1) + "OtherHandler"];
			if (func)
				func.apply(this, [e.target, e])
		}
	},

	_get_CS: function () { return $get(this._id + '_clientState'); },

	_get_currentState: function ()
	{
		var vse = this.__getViewStateEnabled();
		var ocs = this.__getOptimizeClientState();
		var state = [[this._clientStateManager.get_serverProps(vse),
                      this._objectsManager.getServerObjects(vse),
                      (ocs ? null : this._collectionsManager.getServerCollection(vse))]];
		return state;
	},

	_onSubmitOtherHandler: function (e)
	{
		var clientState = this._get_CS();
		if (clientState)
		{
			var state = this._get_currentState();

			state[1] = [this._clientStateManager.get_transactionList(),
                        this._collectionsManager.get_allTransactionLists()];

			state[2] = this._saveAdditionalClientState();

			var val = Sys.Serialization.JavaScriptSerializer.serialize(state), bs = this.__backState;
			
			
			
			if (bs && bs.length > 2)
				val = bs + val;
			clientState.value = val;
		}
	},

	
	
	
	_setBackState: function (key, val)
	{
		var cs = this._ig_submit_time ? null : this._get_CS();
		if (!cs)
			return;
		key = key ? '' + key : '0';
		if (key.indexOf('|') >= 0)
			throw Error.invalidOperation('_setBackState: key cant have |');
		key = '|' + key + '|';
		val = '' + val;
		
		val = val.replace(/\|/g, '&tilda;').replace(/\"/g, '&qout;') + '|';
		var old = this._fixCS(cs);
		var i = old.indexOf(key), empty = old.length < 3;
		if (empty || i < 0)
		{
			
			
			this.__backState = cs.value = key + val + (empty ? '|' : old);
			return;
		}
		
		var str = old.substring(i += key.length);
		
		var end = str.indexOf('|');
		if (end < 0)
			return;
		
		this.__backState = cs.value = old.substring(0, i) + val + str.substring(end + 1);
	},
	
	
	
	_getBackState: function (key)
	{
		var i = -1, cs = this._get_CS();
		if (cs)
			cs = this._fixCS(cs);
		if (!cs || cs.indexOf('|') != 0)
			return null;
		key = key ? '' + key : '0';
		
		cs = cs.split('|');
		
		
		while ((i += 2) + 2 < cs.length)
			if (cs[i] == key)
			
				return cs[i + 1].replace(/&tilda;/g, '|').replace(/&qout;/g, '"');
		return null;
	},
	
	
	_fixCS: function (cs)
	{
		var val = cs ? cs.value : '';
		var len = val ? val.length : 0;
		if (this.__backState != null || len < 3)
			return val;
		
		if (val.indexOf('|') != 0)
			val = '';
		
		var end = val.indexOf('||');
		
		if (end > 0 && end + 2 < len)
			cs.value = val = val.substring(0, end + 2);
		return this.__backState = val;
	},

	_onBeforeunloadOtherHandler: function (e)
	{
	},

	

	
	_setupMarkerElements: function ()
	{

	},
	_addHandlers: function ()
	{
		
	},

	_addOtherHandlers: function ()
	{
		var form = window.theForm;
		if (!form)
		{
			form = document.forms.form1 || document.forms[0];
			if (!form)
				return;
		}
		this._registerOtherHandlers([{ "submit": form, "beforeunload": window}]);
	},

	_createItem: function (element, adr)
	{

	},

	_createObject: function (element, obj)
	{

	},

	__responseCompleteInternal: function (callbackObject, responseObject, browserResponseObject)
	{
		var cssClasses = responseObject.context.shift();
		if (cssClasses)
		{
			this.__appendStyles(cssClasses);
		}
		this._responseComplete(callbackObject, responseObject, browserResponseObject);
		this._posted = false;

	},
	__findIgStyleSheet: function ()
	{
		
		if (!document.styleSheets || !document.styleSheets.length)
			return null;
		
		for (var i = 0; i < document.styleSheets.length; i++)
		{
			var ss = document.styleSheets[i];
			if (ss.id == "igStyles" || (ss.ownerNode && ss.ownerNode.id == "igStyles"))
				return ss;
		}		

		return document.styleSheets[document.styleSheets.length - 1];
	},
	__appendStyles: function (cssClasses)
	{
		var igStyles = this.__findIgStyleSheet();
		
		if (!igStyles)
			return;
		



		this._removeExistingStyleRules(igStyles, cssClasses);
		if ($util.IsIE)
		{
			
			if (igStyles.addRule)
			{
				var rules = cssClasses.split("}");
				for (var i = 0; i < rules.length - 1; i++)
				{
					// A.Y. 4.2.2011 Bug 64859
					// Due to some unknown reason invalid cssClasses({width: ;}) are returned from the server and
					// some browsers throw an error when adding styles like those.
					var parts = rules[i].split('{');
					try
					{
						
						if (parts[1].length == 0)
							parts[1] = " ";
						igStyles.addRule(parts[0], parts[1]);
					}
					catch (err)
					{
					}
				}
			}
			else
				igStyles.cssText += cssClasses;
		}
		else
		{

			var rules = cssClasses.split("}");
			for (var i = 0; i < rules.length - 1; i++)
			{
				// A.Y. 4.2.2011 Bug 64859
				// Due to some unknown reason invalid cssClasses({width: ;}) are returned from the server and
				// some browsers throw an error when adding styles like those.
				try
				{
					igStyles.insertRule(rules[i] + "}", igStyles.cssRules.length);
				}
				catch (err)
				{
				}
			}
		}
		
		for (var igControlID in ig_controls)
		{
			var igControl = ig_controls[igControlID];
			if (igControl && igControl.__stylesHaveBeenAppended)
				igControl.__stylesHaveBeenAppended();
		}
	},

	_customResponse: function (response)
	{
		if (response)
			response = response.context;
		var item, i = response ? response.length : 0;
		while (i-- > 0)
		{
			item = response[i];
			if (item && item.indexOf && item.indexOf('{customResponse:') >= 0)
				return Sys.Serialization.JavaScriptSerializer.deserialize(item).customResponse;
		}
		return new $IG.CustomAJAXResponse();
	},

	_removeExistingStyleRules: function (igStyles, cssClasses)
	{
		var rules = cssClasses.split("}");
		for (var i = 0; i < rules.length - 1; i++)
		{
			var ruleAttributes = rules[i].split("{");
			var ruleName = ruleAttributes[0]; // this is not just the class name, it could have a selector so will have to strip out the selector
			var ruleNameSelectors = ruleName.split(">");
			for (var j = 0; j < ruleNameSelectors.length; j++)
				ruleNameSelectors[j] = ruleNameSelectors[j].replace(/^\s+|\s+$/g, ""); // trim the empty space
			ruleName = ruleNameSelectors.join(" > ");


			this._deleteCssRule(igStyles, ruleName);
		}
	},
	_deleteCssRule: function (styleSheet, ruleName)
	{
		ruleName = ruleName.toLowerCase();
		if ($util.IsIE)
		{
			
			if (styleSheet.removeRule && styleSheet.rules)
			{
				for (var i = 0; i < styleSheet.rules.length; i++)
				{
					if (styleSheet.rules[i].selectorText.toLowerCase() == ruleName)
					{
						//remove rule
						styleSheet.removeRule(i);
						return;
					}
				}

			}
			else
			{
				var cssText = styleSheet.cssText.toLowerCase();
				var indexOfName = cssText.indexOf(ruleName);
				
				if (indexOfName != -1)
				{
					var endOfRulePos = cssText.indexOf("}", indexOfName + 1) + 1;
					if (endOfRulePos < cssText.length)
						styleSheet.cssText = cssText.replace(cssText.substring(indexOfName, endOfRulePos), "");
				}
			}
		}
		else
		{
			

			var cssRule = false;
			var i = 0;
			
			try
			{
				cssRule = (styleSheet && styleSheet.cssRules ? styleSheet.cssRules[i] : false);
			}
			catch (ex)
			{ }
			while (cssRule)
			{
				if (cssRule && typeof cssRule.selectorText != "undefined" && cssRule.selectorText)
				{                               // If we found a rule...
					if (cssRule.selectorText.toLowerCase() == ruleName)
					{
						styleSheet.deleteRule(i);
						return;
					}
				}
				i++;
				cssRule = styleSheet.cssRules[i];
			}
		}
	},
	_responseComplete: function (callbackObject, response, browserResponseObj)
	{
		
		this._raiseClientEvent('AJAXResponse', 'AJAXResponse', null, 0, browserResponseObj, this._customResponse(response));
	},

	_responseCompleteError: function (callbackObj, responseObj, timedOut, message)
	{
		
		var args = this._raiseClientEvent('AJAXResponseError', 'AJAXResponseError', null, 0, responseObj, timedOut, message);
		if (!args || !args.get_cancel())
			alert(timedOut ? 'Server does not respond.' : (message ? message : callbackObj._parseErrorMessage(responseObj)));
	},

	_setupCollections: function ()
	{
		this._itemCollection = this._collectionsManager.register_collection(0, $IG.ObjectCollection);
	},

	_saveAdditionalClientState: function ()
	{
		return null;
	},

	


	

	_set_value: function (index, value)
	{
		this._clientStateManager.set_value(index, value);
	},

	_get_value: function (index, isBool)
	{
		return this._clientStateManager.get_value(index, isBool);
	},

	_get_clientOnlyValue: function (propName)
	{
		return this._clientStateManager.get_clientOnlyValue(propName);
	},

	_get_occasionalProperty: function (propName)
	{
		return this._clientStateManager.get_occasionalProperty(propName);
	},

	_set_occasionalProperty: function (propName, val)
	{
		this._clientStateManager.set_occasionalProperty(propName, val);
	},

	_cancelEvent: function (e)
	{
		e.stopPropagation();
		e.preventDefault();
	},

	_registerHandlers: function (handlers)
	{
		if (!this._handlers)
			this._handlers = [];

		this._handlers = this._handlers.concat(handlers);
	},

	_registerOtherHandlers: function (handlers)
	{
		if (!this._otherHandlers)
			this._otherHandlers = [];

		this._otherHandlers = this._otherHandlers.concat(handlers);
	},

	_add_item: function (adr, item)
	{
		this._items[adr] = item;
		this.__itemCount++;
	},

	_remove_item: function (adr)
	{
		if (adr in this._items)
		{
			delete this._items[adr];
			this.__itemCount--;
		}
	},

	_initClientEvents: function (vals)
	{
		this._initClientEventsForObject(this, vals);
	},
	_initClientEventsForObject: function (owner, vals)
	{
		owner._clientEvents = new Object();
		var i = vals ? vals.length : 0;
		while (i-- > 0)
		{
			var evt = vals[i].split(':');
			this.setClientEvent(owner, evt[0], evt[1], evt[2]);
		}
	},
	
	
	
	
	_postAction: function (args, evtName, noIndicator)
	{
		var act = args._props ? args._props[1] : args;
		if (act == 1)
		{
			var time = new Date().getTime();
			
			if (this._posted && this._posted + 300 > time)
				return;
			
			// ??
			
			
			if (this._causeValidation && typeof WebForm_DoPostBackWithOptions == 'function')
			{
				WebForm_DoPostBackWithOptions({ validation: true, validationGroup: this._validationGroup });
				if (typeof Page_IsValid == 'boolean' && !Page_IsValid)
					return;
			}
			
			this._posted = time;
			
			__doPostBack(this._id, evtName + (args._getPostArgs ? args._getPostArgs() : ''));
		}
		if (act == 2)
		{
			
			// ??
			var cb = this._callbackManager.createCallbackObject();
			
			
			cb.serverContext.eventName = evtName;
			
			var i = args._props ? args._props.length : 0;
			while (--i > 1)
				eval('cb.serverContext.props' + (i - 2) + '="' + args._props[i] + '"');
			if (args._context)
			{
				for (var contextProp in args._context)
					cb.serverContext[contextProp] = args._context[contextProp];
			}
			
			if (this._filterAsyncPostBack)
				this._filterAsyncPostBack(cb.serverContext, evtName, args);
			this._callbackManager.execute(cb, null, null, noIndicator);
		}
	},

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	_raiseClientEventStart: function (param)
	{
		var params = param; 
		if (params.substring)
			params = arguments;
		var post = this.getClientEventPostBack(params[0]);
		if (!post)
			post = params[3];
		return this._raiseCE_0(this, params[0], post, params[1], params);
	},
	_raiseClientEvent: function (param)
	{
		var args = this._raiseClientEventStart(param.substring ? arguments : param);
		return args ? this._raiseClientEventEnd(args, args._name) : null;
	},
	_raiseClientEventEnd: function (args)
	{
		///<summary>Triggers possible post back to end client event processing.</summary>
		///<param name="args">Event arguments.</param>
		///<returns>First parameter</returns>
		if (args && args._props && !(args.get_cancel && args.get_cancel()))
			this._postAction(args, args._name, args._noIndicator);
		return args;
	},
	_raiseSenderClientEvent: function (sender, clientEvent, eventArgs)
	{
		///<summary>Raises and triggers post back for a notify event.</summary>
		///<param name="sender">Object that raises the event and contains the clientEvents array.</param>
		///<param name="clientEvent">Client event object.</param>
		///<param name="eventArgs">Event arguments. Generally an object derived from Infragistics.Web.UI.CancelEventArgs.</param>
		///<returns>Event arguments object, the same object that is passed as the third parameter.</returns>
		eventArgs = this._raiseSenderClientEventStart(sender, clientEvent, eventArgs);
		return this._raiseClientEventEnd(eventArgs);
	},
	_raiseSenderClientEventStart: function (sender, clientEvent, eventArgs)
	{
		///<summary>Raises a cancelable before event but does not trigger post back.</summary>
		///<param name="sender">Object that raises the event and contains the clientEvents array.</param>
		///<param name="clientEvent">Client event object.</param>
		///<param name="eventArgs">Event arguments. Generally an object derived from Infragistics.Web.UI.CancelEventArgs.</param>
		///<returns>Event arguments object, the same object that is passed as the third parameter.</returns>
		return this._raiseCE_0(sender, clientEvent.name, clientEvent.postBack, eventArgs);
	},
	_raiseCE_0: function (me, evtName, post, args, params)
	{
		var fnc = me.get_events().getHandler(evtName);
		var str = args && args.substring;
		
		if (!fnc && post == null)
			return str ? null : args;
		if (str)
			eval('try{args = new Infragistics.Web.UI.' + args + 'EventArgs(evtName);}catch(ex){args = null;}');
		var i = 1, len = params ? params.length : 0;
		if (!args)
			args = (len < 3) ? new Sys.EventArgs() : new $IG.EventArgs();
		
		if (args._props)
			while (++i < len) if (params[i] != null)
				args._props[i - 2] = params[i];
		
		if (post)
		{
			if (!args._props)
				args._props = new Array();
			if (!args._props[1] || args._props[1] == 0)
				args._props[1] = post;
		}
		
		if (fnc)
			fnc(this, args);
		if (args._props)
			delete args._props[0];
		args._name = evtName;
		return args;
	},

	_getFlags: function ()
	{
		if (this._flags == null)
		{
			this.__flagHelper = new $IG.FlagsHelper();
			var key = [$IG.ObjectBaseProps.Count + 0, this.__getDefaultFlags()]
			this._flags = new $IG.FlagsObject(this._get_value(key), this);
		}
		return this._flags;
	},

	_updateFlags: function (flags)
	{
		var key = [$IG.ObjectBaseProps.Count + 0, this.__getDefaultFlags()]
		this._set_value(key, flags)
	},

	_ensureFlags: function ()
	{
		this._ensureFlag($IG.ClientUIFlags.Visible, $IG.DefaultableBoolean.True);
		this._ensureFlag($IG.ClientUIFlags.Enabled, $IG.DefaultableBoolean.True);
	},

	__getDefaultFlags: function ()
	{
		if (this.__defaultFlags == null)
		{
			this._ensureFlags();
			this.__defaultFlags = this.__flagHelper.calculateFlags();
		}
		return this.__defaultFlags;
	},

	_ensureFlag: function (flag, val)
	{
		this.__flagHelper.updateFlag(flag, val);
	},

	

	

	_get_clientStateManager: function () { return this._clientStateManager; },

	_get_item: function (adr)
	{
		return this._itemCollection._getObjectByAdr(adr);
	},

	// A.T. used for generating IDs on the client, in the same way they are generated on the server
	// this._id is the ID of the control itself, such as WebDataGrid1 
	_getHashCode: function ()
	{
		var attributeCounter = 10000;
		var hash = 0;
		for (var i = 0; i < this._id.length; i++)
		{
			hash = hash << 2;
			hash += this._id.charCodeAt(0);
		}

		return "x:" + hash + '.' + attributeCounter;
	},

	

	
	set_id: function (id)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.id">Sets id of control.</summary>
		///<param name="id" type="String">Id of control.</param>
		this._id = id;
	},
	get_name: function (name)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.name">
		/// Return's the name of the control. 
		///</summary>
		///<returns type="String" mayBeNull="false"> the name of the control </returns>
		return this.get_element().name;
	},
	set_name: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.name">Sets name of html element.</summary>
		///<param name="value" type="String">Name for element.</param>
		this.get_element().name = value;
	},
	get_uniqueID: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.uniqueID">
		/// Return's the Unique ID of the control. 
		///</summary>
		///<returns type="String" mayBeNull="false"> The unique ID of the control </returns>
		return this._uniqueID
	},

	
	
	addClientEventHandler: function (owner, evtName, fnc)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ControlMain.addClientEventHandler">
		/// Adds a function handler to process a ClientEvent.
		///</summary>
		$util.addClientEvent(owner, evtName, fnc);
	},
	removeClientEventHandler: function (owner, evtName, fnc)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ControlMain.removeClientEventHandler">
		/// Removes a function handler of a ClientEvent.
		///</summary>
		$util.removeClientEvent(owner, evtName, fnc);
	},

	getClientEventPostBack: function (name)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlMain.getClientEventPostBack">For internal use only.</summary>
		/// <param name="name" type="String" mayBeNull="false">Name of ClienEvent.</param>
		/// <returns type="Number">Postback action.</returns>
		return this.getClientEventPostBackForObject(this, name);
	},
	getClientEventPostBackForObject: function (owner, name)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlMain.getClientEventPostBackForObject">For internal use only.</summary>
		/// <param name="owner" type="Object">Reference to owner control.</param>
		/// <param name="name" type="String" mayBeNull="false">Name of ClienEvent.</param>
		/// <returns type="Number">Postback action.</returns>
		var ce = owner._clientEvents[name];
		return ce ? ce.postBack : null;
	},
	setClientEvent: function (owner, evtName, fnc, postBack)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ControlMain.setClientEvent">For internal use only.</summary>
		/// <param name="owner" type="Object">Reference to owner control.</param>
		/// <param name="evtName" type="String" mayBeNull="false">Name of ClientEvent.</param>
		/// <param name="fnc" type="Object">Function to call.</param>
		/// <param name="postBack" type="Number">Postback action.</param>
		
		if (postBack)
			postBack = parseInt(postBack, 10);
		else
			postBack = 0;
		owner._clientEvents[evtName] = { name: evtName, fnc: fnc, postBack: postBack };
		if (evtName && fnc)
			this.addClientEventHandler(owner, evtName, fnc);
	},
	get_ajaxIndicator: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.ajaxIndicator">
		/// Gets reference to instance of Infragistics.Web.UI.AjaxIndicator or null.
		///</summary>
		///<returns type="Infragistics.Web.UI.AjaxIndicator"> the ajax indicator instance </returns>
		return this._pi;
	},

	get_props: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ControlMain.props">
		/// For Internal Use Only.
		/// Contains ClientState information for the control.
		///</summary>
		return this._props;
	},

	set_props: function (value)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ControlMain.props">Internal use only.</summary>
		/// <param name="value">Properties for subobjects.</param>
		this._dataStore = value;
		this._props = value[0];
		this._clientStateManager = new $IG.ObjectClientStateManager(this._props);
		this._objectsManager = new $IG.ObjectsManager(this, value[1]);
		this._collectionsManager = new $IG.CollectionsManager(this, value[2]);
		this._initClientEvents(value[3]);
	},

	set_clientbindingprops: function (value)
	{
		if (this._usesCollectionsClientState && this._supportsClientRendering && this._thisType !== 'tree')
		{
			this._dataStore = value;
			this._props = value[0];
			this._clientStateManager = new $IG.ObjectClientStateManager(this._props);
			this._objectsManager = new $IG.ObjectsManager(this, value[1]);
			// instantiate the new $IG.MSAjaxCollectionManager
			this._collectionsManager = new $IG.MSAjaxCollectionsManager(this, value[4], this._bindings, this._parentBinding);
			this._initClientEvents(value[3]);

		} else
		{
			this.set_props(value);
		}
	},

	get_clientbindingprops: function ()
	{
		return this._props;
	}
	
}
$IG.ControlMain.registerClass('Infragistics.Web.UI.ControlMain', Sys.UI.Control);




$IG._from = function (obj)
{
	///<summary locid="T:J#Infragistics.Web.UI._from">Casts passed in object to the control type.</summary>
	///<param name="obj">Object to convert to the control type.</param>
	///<returns type="Infragistics.Web.UI.ControlMain">Reference to the same object that is passed in, only type converted to the control type.</returns>

	return obj;
};




$IG.NavControlProps = new function()
{
	this.Count = $IG.ControlMainProps.Count + 0;
};




$IG.NavControl = function(elem)
{
	/// <summary locid="T:J#Infragistics.Web.UI.NavControl">
	/// Represents a control class for hierarchical data controls. 
	/// </summary>
	$IG.NavControl.initializeBase(this, [elem]);
}

$IG.NavControl.prototype =
{
	initialize: function()
	{
		$IG.NavControl.callBaseMethod(this, 'initialize');
	},

	_setupCollections: function()
	{
		this._itemCollection = this._collectionsManager.register_collection(0, $IG.NavItemCollection);
		this._collectionsManager.registerUIBehaviors(this._itemCollection);
	},
	
	resolveItem: function(address)
	{
	/// <summary locid="M:J#Infragistics.Web.UI.NavControl.resolveItem">
	/// Translates an address string specifier into the resolved NavItem object that lives at the specified address.
	/// </summary>
	/// <param name="address">The full address specifier for an item.</param>
	/// <remarks>
	/// For Example: '0.3.2' specifies the item at index 2 whose parent is at index 3 of the collection
	/// who's parent is index 0 of the top-level collection.
	/// </remarks>
	/// <returns>The NavItem object that corresponds to the passed in address specifier.</returns>
	    return this._itemCollection._getObjectByAdr(address);
	}
	
}

$IG.NavControl.registerClass('Infragistics.Web.UI.NavControl', $IG.ControlMain);



/*
* igWebDataGridClipboard.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


$IG.Clipboard = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.Clipboard">
	/// Clipboard behavior object of the grid.
	/// </summary>
	$IG.Clipboard.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._hierarchical = hierarchical;
	this._rows = this._owner.get_rows();

	this._container = control._elements["container"];

	this._gridElement = this._grid._element;

	this._gridKeyDownHandler = Function.createDelegate(this, this._onKeyDown);
	this._grid._gridUtil._registerEventListener(this._grid, "KeyDown", this._gridKeyDownHandler);

	
	//this._gridKeyUpHandler = Function.createDelegate(this, this._onKeyUp);
	//this._grid._gridUtil._registerEventListener(this._grid, "KeyUp", this._gridKeyUpHandler);

	this._gridCopyHandler = Function.createDelegate(this, this._onCopy);
	$addHandler(document.body, "copy", this._gridCopyHandler);

	this._gridCutHandler = Function.createDelegate(this, this._onCut);
	$addHandler(document.body, "cut", this._gridCutHandler);

	this._gridPasteHandler = Function.createDelegate(this, this._onPaste);
	$addHandler(document.body, "paste", this._gridPasteHandler);
}

$IG.Clipboard.prototype =
{
	

	

	

    _copyText: null,
	_onKeyDown: function (evnt)
	{
		var ctrl = evnt.ctrlKey, key = evnt.keyCode;
		if (ctrl && (key == 67 || key == 45)) // Ctrl-C || Ctrl-Ins
			this._copyText = this.copy();
		else if (ctrl && key == 88) // Ctrl-X
			this._copyText = this.cut();
		
		else if (ctrl && key == 86 || evnt.shiftKey && key == 45) // Ctrl-V || Shift-Ins
		{
		    if (window.clipboardData)
		        this.paste();
		    else
		        this._pasteKeyDown = new Date().getTime();
        }
	},

	
	//_onKeyUp: function (evnt)
	//{
	//	if (evnt.ctrlKey && evnt.keyCode == 86 || evnt.shiftKey && evnt.keyCode == 45) // Ctrl-V || Shift-Ins
	//		this.paste();
	//},

	_onCopy: function (evnt)
	{
		if (this._copyText)
		{
			
			if (evnt.rawEvent.preventDefault)
				evnt.rawEvent.preventDefault();
			else if (evnt.preventDefault)
				evnt.preventDefault();
			this._setClipboardData(this._copyText, evnt.rawEvent.clipboardData);
			var args = this.__raiseClientEvent("Copied", $IG.ClipboardEventArgs, { "owner": this, "clipboardText": this._copyText });
			this._copyText = null;
		}
	},

	_onCut: function (evnt)
	{
	},

	_pasteText: null,
	_onPaste: function (evnt)
	{
	    var e = evnt.rawEvent;
		this._pasteText = e.clipboardData && e.clipboardData.getData ? e.clipboardData.getData('text/plain') : null;
		if (this._pasteKeyDown && new Date().getTime() - this._pasteKeyDown < 300)
		{
			delete this._pasteKeyDown;
			this.paste();
		}
	},

	

	

	_getClipboardData: function ()
	{
		if (this._pasteText) // Safari/Chrome logic
			return this._pasteText;

		if (window.clipboardData) // IE logic
			return window.clipboardData.getData("Text");

		if (typeof (netscape) != "undefined") // Firefox logic
		{
			try
			{
				netscape.security.PrivilegeManager.enablePrivilege('UniversalXPConnect');
				var clip = Components.classes["@mozilla.org/widget/clipboard;1"].createInstance(Components.interfaces.nsIClipboard);
				var trans = Components.classes["@mozilla.org/widget/transferable;1"].createInstance(Components.interfaces.nsITransferable);
				trans.addDataFlavor("text/unicode");
				clip.getData(trans, clip.kGlobalClipboard);
				var str = new Object();
				var len = new Object();
				trans.getTransferData("text/unicode", str, len);
				if (str)
					return str.value.QueryInterface(Components.interfaces.nsISupportsString).toString();
			}
			catch (exc)
			{
				throw this.__errorFirefox;
			}
		}		

		if ($util.IsOpera)
			throw this.__errorOpera;

		return null;
	},

	_setClipboardData: function (text, clipboardData)
	{
		var success = true;

		if (window.clipboardData) // for IE
		{
			window.clipboardData.setData("Text", text);
		}
		else if (typeof (netscape) != "undefined") // for Firefox
		{
			try
			{
				netscape.security.PrivilegeManager.enablePrivilege('UniversalXPConnect'); 
				var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard); 
				var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable); 
				trans.addDataFlavor('text/unicode'); 
				var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);
				str.data = text;
				trans.setTransferData("text/unicode", str, text.length * 2);
				var clipid = Components.interfaces.nsIClipboard;
				clip.setData(trans, null, clipid.kGlobalClipboard);
			}
			catch (exc)
			{
				throw this.__errorFirefox;
			}
		}
		else if (clipboardData)
		{
			clipboardData.setData("text/plain", text);
			if (clipboardData.getData("text/plain") != text)
				success = false;
		}
		else
			success = false;

		if (!success)
			throw this.__errorOpera;

		return true;
	},

	_generateSelArray: function ()
	{
		if (!this._selection)
			return null;
		var result = [];

		var rowsHash = {};
		var selRows = this._selection.get_selectedRowsResolved();
		for (var i = 0; i < selRows.length; i++)
		{
			var row = selRows[i];
			if (!row)
				continue;
			var rk = this._getGridRowKey(row);
			if (!rowsHash[rk])
				rowsHash[rk] = [];
			for (var j = 0; j < row.get_cellCount(); j++)
				rowsHash[rk][rowsHash[rk].length] = row.get_cell(j);
		}
		var selCols = this._selection.get_selectedColumnsResolved();
		for (var i = 0; i < selCols.length; i++)
		{
			var column = selCols[i];
			if (!column)
				continue;
			var grid = column._get_owner();
			for (var j = 0; j < grid.get_rows().get_length(); j++)
			{
				var row = grid.get_rows().get_row(j);
				var cell = row.get_cellByColumn(column);
				var rk = this._getGridRowKey(row);
				if (!rowsHash[rk])
					rowsHash[rk] = [];
				var exists = false;
				for (var ck in rowsHash[rk])
					if (rowsHash[rk][ck] == cell)
					{
						exists = true;
						break;
					}
				if (!exists)
					rowsHash[rk][rowsHash[rk].length] = cell;
			}
		}
		var selCells = this._selection.get_selectedCellsResolved();
		for (var i = 0; i < selCells.length; i++)
		{
			var cell = selCells[i];
			if (!cell)
				continue;
			var row = cell.get_row();
			var rk = this._getGridRowKey(row);
			if (!rowsHash[rk])
				rowsHash[rk] = [];
			var exists = false;
			for (var ck in rowsHash[rk])
				if (rowsHash[rk][ck] == cell)
				{
					exists = true;
					break;
				}
			if (!exists)
				rowsHash[rk][rowsHash[rk].length] = cell;
		}
		rowsHash = this._sortSelArray(rowsHash);
		
		//for (var r in rowsHash)
		for (var r = 0; r < rowsHash.length; r++)
		{			 
			var resCells = result[result.length] = [];
			var cells = rowsHash[r];
			for (var j = 0; j < cells.length; j++)
			{
				resCells[resCells.length] = cells[j];
			}
		}
		return result;
	},

	_getGridRowKey: function (row)
	{
		return this._getGridKey(row.get_grid()) + "|" + this._getRowKey(row);
	},

	_getRowKey: function (row)
	{
		var parentKey = "";
		if (typeof row.get_grid().get_parentRow != "undefined" && row.get_grid().get_parentRow())
		{
			parentKey = this._getRowKey(row.get_grid().get_parentRow());
			parentKey += "_";
		}
		return parentKey + row.get_index().toString();
	},

	_getGridKey: function (grid)
	{
		var parentKey = "";
		if (typeof grid.get_parentRow != "undefined" && grid.get_parentRow())
		{
			parentKey = this._getGridKey(grid.get_parentRow().get_grid());
			parentKey += "_";
		}
		if (typeof grid.get_rowIslandIndex != "undefined")
			return parentKey + grid.get_rowIslandIndex().toString();
		return "0";
	},

	_sortSelArray: function (sel)
	{
		var sorted = false;
		var resSel = [];
		while (!sorted)
		{
			sorted = true;
			var minRKey = null;
			for (var r in sel)
			{
				if (!minRKey)
					minRKey = r;
				else
				{
					if (this._compareRKeys(minRKey, r) < 0)
						minRKey = r;
				}
			}
			if (minRKey)
			{
				resSel[resSel.length] = sel[minRKey];
				delete sel[minRKey];
				sorted = false;
			}
		}
		return resSel;
	},

	_compareRKeys: function (a, b)
	{
		var a1 = a.split("|");
		a1[0] = a1[0].split("_");
		a1[1] = a1[1].split("_");
		var b1 = b.split("|");
		b1[0] = b1[0].split("_");
		b1[1] = b1[1].split("_");

		for (var i = 0; i < a1[0].length; i++)
		{
			if (typeof b1[0][i] == "undefined")
				return -1;
			if (a1[0][i] == b1[0][i] && parseInt(a1[1][i]) > parseInt(b1[1][i]))
				return -1;
			if (a1[0][i] == b1[0][i] && parseInt(a1[1][i]) < parseInt(b1[1][i]))
				return 1;
			if (a1[1][i] == b1[1][i] && parseInt(a1[0][i]) > parseInt(b1[0][i]))
				return -1;
			if (a1[1][i] == b1[1][i] && parseInt(a1[0][i]) < parseInt(b1[0][i]))
				return 1;
		}
		if (a1[0].length < b1[0].length)
			return 1;
		return 0;
	},

	

	

	copy: function (cut)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Clipboard.copy">
		/// Copies selected cells into clipboard.
		/// </summary>
		/// <returns type="String">
		/// Returns new clipboard content if the operation was successful. Null otherwise.
		/// </returns>

		if (!this._copyMode) //Disabled
			return;
		
		if (this.getEditingOn())
			return;
		if (this._updating && this._updating.get_cellInEditMode())
			return;

		var copyFormatted = this._copyFormatted;
		var ignoreHidden = this._ignoreHidden;

		var copyText = "";
		var headersText = [];
		var clipArray = this._generateSelArray();
		var rowGridHash = []; // for hgrid - history of the row indices as we get in depth
		var rowIndex = -1;
		var gridKey = "";
		var minCellIndex = 10000;
		for (var i = 0; clipArray && i < clipArray.length; i++)
		{
			var line = clipArray[i];
			var sorted = false;
			

			while (!sorted)
			{
				sorted = true;
				for (var j = 0; j < line.length - 1; j++)
				{
					if (line[j].get_column().get_visibleIndex() > line[j + 1].get_column().get_visibleIndex())
					{
						sorted = false;
						var tmp = line[j];
						line[j] = line[j + 1];
						line[j + 1] = tmp;
					}
				}
			}
			var firstCellIndex = clipArray[i][0].get_column().get_visibleIndex();
			if (firstCellIndex < minCellIndex)
				minCellIndex = firstCellIndex;
		}
		for (var i = 0; clipArray && i < clipArray.length; i++)
		{
			var cLine = clipArray[i];
			var cellIndex = minCellIndex;
			var ri = 0;
			for (var j = 0; j < cLine.length; j++)
			{
				var cell = cLine[j];
				var column = cell.get_column();
				var row = cell.get_row();
				var newRowIndex = row.get_index();
				var newGridKey = this._getGridKey(row.get_grid());
				rowIndex = (typeof rowGridHash[newGridKey] == "undefined" ? -1 : rowGridHash[newGridKey]);
				if (j == 0 && rowIndex != -1 && newGridKey == gridKey)
				{
					while (++rowIndex != newRowIndex)
						copyText += "\r\n";
				}
				rowGridHash[newGridKey] = newRowIndex;
				gridKey = newGridKey;
				

				var newCellIndex = cell.get_column().get_visibleIndex();
				while (cellIndex < newCellIndex)
				{
					var col = this._grid._gridUtil._getColumnFromVisibleIndex(cellIndex);
					
					
					if (!col.get_isTemplated() && (!ignoreHidden || (!col.get_hidden() && !col._get_hiddenByParent())))
					{
						copyText += '\t';
						ri++;
					}
					cellIndex++;
				}
				if (this._copyHeaders && !column.get_isTemplated() && cell != null && (typeof headersText[j] == "undefined" || headersText[j] === null))
					headersText[ri] = column.get_headerText();
				cellIndex++;
				
				if (!column.get_isTemplated() && (cell == null || !ignoreHidden || (!column.get_hidden() && !column._get_hiddenByParent())))
				{
					if (cell != null)
					{
						var v = this.__resolveCopyFormatted(cell, copyFormatted) ? cell.get_text() : cell.get_value();
						if (v !== null && v !== undefined)
							copyText += v.toString();
						if (cut)
							cell.set_value(null);
					}
					if (j < cLine.length - 1)
						copyText += '\t';
					ri++;
				}
			}
			copyText += "\r\n";
		}

		if (this._copyHeaders)
		{
			var header = "";
			var hasText = false;
			for (var i = 0; i < headersText.length; i++)
			{
				if (headersText[i])
				{
					hasText = true;
					header += headersText[i];
				}
				if (i < headersText.length - 1)
					header += "\t";
			}
			if (hasText)
				copyText = header + "\r\n" + copyText;
		}

		var ingEvent = cut ? "Cutting" : "Copying";
		var edEvent = cut ? "Cut" : "Copied";
		var args = this.__raiseClientEvent(ingEvent, $IG.ClipboardEventArgs, { "owner": this, "clipboardText": copyText, "copyFormatted": copyFormatted, "ignoreHiddenColumns": ignoreHidden });
		if (args != null && args.get_cancel())
			return;

		if (args)
			copyText = args.get_clipboardText();

		var excMessage = null;
		var copySuccess = false;
		try
		{
			copySuccess = this._setClipboardData(copyText);
		}
		catch (exc)
		{
			excMessage = exc;
			copySuccess = true;
		}

		if (copySuccess)
		{
			var args = this.__raiseClientEvent(edEvent, $IG.ClipboardEventArgs, { "owner": this, "clipboardText": copyText, "copyFormatted": copyFormatted, "ignoreHiddenColumns": ignoreHidden, "error": excMessage });
			if (excMessage && (args == null || !args.get_exceptionHandled()))
			{
				alert(excMessage);
				return null;
			}
		}

		return copyText;
	},

	cut: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Clipboard.cut">
		/// Places currently active or selected cells into clipboard and removes the cell values from the grid by assiggning null. 
		/// Numeric columns convert null into 0.
		/// </summary>
		/// <returns type="String">
		/// Returns new clipboard content if the operation was successful. Null otherwise.
		/// </returns>

		if (!this._cutMode) //Disabled
			return null;

		return this.copy(true);
	},

	paste: function (clipboardText)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Clipboard.paste">
		/// Pastes clipboard content into the grid starting from either active or passed in cell.
		/// The grid attempts to cast pasted values to each column's type;
		/// it is possible that strings will be converted to 0 and dates of unmatched format to null.
		/// If the clipboard contains more than one cell of data this cell is used as the left top cell of pasted data.
		/// Pasting a single cell value into several selected cells will replicate this value into each selected cell in the grid.
		/// If no actvive cell nor the parameter are defined, data is pasted from the first cell of the first row.
		/// </summary>

		if (!this._pasteMode) //Disabled
			return;
		
		if (this.getEditingOn())
			return;
		


		var fromCell = null

		

		if (this._selection && this._activation)
		{
			fromCell = this._activation.get_activeCell();
			if (fromCell)
			{
				var fromRow = fromCell.get_row();
				for (var i = 0; i < fromRow.get_cellCount(); i++)
				{
					var cell = fromRow.get_cell(this._grid._gridUtil._getColumnFromVisibleIndex(i).get_index());
					
					if (this._ignoreHidden && (cell.get_column().get_hidden() || cell.get_column()._get_hiddenByParent()))
						continue;
					var el = cell.get_element();
					if (el && el.className.indexOf(this._selection._selectedCellCss) >= 0)
					{
						fromCell = cell;
						break;
					}
				}
			}
		}
		else if (this._activation)
			fromCell = this._activation.get_activeCell();
		else if (this._grid.get_rows().get_length() > 0)
		{
			var firstCol = this._grid._gridUtil._findFirstVisibleColumn();
			if (column)
				fromCell = this._grid.get_rows().get_row(0).get_cell(firstCol.get_index());
		}

		if (this._updating && this._updating.get_cellInEditMode() || fromCell && this._grid._isAuxRow(fromCell.get_row()))
			return;

		var excMessage = null;
		if (typeof clipboardText == "undefined")
		{
			try
			{
				clipboardText = this._getClipboardData();
			}
			catch (exc)
			{
				excMessage = exc;
				clipboardText = null;
			}
		}

		var selectPasted = true;
		var ignoreHidden = this._ignoreHidden;
		var args = this.__raiseClientEvent("Pasting", $IG.ClipboardEventArgs, { "owner": this, "clipboardText": clipboardText, "targetCell": fromCell, "selectPastedCells": selectPasted, "ignoreHiddenColumns": ignoreHidden, "error": excMessage });
		if (args && args.get_cancel())
			return;

		if (args)
			clipboardText = args.get_clipboardText();

		if (clipboardText && (!excMessage || args && args.get_exceptionHandled()))
		{
			if (args != null)
			{
				fromCell = args.get_targetCell();
				selectPasted = args.get_selectPastedCells();
				ignoreHidden = args.get_ignoreHiddenColumns();
			}

			if (fromCell)
			{
				// Excel stores its data in text clipboard separated 
				// by \n between rows and by \t between cells
				var pasteData = clipboardText.split("\n");
				for (var i = 0; i < pasteData.length; i++)
					pasteData[i] = pasteData[i].split("\t");

				// Last row may be a dummy row
				if (pasteData[pasteData.length - 1].length == 1 && pasteData[pasteData.length - 1][0] == "")
					pasteData.pop();
				// Empty data pretty much
				if (pasteData.length == 1 && pasteData[0].length == 1 && (pasteData[0][0] == "" || pasteData[0][0] == "\r"))
					pasteData.pop();

				if (pasteData.length > 0 && pasteData[0].length > 0)
				{
					var rowDataIndex = 0;
					var rowIndex = fromCell.get_row().get_index();

					var pasteSelected = false;
					if (selectPasted && this._selection)
					{
						if (pasteData.length == 1 && pasteData[0].length == 1)
							pasteSelected = true;
						else
							this._selection.__clearAll();
					}

					if (pasteSelected)
					{
						// A single value is pasted into multiple selected cells
						var selCells = this._generateSelArray();
						var data = pasteData[0][0];
						if (data.endsWith("\n"))
							data = data.substr(0, data.length - 1);
						if (data.endsWith("\r"))
							data = data.substr(0, data.length - 1);
						if (data != "")
							for (var i = 0; selCells && i < selCells.length; i++)
							{
								var cLine = selCells[i];
								for (var j = 0; j < cLine.length; j++)
								{
									var cell = cLine[j];
									if (cell != null)
									{
										
										if (!cell.get_column().get_isTemplated() && (!ignoreHidden || (!cell.get_column().get_hidden() && !cell.get_column()._get_hiddenByParent())))
											
											cell.set_value(data, undefined, true);
									}
								}
							}
					}
					else
					{
						// Let's paste until the end of our clipboard data or until the end of the grid rows
						while (rowDataIndex < pasteData.length && rowIndex < this._grid.get_rows().get_length())
						{
							var row = this._grid.get_rows().get_row(rowIndex++);

							var cellDataIndex = 0;
							var cellData = pasteData[rowDataIndex++];
							

							var cellIndex = fromCell.get_column().get_visibleIndex();

							//Let's paste until the end of the clipboard data or until the end of the cells
							while (cellData && cellDataIndex < cellData.length && cellIndex < row.get_cellCount())
							{
								var cell = row.get_cell(this._grid._gridUtil._getColumnFromVisibleIndex(cellIndex++).get_index());
								
								if (cell.get_column().get_isTemplated() || ignoreHidden && (cell.get_column().get_hidden() || cell.get_column()._get_hiddenByParent()))
									continue;

								var text = cellData[cellDataIndex++];
								if (text.endsWith("\n"))
									text = text.substr(0, text.length - 1);
								if (text.endsWith("\r"))
									text = text.substr(0, text.length - 1);
								if (text == "")
								    continue;

							    
							    //Match m/d/yy and mm/dd/yyyy, allowing any combination of one or two digits for the day and month, and two or four digits for the year
								var dtRegex = new RegExp("^(1[0-2]|0?[1-9])/(3[01]|[12][0-9]|0?[1-9])/(?:[0-9]{2})?[0-9]{2}$");

								if (dtRegex.test(text) == true) {
								    var evalDate = text.split(/-|\//);
								    if (evalDate[2].length == 2) {
								        var date = new Date(text);
								        var fullYear = date.getFullYear();
								        if (fullYear < 2000)
								            date.setFullYear(fullYear + 100);
								    }
								    text = evalDate[0] + '/' + evalDate[1] + '/' + date.getFullYear();
								}

							    
								cell.set_value(text, undefined, true);

								if (selectPasted && this._selection)
								    this._selection.get_selectedCells().add(cell);
                            }
						}
					}
					this.__raiseClientEvent("Pasted", $IG.ClipboardEventArgs, { "owner": this, "clipboardText": clipboardText, "targetCell": fromCell, "selectPastedCells": selectPasted, "ignoreHiddenColumns": ignoreHidden });
				}
			}
		}
		else if (excMessage && (args == null || !args.get_exceptionHandled()))
			alert(excMessage);
	},

	

	

	__resolveCopyFormatted: function (cell, copyFormatted)
	{
		if (cell.get_column().get_isCheckbox())
			return false;
		return copyFormatted;
	},

	





	

	

	_initializeComplete: function ()
	{
		this._selection = this._parentCollection.getBehaviorFromInterface($IG.ISelectionBehavior);
		this._activation = this._parentCollection.getBehaviorFromInterface($IG.IActivationBehavior);
		this._updating = this._parentCollection.getBehaviorFromInterface($IG.IUpdatingBehavior);

		this._copyMode = this._get_clientOnlyValue("cm");
		this._cutMode = this._get_clientOnlyValue("ctm");
		this._pasteMode = this._get_clientOnlyValue("pm");
		this._copyFormatted = this._get_clientOnlyValue("cf");
		this._ignoreHidden = this._get_clientOnlyValue("ih");
		
		this._copyHeaders = this._get_clientOnlyValue("csh");
		this.__errorFirefox = this._get_clientOnlyValue("err1");
		this.__errorOpera = this._get_clientOnlyValue("err2");
	},

	dispose: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.Clipboard.dispose">Called by the framework whe the object is being disposed of.</summary>

		if (!this._grid)
			return;

		this._grid._gridUtil._unregisterEventListener(this._grid, "KeyDown", this._gridKeyDownHandler);
		delete this._gridKeyDownHandler;

		
		//this._grid._gridUtil._unregisterEventListener(this._grid, "KeyUp", this._gridKeyUpHandler);
		//delete this._gridKeyUpHandler;

		$removeHandler(document.body, "copy", this._gridCopyHandler);
		delete this._gridCopyHandler;

		$removeHandler(document.body, "cut", this._gridCutHandler);
		delete this._gridCutHandler;

		$removeHandler(document.body, "paste", this._gridPasteHandler);
		delete this._gridPasteHandler;

		$IG.Clipboard.callBaseMethod(this, "dispose");
	}
	

}
$IG.Clipboard.registerClass('Infragistics.Web.UI.Clipboard', $IG.GridBehavior);



$IG.GridClipboardProps = new function () {
	


};





$IG.ClipboardEventArgs = function (params)
{
	///<summary locid="T:J#Infragistics.Web.UI.ClipboardEventArgs">
	///Event arguments object passed into a clipboard related event handler.
	///</summary>
	$IG.ClipboardEventArgs.initializeBase(this);

	this._props = params;
	this._props.exceptionHandled = false;
}
$IG.ClipboardEventArgs.prototype =
{
	get_clipboardText: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_clipboardText">
		/// Text that is being copied from ot pasted into the grid.
		/// </summary>
		/// <returns type="String" />

		return this._props.clipboardText;
	},
	set_clipboardText: function (value)
	{
		this._props.clipboardText = value;
	},

	get_targetCell: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_targetCell">
		/// Contains reference to the top left cell during paste operation. Data from the clipboard
		/// is pasted to the right and to the bottom off of this cell.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell" />

		return this._props.targetCell;
	},
	set_targetCell: function (value)
	{
		this._props.targetCell = value;
	},

	get_selectPastedCells: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_selectPastedCells">
		/// Indicates whether pasted cells must be selected.
		/// </summary>
		/// <returns type="Boolean" />
		return this._props.selectPastedCells;
	},
	set_selectPastedCells: function (value)
	{
		this._props.selectPastedCells = value;
	},

	get_ignoreHiddenColumns: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_ignoreHiddenColumns">
		/// Indicates whether hidden columns must be ignored during copying or pasting.
		/// </summary>
		/// <returns type="Boolean" />
		return this._props.ignoreHiddenColumns;
	},
	set_ignoreHiddenColumns: function (value)
	{
		this._props.ignoreHiddenColumns = value;
	},

	get_error: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_exceptionHandled">
		/// Error message that occured during a clipboard operation.
		/// </summary>
		/// <returns type="String" />
		return this._props.error;
	},

	get_exceptionHandled: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ClipboardArgs.get_exceptionHandled">
		/// Indicates whether an exception was handled by the application. Setting to true
		/// inside of an event handler prevents default error message popup.
		/// </summary>
		/// <returns type="Boolean" />
		return this._props.exceptionHandled;
	},
	set_exceptionHandled: function (value)
	{
		this._props.exceptionHandled = value;
	}
}

$IG.ClipboardEventArgs.registerClass('Infragistics.Web.UI.ClipboardEventArgs', $IG.CancelEventArgs);


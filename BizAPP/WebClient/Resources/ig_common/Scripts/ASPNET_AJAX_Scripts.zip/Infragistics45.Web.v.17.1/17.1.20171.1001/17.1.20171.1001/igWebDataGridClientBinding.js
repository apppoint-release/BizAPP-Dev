/*
* igWebDataGridClientBinding.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


$IG.WebDataGrid.prototype.__loadClientBindingObjects = function ()
{
	var clientBindingsCount = this._get_clientOnlyValue("cbc");
	var clientBindingDataContextIndex = this._get_clientOnlyValue("cbdci");

	this._clientBindingDataContext = new $IG.ClientBindingDataContext("clientBindingDataContext", null, this._objectsManager.get_objectProps(clientBindingDataContextIndex), this, "clientBindingDataContext");
	this._objectsManager.register_object(clientBindingDataContextIndex, this._clientBindingDataContext);
	this._clientBindings = [];

	var count = 0;
	for (i = clientBindingDataContextIndex + 1; i < clientBindingDataContextIndex + 1 + clientBindingsCount; i++)
	{
		this._clientBindings[count] = new $IG.ClientDataBinding("clientBinding", null, this._objectsManager.get_objectProps(i), this, "clientBinding");
		this._objectsManager.register_object(i, this._clientBindings[count]);
		count++;
	}
	var ds = this._dataStore[this._dataStore.length - 1];
	for (var r = 0; r < ds.length; ++r)
	{
		for (var c = 0; c < this.get_columns().get_length(); ++c)
		{
			var col = this.get_columns().get_column(c);
			if (col.get_type() == "date" && typeof ds[r][col._dataFieldName] == "string")
				ds[r][col._dataFieldName] = this._gridUtil._convertServerDateStringToClientObject(ds[r][col._dataFieldName]);
		}
	}
	
	this._onHideColumnCssCreatedClientRenderingHandler = Function.createDelegate(this, this._onHideColumnCssCreatedClientRendering);
	this._gridUtil._registerEventListener(this, "HideColumnCssCreated", this._onHideColumnCssCreatedClientRenderingHandler);
}
$IG.WebDataGrid.prototype._renderFormatedValue = function (item, text, htmlEncode, multiLine)
{
	if ($util.IsIE && text == "")			
		return "<!---->";	
    
    if (htmlEncode)
        text = $util.htmlEscapeCharacters(text);
    if (multiLine)
        text = text.split("\n").join("<BR>");
	return text;

}
$IG.WebDataGrid.prototype.applyClientBinding = function ()
{
	/// <summary locid="P:J#Infragistics.Web.UI.WebDataGrid.applyClientBinding">
	/// Used the render the HTML rows of WebDataGrid on the client.
	/// </summary>
	this._applyClientBinding(false);
}
$IG.WebDataGrid.prototype._applyClientBinding = function (init)
{
	var firstTime = false;
	if (!this._tableTemplate)
	{
		this._emptyRowTemplate = this._get_clientOnlyValue("ertmpl");
		this._tableTemplate = this._get_clientOnlyValue("tmpl");

	    // H.A. fix bug #234525 - [WebDataGrid] Selection does not works with client side rendering
		this.__dataKeyFieldsSet = (this._tableTemplate.startsWith("<tr data-rowkey") ? true : false);
		firstTime = true;
	}
	var args = this._raiseClientEvent('DataBinding', 'Cancel', null);
	var cancel = args ? args.get_cancel() : false;
	if (cancel)
		return;

	this._gridUtil._fireEvent(this, "DataBinding");

	var dataSource = this.get_dataSource();

	
	if (!firstTime && this._rows)
	{
		this._rows._disposeEachRow();
		this._rows._disposeOfKeyIndexTree();
	}
	$(this._elements.dataTbl.lastChild).attr('mkr', 'rows');
	$(this._elements.dataTbl.lastChild).empty();


	// A.T. 30 August 2010 - adding support for alt classes and more flexible row-by-row rendering
	var dataSourceObject = eval(dataSource);

	var hash = this._getHashCode();
	var rowsElement = this._elements["rows"];

	if (dataSourceObject.length > 0 || !this._emptyRowTemplate)
	{
		

		if (rowsElement && this._rowsClass && rowsElement.className != this._rowsClass)
		{			
			rowsElement.className = this._rowsClass;
			this._rowsClass = null;
		}

		var grid = this;
        var count = 0;
		$.each(dataSourceObject, function (index, val)
		{
			var dataTable = grid._elements.dataTbl;
            if (grid._clientEvents["RowRendering"])
            {
                var args = grid._raiseClientEvent("RowRendering", "RowRendering", null, val);
                if (args && args.get_cancel())
                    return;
            }
			$.tmpl(grid._tableTemplate, val, { grid: grid, rowIndex: index }).appendTo(dataTable);

		    // H.A. fix bug #234525 - [WebDataGrid] Selection does not works with client side rendering
			// var row = grid.__dataKeyFieldsSet ? $(dataTable.lastChild.lastChild) : dataTable.lastChild.childNodes[dataTable.lastChild.childNodes.length - 2];
			var row = $(dataTable.lastChild.lastChild);
			$(row).attr($util._xAttr, hash + ":adr:" + count);
			if (index % 2 != 0)
				$(row).addClass(grid._get_clientOnlyValue("rac"));
			if (!grid.__dataKeyFieldsSet)
			{
			    // H.A. fix bug #234525 - [WebDataGrid] Selection does not works with client side rendering
			    dataTable.lastChild.lastChild.setAttribute('data-rowkey', "[" + count + "]");
			}
            if (grid._clientEvents["RowRendered"])
            {
                // H.A. fix bug #234525 - [WebDataGrid] Selection does not works with client side rendering
                var keyNode = dataTable.lastChild.lastChild.getAttributeNode("data-rowkey");
                grid._raiseClientEvent("RowRendered", "RowRendered", Sys.Serialization.JavaScriptSerializer.deserialize($util.replace(keyNode.nodeValue, "~$~", ":")), dataTable.lastChild.lastChild, val, count);
            }
            count++;
		});
	}
	if (this._emptyRowTemplate && (count == 0 || dataSourceObject.length == 0))
	{
		

		if (rowsElement && (!this._rowsClass))
		{			
			this._rowsClass = rowsElement.className;
			rowsElement.className = "";
		}
		$(this._elements.dataTbl.lastChild).html(this._emptyRowTemplate);
	}
    
	if (!firstTime && this._rows)
	{
		this._rows._set_length(count);
		if (this._rows.get_length() > 0)
			this._adjustFirstRowHTML(this._rows.get_row(0));

		this._onDataTblResize({ "clientHeight": this._elements.dataTbl.clientHeight }, null);
		this._onResize({ "clientHeight": this._element.clientHeight }, false);
	}
    else
        this._set_value($IG.WebDataGridProps.RowCount, count);

	this._gridUtil._fireEvent(this, "DataBound", { init: init });
	this._raiseClientEvent('DataBound', null, null);
}

$IG.WebDataGrid.prototype._adjustFirstRowHTML = function (row)
{
		
	if (row)
	{
		for (var i = 0; i < row.get_cellCount(); i++)
		{
			var cell = row.get_cell(i);
			if (cell && cell.get_element())
			{
				var width = cell.get_column().get_width();
				width = (width == "" ? this.get_defaultColumnWidth() : width );
				if (width != "")
					cell.get_element().style.width = width;
			}
		}
	}
}

$IG.WebDataGrid.prototype._get_dataKeyFieldsSet = function ()
{
	return this.__dataKeyFieldsSet;
}

$IG.WebDataGrid.prototype._getHashCode = function ()
{
	var attributeCounter = 10000;
	var hash = 0;
	for (var i = 0; i < this._id.length; i++)
	{
		hash = hash << 2;
		hash += this._id.charCodeAt(0);
	}

	return "x:" + hash + '.' + attributeCounter;
}


$IG.WebDataGrid.prototype._onHideColumnCssCreatedClientRendering = function (args)
{
	var column = args.column;
	var css = args.css;
	var tableTemplate = $("<div></div>").html(this._tableTemplate);
	var rowTemplate = tableTemplate[0].firstChild;
	var offset = this._cell_index_offset + column.get_visibleIndex();
	var cellElem = rowTemplate.childNodes[offset];
	if (cellElem)
		$util.addCompoundClass(cellElem, css);
	this._tableTemplate = tableTemplate.html();
}


$IG.RowRenderingEventArgs = function ()
{
    /// <summary locid="T:J#Infragistics.Web.UI.RowRenderingEventArgs">
    /// The event args passed to the WebDataGrid RowRendering event
    /// </summary>
    $IG.RowRenderingEventArgs.initializeBase(this);
}
$IG.RowRenderingEventArgs.prototype =
{
    get_dataItem: function ()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.RowRenderingEventArgs.getDataItem">
        /// Returns the data object in the source the row is going to be bound to
        /// </summary>
        return this._props[1];
    }

}
$IG.RowRenderingEventArgs.registerClass('Infragistics.Web.UI.RowRenderingEventArgs', $IG.CancelEventArgs);



$IG.RowRenderedEventArgs = function ()
{
    /// <summary locid="T:J#Infragistics.Web.UI.RowRenderedEventArgs">
    /// The event args passed to the WebDataGrid RowRendered event
    /// </summary>
    $IG.RowRenderedEventArgs.initializeBase(this);
}
$IG.RowRenderedEventArgs.prototype =
{
	get_browserEvent: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowRenderedEventArgs.browserEvent">Gets reference to browser event.</summary>
		/// <value type="Sys.UI.DomEvent" mayBeNull="true">Reference to browser event.</value>
		return null;
	},
	
	get_dataKey: function ()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.RowRenderedEventArgs.DataKey">
        /// Returns the data key of the row
        /// </summary>
        /// <value type="Array"></value>
        return this._props[0];
    },

    get_rowElement: function ()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.RowRenderedEventArgs.RowElement">
        /// Returns the html TR for the row.  The rows collection is not set up yet, so a temporary
        /// grid object can be created as follows: new $IG.GridRow(eventArgs.get_index(), eventArgs.get_rowElement(), [], sender, null);
        /// </summary>
        /// <value domElement="true"></value>
        return this._props[1];
    },
    
    get_dataItem: function ()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.RowRenderedEventArgs.getDataItem">
        /// Returns the data object in the source the row was bound to
        /// </summary>
        return this._props[2];
    },
    
    get_index: function ()
    {
        /// <summary locid="M:J#Infragistics.Web.UI.RowRenderedEventArgs.Index">
        /// Returns the index of the row in the rows collection
        /// </summary>
        /// <value type="Number"></value>
        return this._props[3];
    }

}
$IG.RowRenderedEventArgs.registerClass('Infragistics.Web.UI.RowRenderedEventArgs', $IG.EventArgs);


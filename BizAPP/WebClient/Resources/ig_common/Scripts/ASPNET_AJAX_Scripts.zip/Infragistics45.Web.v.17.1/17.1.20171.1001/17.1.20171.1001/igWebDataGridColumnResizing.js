/*
* igWebDataGridColumnResizing.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/



$IG.ColumnResizing = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnResizing">
	/// ColumnResizing behavior object of the grid.
	/// </summary>
	
	$IG.ColumnResizing.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._container = control._elements["container"]; 
	this._header = control._elements["header"]; 
	this._dataTbl = control._elements["dataTbl"];
	this._resizingIndicatorCssClass = this._get_clientOnlyValue("ric"); 
	this._autoPostBackColumnResized = this._get_clientOnlyValue("apcr");
	this._dragDropBehavior = new $IG.DragDropBehavior(); 
	
	this._dragDropBehavior._autoStartLastThEdge = true;
	this._autoGenCols = this._get_clientOnlyValue("agc");

	




	this._currentDraggingAction = new Object();
	
	this._currentDraggingAction.elementDragged = null;
	
	this._currentDraggingAction.startingWidth = 0;
	
	this._currentDraggingAction.isDragEligible = false;
	

	this._hierarchical = hierarchical;
	
	this._gridHasHeaderLayout = control._get_clientOnlyValue("hdlay");
	this._gridManualLoadDemand = this._get_clientOnlyValue("imld");

	if (this._columnFixing && this._gridHasHeaderLayout)
		this._currentDraggingAction.startingFixedCapsWidth = 0;
	this._onAlignStatCaptionHandler = Function.createDelegate(this, this._onAlignStatCaption);
	this._grid._gridUtil._registerEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);
}
$IG.ColumnResizing.prototype =
{
	
	get_columnResizeSettings: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizing.columnResizeSettings">
		///Returns an array of the ColumnResizeSettings available.
		///</summary>
		///<value type="Infragistics.Web.UI.ColumnResizeSettings" />
		return this._columnResizeSettings;
	},
	
	
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnResizing.dispose">
		/// Called whenever the object is being disposed of.
		/// </summary>
		delete this._columnMoving;
		delete this._columnFixing;
		if (!this._grid)
			return;
		if (this._columnResizeSettingSingleton)
		{
			this._columnResizeSettingSingleton.onPropertyChanging = null;
			this._columnResizeSettingSingleton.dispose();
			this._columnResizeSettingSingleton = null;
		}
		if (this._header)
			this._grid._removeElementEventHandler(this._header, "mousemove", this.__headerMouseMoveEventHandler);
		if (this._dragDropBehavior)
		{
			this._dragDropBehavior.dispose();
		}
		this._internalColumnSelectionChangingHandler = null;
		this._currentDraggingAction = null;
		this._container = null;
		this._header = null;
		this._dataTbl = null;
		
		if (this._hierarchical)
		{
			if (this._band && this._band._grids)
				delete this._band._grids[this._grid._id];
			delete this._band;
			if (this._ancestorGridElements)
			{
				for (var x = 0; x < this._ancestorGridElements.length; ++x)
					this._ancestorGridElements[x] = null;
				delete this._ancestorGridElements;
			}
		}
		delete this._hierarchical;

		this._grid._gridUtil._unregisterEventListener(this._grid, "AlignStatCaption", this._onAlignStatCaptionHandler);
		delete this._onAlignStatCaptionHandler;

		$IG.ColumnResizing.callBaseMethod(this, "dispose");
	},
	_createCollections: function (collectionsManager)
	{
		this._columnResizeSettings = collectionsManager.register_collection(0, $IG.ColumnResizeSettings);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnResizeSettings._addObject($IG.ColumnResizeSetting, null, columnKey);
		this._columnResizeSettingSingleton = this.__createResizeSettingSingleton();
	},
	_initializeComplete: function ()
	{
		this._columnMoving = this._grid.get_behaviors().get_columnMoving();
		this._columnFixing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IColumnFixingBehavior);
		this._selection = this._grid.get_behaviors().getBehaviorFromInterface($IG.ISelectionBehavior);
		if (this._selection)
		{
			this._internalColumnSelectionChangingHandler = Function.createDelegate(this, this.__columnSelectionChanging);
			this._selection.addInternalColumnSelectionChangingHandler(this._internalColumnSelectionChangingHandler);
		}
		this.__headerMouseMoveEventHandler = Function.createDelegate(this, this._onMouseMove);
		if (this._header)
		{
			this._grid._addElementEventHandler(this._header, "mousemove", this.__headerMouseMoveEventHandler);
		}
		this.__createDragDropBehavior();
		
		if (this._hierarchical && !this._gridManualLoadDemand)
		{
			this._grid._gridUtil = new $IG.HierarchicalGridUtility(this._grid);
			var band = this._band = this._grid.get_band();
			band._grids[this._grid._id] = this._grid;
		}
	},
	_onAlignStatCaption: function (eventArgs)
	{
		eventArgs.alignPixels = true;
	},
	_addStartColumnResizingEventListener: function (handler)
	{
		this._grid._gridUtil._registerEventListener(this, "StartColumnResizing", handler);
	},
	
	
	_isColumnResizingInProgress: function ()
	{
		if (this._currentDraggingAction.isDragEligible) return true;
	},
	
	__columnSelectionChanging: function ()
	{
		this._isColumnResizingInProgress();
	},
	__createDragDropBehavior: function ()
	{
		if (this._header)
		{
			var events = this._dragDropBehavior.get_events();
			this._dragDropBehavior.addTargetElement(document.body, true);

			var headerContent = this._grid._elements["headerContent"];

			if (this._gridHasHeaderLayout)
			{
				var headerRows = this._grid._elements["columnHeaderRow"];
				for (var i = 0; i < headerRows.length; i++)
				{
					if ($util.IsFireFox && (this._columnMoving || (this._hierarchical && this._grid._get_mainGrid().get_gridView()._elements["grpArea"])))
					{
						var headerRowCells = headerRows[i].childNodes;
						
						for (var x = this._columnFixing ? 0 : this._grid._get_cellIndexOffset(); x < headerRowCells.length; ++x)
							this._dragDropBehavior.addSourceElement(headerRowCells[x], true);
					}
					else
						this._dragDropBehavior.addSourceElement(headerRows[i], true);

				}
			}
			else
			{
				

				if ($util.IsFireFox && (this._columnMoving || (this._hierarchical && this._grid._get_mainGrid().get_gridView()._elements["grpArea"])))
				{
					var columnHeaderRow = this._grid._elements["columnHeaderRow"];
					if (columnHeaderRow.length)
						columnHeaderRow = columnHeaderRow[0];
					var headerRow = new $IG.GridRow(null, columnHeaderRow, [], this._grid, null);
					var cellCount = headerRow.get_cellCount();
					for (var x = 0; x < cellCount; ++x)
						this._dragDropBehavior.addSourceElement(headerRow.get_cell(x).get_element(), true);
				}
				else
					this._dragDropBehavior.addSourceElement(headerContent.getElementsByTagName("TR")[0], true);
			}



			this._dragDropBehavior.addDragChannels([this._grid._id + "_colResizing"]);
			this._dragDropBehavior.addDropChannels([this._grid._id + "_colResizing"]);

			events.addDragStartHandler(Function.createDelegate(this, this._dragStart));
			events.addDragMoveHandler(Function.createDelegate(this, this._dragMove));
			events.addDragCancelHandler(Function.createDelegate(this, this._dragCancel));
			events.addDragEndHandler(Function.createDelegate(this, this._dragEnd));
			events.addDropHandler(Function.createDelegate(this, this._dragDrop));
		}
	},
	__restoreHeaderCursor: function (headerElem)
	{
		if (headerElem.__previousCursor || headerElem.style.cursor != headerElem.__previousCursor)
		{
			headerElem.style.cursor = headerElem.__previousCursor;
			this.__previousGrpHeader.style.cursor = this.__previousGrpHeader.__previousCursor;
		}
	},
	__get_resizingColumnsOriginalState: function ()
	{
		var resizingColumns = new Array();
		var resizingColumnsOrigWidths = new Array();
		if (this._selection)
		{
			var selectedColumns = this._selection.get_selectedColumns();
			var indexOfResizingColumn = selectedColumns.indexOf(this._currentDraggingAction.currentSourceColumn);
			if (indexOfResizingColumn != -1)
			{
				var columnResizeSettings = this.get_columnResizeSettings();
				for (var i = 0; i < selectedColumns.get_length(); i++)
				{
					var item = selectedColumns.getItem(i);
					




					if (columnResizeSettings.getItemFromColumnKey(item.get_key()).get_enableResize())
					{
						resizingColumns.push(item);
						resizingColumnsOrigWidths.push(item.get_width());
					}
				}
			}
		}
		if (resizingColumns.length == 0)
		{
			resizingColumns.push(this._currentDraggingAction.currentSourceColumn);
			resizingColumnsOrigWidths.push(this._currentDraggingAction.currentSourceColumn.get_width());
		}
		return [resizingColumns, resizingColumnsOrigWidths];
	},
	__gatherEventArgs: function ()
	{
		return [this, this._currentDraggingAction.currentSourceColumn,
															  this._currentDraggingAction.currentColumnResizingGroup,
															  this._currentDraggingAction.startingWidth,
															  this._currentDraggingAction.currentColumnResizingGroupWidths];
	},
	__createResizeSetting: function ()
	{
		var props = new Array();
		var csm = new $IG.ObjectClientStateManager(props);
		var clientProps = new Array();
		var length = $IG.ColumnResizeSettingProps.Count;
		for (var i = 0; i < length; i++)
			clientProps.push(null);
		props.push(clientProps);
		var columnResizeSetting = new $IG.ColumnResizeSetting(null, null, null, null, csm);
		columnResizeSetting._set_owner(this);
		return columnResizeSetting;
	},
	__createResizeSettingSingleton: function ()
	{   



		var props = new Array();
		var csm = new $IG.ObjectClientStateManager(props);
		var clientProps = new Array();
		var length = $IG.ColumnResizeSettingProps.Count;
		for (var i = 0; i < length; i++)
			clientProps.push(null);
		props.push(clientProps);
		var singleton = new $IG.ColumnResizeSetting(null, null, null, null, csm);
		singleton._set_owner(this);

		singleton["__isSingleton"] = true;
		singleton["__tempColumnId"] = "_Unassigned_";
		singleton.onPropertyChanging = Function.createDelegate(this, this.__propertyChanging);

		return singleton;
	},
	__propertyChanging: function (propName, value)
	{
		
		var exsingleton = this._columnResizeSettingSingleton;
		var clientState = exsingleton._csm.get_clientState();
		this._columnResizeSettings._addExistingObject(exsingleton, exsingleton["__tempColumnId"], clientState);
		exsingleton["__tempColumnId"] = null;
		this._columnResizeSettingSingleton.onPropertyChanging = null;
		
		this._columnResizeSettingSingleton = this.__createResizeSettingSingleton();
	},
	__getColumnResizeSettingFromHeader: function (headerElem)
	{
		


		var column = this._grid._gridUtil._getColumnFromHeader(headerElem);
		if (this._gridHasHeaderLayout)
			column = this._grid.get_columns().get_columnFromKey(headerElem.getAttribute("key"));
		if (!column) return null;
		var resizeSetting = this.get_columnResizeSettings()._getObjectByAdr(column.get_key());
		if (resizeSetting == null)
		{
			resizeSetting = this._columnResizeSettingSingleton;
			this._columnResizeSettingSingleton.__tempColumnId = column.get_key();
		}
		return resizeSetting;
	},
	__doColumnResize: function (columnToResize, pixelWidth)
	{
		if (pixelWidth < 0) return;
		var currentWidthSetting = columnToResize.get_width();

		if (currentWidthSetting == "")
		{
			columnToResize.set_width(pixelWidth + "px");
		}
		else if (currentWidthSetting.endsWith("%"))
		{
			var gridWidth = this._grid._gridUtil._get_containerTableWidthResolved();
			var colWidth = pixelWidth;
			var newPercentValue = Math.round((colWidth / gridWidth) * 100);
			columnToResize.set_width(newPercentValue + "%");
		}
		else
		{
			columnToResize.set_width(pixelWidth + "px");
		}
	},
	
	
	_onMouseMove: function (evnt)
	{
		
		delete this._grid._mouseBetweenColumns;
		var target = evnt.target;
		if (target != null && target.nodeName == "TH")
		{
			var elemBounds = Sys.UI.DomElement.getBounds(target);
			var brw = $util.getStyleValue(null, "borderRightWidth", target);
			brw = parseInt(brw);
			if (isNaN(brw))
				brw = 3;
			else if (brw < 3) brw = 3;
			var blw = 3;
			blw = $util.getStyleValue(null, "borderLeftWidth", target);
			blw = parseInt(blw);
			if (isNaN(blw))
				blw = 3;
			else
				if (blw < 3)
					blw = 3;

			var column = this._grid._gridUtil._getColumnFromHeader(target);
			var realTarget = target;
			var headerLayoutColumn = null;
			if (this._gridHasHeaderLayout && target)
			{
				if (target.parentNode && target.parentNode.getAttribute && target.parentNode.getAttribute("mkr") == "sizeHeaderRow")
				{
					this._currentDraggingAction.isDragEligible = false;
					this.__restoreSettings();
					return;
				}
				var key = target.getAttribute("key");
				column = this._grid.get_columns().get_columnFromKey(key);

				if (!column)
				{
					headerLayoutColumn = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(key);
					if (headerLayoutColumn)
					{

						column = this.__get_lastDataColumn(headerLayoutColumn);
						if (column)
							target = column.get_headerElement();
					}
				}

			}

			if (this.__previousHeader && this.__previousHeader != target)
			{
				this.__restoreSettings();
			}
			if (!column) return;
			
			var b = document.body, windowScrollLeft = b.parentNode.scrollLeft || b.scrollLeft;

			var rightEdgeDelta = Math.abs(windowScrollLeft + evnt.clientX - (elemBounds.x + elemBounds.width));
			var leftEdgeDelta = Math.abs(windowScrollLeft + evnt.clientX - elemBounds.x);
			if ((rightEdgeDelta <= brw) || (leftEdgeDelta <= blw))
			{
				var allowResize = false;
				var resizeSetting = this.__getColumnResizeSettingFromHeader(target);

				if (leftEdgeDelta <= blw)
				{
					
					if (headerLayoutColumn == null && column.get_visibleIndex() != 0)
					{
						var prevColumn = this._grid._gridUtil._getPreviousRenderedColumn(column);
						if (prevColumn)
						{
							var prevSib = prevColumn.get_headerElement();
							resizeSetting = this.__getColumnResizeSettingFromHeader(prevSib);
							// H.A. 07/07/2016 fix bug #221411 - ColumnResizing feature detects hidden columns by mouse operation
							if (resizeSetting && resizeSetting.get_enableResize() && !prevColumn.get_hidden())
							{
								allowResize = true;
								target = prevSib;
							}
						}
					}
					else if (headerLayoutColumn != null && headerLayoutColumn.get_visibleIndex() != 0)
					{
						var prevHeaderLayoutColumn = this._grid._gridUtil._getPreviousRenderedHeaderLayoutColumn(headerLayoutColumn);
						if (prevHeaderLayoutColumn)
						{
							realTarget = prevHeaderLayoutColumn.get_headerElement();
							var prevColumn = this.__get_lastDataColumn(prevHeaderLayoutColumn);
							if (prevColumn)
								target = prevColumn.get_headerElement();
						}
					}
				}
				// H.A. 07/07/2016 fix bug #221411 - ColumnResizing feature detects hidden columns by mouse operation
				else if ((rightEdgeDelta <= brw) && resizeSetting && resizeSetting.get_enableResize() && !this._grid._gridUtil._getColumnFromHeader(target).get_hidden())
				{
					allowResize = true;
				}
				
				this._grid._mouseBetweenColumns = allowResize;
				if (allowResize && this.__previousHeader == null)
				{
					this._currentDraggingAction.isDragEligible = true;
					this.__previousHeader = target;
					this.__previousGrpHeader = realTarget;
					this.__previousHeader.__previousCursor = this.__previousHeader.style.cursor;
					this.__previousGrpHeader.__previousCursor = this.__previousGrpHeader.style.cursor;
					this.__previousHeader.style.cursor = "w-resize";
					this.__previousGrpHeader.style.cursor = "w-resize";
				}
			}
			else
			{
				this.__restoreSettings();
			}
		}
	},
	__restoreSettings: function ()
	{
		if (this.__previousHeader)
		{
			this.__restoreHeaderCursor(this.__previousHeader);
			this.__previousHeader = null;
			this.__previousGrpHeader = null;
			this._currentDraggingAction.isDragEligible = false;
		}
	},
	
	__get_lastDataColumn: function (groupedField)
	{
		var columns = groupedField.get_columns();

		for (var i = columns.length - 1; i >= 0; i--)
		{
			
			var column = groupedField.__get_childColumnByVisibleIndex(i);
			if (!column.get_isGroupField())
			{
				var dataColumn = this._grid.get_columns().get_columnFromKey(column.get_key());
				if (this.__isLastDataColumnEligibleForResize(dataColumn))
					return dataColumn;
			}
			else
			{
				var lastColumn = this.__get_lastDataColumn(column);
				if (lastColumn)
					return lastColumn;
			}
		}
		return null;
	},
	__isLastDataColumnEligibleForResize: function (dataColumn)
	{
		var resizeSetting = this.__getColumnResizeSettingFromHeader(dataColumn.get_headerElement());
		if (!resizeSetting || (resizeSetting && resizeSetting.get_enableResize()))
			return true;
		return false;
	},

	
	__shouldCancelColumnResizing: function (target, xPosition)
	{
		var elemBounds = Sys.UI.DomElement.getBounds(target);
		var brw = $util.getStyleValue(null, "borderRightWidth", target);
		brw = parseInt(brw);
		if (isNaN(brw) || brw < 3)
			brw = 3;
		
		
		var rightBorderPos = elemBounds.x + elemBounds.width - brw + (this._columnMoving ? 2 : 3);// - 1;
		if (xPosition < rightBorderPos)
			return true;
		return false;
	},
	_dragStart: function (behavior, evntArgs)
	{
		
		if (this._grid._get_isAjaxCallInProgress() || this.getEditingOn())
			return;
		this._grid._gridUtil._fireEvent(this, "StartColumnResizing", null);
		
		if (this._currentDraggingAction.isDragEligible)
		{
			
			this._currentDraggingAction.isDragEligible = false;
			this._currentDraggingAction.currentSourceColumn = this._grid._gridUtil._getColumnFromHeader(this.__previousHeader);

			
			if (this._hierarchical)
				this._getParentGridElements();

			
			this._currentDraggingAction.elementDragged = this.__previousHeader;
			this._currentDraggingAction.startingWidth = this.__previousHeader.offsetWidth;

			if (this._columnFixing && this._gridHasHeaderLayout)
			{
				var colObj = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(this._currentDraggingAction.elementDragged.getAttribute("key"));
				var side = (colObj._parentFixedDir != undefined ? colObj._parentFixedDir : colObj._fixedDirection);
				var fixedCaps = null;
				if (side == $IG.ColRegion.LeftFixed)
				{
					var fixedLeftCaps = this._grid._elements["fxdCapThLeft"];
					if (fixedLeftCaps.length)
						fixedLeftCaps = fixedLeftCaps[0];
					fixedCaps = fixedLeftCaps;
				}
				else if (side == $IG.ColRegion.RightFixed)
				{
					var fixedRightCaps = this._grid._elements["fxdCapThRight"];
					if (fixedRightCaps.length)
						fixedRightCaps = fixedRightCaps[0];
					fixedCaps = fixedRightCaps;
				}
				if (fixedCaps)
					this._currentDraggingAction.startingFixedCapsWidth = fixedCaps.offsetWidth;				
			}

			if (this._gridHasHeaderLayout)
			{
				var dragedKey = this.__previousHeader.getAttribute("key");
				this._currentDraggingAction.currentSourceColumn = this._grid.get_columns().get_columnFromKey(dragedKey);

				var sizeHeaderRows = this._grid._elements["sizeHeaderRow"];
				if (sizeHeaderRows)
				{
					if (!sizeHeaderRows.length)
					{
						var tmp = sizeHeaderRows;
						sizeHeaderRows = [];
						sizeHeaderRows[0] = tmp;
					}
					for (var j = 0; j < sizeHeaderRows.length; j++)
					{
						var sizeHeaderRowTH = sizeHeaderRows[j].childNodes;
						for (var i = 0; i < sizeHeaderRowTH.length; i++)
						{
							if (sizeHeaderRowTH[i].getAttribute("key") == dragedKey)
							{
								this._currentDraggingAction.elementDragged = sizeHeaderRowTH[i];
								
								j = sizeHeaderRows.length;
								break;
							}
						}
					}
				}
			}

			var colWidth = this._currentDraggingAction.currentSourceColumn.get_width();

			this._currentDraggingAction.isOriginallyPercentage = (colWidth && colWidth.endsWith("%"));

			this._currentDraggingAction.resizeSetting = this.__getColumnResizeSettingFromHeader(this.__previousHeader);
			
			var b = document.body, windowScrollLeft = b.parentNode.scrollLeft || b.scrollLeft;
			this._currentDraggingAction.startingX = windowScrollLeft + evntArgs.get_x();

			var resizingOriginalState = this.__get_resizingColumnsOriginalState();
			this._currentDraggingAction.currentColumnResizingGroup = resizingOriginalState[0];
			this._currentDraggingAction.currentColumnResizingGroupWidths = resizingOriginalState[1];
			this._currentDraggingAction.currentResizeSize = -1;

			this._currentDraggingAction.originalTableWidth = this._dataTbl.style.width;

			var args = this.__raiseClientEvent("ColumnResizing", $IG.ColumnResizingEventArgs, this.__gatherEventArgs());
			if (args != null && args.get_cancel())
			{
				




				evntArgs.set_cancel(true);
				return;
			}

			if (!this.__resizeDiv)
			{
				this.__resizeDiv = document.createElement("DIV");
				this.__resizeDiv.style.position = "absolute";
				this.__resizeDiv.className = this._resizingIndicatorCssClass;
				document.body.appendChild(this.__resizeDiv);
			}
			

			var top = $util.getLocation(this._container).y;
			var height = this._container.offsetHeight;
			if (this._hierarchical)
			{
				var mainGridElem = this._grid._get_mainGrid().get_element();
				var bounds = $util.getLocation(mainGridElem);
				var bottom = bounds.y + mainGridElem.offsetHeight;
				if (bottom < top + height)
					height = bottom - top;
			}
			if (height < 0)
				height = 0;
			this.__resizeDiv.style.top = top + "px";
			this.__resizeDiv.style.height = height + "px";
			this.__resizeDiv.style.display = "";
			var widthOfDiv = parseInt($util.getStyleValue(null, "width", this.__resizeDiv));
			if (this._gridHasHeaderLayout)
			{
				 
				var bounds = Sys.UI.DomElement.getBounds(this._currentDraggingAction.elementDragged);
				this.__resizeDiv.style.left = bounds.x + bounds.width - (isNaN(widthOfDiv) ? 0 : widthOfDiv / 2) + "px";
			}
			else
				this.__resizeDiv.style.left = this._currentDraggingAction.startingX - (isNaN(widthOfDiv) ? 0 : widthOfDiv / 2) + "px";
			this._dragDropBehavior.set_dragMarkup(document.createElement("div"));
		}
		else
		{
			

			
			if (
				this.__shouldCancelColumnResizing(evntArgs.get_manager().get_sourceElement().tagName == "TH" ? evntArgs.get_manager().get_sourceElement() : evntArgs.get_manager().get_sourceElement().parentNode, evntArgs.get_x()))
			{
				evntArgs.set_cancel(true);
				return;
			}
		}
	},
	_dragMove: function (behavior, evntArgs)
	{

		if (!this._currentDraggingAction || this._currentDraggingAction.resizeSetting == null) return;

		var difX = this._currentDraggingAction.startingX - evntArgs.get_x();
		
		if (difX) 
		{
			
			var calcWidth;
			var moveDiv = false;

			if (difX > 0)
			{
				var colWidth = this._currentDraggingAction.currentSourceColumn.get_width();
				var minWidth = this._currentDraggingAction.resizeSetting.get_minimumWidth();
				var currentWidthOffset = this._currentDraggingAction.elementDragged.offsetWidth;
				


				calcWidth = this._currentDraggingAction.startingWidth - difX;
				if (calcWidth < 0) calcWidth = 0;
				if (minWidth > -1 && calcWidth < minWidth)
					calcWidth = minWidth;
				




				if (this.__dragResizingEvent(calcWidth))
				{
					return;
				}
				if (currentWidthOffset > 0 && calcWidth > 0 &&
				(minWidth == -1 || currentWidthOffset > minWidth || this._currentDraggingAction.isOriginallyPercentage))
				{
					







					var headerContent = this._grid._elements["headerContent"];
					if (headerContent.style.width && headerContent.style.width.indexOf("px") > 0)
					{
						var headerContentWidth = parseInt(headerContent.style.width);
						var columnDif = this._currentDraggingAction.currentResizeSize - calcWidth;
						if ((headerContentWidth + columnDif) > 0)
						{
							headerContent.style.width = (headerContentWidth + columnDif) + "px";
						}
					}

					this._dragDropBehavior.set_dragDropMode($IG.DragDropEffects.Move);
					moveDiv = true;
					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					var reDiff = this._currentDraggingAction.elementDragged.offsetWidth - calcWidth;
					calcWidth -= reDiff;
					if (calcWidth < 0) calcWidth = 0;
					if (minWidth > -1 && calcWidth < minWidth)
						calcWidth = minWidth;
					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					this._currentDraggingAction.currentResizeSize = calcWidth;

					if (this._columnFixing && this._gridHasHeaderLayout)
					{
						var colObj = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(this._currentDraggingAction.elementDragged.getAttribute("key"));
						var side = (colObj._parentFixedDir != undefined ? colObj._parentFixedDir : colObj._fixedDirection);
						var fixedCaps = null;
						if (side == $IG.ColRegion.LeftFixed)
						{
							var fixedLeftCaps = this._grid._elements["fxdCapThLeft"];
							if (fixedLeftCaps.length)
								fixedLeftCaps = fixedLeftCaps[0];
							fixedCaps = fixedLeftCaps;
						}
						else if (side == $IG.ColRegion.RightFixed)
						{
							var fixedRightCaps = this._grid._elements["fxdCapThRight"];
							if (fixedRightCaps.length)
								fixedRightCaps = fixedRightCaps[0];
							fixedCaps = fixedRightCaps;
						}
						if (fixedCaps)
							fixedCaps.style.width = (this._currentDraggingAction.startingFixedCapsWidth - difX) + "px";
					}

				}
				else
				{
					this._dragDropBehavior.set_dragDropMode($IG.DragDropEffects.None);
				}
			}
			else
			{

				var maxWidth = this._currentDraggingAction.resizeSetting.get_maximumWidth();
				var currentWidthOffset = this._currentDraggingAction.elementDragged.offsetWidth;

				if (maxWidth == -1 || currentWidthOffset < maxWidth || this._currentDraggingAction.isOriginallyPercentage)
				{
					this._dragDropBehavior.set_dragDropMode($IG.DragDropEffects.Move);
					moveDiv = true;
					calcWidth = this._currentDraggingAction.startingWidth + Math.abs(difX);

					if (maxWidth > -1 && calcWidth > maxWidth)
						calcWidth = maxWidth;

					




					if (this.__dragResizingEvent(calcWidth))
					{
						return;
					}

					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					var reDiff = this._currentDraggingAction.elementDragged.offsetWidth - calcWidth;
					calcWidth -= reDiff;
					if (calcWidth < 0) calcWidth = 0;
					if (maxWidth > -1 && calcWidth > maxWidth)
						calcWidth = maxWidth;
					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					this._currentDraggingAction.currentResizeSize = calcWidth;

					if (this._columnFixing && this._gridHasHeaderLayout)
					{
						var colObj = this._grid._gridUtil._get_HeaderLayoutColumnFromKey(this._currentDraggingAction.elementDragged.getAttribute("key"));
						var side = (colObj._parentFixedDir != undefined ? colObj._parentFixedDir : colObj._fixedDirection);
						var fixedCaps = null;
						if (side == $IG.ColRegion.LeftFixed)
						{
							var fixedLeftCaps = this._grid._elements["fxdCapThLeft"];
							if (fixedLeftCaps.length)
								fixedLeftCaps = fixedLeftCaps[0];
							fixedCaps = fixedLeftCaps;
						}
						else if (side == $IG.ColRegion.RightFixed)
						{
							var fixedRightCaps = this._grid._elements["fxdCapThRight"];
							if (fixedRightCaps.length)
								fixedRightCaps = fixedLeftCaps[0];
							fixedCaps = fixedRightCaps;
						}
						if (fixedCaps)
							fixedCaps.style.width = (this._currentDraggingAction.startingFixedCapsWidth + Math.abs(difX)) + "px";
					}
				}
				else if (currentWidthOffset > maxWidth)
				{
					moveDiv = true;
					calcWidth = maxWidth;

					




					if (this.__dragResizingEvent(calcWidth))
					{
						return;
					}

					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					var reDiff = this._currentDraggingAction.elementDragged.offsetWidth - calcWidth;
					calcWidth -= reDiff;
					if (calcWidth < 0) calcWidth = 0;
					this._currentDraggingAction.elementDragged.style.width = calcWidth + "px";
					this._currentDraggingAction.currentResizeSize = calcWidth;
				}
				else
				{
					this._dragDropBehavior.set_dragDropMode($IG.DragDropEffects.None);
				}
			}

			if (moveDiv)
			{
				





				var evntArgsX = evntArgs.get_x();
				var gridBounds = Sys.UI.DomElement.getBounds(this._grid._container);
				
				var gridLeft = gridBounds.x;
				var gridRight = gridBounds.x + gridBounds.width;
				if (this._hierarchical && this._ancestorGridElements)
				{
					var setLeft = false;
					for (var i = 0; i < this._ancestorGridElements.length; ++i)
					{
						if (this._ancestorGridElements[i])
						{
							var parentGridEdgeLeft = $util.getLocation(this._ancestorGridElements[i]).x;
							var parentGridEdgeRight = parentGridEdgeLeft + this._ancestorGridElements[i].offsetWidth;
							if (!setLeft && gridLeft < parentGridEdgeLeft)
							{
								gridLeft = parentGridEdgeLeft;
								setLeft = true;
							}
							if (gridRight > parentGridEdgeRight)
								gridRight = parentGridEdgeRight;
						}
					}
				}
				var widthOfDiv = parseInt($util.getStyleValue(null, "width", this.__resizeDiv));
				var bounds = Sys.UI.DomElement.getBounds(this._currentDraggingAction.elementDragged);
				var resizeDivLeft = bounds.x + bounds.width;

				
				//if ((evntArgsX - gridBounds.x) >= 0 && (gridBounds.x + gridBounds.width - evntArgsX) >= 0)
				if ((!this._gridHasHeaderLayout && (evntArgsX - gridLeft) >= 0 && (gridRight - evntArgsX) >= 0) || (this._gridHasHeaderLayout && (resizeDivLeft - gridLeft) >= 0 && (gridRight - resizeDivLeft) >= 0))
				{
					this.__resizeDiv.style.left = resizeDivLeft + "px";
					//	this.__resizeDiv.style.left = (evntArgs.get_x() - (isNaN(widthOfDiv) ? 0 : widthOfDiv / 2)) + "px";
				}
				else if (this._gridHasHeaderLayout)
				{
					if ((resizeDivLeft - gridLeft) < 0)
						this.__resizeDiv.style.left = gridLeft + 2 + "px";
					else if ((gridRight - resizeDivLeft) < 0)
						this.__resizeDiv.style.left = gridRight - 2 + "px";
				}

			}
		}
	},

	__dragResizingEvent: function (calcWidth)
	{
		




		var eventArgs = this.__gatherEventArgs();
		eventArgs[eventArgs.length] = calcWidth;
		var args = this.__raiseClientEvent("ColumnResizeDragging", $IG.ColumnResizeDraggingEventArgs, eventArgs);
		if (args != null && args.get_cancel())
		{
			return true;
		}
		return false;
	}
	,
	_dragCancel: function (behavior, evntArgs)
	{
		if (!this._currentDraggingAction || this._currentDraggingAction.resizeSetting == null) return;
		
		if (this._currentDraggingAction.currentSourceColumn && this._currentDraggingAction.currentSourceColumn.get_width() != "")
			this._currentDraggingAction.currentSourceColumn.set_width(this._currentDraggingAction.currentSourceColumn.get_width());

		this._dataTbl.style.width = this._currentDraggingAction.originalTableWidth;

		this.__raiseClientEvent("ColumnResized", $IG.ColumnResizedEventArgs, [this,
			this._currentDraggingAction.currentSourceColumn,
			this._currentDraggingAction.currentColumnResizingGroup,
			this._currentDraggingAction.currentColumnResizingGroupWidths,
			true,
			true]);
	},
	_dragEnd: function (behavior, evntArgs)
	{
		if (!this._currentDraggingAction) return;
		this._currentDraggingAction.isDragEligible = false;
		this._currentDraggingAction.elementDragged = null;
		this._currentDraggingAction.startingWidth = 0;
		if (this._columnFixing && this._gridHasHeaderLayout)
			this._currentDraggingAction.startingFixedCapsWidth = 0;
		this._currentDraggingAction.resizeSetting = null;
		this._currentDraggingAction.currentSourceColumn = null;
		this._currentDraggingAction.currentColumnResizingGroup = null;
		this._currentDraggingAction.currentColumnResizingGroupWidths = null;
		this._currentDraggingAction.currentResizeSize = -1;
		this._currentDraggingAction.allPixels = false;
		this._currentDraggingAction.originalTableWidth = "";
		this._currentDraggingAction.isOriginallyPercentage = false;
		
		this.__restoreSettings();

		this._grid._onResize({ "clientHeight": this._grid.get_element().clientHeight }, true);
		if (this.__resizeDiv) this.__resizeDiv.style.display = "none";
	},
	__get_allColumnsPixel: function ()
	{
		var columns = this._grid.get_columns();
		var colCount = columns.get_length();
		for (var i = 0; i < colCount; i++)
		{
			var column = columns.get_column(i);
			var widthValue = column.get_width();
			if (!widthValue || widthValue.endsWith("%")) return false;
		}
		return true;
	},
	_rebalanceColumns: function ()
	{

		var columns = this._grid.get_columns();
		var colCount = columns.get_length();
		var columnSettings = new Array();

		
		var isColumnInSelected = (this._currentDraggingAction.currentColumnResizingGroup && this.__indexOfColumn(this._currentDraggingAction.currentColumnResizingGroup, this._currentDraggingAction.currentSourceColumn) > -1);
		
		var usedSpace = 0;
		
		var percentValueInAllUnchangedColumns = 0;
		var reactiveColumns = 0;
		for (var i = 0; i < colCount; i++)
		{
			var column = columns.get_column(i);
			if (column.get_hidden())
				continue;
			var widthValue = column.get_width();
			if (!widthValue || !widthValue.endsWith("%")) return;
			var intWidthValue = parseInt(widthValue);

			if (column == this._currentDraggingAction.currentSourceColumn ||
				(this._currentDraggingAction.currentColumnResizingGroup && this.__indexOfColumn(this._currentDraggingAction.currentColumnResizingGroup, column) > -1))
			{
				usedSpace += intWidthValue;
				
				columnSettings.push([true, column.get_key(), intWidthValue, intWidthValue]);
			}
			else
			{
				percentValueInAllUnchangedColumns += intWidthValue;
				columnSettings.push([false, column.get_key(), intWidthValue, intWidthValue]);
				reactiveColumns++;
			}
		}

		
		if (usedSpace > 100)
		{
			for (var i = 0; i < columnSettings.length; i++)
			{
				if (!columnSettings[i][0])
					columnSettings[i][3] = 1;
			}
		}
		else if (percentValueInAllUnchangedColumns > 0)
		{
			var spaceForTheRest = 100 - usedSpace;
			var newAllocatedSpace = 0;
			for (var i = 0; i < columnSettings.length; i++)
			{
				if (!columnSettings[i][0])
				{
					var newWidth = Math.round((spaceForTheRest * columnSettings[i][2]) / percentValueInAllUnchangedColumns);
					columnSettings[i][3] = newWidth;
					newAllocatedSpace += newWidth;
				}
			}
			if (newAllocatedSpace != spaceForTheRest)
			{
				


				var difference = newAllocatedSpace - spaceForTheRest;
				if (difference > 0) 
				{
					var largestCol = null;
					for (var i = 0; i < columnSettings.length; i++)
					{
						if (!columnSettings[i][0])
						{
							if (largestCol == null)
							{
								largestCol = columnSettings[i];
							}
							else if (largestCol[3] < columnSettings[i][3])
							{
								largestCol = columnSettings[i];
							}
						}
					}
					if (largestCol != null)
					{
						if (largestCol[3] > (difference + 1))
						{
							largestCol[3] -= difference;
						}
						else
							largestCol[3] = 1;
					}
				}
				else
				{
					var smallestCol = null;
					for (var i = 0; i < columnSettings.length; i++)
					{
						if (!columnSettings[i][0])
						{
							if (smallestCol == null)
							{
								smallestCol = columnSettings[i];
							}
							else if (smallestCol[3] > columnSettings[i][3])
							{
								smallestCol = columnSettings[i];
							}
						}
					}
					if (smallestCol != null)
					{
						smallestCol[3] -= difference;
					}
				}
			}
		}

		var debugCheckingValue = 0;
		for (var i = 0; i < columnSettings.length; i++)
		{
			debugCheckingValue += columnSettings[i][3];
		}

		for (var i = 0; i < columnSettings.length; i++)
		{
			var columnInfo = columnSettings[i];
			var column = columns.get_columnFromKey(columnInfo[1]);
			var newWidth = columnInfo[3] + "%";
			if (column.get_width() != newWidth)
			{
				column.set_width(newWidth);
			}
		}
	},
	__indexOfColumn: function (collectionArray, column)
	{
		if (collectionArray == null || column == null) return -1;
		for (var i = 0; i < collectionArray.length; i++)
		{
			if (collectionArray[i] == column) return i;
		}
		return -1;
	},
	__indexOfColumnSibling: function (collectionArray, column)
	{
		if (collectionArray == null || column == null) return -1;
		for (var i = 0; i < collectionArray.length; i++)
		{
			if (collectionArray[i]._key == column._key) return i;
		}
		return -1;
	},
	_dragDrop: function (behavior, evntArgs)
	{
		
		if (!this._currentDraggingAction || !this._currentDraggingAction.currentSourceColumn) return;

		




		
		var scrollBar = this._grid._elements["hScrBar"];
		var scrollLeftCurrent = 0;
		var scrollBarMax = 1;
		if (scrollBar)
		{
			scrollLeftCurrent = scrollBar.scrollLeft;
			scrollBarMax = scrollBar.scrollWidth;
		}


		this.__doColumnResize(this._currentDraggingAction.currentSourceColumn, this._currentDraggingAction.currentResizeSize);

		if (this._currentDraggingAction.currentColumnResizingGroup && this.__indexOfColumn(this._currentDraggingAction.currentColumnResizingGroup, this._currentDraggingAction.currentSourceColumn) > -1)
		{
			for (var i = 0; i < this._currentDraggingAction.currentColumnResizingGroup.length; i++)
			{
				var col = this._currentDraggingAction.currentColumnResizingGroup[i];
				this.__doColumnResize(col, this._currentDraggingAction.currentResizeSize);
			}
		}
		





		this._rebalanceColumns();

		this._rebalanceContainerWidths();

		


		this._grid._onResize({ "clientHeight": this._owner._element.clientHeight }, false);

		this.__raiseClientEvent("ColumnResized", $IG.ColumnResizedEventArgs, [this,
			this._currentDraggingAction.currentSourceColumn,
			this._currentDraggingAction.currentColumnResizingGroup,
			this._currentDraggingAction.currentColumnResizingGroupWidths,
			false,
			true]);
		

		var resizedColumns = new Array();
		for (var i = 0; i < this._currentDraggingAction.currentColumnResizingGroup.length; i++)
		{
			resizedColumns.push(this._currentDraggingAction.currentColumnResizingGroup[i].get_key());
		}

		var columnResizeSerial = { "SourceColumn": this._currentDraggingAction.currentSourceColumn.get_key(),
			"ResizedColumns": resizedColumns, "OriginalWidths": this._currentDraggingAction.currentColumnResizingGroupWidths
		};

		
		if (this._hierarchical && (this._grid._get_level() > 0 || !this._grid._enableAjax))
		{
			var hasCol = !this._autoGenCols;
			if (hasCol)
			{
				var mainGrid = this._grid._get_mainGrid();
				var actionInfo = new Object();
				actionInfo.bandAdr = this._grid._get_band()._get_bandIndexAddress();
				actionInfo.resizeInfo = columnResizeSerial;
				actionInfo.newSize = this._currentDraggingAction.currentResizeSize;
				actionInfo.gridAdr = "";
				var action = new $IG.HierarchicalGridAction("resizeCol", mainGrid, actionInfo);
				
				mainGrid._actionList.add_transaction(action, true);

				if (this._autoPostBackColumnResized)
					mainGrid._postAction((mainGrid._enableAjax ? 2 : 1));
			}
			if (!hasCol || !this._autoPostBackColumnResized)
			{
				
				var grids = this._gridManualLoadDemand ? [] : this._grid._get_band()._get_containerGrids();
                for (var gridId in grids)
				{
					var grid = grids[gridId];
					
					
					if (grid && (!hasCol || grid != this._grid) && grid.get_behaviors().get_columnResizing())
						grid.get_behaviors().get_columnResizing()._resizeFromSibling(hasCol, columnResizeSerial, this);
				}
			}
		}
		else
		{

			



			var acts = this._owner._actionList;
			var transList = acts.get_actionListForType("ColumnResized");
			for (var i = 0; i < transList.length; i++)
			{
				var resizeTransaction = transList[i];
				if (resizeTransaction.get_tag() == this._currentDraggingAction.currentSourceColumn.get_key())
				{
					acts.remove_transaction(resizeTransaction);
					break;
				}
			}
			
			if (this._hierarchical)
				columnResizeSerial.hierarchical = true;
			
			var act = new $IG.GridAction("ColumnResized", this.get_name(), this, Sys.Serialization.JavaScriptSerializer.serialize(columnResizeSerial), this._currentDraggingAction.currentSourceColumn.get_key());
			acts.add_transaction(act, true);

			var scrollMaxCurrent = scrollBar ? scrollBar.scrollWidth : 0;
			scrollBarMax = (scrollBarMax == 0 ? 1 : scrollBarMax);
			




			this._grid.set_scrollLeft((scrollMaxCurrent * scrollLeftCurrent / scrollBarMax));

			if (this._autoPostBackColumnResized)
			{
				
				var eventArgs = new $IG.ColumnResizedEventArgs([this,
			this._currentDraggingAction.currentSourceColumn,
			this._currentDraggingAction.currentColumnResizingGroup,
			this._currentDraggingAction.currentColumnResizingGroupWidths,
			false,
			true]);
				if (!this._grid._enableAjax)
					this._owner._postAction(1);
				else
				{
					eventArgs._props[1] = 2;
					this._owner._raiseClientEventEnd(eventArgs);
				}
				
				acts.remove_transaction(act);
			}
		}
	},
	_fireClientEvent: function (draggingAction, columnResizeSerial)
	{
		



		var acts = this._owner._actionList;
		var transList = acts.get_actionListForType("ColumnResized");
		for (var i = 0; i < transList.length; i++)
		{
			var resizeTransaction = transList[i];
			if (resizeTransaction.get_tag() == draggingAction.currentSourceColumn.get_key())
			{
				acts.remove_transaction(resizeTransaction);
				break;
			}
		}
		
		var act = new $IG.GridAction("ColumnResized", this.get_name(), this, Sys.Serialization.JavaScriptSerializer.serialize(columnResizeSerial), draggingAction.currentSourceColumn.get_key());
		acts.add_transaction(act, true);

		if (this._autoPostBackColumnResized)
		{
			
			var eventArgs = new $IG.ColumnResizedEventArgs([this,
			draggingAction.currentSourceColumn,
			draggingAction.currentColumnResizingGroup,
			draggingAction.currentColumnResizingGroupWidths,
			false,
			true]);
			if (!this._grid._enableAjax)
				this._owner._postAction(1);
			else
			{
				eventArgs._props[1] = 2;
				this._owner._raiseClientEventEnd(eventArgs);
			}
			
			acts.remove_transaction(act);
		}
	}
	,
	_resizeFromSibling: function (hasCol, columnResizeSerial, originalResizingBehavior)
	{
		var draggingAction = originalResizingBehavior._currentDraggingAction;
		var scrollBar = this._grid._elements["hScrBar"];
		var scrollLeftCurrent = 0;
		var scrollBarMax = 1;
		if (scrollBar)
		{
			scrollLeftCurrent = scrollBar.scrollLeft;
			scrollBarMax = scrollBar.scrollWidth;
		}

		if (this._grid != originalResizingBehavior._grid)
		{
			var column = this._grid.get_columns().get_columnFromKey(draggingAction.currentSourceColumn.get_key());
			this.__doColumnResize(column, draggingAction.currentResizeSize);

			if (draggingAction.currentColumnResizingGroup && this.__indexOfColumnSibling(draggingAction.currentColumnResizingGroup, column) > -1)
			{
				for (var i = 0; i < draggingAction.currentColumnResizingGroup.length; i++)
				{
					var col = this._grid.get_columns().get_columnFromKey(draggingAction.currentColumnResizingGroup[i].get_key());
					this.__doColumnResize(col, draggingAction.currentResizeSize);
				}
			}
			





			this._rebalanceColumns();

			this._rebalanceContainerWidths();

			


			this._grid._onResize({ "clientHeight": this._owner._element.clientHeight }, false);
		}

		
		if (!hasCol)
			this._fireClientEvent(draggingAction, columnResizeSerial);
	},
	_rebalanceContainerWidths: function ()
	{
		if (this.__get_allColumnsPixel())
		{
			var columnSum = 0;
			var columns = this._grid.get_columns();
			var colCount = columns.get_length();
			for (var i = 0; i < colCount; i++)
			{
				var column = columns.get_column(i);
				if (column.get_hidden())
					continue;
				var widthValue = column.get_width();
				columnSum += parseInt(widthValue);
			}

			this._dataTbl.style.width = columnSum + "px";
			if (this._owner._elements["headerContent"])
			{
				this._owner._elements["headerContent"].style.width = columnSum + "px";
			}
			if (this._owner._elements["footerContent"])
			{
				this._owner._elements["footerContent"].style.width = columnSum + "px";
			}
		}
	},
	
	_getParentGridElements: function ()
	{
		if (this._initializedScrollElements || !this._hierarchical)
			return;
		this._initializedScrollElements = true;
		if (this._ancestorGridElements == null)
			this._ancestorGridElements = [];
		var parentRow = this._grid.get_parentRow();
		this._hasHorizontalScroll = this._horizontalScrollBar != null;
		while (parentRow != null)
		{
			var grid = parentRow.get_grid();
			this._ancestorGridElements[this._ancestorGridElements.length] = grid._elements["container"];
			parentRow = grid.get_parentRow();
		}
	}
	
}

$IG.ColumnResizing.registerClass('Infragistics.Web.UI.ColumnResizing', $IG.GridBehavior, $IG.IColumnResizingBehavior);


$IG.ColumnResizedEventArgs = function (args)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnResizedEventArgs">
	///Event arguments object that is passed into the ColumnResized event handler.
	///</summary>	
	$IG.ColumnResizedEventArgs.initializeBase(this, [args[0]]);
	this._sourceColumn = args[1];
	this._selectedColumns = args[2];
	this._startingWidths = args[3];
	this._cancelled = args[4];
	this._context = {};
	this._context["behavior"] = args[0].get_name();
	this._name = "ColumnResized";
	this._noIndicator = args[5];
}
$IG.ColumnResizedEventArgs.prototype =
{
	get_column: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizedEventArgs.column">
		///Returns which column is being used as the drag source for the resize action. 
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn" />
		return this._sourceColumn;
	},
	get_columns: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizedEventArgs.columns">
		/// Returns which columns are being resized by this resize action.        
		///</summary>
		///<value type="Array" elementType="Infragistics.Web.UI.GridColumn" />
		return this._selectedColumns;
	},
	get_startingWidths: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizedEventArgs.startingWidths">
		/// Returns the original width collection for this resize action.
		///</summary>        
		///<value type="Array" elementType="String" />
		return this._startingWidths;
	},
	get_cancelled: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizedEventArgs.cancelled">
		/// Returns if the resize action was cancelled.
		///</summary>
		///<value type="Boolean" />
		return this._cancelled;
	}
}
$IG.ColumnResizedEventArgs.registerClass('Infragistics.Web.UI.ColumnResizedEventArgs', $IG.EventArgs);


$IG.ColumnResizingEventArgs = function (args)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnResizingEventArgs">
	///Event arguments object that is passed into the ColumnResizing event handler.
	///</summary>	
	



	$IG.ColumnResizingEventArgs.initializeBase(this, [args[0]]);
	this._sourceColumn = args[1];
	this._selectedColumns = args[2];
	this._startingWidth = args[3];
	this._startingWidths = args[4];
}
$IG.ColumnResizingEventArgs.prototype =
{
	get_column: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizingEventArgs.column">
		///Returns which column is being used as the drag source for the resize action. 
		///</summary>
		///<value type="Infragistics.Web.UI.GridColumn" />
		return this._sourceColumn;
	},
	get_columns: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizingEventArgs.columns">
		/// Returns which columns are being resized by this resize action.        
		///</summary>
		///<value type="Array" elementType="Infragistics.Web.UI.GridColumn" />
		return this._selectedColumns;
	},
	get_startingWidth: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizingEventArgs.startingWidth">
		/// Returns the width of the column that is being resized by the user.
		///</summary>
		///<value type="String" />
		return this._startingWidth;
	},
	get_startingWidths: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizingEventArgs.startingWidths">
		/// Returns the original width collection for this resize action.
		///</summary>
		///<value type="Array" elementType="String" />
		return this._startingWidths;
	}
}
$IG.ColumnResizingEventArgs.registerClass('Infragistics.Web.UI.ColumnResizingEventArgs', $IG.CancelBehaviorEventArgs);


$IG.ColumnResizeDraggingEventArgs = function (args)
{
	///<summary locid="T:J#Infragistics.Web.UI.ColumnResizeDraggingEventArgs">
	///Event arguments object that is passed into the ColumnResizeDragging event handler.
	///</summary>	
	$IG.ColumnResizeDraggingEventArgs.initializeBase(this, [args]);
	this._currentWidth = args[args.length - 1];

}
$IG.ColumnResizeDraggingEventArgs.prototype =
{
	get_currentWidth: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeDraggingEventArgs.currentWidth">
		///Returns the current width of the column being used for the resize operation. 
		///</summary>
		///<value type="String" />
		return this._currentWidth;
	}
}
$IG.ColumnResizeDraggingEventArgs.registerClass('Infragistics.Web.UI.ColumnResizeDraggingEventArgs', $IG.ColumnResizingEventArgs);


$IG.ColumnResizeSettings = function (control, clientStateManager, index, manager)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnResizeSettings">
	/// A collection of ColumnResizeSetting objects.
	/// </summary>
	$IG.ColumnResizeSettings.initializeBase(this, [control, clientStateManager, index, manager]);
}
$IG.ColumnResizeSettings.prototype =
{
	getItemFromColumnKey: function (columnKey)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ColumnResizeSettings.getItemFromColumnKey">
		///Returns the ColumnResizeSetting with the specified column key
		///</summary>
		///<param name="columnKey" type="String">Column key</param>
		///<returns type="Infragistics.Web.UI.ColumnResizeSetting" mayBeNull="true">Column setting that corresponds to the column key, or null.</returns>
		var resizeSetting = this._getObjectByAdr(columnKey);

		if (!resizeSetting && this._control._grid.get_columns().get_columnFromKey(columnKey))
		{
			resizeSetting = this._control.__createResizeSetting();

			var clientState = resizeSetting._csm.get_clientState();

			this._addExistingObject(resizeSetting, columnKey, clientState);
			
		}
		return resizeSetting;
	}
}
$IG.ColumnResizeSettings.registerClass('Infragistics.Web.UI.ColumnResizeSettings', $IG.ObjectCollection);


$IG.ColumnResizeSetting = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnResizeSetting">
	/// ColumnResizeSetting object of the grid. 
	/// </summary>
	$IG.ColumnResizeSetting.initializeBase(this, [adr, element, props, owner, csm]);

	
	this.__isDirty = false;
}
$IG.ColumnResizeSetting.prototype =
{
	__set_property: function (propName, value, fireEvent)
	{
		if (fireEvent)
		{
			


			if (this.onPropertyChanging)
			{
				this.onPropertyChanging(propName);
			}
		}
		this._set_value(propName, value);
	},
	get_enableResize: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.enableResize">
		/// Returns the EnableResize value from the ColumnResizeSetting object.
		///</summary>
		///<value type="Boolean" />
		return this._get_value($IG.ColumnResizeSettingProps.EnableResize, true);
	},
	set_enableResize: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.enableResize">
		/// Sets the EnableResize value from the ColumnResizeSetting object.
		///</summary>
		///<param name="value" type="Boolean" />
		this.__set_property($IG.ColumnResizeSettingProps.EnableResize, value, true);
	},
	get_minimumWidth: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.minimumWidth">
		/// Returns the MinimumWidth value from the ColumnResizeSetting object.
		///</summary>
		///<value type="String" />
		return this._get_value($IG.ColumnResizeSettingProps.MinimumWidth, -1);
	},
	set_minimumWidth: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.minimumWidth">
		/// Sets the MinimumWidth value from the ColumnResizeSetting object.
		///</summary>
		///<param name="value" type="String" />
		this.__set_property($IG.ColumnResizeSettingProps.MinimumWidth, value, true);
	},
	get_maximumWidth: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.maximumWidth">
		/// Returns the MaximumWidth value from the ColumnResizeSetting object.
		///</summary>
		///<value type="String" />
		return this._get_value($IG.ColumnResizeSettingProps.MaximumWidth, -1);
	},
	set_maximumWidth: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ColumnResizeSetting.maximumWidth">
		/// Sets the MaximumWidth value from the ColumnResizeSetting object.
		///</summary>    
		///<param name="value" type="String" />
		this.__set_property($IG.ColumnResizeSettingProps.MaximumWidth, value, true);
	},
	onPropertyChanging: function (propName)
	{
		///<summary locid="M:J#Infragistics.Web.UI.ColumnResizeSetting.onPropertyChanging">Notification of a property change in the setting object</summary>
		///<param name="propName" type="String">name of the changing propert.</param>

	}
}
$IG.ColumnResizeSetting.registerClass('Infragistics.Web.UI.ColumnResizeSetting', $IG.ColumnSetting);


$IG.ColumnResizingProps = new function ()
{
	var count = $IG.GridBehaviorProps.Count;
	this.Count = count;
};

$IG.ColumnResizeSettingProps = new function ()
{
	var count = $IG.ColumnSettingProps.Count;
	this.EnableResize = [count++, true];
	this.MinimumWidth = [count++, -1];
	this.MaximumWidth = [count++, -1];
	this.Count = count;
};

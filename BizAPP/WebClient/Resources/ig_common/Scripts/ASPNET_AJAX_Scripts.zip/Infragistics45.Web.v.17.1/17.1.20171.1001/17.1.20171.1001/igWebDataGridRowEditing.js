/*
* igWebDataGridRowEditing.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/


$IG.RowEditing = function(obj, objProps, control, parentCollection)
{
	///<summary locid="T:J#Infragistics.Web.UI.RowEditing">
	///Behavior which allows to put all cells in a row of WebDataGrid in edit mode.
	///</summary>
	$IG.RowEditing.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._re_props = this._get_clientOnlyValue('re').split(',') || [];
	this._enableDialog = this._re_props.length > 5;
}

$IG.RowEditing.prototype =
{
	_createCollections: function(collectionsManager)
	{
		this._editors = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._editors._addObject($IG.ColumnEditableSetting, null, columnKey);
	},
	_initializeComplete: function()
	{
		$IG.RowEditing.callBaseMethod(this, '_initializeComplete');
	},
	get_columnSettings: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.RowEditing.columnSettings">
		///Returns column settings.
		///</summary>
		///<value></value>
		return this._editors;
	},
	get_columnSettingFromKey: function(columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditing.get_columnSettingFromKey">
		/// Gets the column summary setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the cell editing column setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnEditableSetting">The editing column setting tied to the specified column key</value>
		var items = this._editors ? this._editors._items : null;
		var i = items ? items.length : 0;
		while (i-- > 0)
			if (items[i].get_columnKey() === columnKey)
				return items[i];
		return null;
	},
	_fixCss: function (elem, css, add)
	{
		// 0-cell css
		// 1-container css
		// 2-button hover css
		// 3-button focus css
		// 4-dialog css
		// 5-button css
		// 6-button done css
		// 7-button cancel css
		css = elem ? this._re_props[css] : null;
		if (!css)
			return;
		css = ' ' + css;
		var old = elem.className || '';
		if (add && old.indexOf(css) < 0)
			elem.className = old + css;
		if (!add && old.indexOf(css) >= 0)
			elem.className = old.replace(css, '');
	},
	enterEditMode: function (cell, key)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditing.enterEditMode">
		/// Causes the grid to enter row-edit mode.
		/// </summary>
		/// <param name="cell" type="Infragistics.Web.UI.GridCell">The cell which gets request (mouse click or key press) to enter edit mode.</param>
		/// <param name="key" type="String" optional="true">Optional.  Used internally to send pressed key to editor when entering
		/// via key press is used.</param>
		
		if (!cell)
			return;
		this._cellEditBlock();
		var me = this;
		setTimeout(function () { me._enterEditMode(cell, key); }, 1);
	},
	_cellEditBlock: function ()
	{
		
		$util._re_may_start = this._now();
	},
	_enterEditMode: function (cell, key)
	{
		var grid = this._grid;
		if (!grid || this._re_cells || !cell || grid._cellInEditMode)
			return;
		
		if (grid.getEditingOn() == 2)
			return;
		
		if (grid._delButtonOwner)
			grid._delButtonOwner.hideButton();
		var mainGrid = this._mainGrid();
		
		this._re_native_ie7 = $util.IsIE && !document.documentMode && $util.MajorIEVersion < 8;
		var ie7 = $util.IsIE && (document.documentMode == 7 || this._re_native_ie7);
		var aGrid = ie7 && mainGrid != grid ? grid._getTopGrid() : null;
		
		if (aGrid && aGrid != grid)
		{
			aGrid = grid;
			for (var i = 0; i < 20; i++)
			{
				aGrid = aGrid.get_parentRow();
				aGrid = aGrid ? aGrid.get_grid() : null;
				var div = aGrid ? aGrid._container : null;
				if (!div)
					break;
				if (div.offsetHeight + 5 < div.scrollHeight || div.offsetWidth + 5 < div.scrollWidth)
				{
					alert('Cannot edit a child grid row located within a scrollable parent container under IE7');
					return;
				}
			}
		}
		var old = mainGrid._re_obj || grid._re_obj;
		if (old)
			old.exitEditMode(true, true, true);
		delete this._re_TR_height;
		delete this.Validators;
		delete this._re_first_tab;
		delete this._re_last_tab;
		this._re_focusCell = cell;
		var index = grid._element.tabIndex;
		this._re_tabIndex = (!index || index < 0) ? 1 : index;
		this._ensureDialog();
		delete this._re_dialogInit;
		var editable, td, val, editor, cells = {}, row = cell.get_row(), first = true;
		var i = -1, count = row.get_cellCount(), evtCells = [];
		while (++i < count)
		{
			cell = row.get_cell(i);
			if (!cell)
				continue;
			index = cell.get_index();
			td = cell._element;
			cells[index] = {cell: cell, val: val = cell.get_value(), index: index, width: td.offsetWidth};
			editable = this._canEdit(cell);
			if (first && editable)
			{
				first = false;
				this._re_TR = td.parentNode;
				this._re_TR_top = td.offsetTop;
			}
			evtCells[evtCells.length] = new $IG.RowEditCell(cell, val, index, this._re_focusCell == cell, editable);
		}
		if (first)
			return;
		val = this.__raiseClientEvent('EnteringEditMode', $IG.EnteringRowEditEventArgs, [evtCells]);
		if (val && val.get_cancel())
			return;
		this._re_evtCells = evtCells;
		this._re_cells = cells;
		grid._re_obj = this;
		if (mainGrid)
			mainGrid._re_obj = this;
		i = -1;
		first = ie7;
		while (++i < evtCells.length)
		{
			this._cellEditBlock();
			cell = evtCells[i];
			
			if (first)
			{
				first = false;
				
				this._re_rel_ie7 = grid._container;
				grid._container.style.position = 'relative';
			}
			if (cell._editable)
				this.__internalEnterEditMode(cell._cell, cell._first ? key : null, this);
		}
		i = -1;
		
		row = row._element.cells;
		first = 99999;
		var count = row ? row.length : 0, last = this._enableDialog ? count : -1;
		while (++i < evtCells.length)
		{
			val = evtCells[i];
			cell = cells[val._index];
			editor = cell ? cell.editor : null;
			if (editor)
			{
				
				cell.cell._blockValue = true;
				val._editor = editor;
				
				if (first > 0 || last < count - 1)
				{
					for (var j = 0; j < count; j++) if (row[j] == cell.cell._element)
					{
						if (j < first)
						{
							first = j;
							this._re_first_tab = editor.get_inputElement();
						}
						if (j > last)
						{
							last = j;
							this._re_last_tab = editor.get_inputElement();
						}
						break;
					}
				}
				if (val._val !== val._old)
				{
					editor.set_value(val._val);
					cell.startVal = cell.curVal = editor.get_value();
				}
			}
		}
		this.__raiseClientEvent('EnteredEditMode', $IG.EnteredRowEditEventArgs, [evtCells]);
		if (!this._re_mdFn)
			this._re_mdFn = Function.createDelegate(this, this._onMouseDown);
		if (!this._re_mdOn)
		{
		    // R.K. 26/07/2016 bug #222479 Different Behavior of RowEditing between IE and Chrome/Firefox/Edge in WebHierarchicalDataGrid
		    // scope it only to Hierarchical grid
		    if (!$util.IsIE && (this._grid._rowIslandIndex != undefined || this._grid.get_band != undefined)) {
                // attach a handler for the capturing phase
		        mainGrid._element.addEventListener('mousedown', this._re_mdFn, true);
		    }
		    $addHandler(mainGrid._element, 'mousedown', this._re_mdOn = this._re_mdFn);
		}
	},
	_ensureDialog: function ()
	{
		if (!this._enableDialog)
			return;
		var but, dialog = this._re_dialog, gridElem = this._grid._element, id = gridElem.id;
		if (!dialog)
			dialog = this._re_dialog = document.getElementById(id + '_re_dialog');
		
		if (dialog)
		{
			dialog._me = this;
			but = dialog.getElementsByTagName('SPAN');
			for (var i = 0; i < but.length; i++)
			{
				// 2-button hover css
				// 3-button focus css
				this._fixCss(but[i], 2);
				this._fixCss(but[i], 3);
			}
			return;
		}
		
		dialog = this._re_dialog = document.createElement('DIV');
		dialog._me = this;
		dialog.id = id + '_re_dialog';
		// 4-dialog css
		this._fixCss(dialog, 4, 1);
		but = document.createElement('SPAN');
		var done = but;
		// 5-button css
		this._fixCss(but, 5, 1);
		// 6-button done css
		this._fixCss(but, 6, 1);
		// 8-"Done"
		but.innerHTML = this._re_props[8];
		but.id = id + '_re_done';
		but.tabIndex = this._re_tabIndex + 1;
		dialog.appendChild(but);
		but = document.createElement('SPAN');
		// 5-button css
		this._fixCss(but, 5, 1);
		// 7-button cancel css
		this._fixCss(but, 7, 1);
		// 9-"Cancel"
		but.innerHTML = this._re_props[9];
		but.id = id + '_re_cancel';
		but.tabIndex = this._re_tabIndex + 1;
		dialog.appendChild(but);
		var find = function(e, id)
		{
			e = e || window.event;
			e = e ? (e.target || e.srcElement) : e;
			while (e)
			{
				if (e == but || e == done)
					return id ? e.id : e;
				e = e.parentNode;
			}
		};
		var me = function () { return dialog._me; };
		dialog.onclick = function(evt)
		{
			evt = evt || window.event;
			if (!evt || !me())
				return;
			$util.cancelEvent(evt);
			id = find(evt, true);
			if (id && id.indexOf('done') > 0)
				me().exitEditMode(true, false, true);
			else if (id && id.indexOf('cancel') > 0)
				me().exitEditMode(false, false, true);
		};
		done.onfocus = but.onfocus = function(evt)
		{
			// 3-button focus css
			if (me())
				me()._fixCss(find(evt), 3, true);
		};
		done.onblur = but.onblur = function(evt)
		{
			// 3-button focus css
			if (me())
				me()._fixCss(find(evt), 3);
		};
		done.onmousemove = but.onmousemove = function(evt)
		{
			// 2-button hover css
			if (me())
				me()._fixCss(find(evt), 2, true);
		};
		done.onmouseout = but.onmouseout = function(evt)
		{
			// 2-button hover css
			if (me())
				me()._fixCss(find(evt), 2);
		};
		done.onkeydown = but.onkeydown = function(evt)
		{
			evt = evt || window.event;
			var key = evt ? evt.keyCode : null;
			if (!key || !me())
				return;
			id = find(evt, true);
			var cancel = id && id.indexOf('cancel') > 0;
			if (key == 27)
				me().exitEditMode(false, false, true);
			if (key == 13 || key == 32)
				me().exitEditMode(!cancel, false, true);
			if (key == 9 && cancel && !evt.shiftKey)
				$util.cancelEvent(evt);
		};
	},
	_onMouseDown: function (e)
	{
		e = e ? e.target : e;
		var id = e ? $util._getXAttr(e) : e;
		
		if (id && id.indexOf(':mkr:') > 0 && (id.indexOf('Scr') > 0 || id.indexOf('vsb') > 0))
			return;
		if (id && id.indexOf(':expColBtn') > 0)
			e = null;
		while (e)
		{
			if (e == this._re_TR || e == this._re_dialog)
				return;
			e = e.parentNode;
		}
		this.exitEditMode(true, false, true);
	},
	_areEqual: function (value1, value2) {
        // Checking equality for primitives and date objects
	    var val1, val2;
        // JD May 11, 2015 TFS 193656 Add in a check for null for value1 and value2
	    val1 = (value1 && value1.getTime) ? value1.getTime() : value1;
	    val2 = (value2 && value2.getTime) ? value2.getTime() : value2;
	    return val1 === val2;
	},
	exitEditMode: function (update, force, canExit)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditing.exitEditMode">
		/// Causes the grid to exit edit mode.
		/// </summary>
		/// <param name="update" optional="true" type="Boolean">Request to update value.</param>
		/// <param name="force" optional="true" type="Boolean">Request to end edit mode regardless of possible block like failed validator or keepEditing set by client event.</param>
		/// <param name="canExit" optional="false" type="Boolean">Value of that parameter must be true, otherwise, edit mode can continue.</param>
		/// <returns type="Boolean" mayBeNull="true">Returns true if exit edit mode was canceled by validator or by setting eventArgs.set_keepEditing(true).</returns>
		var cells = this._re_cells, grid = this._grid;
		if (!cells || !(canExit || force) || this._re_exiting || this._isExitingEditMode && this._now() - this._isExitingEditMode < 100)
		{
			return;
		}
		var val, cell, parent, editor, i = -1, evtCells = this._re_evtCells, keepEditing = false, length = evtCells.length;
		
		while (++i < length)
		{
			cell = evtCells[i];
			editor = cell._editor;
			if (editor && editor._element)
			{
				cell._val = editor.get_value();
				if (update && this._validate(editor, force))
					keepEditing = true;
			}
		}
		if (force && keepEditing) {
		    update = false;
		} else if (update) {
		    // K.D. February 16th, 2015 Bug #188481 isUpdate method always returns true when 'Done' is clicked, even if no changes have been made.
            // Looping through the cells in edit mode to check whether the old values of all match the new ones. If they do the update parameter is false.
		    length = evtCells.length;
		    for (i = 0; i < length; i++) {
		        cell = evtCells[i];
		        if (this._areEqual(cell.get_value(), cell.getOldValue())) {
		            update = false;
		        } else {
		            update = true;
		            break;
		        }
		    }
		}
		val = this.__raiseClientEvent('ExitingEditMode', $IG.ExitingRowEditEventArgs, [evtCells, update, keepEditing]);
		if (val)
		{
			keepEditing = val.get_keepEditing();
			update = val.isUpdate() && !val.get_cancel();
		}
		if (keepEditing && !force)
			return true;
		
		cell = this._re_relative;
		if (cell)
			cell.style.position = '';
		delete this._re_relative;
		cell = this._re_hidden;
		if (cell)
			cell.style.overflow = 'hidden';
		delete this._re_hidden;
		cell = this._re_rel_ie7;
		if (cell)
			cell.style.position = '';
		delete this._re_rel_ie7;
		cell = this._te_div_height;
		if (cell)
			cell.style.height = '';
		delete this._te_div_height;
		this._re_exiting = true;
		cell = this._re_dialog;
		var pool = grid._editorProvidersPool;
		if (cell && pool)
		{
			parent = cell.parentNode;
			$util.display(cell, true);
			
			if (cell.parentNode != pool)
			{
				pool.appendChild(cell);
				if (parent)
					parent.style.zIndex = 0;
			}
			else
				pool.parentNode.style.zIndex = 0;
		}
		i = -1;
		length = evtCells.length;
		while (++i < length)
		{
			val = evtCells[i];
			cell = val ? cells[val._index] : null;
			if (!cell || !cell.cell)
				continue;
			
			delete cell.cell._blockValue;
			var elem = cell.editor;
			
			keepEditing = this._hideValidator(cell.editor);
			if (elem)
				elem = elem._element;
			if (!cell.cell || !elem || !val._editable)
			{
				cell.newVal = val._val;
				continue;
			}
			delete this._newCellVal;
			
			this._cellInEditMode = cell.cell;
			this._currentEditor = cell.editor;
			elem.className = '';
			cell.oldParent.appendChild(elem);
			// 0-cell css
			this._fixCss(cell.cell._element, 0);
			
			$IG.RowEditing.callBaseMethod(this, 'exitEditMode', [update && !keepEditing, force]);
			
			cell.newVal = this._newCellVal;
			if (cell.newVal !== undefined)
				cell.newTxt = cell.editor.get_text(cell.newVal);
		}
		i = -1;
		length = evtCells.length;
		if (update) while (++i < length)
		{
			val = evtCells[i];
			cell = val ? cells[val._index] : null;
			if (!cell || !cell.cell)
				continue;
			val = cell.newVal;
			if (val !== undefined && val != cell.startVal0)
			{
				if (typeof cell.val == 'boolean' && typeof val != 'boolean')
				{
					if (!val)
						val = cell.val;
					else
					{
						val = val.toString().toLowerCase();
						if (val == 'true')
							val = true;
						else if (val == 'false')
							val = false;
						else
							val = cell.val;
					}
					if (val == cell.val)
						val = cell.startVal0;
				}
				if (val != cell.startVal0)
					cell.cell.set_value(val, cell.newTxt);
			}
		}
		var mainGrid = this._mainGrid();
		delete mainGrid._re_obj;
		delete grid._re_obj;
		delete this._re_exiting;
		delete this._re_cells;
		delete this._re_evtCells;
		delete this._re_fixedC;
		elem = this._re_mdOn ? mainGrid._element : null;
		if (elem)
		{
		    // R.K. 26/07/2016 bug #222479 Different Behavior of RowEditing between IE and Chrome/Firefox/Edge in WebHierarchicalDataGrid
		    // scope it only to Hierarchical grid
		    if (!$util.IsIE && (this._grid._rowIslandIndex != undefined || this._grid.get_band != undefined)) 
            {
		        // remove the handler for the capturing phase
		        mainGrid._element.removeEventListener('mousedown', this._re_mdFn, true);
		    }
		    $removeHandler(elem, 'mousedown', this._re_mdFn);
		}
		delete this._re_mdOn;
		this.__raiseClientEvent('ExitedEditMode', $IG.ExitedRowEditEventArgs, [evtCells, update]);
	},
	_mainGrid: function ()
	{
		var g = this._grid;
		return g && g._get_mainGrid ? g._get_mainGrid() : g;
	},
	_showEditor: function (provider, top, left, width, height, cssClass, holder, cell)
	{
		if (!this._re_TR_height)
		{
			
			var e = cell ? cell._element : null;
			while (e && e != this._grid._element)
			{
				if (e.nodeName == 'DIV')
				{
					if ($util._isXAttrContains(e, ':unfixedDiv:'))
					{
						var heightDIV = e.offsetHeight, heightTD = e.parentNode.offsetHeight;
						if (heightTD > heightDIV + 5)
						{
							height = heightTD;
							e.style.height = heightTD + 'px';
							this._te_div_height = e;
						}
					}
					break;
				}
				e = e.parentNode;
			}
			this._re_TR_height = height - 2;
		}
		// 0-cell css
		this._fixCss(cell._element, 0, true);
		height = this._re_TR_height;
		provider._show(top, left, width, height, cssClass, holder, cell);
	},
	_setBounds: function (provider, cell, height)
	{
		var elem = provider._element, cells = this._re_cells, input = provider.get_inputElement();
		var style = elem.style, obj = cells[cell.get_index()];
		if (obj)
			obj.oldParent = elem.parentNode;
		style.marginTop = style.marginLeft = '';
		if (input)
		{
			input._re_id = cell.get_index();
			input._re_last_ti = null;
			input.tabIndex = this._re_tabIndex;
			if (this._re_focusCell == cell && (!provider._charKey || provider._editor)) setTimeout(function()
			{
				try { provider._focus(input, true); } catch (ex) {}
			}, 0);
		}
		cell = cell._element;
		cell.insertBefore(elem, cell.firstChild);
		// 1-container css
		elem.className = this._re_props[1];
		
		
		if (this._re_rel_ie7 && !provider._onSpanEvt && !provider._onInternalDropDownOpening && !(provider._editor && provider._editor._element.nodeName == 'TABLE'))
		{
			var margin = parseInt($util.getStyleValue(null, 'marginLeft', elem));
			if (!isNaN(margin) && margin < -1)
			{
				margin = Math.floor(margin / 2);
				elem.style.marginLeft = margin + 'px';
				if (this._re_native_ie7)
				{
					var input = provider.get_inputElement();
					if (input)
						input.style.marginTop = margin + 'px';
				}
			}
		}
		obj = this._re_dialog;
		
		if (!obj || this._re_dialogInit)
			return;
		this._re_dialogInit = true;
		$util.display(obj);
		var pool = this._usePool(cell);
		if (pool)
		{
			
			pool.parentNode.style.zIndex = 1001;
			elem = pool;
		}
		if (obj.parentNode != elem)
			elem.insertBefore(obj, elem.firstChild);
		this._fixDialogPos(height);
	},
	_usePool: function (e)
	{
		var height = e.offsetHeight + 30, grid = this._grid, pool = grid._editorProvidersPool;
		if (!pool)
			return;
		
		if (grid._container.offsetHeight < height)
		{
			
			e = grid._get_level && grid._get_level() ? pool : null;
			while (e && e.nodeName != 'TABLE')
				e = e.parentNode;
			
			
			if ($util._isXAttrContains(e, 'mkr:contentTbl'))
			{
				this._re_relative = e;
				e.style.position = 'relative';
				
				e = grid._element;
				if (e && e.style.overflow == 'hidden')
				{
					this._re_hidden = e;
					e.style.overflow = 'visible';
				}
			}
			return pool;
		}
		
		while (e && e != grid._element)
		{
			if (e.nodeName == 'DIV' && $util._isXAttrContains(e, ':unfixedDiv:'))
			{
				
				if (e.offsetHeight > height)
					return;
				this._re_fixedC = true;
				this._re_TR_top = e.parentNode.offsetTop;
				return pool;
			}
			e = e.parentNode;
		}
	},
	_onKeydownHandler: function (evt)
	{
		var src = evt.target, id = src ? src._re_id : null, cells = this._re_cells;
		var cell = (id != null && cells != null) ? cells[id] : null;
		if (cell)
		{
			var key = evt.keyCode;
			
			if (key == 9 && ((src == this._re_first_tab && evt.shiftKey) || (!evt.shiftKey && src == this._re_last_tab)))
				$util.cancelEvent(evt);
			else if (key == 13)
			{
			    // N.R. August 17, 2015 Bug #204817: When use MultiLine textEditor and RowEditing and press Enter key, this key is not set to the editor
			    // When exitEditMode event is canceled key down event should not be.
				var cancelEv = !this.exitEditMode(true, false, true);
				if (cancelEv)
				    $util.cancelEvent(evt);
			}
			else if (key == 27)
			{
				$util.cancelEvent(evt);
				if (cell.curVal == cell.startVal)
					this.exitEditMode(false, false, true);
				else
					cell.editor.set_value(cell.curVal = cell.startVal);
			}
			else if (cell.editor)
				setTimeout(function() { cell.curVal = cell.editor.get_value(); }, 20);
		}
		$IG.RowEditing.callBaseMethod(this, '_onKeydownHandler', [evt]);
	},
	
	_get_mLeft: function (grid)
	{
		var div, par, scrollLeft, left = 0, i = -1, parents = this._re_hg_parents;
		
		if (!parents)
		{
			parents = this._re_hg_parents = [];
			while (i++ < 100)
			{
				grid = grid.get_parentRow();
				if (!grid)
					break;
				grid = grid.get_grid();
				div = grid ? grid._container : null;
				if (!div)
					break;
				parents[i] = { div: div, hScroll: grid._hScrBar };
			}
		}
		i = parents.length;
		var left = 0;
		
		while (i-- > 0)
		{
			par = parents[i];
			scrollLeft = par.useHScroll ? 0 : par.div.scrollLeft;
			
			if (!par.useHScroll && scrollLeft && par.hScroll && par.hScroll.offsetWidth)
				par.useHScroll = true;
			if (par.useHScroll)
				scrollLeft = par.hScroll.scrollLeft;
			left += scrollLeft;
		}
		return left;
	},
	
	
	_fixDialogPos: function (rowHeight, delay)
	{
		var grid = this._grid, dialog = this._re_dialog;
		if (!grid || !dialog)
			return;
		var elem = grid._container,
			
			gWidth = Math.min(elem.clientWidth, this._re_TR.offsetWidth),
			
			left = elem.scrollLeft,
			hScroll = grid._hScrBar,
			
			fixedCol = this._re_fixedC,
			
			trTop = this._re_TR_top,
			top = (rowHeight || fixedCol) ? elem.scrollTop : 0,
			
			gHeight = elem.clientHeight,
			dHeight = dialog.offsetHeight,
			
			m_grid = grid._getTopGrid(),
			m_elem = m_grid && m_grid != grid ? m_grid._container : null,
			m_gWidth = m_elem ? m_elem.offsetWidth : 0,
			m_left = m_elem ? this._get_mLeft(grid) : 0;
		if (fixedCol)
			trTop -= top;
		if (!this._re_useHScroll && left && left > 1 && hScroll && hScroll.offsetWidth)
			this._re_useHScroll = true;
		if (this._re_useHScroll)
			left = hScroll.scrollLeft;
		if (!rowHeight && this._re_gWidth == gWidth && this._re_gLeft == left && this._re_m_gWidth == m_gWidth && this._re_m_gLeft == m_left)
		{
			if (fixedCol && !delay)
			{
				var me = this;
				setTimeout(function()
				{
					try
					{
						me._fixDialogPos(null, true);
					} catch (ex){}
				}, 200);
			}
			if (this._re_gTop == trTop)
				return;
		}
		
		if (!rowHeight && (this._re_gWidth != gWidth || this._re_m_gWidth != m_gWidth))
		{
			var key, e, cells = this._re_cells;
			for (key in cells)
			{
				cell = cells[key];
				e = cell.cell ? cell.cell._element : null;
				
				if (e && e.offsetWidth != cell.width)
					return this.exitEditMode(false, true, true);
			}
		}
		
		this._re_gWidth = gWidth;
		
		this._re_gLeft = left;
		
		this._re_m_gWidth = m_gWidth;
		
		this._re_m_gLeft = m_left;
		this._re_gTop = trTop;
		
		if (rowHeight)
		{
			
			dialog.style.marginTop = (rowHeight + 2) + 'px';
			dialog.style.marginLeft = '';
			
			var validatorPos, xyElem = $util.getPosition(elem), xyDlg = $util.getPosition(dialog), xyMElem = m_gWidth ? $util.getPosition(m_elem) : null;
			
			this._re_leftShift = xyElem.x - xyDlg.x - dialog.offsetWidth - 10;
			
			if (fixedCol)
			{
				
				this._re_topShift = rowHeight + 2;
				top = trTop + this._re_topShift;
				if (top + dHeight > gHeight && top + dHeight - gHeight > dHeight - trTop)
					
					validatorPos = this._re_topShift = -dHeight - 1;
			}
			
			
			
			
			
			else if ((trTop > rowHeight || this._re_hidden) && (dHeight + rowHeight - top + trTop > gHeight || (xyMElem && xyMElem.y + m_elem.offsetHeight + m_elem.scrollTop < xyDlg.y + dialog.offsetHeight * 0.7)))
				
				validatorPos = dialog.style.marginTop = (-dHeight - 1) + 'px';
			
			this._validatorPos = (validatorPos ? 2 : 1) * (fixedCol ? -1 : 1);
			if (m_gWidth)
			{
				
				this._re_leftShift -= xyElem.x - xyMElem.x;
			}
		}
		if (fixedCol)
			dialog.style.marginTop = Math.min(Math.max(this._re_topShift + trTop, -dHeight - 2), gHeight + 2) + 'px';
		left = this._re_leftShift + gWidth + left;
		
		if (m_gWidth)
			
			left += Math.min(m_left - gWidth + m_gWidth, (grid._level || 0) * 10);
		dialog.style.marginLeft = left + 'px';
	},
	_onGridStopEditing: function (args)
	{
		if (!this._re_cells)
			return $IG.RowEditing.callBaseMethod(this, '_onGridStopEditing', [args]);
		this._fixDialogPos();
	},
	
	__enterEditFilter: function (cell, editor)
	{
		
		delete this._cellInEditMode;
		delete this._currentEditor;
		delete this._grid._cellInEditMode;
		
		cell = this._re_cells ? this._re_cells[cell.get_index()] : null;
		if (cell)
		{
			cell.editor = editor;
			cell.startVal = cell.startVal0 = cell.curVal = editor.get_value();
		}
	},
	dispose: function()
	{
		///<summary locid="M:J#Infragistics.Web.UI.RowEditing.dispose">
		/// For internal use.
		///</summary>
		var elem = this._mainGrid();
		if (elem)
			elem = elem._element;
		if (elem)
			this.exitEditMode(true, true, true);
		if (this._re_mdOn && elem)
			$removeHandler(elem, 'mousedown', this._re_mdFn);
		elem = this._re_dialog;
		if (elem)
			elem._me = null;
		delete this._re_hg_parents;
		delete this._re_dialog;
		delete this._re_mdOn;
		var i = this._editors ? this._editors.length : 0;
		while (i-- > 0)
			this._editors[i].dispose();
		delete this._editors;
		$IG.RowEditing.callBaseMethod(this, 'dispose');
	}
}
$IG.RowEditing.registerClass('Infragistics.Web.UI.RowEditing', $IG.GridEditBase, $IG.IUpdatingBehavior);

$IG.EnteringRowEditEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EnteringRowEditEventArgs">
	/// Event arguments object that is passed into the EnteringEditMode event used by RowEditing.
	/// </summary>
	$IG.EnteringRowEditEventArgs.initializeBase(this);
	this._cells = params[0];
	this._props[0] = $util._browser_evt;
}
$IG.EnteringRowEditEventArgs.prototype =
{
	getCells: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CancelRowEditEventArgs.getCell">
		/// Returns cells entered row edit mode.
		/// </summary>
		/// <returns type="Array">Array of Infragistics.Web.UI.RowEditCell objects</returns>
		return this._cells;
	}
}
$IG.EnteringRowEditEventArgs.registerClass('Infragistics.Web.UI.EnteringRowEditEventArgs', $IG.CancelEventArgs);

$IG.ExitingRowEditEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ExitingRowEditEventArgs">
	/// Event arguments object that is passed into ExitingEditMode and ExitedEditMode event handler used by RowEditing.
	/// </summary>
	$IG.ExitingRowEditEventArgs.initializeBase(this, [params]);
	this._update = params[1];
	this._keepEditing = params[2];
}
$IG.ExitingRowEditEventArgs.prototype =
{
	isUpdate: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ExitingRowEditEventArgs.isUpdate">
		/// Check if data will be update after row editing.
		///</summary>
		/// <returns type="Boolean">Returns true when row data should be updated after exiting row edit mode</returns>
		return this._update;
	},
	set_keepEditing: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.ExitingRowEditEventArgs.set_keepEditing">
		/// Set request to continue or stop row editing.
		///</summary>
		///<param name="value" type="Boolean">Value true will continue row editing, false will stop row editing regardless of possible failed cell-value validation</param>
		this._keepEditing = value;
	},
	get_keepEditing: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ExitingRowEditEventArgs.get_keepEditing">
		/// Request to continue or stop row editing.
		///</summary>
		///<value type="Boolean">Value true will continue row editing, false will stop row editing regardless of possible failed cell-value validation</value>
		return this._keepEditing;
	}
}
$IG.ExitingRowEditEventArgs.registerClass('Infragistics.Web.UI.ExitingRowEditEventArgs', $IG.EnteringRowEditEventArgs);


$IG.EnteredRowEditEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.EnteredRowEditEventArgs">
	/// Event arguments object that is passed into the EnteredEditMode and ExitedEditMode event handlers.
	/// </summary>
	$IG.EnteredRowEditEventArgs.initializeBase(this);
	this._cells = params[0];
	this._props[0] = $util._browser_evt;
}
$IG.EnteredRowEditEventArgs.prototype =
{
	getCells: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.EnteredRowEditEventArgs.getCells">
		/// Returns cells entered row edit mode.
		/// </summary>
		/// <returns type="Array">Array of Infragistics.Web.UI.RowEditCell objects</returns>
		return this._cells;
	}
}
$IG.EnteredRowEditEventArgs.registerClass('Infragistics.Web.UI.EnteredRowEditEventArgs', $IG.EventArgs);

$IG.ExitedRowEditEventArgs = function (params)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ExitedRowEditEventArgs">
	/// Event arguments object that is passed into ExitingEditMode and ExitedEditMode event handler used by RowEditing.
	/// </summary>
	$IG.ExitedRowEditEventArgs.initializeBase(this, [params]);
	this._update = params[1];
}
$IG.ExitedRowEditEventArgs.prototype =
{
	isUpdate: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.ExitedRowEditEventArgs.isUpdate">
		/// Update after row editing.
		///</summary>
		/// <returns type="Boolean">Returns true when row data should be updated after exiting row edit mode</returns>
		return this._update;
	}
}
$IG.ExitedRowEditEventArgs.registerClass('Infragistics.Web.UI.ExitedRowEditEventArgs', $IG.EnteredRowEditEventArgs);

$IG.RowEditCell = function (cell, val, index, first, editable)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowEditCell">
	/// Object used for items in getCells() method of editing events.
	/// </summary>
	this._cell = cell;
	this._old = val;
	this._val = val;
	this._index = index;
	this._first = first;
	this._editable = editable;
}
$IG.RowEditCell.prototype =
{
	getCell: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.getCell">
		/// Returns reference to Infragistics.Web.UI.GridCell that has entered edit mode.
		/// </summary>
		/// <returns type="Infragistics.Web.UI.GridCell"></returns>
		return this._cell;
	},
	get_value: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.get_value">
		/// Returns new value.
		/// </summary>
		///<value type="Object" mayBeNull="true">New value</value>
		return this._val;
	},
	set_value: function (value)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.get_value">
		/// Sets new value.
		/// </summary>
		/// <param name="value">New value</param>
		this._val = value;
		if (this._editor)
			this._editor.set_value(value);
	},
	getOldValue: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.getOldValue">
		/// Returns new value.
		/// </summary>
		/// <returns>Old value</returns>
		return this._old;
	},
	isFirst: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.isFirst">
		/// Checks for first editing cell.
		/// </summary>
		/// <returns>True if row-editing was started on that cell</returns>
		return !!this._first;
	},
	isReadOnly: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.isReadOnly">
		/// Checks if cell is editable.
		/// </summary>
		/// <returns>True if cell is editable</returns>
		return !this._editable;
	},
	setReadOnly: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.setReadOnly">
		/// Disables editing.
		/// </summary>
		this._editable = false;
	},
	getEditor: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowEditCell.getEditor">
		/// Returns the reference to html element or javascript object which is used as editor. That is available after edit mode was started.
		/// </summary>
		/// <returns mayBeNull="true">Reference to editor or INPUT or null</returns>
		var e = this._editor;
		return e ? (e._editor || e._input) : null;
	}
}
$IG.RowEditCell.registerClass('Infragistics.Web.UI.RowEditCell');

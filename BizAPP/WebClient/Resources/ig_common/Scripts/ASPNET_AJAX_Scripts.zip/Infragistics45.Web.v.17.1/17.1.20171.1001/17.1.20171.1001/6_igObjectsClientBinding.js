/*
* 6_igObjectsClientBinding.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/




$IG.ClientBindingDataContext = function (obj, element, props, control, mkrAttribute)
{
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;
	$IG.ClientBindingDataContext.initializeBase(this, [obj, element, props, control, csm]);
	//this._mkrAttribute = mkrAttribute;
}

$IG.ClientBindingDataContext.prototype =
{
	get_serviceUri: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.serviceUri">
		/// Web Service Uri
		///</summary>
		return this._get_value($IG.ClientBindingDataContextProps.ServiceUri);
	},

	set_serviceUri: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.serviceUri">
		/// Web Service Uri
		///</summary>
		this._set_value($IG.ClientBindingDataContextProps.ServiceUri, value);
	},

	get_operationName: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.operationName">
		/// Web Service Operation Name
		///</summary>
		return this._get_value($IG.ClientBindingDataContextProps.OperationName);
	},

	set_operationName: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.operationName">
		/// Sets Web Service Operation Name
		///</summary>
		this._set_value($IG.ClientBindingDataContextProps.OperationName, value);
	},

	get_enableAutoFetch: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.enableAutoFetch">
		/// AutoFetch data context parameter 
		///</summary>
		return this._get_value($IG.ClientBindingDataContextProps.EnableAutoFetch);
	},

	set_enableAutoFetch: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.enableAutoFetch">
		/// Auto Fetch data context parameter 
		///</summary>
		this._set_value($IG.ClientBindingDataContextProps.EnableAutoFetch, value);
	},

	get_fetchParameters: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.fetchParameters">
		/// Fetch Parameters  
		///</summary>
		return this._get_value($IG.ClientBindingDataContextProps.FetchParameters);
	},

	set_fetchParameters: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.fetchParameters">
		/// Fetch Parameters  
		///</summary>
		this._set_value($IG.ClientBindingDataContextProps.FetchParameters, value);
	}

}
$IG.ClientBindingDataContext.registerClass('Infragistics.Web.UI.ClientBindingDataContext', $IG.ObjectBase);



$IG.ClientBindingDataContextProps = new function ()
{
	this.ServiceUri = [$IG.ControlObjectProps.Count + 0, ""];
	this.OperationName = [$IG.ControlObjectProps.Count + 1, ""];
	this.AutoFetch = [$IG.ControlObjectProps.Count + 2, true];
	this.FetchParameters = [$IG.ControlObjectProps.Count + 3, ""];
	this.Count = $IG.ControlObjectProps.Count + 4;
};

$IG.ClientDataBinding = function (obj, element, props, control, mkrAttribute)
{
	var csm = obj ? new $IG.ObjectClientStateManager(props[0]) : null;
	$IG.ClientDataBinding.initializeBase(this, [obj, element, props, control, csm]);
	//this._mkrAttribute = mkrAttribute;
}

$IG.ClientDataBinding.prototype =
{
	get_fieldName: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.fieldName">
		/// FieldName
		///</summary>
		return this._get_value($IG.ClientDataBindingProps.FieldName);
	},

	set_fieldName: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.fieldName">
		/// FieldName
		///</summary>
		this._set_value($IG.ClientDataBindingProps.FieldName, value);
	},

	get_bindingType: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.bindingType">
		/// BindingType
		///</summary>
		return this._get_value($IG.ClientDataBindingProps.BindingType);
	},

	set_bindingType: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.bindingType">
		/// BindingType
		///</summary>
		this._set_value($IG.ClientDataBindingProps.BindingType, value);
	},

	get_converterFunction: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.converterFunction">
		/// Converter Function 
		///</summary>
		return this._get_value($IG.ClientDataBindingProps.ConverterFunction);
	},

	set_converterFunction: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.converterFunction">
		/// Converter Function
		///</summary>
		this._set_value($IG.ClientDataBindingProps.ConverterFunction, value);
	},

	get_expressionString: function ()
	{
		///<summary locid="P:J#Infragistics.Web.UI.expressionString">
		/// Expression String 
		///</summary>
		return this._get_value($IG.ClientDataBindingProps.ExpressionString);
	},

	set_expressionString: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.expressionString">
		/// Expression String
		///</summary>
		this._set_value($IG.ClientDataBindingProps.ExpressionString, value);
	}

}
$IG.ClientDataBinding.registerClass('Infragistics.Web.UI.ClientDataBinding', $IG.ObjectBase);



$IG.ClientDataBindingProps = new function ()
{
	this.FieldName = [$IG.ClientBindingDataContextProps.Count + 0, ""];
	this.BindingType = [$IG.ClientBindingDataContextProps.Count + 1, 0];
	this.ConverterFunction = [$IG.ClientBindingDataContextProps.Count + 2, ""];
	this.ExpressionString = [$IG.ClientBindingDataContextProps.Count + 3, ""];
	this.Count = $IG.ClientBindingDataContextProps.Count + 4;
};

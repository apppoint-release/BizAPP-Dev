/*
* igWebDataGridSummaryRow.js
* Version 17.1.20171.1001
* Copyright(c) 2001-2017 Infragistics, Inc. All Rights Reserved.
*/



$IG.SummaryRow = function (obj, objProps, control, parentCollection, hierarchical)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow">
	/// Summary row behavior object of the grid.
	/// </summary>

	$IG.SummaryRow.initializeBase(this, [obj, objProps, control, parentCollection]);

	this._grid = this._owner;
	this._hierarchical = hierarchical;

	this._sumDDItemCss = this._get_clientOnlyValue("srri");
	this._checkedUrl = this._get_clientOnlyValue("srcc");
	this._uncheckedUrl = this._get_clientOnlyValue("srcu");
	this._checkedTooltipEnd = this._get_clientOnlyValue("srct");
	this._uncheckedTooltipEnd = this._get_clientOnlyValue("srut");

	this._sumNames = this._get_clientOnlyValue("srsn").split('|');
	this._maxSumCount = parseInt(this._get_clientOnlyValue("srmaxsumc"));

	this._sumButtons = control._elements["sumBtn"];
	if (this._sumButtons && !this._sumButtons.length)
	{
		var sumBtn = this._sumButtons;
		this._sumButtons = [];
		this._sumButtons[0] = sumBtn;
	}
	this._sumButtonsObjs = [];

	this._dropDownBehaviors = [];
	this._dropDownBehaviorsCount = 0;

	var gridId = this._grid._id;
	var dropDownUl = $get(gridId + "_SummaryDropDown_UL");
	if (dropDownUl)
	{
		this._onMouseDownSumItemHandler = Function.createDelegate(this, this._onMouseDownSumItem);
		$addHandler(dropDownUl, 'mousedown', this._onMouseDownSumItemHandler);
		this._onTouchStartSumItemHandler = Function.createDelegate(this, this._onTouchStartSumItem);
		this._onTouchEndSumItemHandler = Function.createDelegate(this, this._onTouchEndSumItem);
		if (window.navigator.pointerEnabled && window.navigator.maxTouchPoints > 0)
		{
			$addHandler(dropDownUl, 'pointerdown', this._onTouchStartSumItemHandler);
			$addHandler(dropDownUl, 'pointerup', this._onTouchEndSumItemHandler);
		}
		else if (window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0)
		{
			$addHandler(dropDownUl, 'MSPointerDown', this._onTouchStartSumItemHandler);
			$addHandler(dropDownUl, 'MSPointerUp', this._onTouchEndSumItemHandler);
		}
		else
		{
			$addHandler(dropDownUl, 'touchstart', this._onTouchStartSumItemHandler);
			$addHandler(dropDownUl, 'touchend', this._onTouchEndSumItemHandler);
		}
		this._onKeyDownSumItemHandler = Function.createDelegate(this, this._onKeyDownSumItem);
		$addHandler(dropDownUl, 'keydown', this._onKeyDownSumItemHandler);
		if ($util.IsOpera)
		{
			
			this._onKeyPressSumItemHandler = Function.createDelegate(this, this._onKeyPressSumItem);
			$addHandler(dropDownUl, 'keypress', this._onKeyPressSumItemHandler);
		}

		this._okBtnClickHandler = Function.createDelegate(this, this._onOkBtnClick);
		$addHandler($get(gridId + "_SummaryDropDown_okBtn"), 'click', this._okBtnClickHandler);
		this._cancelBtnClickHandler = Function.createDelegate(this, this._onCancelBtnClick);
		$addHandler($get(gridId + "_SummaryDropDown_cancelBtn"), 'click', this._cancelBtnClickHandler);
	}

	this._onImgMouseOverHandler = Function.createDelegate(this, this._onImgMouseOver);
	this._onImgMouseOutHandler = Function.createDelegate(this, this._onImgMouseOut);
	this._onImgMouseDownHandler = Function.createDelegate(this, this._onImgMouseDown);
	this._onImgMouseClickHandler = Function.createDelegate(this, this._onImgMouseClick);
	this._onBtnKeyDownHandler = Function.createDelegate(this, this._onBtnKeyDown);
	this._onBtnFocusHandler = Function.createDelegate(this, this._onBtnFocus);
	if ($util.IsOpera)
		this._onBtnKeyPressHandler = Function.createDelegate(this, this._onBtnKeyPress);
	var btnCnt = this._sumButtons && this._sumButtons.length ? this._sumButtons.length : 0;
	for (var i = 0; i < btnCnt; i++)
	{
		var sumBtn = this._sumButtons[i];
		var sumImg = sumBtn.firstChild;
		if ($util.IsFireFox || $util.IsOpera)
		{
			$addHandler(sumBtn, 'mouseover', this._onImgMouseOverHandler);
			$addHandler(sumBtn, 'mouseout', this._onImgMouseOutHandler);
		}
		else
		{			
			$addHandler(sumImg, 'mouseover', this._onImgMouseOverHandler);
			$addHandler(sumImg, 'mouseout', this._onImgMouseOutHandler);
		}
		$addHandler(sumBtn, 'mousedown', this._onImgMouseDownHandler);
		$addHandler(sumBtn, 'click', this._onImgMouseClickHandler);
		$addHandler(sumBtn, 'keydown', this._onBtnKeyDownHandler);
		if ($util.IsOpera)
			$addHandler(sumBtn, 'keypress', this._onBtnKeyPressHandler);
		$addHandler(sumBtn, 'focus', this._onBtnFocusHandler);
	}

	this._onHidingColumnHandler = Function.createDelegate(this, this._onHidingColumn);
	this._grid._gridUtil._registerEventListener(this._grid, "HidingColumn", this._onHidingColumnHandler);

	this._onMouseDownHandler = Function.createDelegate(this, this._onMouseDown);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);

	this._onMouseUpHandler = Function.createDelegate(this, this._onMouseUp);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);

	this._onMousewheelHandler = Function.createDelegate(this, this._onMousewheel);
	$addHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
	// for FF
	if ($util.IsFireFox)
		$addHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
	
	this._onScrollTopChangeHandler = Function.createDelegate(this, this._onScrollTopChange);
	this._grid._gridUtil._registerEventListener(this._grid, "ScrollTopChange", this._onScrollTopChangeHandler);
	
	if ($util.IsIE6 || $util.IsIE7 || $util.IsIE8)
	{
		this._onScrollLeftChangeHandler = Function.createDelegate(this, this._onScrollLeftChange);
		this._grid._gridUtil._registerEventListener(this._grid, "ScrollLeftChange", this._onScrollLeftChangeHandler);
	}
	

	this._recordCount = this._get_clientOnlyValue("srrecnum");
}

$IG.SummaryRow.prototype =
{
	get_animationEnabled: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_animationEnabled">
		/// Indicates whether the summary dropdown will play an animation while it is displaying and hiding
		/// </summary>
		/// <value type="Boolean">True if an animation will play, false otherwise</value>
		return this._get_clientOnlyValue("srae");
	},

	get_animationType: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_animationType">
		/// The type of animation that the summary dropdown will play when it is displaying and hiding.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AnimationEquationType">The animation type</value>
		return this._get_clientOnlyValue("srat");
	},

	get_animationDurationMs: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_animationDurationMs">
		/// The duration of the animation that the summary dropdown will play while its displaying or hiding 
		/// in milliseconds
		/// </summary>
		/// <value type="Number" integer="true">Animation duration in milliseconds</value>
		return this._get_clientOnlyValue("srad");
	},

	get_showSummariesButtons: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_showSummariesButtons">
		/// Get whether the summary buttons are shown in the header.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("srsb");
	},

	get_summaryDropdownZIndex: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_summaryDropdownZIndex">
		/// Retruns the Z-Index of the summary dropdown element.  The default Z-Index is 100100
		/// </summary>
		/// <value type="Number" integer="true">Z-Index of the summary dropdown element.</value>
		return this._get_value($IG.GridSummaryRowProps.SummaryDropdownZIndex);
	},

	set_summaryDropdownZIndex: function (value)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.set_summaryDropdownZIndex">
		/// Sets the Z-Index of the summary dropdown element.
		/// </summary>
		///<param name="value" type="Number" integer="true" optional="false" mayBeNull="false">
		/// Z-Index of the summary dropdown element.
		///</param>

		if (value == null || value == undefined)
			return;

		this._set_value($IG.GridSummaryRowProps.SummaryDropdownZIndex, value);

		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
				this._dropDownBehaviors[i].set_zIndex(value);
		}
	},

	
	get_columnSettings: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSettings">
		/// Gets the column summaries settings collection
		/// </summary>
		/// <value type="Infragistics.Web.UI.ObjectCollection">column summaries settings collection </value>
		return this._columnSettings;
	},
	

	

	get_columnSetting: function (index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSetting">
		/// Gets the column summary setting object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.SummaryRowSettings">The summary row column setting at the specified index</value>
		if (index >= 0 && index < this._columnSettings._items.length)
			return this._columnSettings._items[index];
		else
			return null;
	},

	get_columnSettingFromKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSettingFromKey">
		/// Gets the column summary setting object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the summary row column setting is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.SummaryRowSettings">The summary row column setting tied to the specified column key</value>

		for (var i = 0; i < this._columnSettings._items.length; i++)
		{
			if (this._columnSettings._items[i].get_columnKey() === columnKey)
				return this._columnSettings._items[i];
		}

		return null;
	},
	

	
	get_columnSummaryInfoCount: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSummaryInfoCount">
		/// Gets the number of ColumnSummaryInfo objects that currently exist.
		/// </summary>
		/// <value type="Integer">The number of ColumnSummaryInfo objects that currently exist</value>

		if (this._columnSummaries)
			return this._columnSummaries.length;
		return 0;
	},

	get_columnSummaryInfo: function (index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSummaryInfo">
		/// Gets the ColumnSummaryInfo object at the specified index.
		/// </summary>
		///<param name="index" type="Number"  optional="false" mayBeNull="false">
		/// Zero based index
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnSummaryInfo">The ColumnSummaryInfo at the specified index</value>
		if (index >= 0 && index < this._columnSummaries.length)
			return this._columnSummaries[index];
		return null;
	},

	get_columnSummaryInfoFromKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.get_columnSummaryInfoFromKey">
		/// Gets the ColumnSummaryInfo object that is tied to the column with the specified column key.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the ColumnSummaryInfo is tied to.
		///</param>
		/// <value type="Infragistics.Web.UI.ColumnSummaryInfo">The ColumnSummaryInfo tied to the specified column key</value>

		for (var i = 0; i < this._columnSummaries.length; i++)
		{
			if (this._columnSummaries[i].get_columnKey() === columnKey)
				return this._columnSummaries[i];
		}

		return null;
	},

	get_columnSummaryInfoIndexOf: function (columnSummary)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.SummaryRow.columnSummaryIndexOf">
		/// Gets the index of the specified column summary in the column summaries array
		/// </summary>
		///<param name="columnSummary" type="Infragistics.Web.UI.ColumnSummaryInfo"  optional="false" mayBeNull="false">
		/// The column summary whose index to look for.
		///</param>
		///<value type="Number" > Zero based index </value>

		for (var i = 0; i < this._columnSummaries.length; i++)
		{
			if (this._columnSummaries[i] === columnSummary)
				return i;
		}

		return -1;
	},

	containsColumnSummaryInfo: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.containsColumnSummaryInfo">
		/// Determines whether a column summary object that is tied to the column with the specified column key
		/// is in the column summaries array.
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column summary is tied to.
		///</param>
		/// <returns type="Boolean">Boolean value indicating whether the column summary currently 
		/// exists in the column summaries array </returns>

		for (var i = 0; i < this._columnSummaries.length; i++)
		{
			if (this._columnSummaries[i].get_columnKey() === columnKey)
				return true;
		}
		return false;
	},

	create_columnSummaryInfo: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.create_columnSummary">
		/// Creates a column summary info object. Viewstate will not be preserved for this object
		/// until it is added to the column summaries' collection
		/// </summary>
		/// <param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column summary will be tied to.
		/// </param>
		/// <returns type="Infragistics.Web.UI.ClientColumnSummaryInfo">Newly created column summary </returns>

		var column = this._grid.get_columns().get_columnFromKey(columnKey);
		
		if (!column)
			return null;

		return new $IG.ClientColumnSummaryInfo(columnKey);
	},


	addColumnSummaryInfo: function (columnSummary)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.add_columnSummary">
		/// Adds the column summary object to the column summaries' collection
		/// </summary>
		///<param name="columnSummary" type="Infragistics.Web.UI.ClientColumnSummaryInfo"  optional="false" mayBeNull="false">
		/// The column summary which to add to the collection this should be created via create_columnSummary
		/// method.
		///</param>

		var columnKey = columnSummary.get_columnKey();
		if (!this.containsColumnSummaryInfo(columnKey))
		{
			var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.SummaryAction("AddSum", this.get_name(), this._grid, columnKey, columnSummary._get_sumsAsValTxtArray()));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},

	addColumnSummaryInfoRange: function (columnSummarys)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.add_columnSummaryRange">
		/// Adds the column summary objects to the column summaries' collection
		/// </summary>
		///<param name="columnSummarys" type="Array" elementType="Infragistics.Web.UI.ClientColumnSummaryInfo" optional="false" mayBeNull="false">
		/// The column summaries which to add to the collection.
		///</param>
		if (columnSummarys)
		{
			var sumsCount = columnSummarys.length;
			var keys = [];
			var sums = [];
			for (var x = 0; x < sumsCount; ++x)
			{
				var colSum = columnSummarys[x];
				if (colSum)
				{
					keys[x] = colSum.get_columnKey();
					sums[x] = colSum._get_sumsAsValTxtArray()
				}
			}
			this._grid._actionList.add_transaction(new $IG.SummaryAction("AddRange", this.get_name(), this._grid, keys, sums));
			var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this);
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},

	removeColumnSummaryInfo: function (columnSummary)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.removeColumnSummaryInfo">
		/// Deletes the column summary from the column summaries array
		/// </summary>
		///<param name="columnSummary" type="Infragistics.Web.UI.ColumnSummaryInfo"  optional="false" mayBeNull="false">
		/// The column summary to delete
		///</param>
		this.removeColumnSummaryInfoByKey(columnSummary.get_columnKey());
	},

	removeColumnSummaryInfoByKey: function (columnKey)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.removeColumnSummaryInfoByKey">
		/// Deletes the column summary that is tied to the specified column key
		/// from the column summaries array
		/// </summary>
		///<param name="columnKey" type="String"  optional="false" mayBeNull="false">
		/// The column key of the column that the column summary is tied to.
		///</param>

		var colSum = this.get_columnSummaryInfoFromKey(columnKey);
		if (!colSum)
			return;

		var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this);
		var sums = colSum._get_sumsAsValTxtArray();
		this._grid._actionList.add_transaction(new $IG.SummaryAction("RemoveSum", this.get_name(), this._grid, columnKey, sums));
		this._grid._raiseClientEventEnd(eventArgs);
	},

	clearColumnSummaries: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.clearColumnSummaryInfos">
		/// Deletes all column summary info objects from the column summaries array
		/// </summary>

		if (this._columnSummaries.length > 0)
		{
			var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this);
			this._grid._actionList.add_transaction(new $IG.SummaryAction("ClearColumnSummaries", this.get_name(), this._grid, null, null));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},

	

	_initializeComplete: function ()
	{
		$IG.SummaryRow.callBaseMethod(this, "_initializeComplete");

		this._cellValueChangedListener = Function.createDelegate(this, this._cellValueChanged);
		this._grid._gridUtil._registerEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
		this._rowAddedBatchListener = Function.createDelegate(this, this._rowAddedBatch);
		this._grid._gridUtil._registerEventListener(this._grid, "RowAddedBatch", this._rowAddedBatchListener);
		this._rowDeletedBatchListener = Function.createDelegate(this, this._rowDeletedBatch);
		this._grid._gridUtil._registerEventListener(this._grid, "RowDeletedBatch", this._rowDeletedBatchListener);
		this._batchUpdateUndoneListener = Function.createDelegate(this, this._batchUpdateUndone);
		this._grid._gridUtil._registerEventListener(this._grid, "BatchUpdateUndone", this._batchUpdateUndoneListener);

		this._activation = this._grid.get_behaviors().get_activation();
		var btnCount = this._sumButtons ? this._sumButtons.length : 0;
		for (var x = 0; x < btnCount; ++x)
		{
			if (!this._activation)
				this._sumButtons[x].tabIndex = -1;
			else
				this._sumButtons[x].tabIndex = 0;
		}
		
		if (this._activation && this._hierarchical && btnCount > 0)
		{
			this._onPreActiveCellChangingListener = Function.createDelegate(this, this._onPreActiveCellChanging);
			this._grid._gridUtil._registerEventListener(this._activation, "PreActiveCellChanging", this._onPreActiveCellChangingListener);
		}

		
		if (this._clientEvents["SummaryCalculated"] && this._columnSummaries)
		{
			for (var i = 0; i < this._columnSummaries.length; i++)
				this._grid._raiseSenderClientEvent(this, this._clientEvents['SummaryCalculated'], new $IG.SummaryCalculatedArgs(this._columnSummaries[i]));
		}
	},

	_cellValueChanged: function (args)
	{
		var cellValue = args.cell.get_value();
		var oldValue = args.oldValue
		if (cellValue != oldValue)
		{
			var column = args.cell.get_column();
			var columnSummaryInfo = this.get_columnSummaryInfoFromKey(column.get_key());
			if (columnSummaryInfo)
			{
				var minRecal = false;
				var maxRecal = false;
				var sumCount = columnSummaryInfo.get_summaryCount();
				for (var i = 0; i < sumCount; i++)
				{
					var summary = columnSummaryInfo.get_summary(i);
					var sumType = summary.get_summaryType();
					var sumValue = summary.get_value();

					switch (sumType)
					{
						case $IG.SummaryType.Sum:
							sumValue = sumValue - oldValue + cellValue;
							summary.set_value(sumValue);
							break;

						case $IG.SummaryType.Average:
							var recordCount = this._recordCount;
							if (recordCount != 0)
							{
								sumValue = (recordCount * sumValue - oldValue + cellValue) / recordCount;
								summary.set_value(sumValue);
							}
							break;
						case $IG.SummaryType.Min:
							if (cellValue < sumValue)
								summary.set_value(cellValue);
							
							else if (oldValue == sumValue || (oldValue && oldValue.valueOf && sumValue && sumValue.valueOf && oldValue.valueOf() == sumValue.valueOf()))
							{
								var calcArgs = this._clientEvents['CalculateSummary'] ? this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateSummary'], new $IG.CalculateSummaryEventArgs(summary, args.cell, args.oldValue, $IG.RowUpdateType.Edit)) : null;
								minRecal = !calcArgs || calcArgs.get_forceCalculationOnServer();
							}
							break;

						case $IG.SummaryType.Max:
							if (cellValue > sumValue)
								summary.set_value(cellValue);
							
							else if (oldValue == sumValue || (oldValue && oldValue.valueOf && sumValue && sumValue.valueOf && oldValue.valueOf() == sumValue.valueOf()))
							{
								var calcArgs = this._clientEvents['CalculateSummary'] ? this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateSummary'], new $IG.CalculateSummaryEventArgs(summary, args.cell, args.oldValue, $IG.RowUpdateType.Edit)) : null;
								maxRecal = !calcArgs || calcArgs.get_forceCalculationOnServer();
							}
							break;

						case $IG.SummaryType.Custom:
							if (this._clientEvents["CalculateCustomSummary"])
								this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateCustomSummary'], new $IG.CalculateCustomSummaryArgs(summary, args.cell, args.oldValue, $IG.RowUpdateType.Edit));
							break;
					}
				}
				if (minRecal || maxRecal)
				{
					this._grid._actionList.add_transaction(new $IG.SummaryAction("RecalcSummaries", this.get_name(), this._grid, "recalc", null));
					if (!this._grid._enableAjax)
						this._owner._postAction(1);
					else
					{
						


						var eventArgs = new $IG.CancelBehaviorEventArgs(this);
						eventArgs._props[1] = 2;
						this._owner._raiseClientEventEnd(eventArgs);
					}
				}
				
				if (this._clientEvents["SummaryCalculated"])
					this._grid._raiseSenderClientEvent(this, this._clientEvents['SummaryCalculated'], new $IG.SummaryCalculatedArgs(columnSummaryInfo));
			}
		}

	},
	_rowAddedBatch: function (args)
	{
		if (args.row)
		{
			var row = args.row;
			var cellCount = row.get_cellCount();
			this._recordCount += 1;
			for (var x = 0; x < cellCount; ++x)
			{
				var cell = row.get_cell(x);
				var cellValue = cell.get_value();
				var column = cell.get_column();
				var columnSummaryInfo = this.get_columnSummaryInfoFromKey(column.get_key());
				if (columnSummaryInfo)
				{
					var sumCount = columnSummaryInfo.get_summaryCount();
					for (var i = 0; i < sumCount; i++)
					{
						var summary = columnSummaryInfo.get_summary(i);
						var sumType = summary.get_summaryType();
						var sumValue = summary.get_value();
						switch (sumType)
						{
							case $IG.SummaryType.Count:
								summary.set_value(this._recordCount);
								break;
							case $IG.SummaryType.Sum:
								sumValue = this._recordCount > 1 ? sumValue + cellValue : cellValue;
								summary.set_value(sumValue);
								break;

							case $IG.SummaryType.Average:
								var recordCount = this._recordCount;
								if (recordCount != 0)
								{
									sumValue = this._recordCount > 1 ? ((recordCount - 1) * sumValue + cellValue) / recordCount : cellValue;
									summary.set_value(sumValue);
								}
								break;
							case $IG.SummaryType.Min:
								if (cellValue < sumValue || this._recordCount == 1)
									summary.set_value(cellValue);
								break;

							case $IG.SummaryType.Max:
								if (cellValue > sumValue || this._recordCount == 1)
									summary.set_value(cellValue);
								break;

							case $IG.SummaryType.Custom:
								if (this._clientEvents["CalculateCustomSummary"])
									this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateCustomSummary'], new $IG.CalculateCustomSummaryArgs(summary, cell, null, $IG.RowUpdateType.Add));
								break;
						}
					}
					
					if (this._clientEvents["SummaryCalculated"])
						this._grid._raiseSenderClientEvent(this, this._clientEvents['SummaryCalculated'], new $IG.SummaryCalculatedArgs(columnSummaryInfo));
				}
			}
		}
	},
	_rowDeletedBatch: function (args)
	{
		if (args.row)
		{
			var row = args.row;
			var cellCount = row.get_cellCount();
			this._recordCount -= 1;
			for (var x = 0; x < cellCount; ++x)
			{
				var minRecal = false;
				var maxRecal = false;
				var cell = row.get_cell(x);
				var cellValue = cell.get_value();
				var column = cell.get_column();
				var columnSummaryInfo = this.get_columnSummaryInfoFromKey(column.get_key());
				if (columnSummaryInfo)
				{
					var sumCount = columnSummaryInfo.get_summaryCount();
					for (var i = 0; i < sumCount; i++)
					{
						var summary = columnSummaryInfo.get_summary(i);
						var sumType = summary.get_summaryType();
						var sumValue = summary.get_value();
						switch (sumType)
						{
							case $IG.SummaryType.Count:
								summary.set_value(this._recordCount);
								break;
							case $IG.SummaryType.Sum:
								sumValue = this._recordCount > 0 ? sumValue - cellValue : "";
								summary.set_value(sumValue);
								break;

							case $IG.SummaryType.Average:
								var recordCount = this._recordCount;
								sumValue = this._recordCount > 0 ? ((recordCount + 1) * sumValue - cellValue) / recordCount : "";
								summary.set_value(sumValue);
								break;
							case $IG.SummaryType.Min:
								if (this._recordCount == 0)
									summary.set_value("");
								
								else if (cellValue == sumValue || (cellValue && cellValue.valueOf && sumValue && sumValue.valueOf && cellValue.valueOf() == sumValue.valueOf()))
								{
									var calcArgs = this._clientEvents['CalculateSummary'] ? this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateSummary'], new $IG.CalculateSummaryEventArgs(summary, args.cell, args.oldValue, $IG.RowUpdateType.Edit)) : null;
									minRecal = !calcArgs || calcArgs.get_forceCalculationOnServer();
								}
								break;

							case $IG.SummaryType.Max:
								if (this._recordCount == 0)
									summary.set_value("");
								
								else if (cellValue == sumValue || (cellValue && cellValue.valueOf && sumValue && sumValue.valueOf && cellValue.valueOf() == sumValue.valueOf()))
								{
									var calcArgs = this._clientEvents['CalculateSummary'] ? this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateSummary'], new $IG.CalculateSummaryEventArgs(summary, args.cell, args.oldValue, $IG.RowUpdateType.Edit)) : null;
									maxRecal = !calcArgs || calcArgs.get_forceCalculationOnServer();
								}
								break;

							case $IG.SummaryType.Custom:
								if (this._clientEvents["CalculateCustomSummary"])
									this._grid._raiseSenderClientEvent(this, this._clientEvents['CalculateCustomSummary'], new $IG.CalculateCustomSummaryArgs(summary, cell, null, $IG.RowUpdateType.Delete));
								break;
						}
					}
					if (minRecal || maxRecal)
					{
						this._grid._actionList.add_transaction(new $IG.SummaryAction("RecalcSummaries", this.get_name(), this._grid, "recalc", null));
						if (!this._grid._enableAjax)
							this._owner._postAction(1);
						else
						{
							


							var eventArgs = new $IG.CancelBehaviorEventArgs(this);
							eventArgs._props[1] = 2;
							this._owner._raiseClientEventEnd(eventArgs);
						}
					}
					
					if (this._clientEvents["SummaryCalculated"])
						this._grid._raiseSenderClientEvent(this, this._clientEvents['SummaryCalculated'], new $IG.SummaryCalculatedArgs(columnSummaryInfo));
				}
			}
		}
	},
	_batchUpdateUndone: function (args)
	{
		var operation = args.type;
		switch (operation)
		{
			case $IG.RowUpdateType.Edit: // edited
				var row = args.row;
				for (var x = 0; x < args.cellIndeces.length; ++x)
				{
				    var cell = row.get_cell(args.cellIndeces[x]);
				    // N.R 8th February 2016 Bug 213710: Summaries are not updated properly after undoing changes.
                    // For the oldValue set the value before undo in order summary to be calcolated correct
					var newArs = { "cell": cell, oldValue: cell._previousValue };
					this._cellValueChanged(newArs);
				}
				break;
			case $IG.RowUpdateType.Delete: // deleted
				this._rowAddedBatch(args);
				break;
			case $IG.RowUpdateType.Add: // added
				this._rowDeletedBatch(args);
				break;
		}
	},
	_get_sumButtonObject: function (column, elem)
	{
		var key = column.get_key();
		if (this._sumButtonsObjs[key] == null)
		{
			this._sumButtonsObjs[key] = new $IG.ImageObject("sumBtn", elem, this._objectManager.get_objectProps(parseInt(this._get_clientOnlyValue("srsc"))), this);
			parseInt(this._get_clientOnlyValue("srsc"))

			var altTxt = this._sumButtonsObjs[key]._get_clientOnlyValue("altTxt");
			var btnElement = this._sumButtonsObjs[key].get_element();
			if (altTxt && btnElement && column.get_headerElement())
			{
				var formatedAltTxt = String.format(altTxt, column.get_headerText());
				btnElement.alt = formatedAltTxt;
				btnElement.title = formatedAltTxt;
			}
		}
		return this._sumButtonsObjs[key];
	},
	_onImgMouseOver: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "sumBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}

		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			var btn = this._get_sumButtonObject(column, element);
			if (btn)
				btn.setState($IG.ImageState.Hover);
		}
	},

	_onImgMouseOut: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "sumBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			delete this._mouseDown;
			var btn = this._get_sumButtonObject(column, element);
			if (btn)
				btn.setState($IG.ImageState.Normal);
		}
	},

	_onImgMouseDown: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "sumBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			var btn = this._get_sumButtonObject(column, element);
			if (btn)
			{
				this._mouseDown = true;
				btn.setState($IG.ImageState.Pressed);
			}
		}
	},

	_onImgMouseClick: function (evnt)
	{
		
		if (this.getEditingOn())
			return;
		$util.cancelEvent(evnt);
		var target = evnt.target;
		var element;
		var td;
		if (target.getAttribute("mkr") == "sumBtn")
		{
			element = target.firstChild;
			td = target.parentNode;
		}
		else if (target.tagName != "DIV")
		{
			element = target;
			td = target.parentNode.parentNode;
		}
		else
			return;
		var column = null;
		if (td)
		{
			if (this._grid._hasHeaderLayout)
				column = this._grid.get_columns().get_columnFromKey(td.getAttribute("key"));
			else
				column = this._grid._gridUtil._getColumnFromHeader(td);
		}
		if (column)
		{
			delete this._mouseDown;
			this._droppedBtn = this._get_sumButtonObject(column, element);
			if (this._droppedBtn)
				this._droppedBtn.setState($IG.ImageState.Normal);
			// now open up drop down
			if (this._columnDroppedDown && !this._columnDroppedDown._dropDownBehaviour.get_visible())
				this._columnDroppedDown = null;
			if (this._columnDroppedDown)
			{
				if (this._columnDroppedDown.get_key() == column.get_key())
				{
					this._onCancelBtnClick();
				}
				else
				{
					this._onCancelBtnClick();
					if (!this._columnDroppedDown)
					{
						column._dropDownBehaviour.set_visible(true);
						var cancelledOrHidden = column._dropDownBehaviour.get_enableAnimations() ? !column._dropDownBehaviour.get_isAnimating() : !column._dropDownBehaviour.get_visible();
						if (!cancelledOrHidden)
						{
							this._columnDroppedDown = column;
							var dropDown = this._columnDroppedDown._dropDownBehaviour.get_targetContainer();
							if (dropDown.firstChild.firstChild)
								dropDown.firstChild.firstChild.focus();
							else
								dropDown.firstChild.nextSibling.focus();
						}
					}
				}
			}
			else
			{
				column._dropDownBehaviour.set_visible(true);
				var cancelledOrHidden = column._dropDownBehaviour.get_enableAnimations() ? !column._dropDownBehaviour.get_isAnimating() : !column._dropDownBehaviour.get_visible();
				if (!cancelledOrHidden)
				{
					this._columnDroppedDown = column;
					var dropDown = this._columnDroppedDown._dropDownBehaviour.get_targetContainer();
					if (dropDown.firstChild.firstChild)
						dropDown.firstChild.firstChild.focus();
					else
						dropDown.firstChild.nextSibling.focus();
				}
			}
		}
	},
	_onBtnKeyDown: function (evnt)
	{
		
		if (this._activation && evnt.keyCode == Sys.UI.Key.tab)
		{
			if (this._activation.get_activeCell() && !evnt.shiftKey)
				return;
			var btnCount = this._sumButtons.length;
			for (var x = 0; x < btnCount; x++)
			{
				if (this._sumButtons[x] == evnt.target)
					break;
			}

			var firstVisualRow = this._grid._gridUtil.getFirstVisualRow();
			if (evnt.shiftKey && x == 0 && firstVisualRow && this._hierarchical)
			{
				var prevGridInfo = this._grid._gridUtil._getPrevRowForPrevGrid(firstVisualRow);
				if (prevGridInfo != null)
				{
					var lastVisCol = prevGridInfo.prevGrid._gridUtil._findLastVisibleColumn();
					lastVisCol = lastVisCol ? lastVisCol.get_index() : 0;
					this._shiftTabOnFirstBtn = true;
					if (this._activation.__processPrevGridInfo(prevGridInfo, evnt, lastVisCol, true))
					{
						if ($util.IsOpera)
							this._OperaCancelEvent = true;
						$util.cancelEvent(evnt);
						delete this._shiftTabOnFirstBtn;
						return;
					}
				}
			}
			else if (!evnt.shiftKey && x == btnCount - 1 && firstVisualRow)
			{
				var visCol = this._grid._gridUtil._findFirstVisibleColumn();
				if (visCol)
					this._activation.set_activeCell(firstVisualRow.get_cell(visCol.get_index()));
				if ($util.IsOpera)
					this._OperaCancelEvent = true;
				$util.cancelEvent(evnt);
			}
		}
		else if (this._activation && evnt.keyCode == Sys.UI.Key.space)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
			this._onImgMouseClick(evnt);
		}
	},

	_onBtnKeyPress: function (evnt)
	{
		if (this._OperaCancelEvent)
		{
			$util.cancelEvent(evnt);
			this._OperaCancelEvent = false;
		}
	},

	
	_onPreActiveCellChanging: function (evnt)
	{
		var firstVisCol = this._grid._gridUtil._findFirstVisibleColumn();
		var lastVisCol = this._grid._gridUtil._findLastVisibleColumn();
		var firstVisualRow = this._grid._gridUtil.getFirstVisualRow();
		var nextGridInfo = evnt.cell != null ? this._grid._gridUtil._getNextRowForNextGrid(evnt.cell._row) : null;
		var activeCellResolved = this._activation.get_activeCellResolved();
		if (evnt.keyCode == Sys.UI.Key.tab && !evnt.shiftKey && evnt.activeCell == null && evnt.cell != null && evnt.cell._column == firstVisCol && evnt.cell._row == firstVisualRow)
		{
			if (firstVisCol && this._sumButtons && this._sumButtons.length)
			{
				var header = firstVisCol.get_headerElement();
				var childNodes = header.childNodes;
				var childCount = childNodes.length;
				for (var x = 0; x < childCount; ++x)
				{
					var child = childNodes[x];
					if (child && child.getAttribute && child.getAttribute('mkr') == "sumBtn")
					{
						child.focus();
						evnt.cancel = true;
						return true;
					}
				}
			}
		}
		else if (evnt.keyCode == Sys.UI.Key.tab && evnt.shiftKey && evnt.activeCell == null && evnt.cell != null && evnt.cell._column == lastVisCol && nextGridInfo != null)
		{
			var nextGrid = nextGridInfo.nextGrid;
			var nextGridFirstVisualRow = nextGrid._gridUtil.getFirstVisualRow();
			var nextGridFirstVisCol = nextGrid._gridUtil._findFirstVisibleColumn();
			var nextGridLastVisCol = nextGrid._gridUtil._findLastVisibleColumn();
			var nextGridSummaryRow = nextGrid.get_behaviors().get_summaryRow();
			if (activeCellResolved && activeCellResolved._column == nextGridFirstVisCol && activeCellResolved._row == nextGridFirstVisualRow
				&& nextGridSummaryRow && !nextGridSummaryRow._shiftTabOnFirstBtn && nextGridSummaryRow._sumButtons && nextGridSummaryRow._sumButtons.length)
			{
				var header = nextGridLastVisCol.get_headerElement();
				var childNodes = header.childNodes;
				var childCount = childNodes.length;
				for (var x = 0; x < childCount; ++x)
				{
					var child = childNodes[x];
					if (child && child.getAttribute && child.getAttribute('mkr') == "sumBtn")
					{
						child.focus();
						evnt.cancel = true;
						return true;
					}
				}
			}
		}
	},

	_onBtnFocus: function (evnt)
	{
		if (this._grid.get_rows().get_length() > 0)
		{
			var btnCount = this._sumButtons.length;
			for (var x = 0; x < btnCount; x++)
			{
				if (this._sumButtons[x] == evnt.target)
					break;
			}
			
			var th = evnt.target;
			while (th.tagName != "TH" && th.parentNode)
				th = th.parentNode;
			var row = this._grid.get_rows().get_row(0);
			if (th)
				row.get_cellByColumnKey(th.getAttribute("key")).scrollToView(1);
		}
	},

	_getSummaryStatesFromDropDown: function ()
	{
		var checkedSums = [];
		var uncheckedSums = [];

		var dropDown = this._columnDroppedDown._dropDownBehaviour.get_targetContainer();
		var items = dropDown.firstChild.childNodes;
		for (var x = 0; x < items.length; ++x)
		{
			var li = items[x];
			if (li.getAttribute("changed"))
			{
				var imgCheckbox = li.firstChild;
				while (imgCheckbox.tagName != "IMG" && imgCheckbox)
					imgCheckbox = imgCheckbox.nextSibling;
				if (imgCheckbox)
				{
					var sumState = { "val": parseInt(li.getAttribute("val")), "name": li.getAttribute("txt") };
					if (imgCheckbox.getAttribute("checked") == "1")
						checkedSums[checkedSums.length] = sumState

					else
						uncheckedSums[uncheckedSums.length] = sumState;
				}
			}
		}
		return { "checkedSums": checkedSums, "uncheckedSums": uncheckedSums };
	},

	_onOkBtnClick: function (evnt)
	{
		if (!this._columnDroppedDown)
			return;

		var sumState = this._getSummaryStatesFromDropDown();
		var columnKey = this._columnDroppedDown.get_key();
		this._closeSummaryDropdown(this._columnDroppedDown);
		if (!this._columnDroppedDown)
		{
			if (sumState.checkedSums.length > 0 || sumState.uncheckedSums.length > 0)
			{
				if (sumState.checkedSums.length > 0)
					this._grid._actionList.add_transaction(new $IG.SummaryAction("AddSum", this.get_name(), this._grid, columnKey, sumState.checkedSums));
				if (sumState.uncheckedSums.length > 0)
					this._grid._actionList.add_transaction(new $IG.SummaryAction("RemoveSum", this.get_name(), this._grid, columnKey, sumState.uncheckedSums));
				if (!this._grid._enableAjax)
					this._owner._postAction(1);
				else
				{
					
					this._grid._notifyPost(new Object(), 2);
					


					var eventArgs = new $IG.CancelBehaviorEventArgs(this);
					eventArgs._props[1] = 2;
					this._owner._raiseClientEventEnd(eventArgs);
				}
			}
		}

	},
	_undoSumStateChange: function (col)
	{
		var dropDown = col._dropDownBehaviour.get_targetContainer();
		var columnSummaryInfo = this.get_columnSummaryInfoFromKey(col.get_key());
		var items = dropDown.firstChild.childNodes;
		for (var x = 0; x < items.length; ++x)
		{
			var li = items[x];
			if (li.getAttribute("changed"))
			{
				var imgCheckbox = li.firstChild;
				if (imgCheckbox.tagName != "IMG")
					imgCheckbox = imgCheckbox.nextSibling;
				var checked = imgCheckbox.getAttribute("checked");
				this._changeCheckedStatus(imgCheckbox, (checked == "1" ? false : true));
				li.removeAttribute("changed")
			}
		}
	},

	_onCancelBtnClick: function (evnt)
	{
		if (!this._columnDroppedDown)
			return;
		var col = this._columnDroppedDown;
		this._closeSummaryDropdown(this._columnDroppedDown);
		if (!this._columnDroppedDown)
			this._undoSumStateChange(col);
	},
	_findSumBtnHeaderLayout: function (column)
	{
		var colElem = column.get_headerElement();
		for (var i = 0; i < this._sumButtons.length; i++)
		{
			if (colElem == this._sumButtons[i].parentNode)
				return this._sumButtons[i];
		}
		return null;
	},
	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var settingProps in collectionItems)
			this._columnSettings._addObject($IG.SummaryRowSettings, null, settingProps);

		if (!this._sumButtons)
			return;

		var count = 0;
		var uncheckedSrc;
		var dropDownElm = $get(this._grid._id + "_SummaryDropDown");
		this._grid.__walkThrough(dropDownElm.firstChild, true);
		dropDownElm.firstChild.setAttribute("tabIndex", "0");

		var colCount = this._grid.get_columns().get_length();
		for (var x = 0; x < colCount; ++x)
		{
			var column = this._grid._gridUtil._getColumnFromVisibleIndex(x);
			var columnKey = column._key;
			var isTemplated = column.get_isTemplated();
			var colSetting = this.get_columnSettingFromKey(columnKey);
			if ((this.get_showSummariesButtons() && colSetting == null) || (colSetting && colSetting.get_enabled() && colSetting.get_showSummaryButton()))
			{
				column._dropDownBehaviour = new $IG.DropDownBehavior((this._grid._hasHeaderLayout ? this._findSumBtnHeaderLayout(column) : this._sumButtons[count++]), $util.IsIE);
				var curDropDownBehavior = column._dropDownBehaviour;
				
				this._dropDownBehaviors[this._dropDownBehaviorsCount++] = curDropDownBehavior;

				var columnType = column.get_type();
				var elmClone;
				elmClone = dropDownElm.cloneNode(true);
				elmClone.id = elmClone.id + "_" + columnKey;
				var i = 0;
				var colSum = this.get_columnSummaryInfoFromKey(columnKey);
				var ul = elmClone.firstChild;
				ul.id = ul.id + "_" + columnKey;
				for (var y = 0; y < ul.childNodes.length; ++y)
				{
					var summarySetting = colSetting != null ? colSetting.get_summarySettingByType(i) : null;
					var customName = summarySetting != null ? summarySetting.get_customSummaryName() : "";
					var remove = ((colSetting != null && !colSetting.get_enableColumnSummaryOptions()) && i < 5) || isTemplated;
					if (summarySetting != null && !summarySetting.get_showOptionInDropDown())
						remove = true;
					var val = ul.childNodes[y].getAttribute("val");
					if (val)
					{
						if (!uncheckedSrc)
						{
							var imgCheckbox = ul.childNodes[y].firstChild;
							if (imgCheckbox.tagName != "IMG")
								imgCheckbox = imgCheckbox.nextSibling;
							uncheckedSrc = imgCheckbox.src;
						}
						if ((i == $IG.SummaryType.Sum || i == $IG.SummaryType.Average) && columnType != "number")
							remove = true;
						if ((i == $IG.SummaryType.Min || i == $IG.SummaryType.Max) && columnType != "number" && columnType != "date")
							remove = true;

						if (remove)
						{
							ul.removeChild(ul.childNodes[y]);
							y--;
						}
						else
						{
							if (customName.length > 0)
							{
								ul.childNodes[y].innerHTML = $util.replace(ul.childNodes[y].innerHTML, this._sumNames[i], customName);
								ul.childNodes[y].setAttribute("txt", customName);
							}
							var imgCheckbox = ul.childNodes[y].firstChild;
							if (imgCheckbox.tagName != "IMG")
								imgCheckbox = imgCheckbox.nextSibling;
							if (colSum && colSum.get_summaryByType(i) != null)
								this._changeCheckedStatus(imgCheckbox, true);
							else
								this._changeCheckedStatus(imgCheckbox, false);
							ul.childNodes[y].setAttribute("tabIndex", "0");
						}
						i++;
					}
				}

				// now add custom options
				if (colSetting != null && colSetting.get_summarySettings().length > 0)
				{
					var customCount = colSetting.get_summarySettings().length;
					for (var c = 0; c < customCount; ++c)
					{
						var summarySetting = colSetting.get_summarySettings()[c];
						var sumType = parseInt(summarySetting.get_summaryType());
						if ((sumType < $IG.SummaryType.Custom && (colSetting.get_enableColumnSummaryOptions() || isTemplated)) ||
							((sumType == $IG.SummaryType.Sum || sumType == $IG.SummaryType.Average) && columnType != "number") ||
							((sumType == $IG.SummaryType.Min || sumType == $IG.SummaryType.Max) && columnType != "number" && columnType != "date") ||
							!summarySetting.get_showOptionInDropDown())
							continue;
						var newLi = document.createElement("li");
						newLi.setAttribute("val", sumType);
						var newCheckbox = document.createElement("img");
						newCheckbox.src = uncheckedSrc;
						ul.appendChild(newLi);
						newLi.appendChild(newCheckbox);
						var sumName;
						if (sumType == $IG.SummaryType.Custom || summarySetting.get_customSummaryName().length > 0)
							sumName = summarySetting.get_customSummaryName();
						else
							sumName = this._sumNames[sumType];
						newLi.innerHTML += sumName;
						newLi.id = sumName + "_item";
						newLi.setAttribute("txt", sumName);

						
						if (sumType != 5)
							sumName = null;
						var imgCheckbox = elmClone.firstChild.childNodes[y].firstChild;
						if (imgCheckbox.tagName != "IMG")
							imgCheckbox = imgCheckbox.nextSibling;
						if (colSum && colSum.get_summaryByType(sumType, sumName) != null)
							this._changeCheckedStatus(imgCheckbox, true);
						else
							this._changeCheckedStatus(imgCheckbox, false);

						newLi.className = this._sumDDItemCss;
						newLi.tabIndex = 0;
						++y;
					}
				}

				
				elmClone.removeChild(elmClone.firstChild.nextSibling);

				
				
				if (!$util.IsIE || $util.IsIE9Plus || !elmClone.firstChild._events)
				{
					
					$addHandler(ul, 'mousedown', this._onMouseDownSumItemHandler);
					if (window.navigator.pointerEnabled && window.navigator.maxTouchPoints > 0)
					{
						$addHandler(ul, 'pointerdown', this._onTouchStartSumItemHandler);
						$addHandler(ul, 'pointerup', this._onTouchEndSumItemHandler);
					}
					else if (window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0)
					{
						$addHandler(ul, 'MSPointerDown', this._onTouchStartSumItemHandler);
						$addHandler(ul, 'MSPointerUp', this._onTouchEndSumItemHandler);
					}
					else
					{
						$addHandler(ul, 'touchstart', this._onTouchStartSumItemHandler);
						$addHandler(ul, 'touchend', this._onTouchEndSumItemHandler);
					}
					$addHandler(ul, 'keydown', this._onKeyDownSumItemHandler);
					if ($util.IsOpera)
						$addHandler(ul, 'keypress', this._onKeyPressSumItemHandler);

					$addHandler(elmClone.lastChild.previousSibling, 'click', this._okBtnClickHandler);
					$addHandler(elmClone.lastChild, 'click', this._cancelBtnClickHandler);

				}
				curDropDownBehavior.set_targetContainer(elmClone);
				curDropDownBehavior.set_zIndex(this.get_summaryDropdownZIndex());
				curDropDownBehavior.set_animationDurationMs(this.get_animationDurationMs());
				curDropDownBehavior.set_enableAnimations(this.get_animationEnabled());
				curDropDownBehavior.set_animationType(this.get_animationType());

				curDropDownBehavior.set_visibleOnBlur(false);

				curDropDownBehavior.set_position($IG.DropDownPopupPosition.Default);

				
				if (this._clientEvents['SummaryDropdownDisplaying'])
				{
					// this will be invoked before the dropdown is physically shown on the screen
					curDropDownBehavior.get_Events().addSettingVisibleHandler(this.get_events().getHandler("SummaryDropdownDisplaying"));
				}
				if (this._clientEvents['SummaryDropdownDisplayed'])
				{
					// this will be invoked after the dropdown container has been shown
					curDropDownBehavior.get_Events().addSetVisibleHandler(this.get_events().getHandler("SummaryDropdownDisplayed"));
				}
				if (this._clientEvents['SummaryDropdownHiding'])
				{
					// this will be invoked before the dropdown is physically hidden on the screen
					curDropDownBehavior.get_Events().addSettingHiddenHandler(this.get_events().getHandler("SummaryDropdownHiding"));
				}
				if (this._clientEvents['SummaryDropdownHidden'])
				{
					// this will be invoked after the dropdown container has been hidden
					curDropDownBehavior.get_Events().addSetHiddenHandler(this.get_events().getHandler("SummaryDropdownHidden"));
				}

				elmClone = null;
				curDropDownBehavior.init();
			}
		}
	},

	_createObjects: function (objectManager)
	{
		this._objectManager = objectManager;
		this._objectManager.__createdObjectCount = 0;

		$IG.SummaryRow.callBaseMethod(this, "_createObjects", [objectManager]);

		var cos = objectManager.__createdObjectCount;
		this._objectManager = objectManager;
		this._columnSummaries = [];
		var columnSummariesCount = parseInt(this._get_clientOnlyValue("srsc"));

		for (var i = 0; i < columnSummariesCount; i++)
		{
			var obj = new $IG.ColumnSummaryInfo("ColumnSummaryInfo", null, objectManager.get_objectProps(cos + i), this);
			objectManager.register_object(cos + i, obj);
			this._columnSummaries[i] = obj;
			obj = null;
		}
	},

	_changeCheckedStatus: function (checkbox, checked)
	{
		if (checked)
		{
			checkbox.src = checkbox.src.replace(this._uncheckedUrl, this._checkedUrl);
			checkbox.setAttribute("checked", "1");
			var tooltip = checkbox.parentNode.getAttribute("txt") + this._checkedTooltipEnd;
			checkbox.alt = tooltip;
			checkbox.title = tooltip;
		}
		else
		{
			checkbox.src = checkbox.src.replace(this._checkedUrl, this._uncheckedUrl);
			checkbox.setAttribute("checked", "0");
			var tooltip = checkbox.parentNode.getAttribute("txt") + this._uncheckedTooltipEnd;
			checkbox.alt = tooltip;
			checkbox.title = tooltip;
		}
	},

	_onMouseDownSumItem: function (evnt)
	{
		if ((evnt.button != 0 && evnt.keyCode != Sys.UI.Key.enter) || this._cancelMouseDown)
		{
			this._cancelMouseDown = null;
			return;
		}
		$util.cancelEvent(evnt);
		if (evnt.target.tagName === "IMG")
		{
			if (evnt.target.getAttribute("checked") == "1")
				this._changeCheckedStatus(evnt.target, false);
			else
				this._changeCheckedStatus(evnt.target, true);
			this._currentSumItem = evnt.target.parentNode;

			if (this._currentSumItem.getAttribute("changed"))
				this._currentSumItem.removeAttribute("changed")
			else
				this._currentSumItem.setAttribute("changed", "1");
		}
		else if (evnt.target.tagName === "LI")
			this._currentSumItem = evnt.target;
	},
	_onTouchStartSumItem: function (evnt)
	{
		var target = evnt.target;
		if (evnt.rawEvent && evnt.rawEvent.pointerType && evnt.rawEvent.pointerType == evnt.rawEvent.MSPOINTER_TYPE_MOUSE)
			return;
		this._touchStart = true;
		if (target.tagName === "IMG" || (target.firstChild && target.firstChild.tagName === "IMG"))
		{
			var img = target.tagName == "IMG" ? target : target.firstChild;
			if (img.getAttribute("checked") == "1")
				this._changeCheckedStatus(img, false);
			else
				this._changeCheckedStatus(img, true);
			this._currentSumItem = img.parentNode;

			if (this._currentSumItem.getAttribute("changed"))
				this._currentSumItem.removeAttribute("changed")
			else
				this._currentSumItem.setAttribute("changed", "1");
		}
	},
	_onTouchEndSumItem: function (evnt)
	{
		if (this._touchStart)
		{
			this._cancelMouseDown = true;
			this._touchStart = null;
		}
	},
	_onKeyDownSumItem: function (evnt)
	{
		var target = evnt.target;
		var items = target.tagName == "LI" ? target.parentNode : target;
		if (evnt.keyCode == Sys.UI.Key.up)// || (evnt.keyCode == Sys.UI.Key.tab && evnt.shiftKey))
		{
			var nextItem = (!this._currentSumItem) ? items.firstChild : this._currentSumItem.previousSibling;

			if (!nextItem)
				nextItem = items.lastChild;

			nextItem.focus();

			this._currentSumItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.down)// || evnt.keyCode == Sys.UI.Key.tab)
		{
			var nextItem = (!this._currentSumItem) ? items.firstChild : this._currentSumItem.nextSibling;

			if (!nextItem)
				nextItem = items.firstChild;

			nextItem.focus();

			this._currentSumItem = nextItem;
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
		}
		else if (evnt.keyCode == Sys.UI.Key.space)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;

			var checkbox = evnt.target.firstChild;
			if (checkbox.tagName != 'IMG')
				checkbox = checkbox.nextSibling;

			if (!this._currentSumItem)
				this._currentSumItem = items.firstChild;
			if (checkbox.getAttribute("checked") == "1")
				this._changeCheckedStatus(checkbox, false);
			else
				this._changeCheckedStatus(checkbox, true);

			if (this._currentSumItem.getAttribute("changed"))
				this._currentSumItem.removeAttribute("changed")
			else
				this._currentSumItem.setAttribute("changed", "1");
		}
		else if (evnt.keyCode == Sys.UI.Key.esc)
		{
			$util.cancelEvent(evnt);
			if ($util.IsOpera)
				this._OperaCancelEvent = true;
			this._onCancelBtnClick(evnt);
		}

	},

	_onKeyPressSumItem: function (evnt)
	{
		
		if (this._OperaCancelEvent)
		{
			$util.cancelEvent(evnt);
			this._OperaCancelEvent = false;
		}
	},

	_closeSummaryDropdown: function (column)
	{
		column._dropDownBehaviour.set_visible(false);

		

		var cancelledOrHidden = column._dropDownBehaviour.get_enableAnimations() ? !column._dropDownBehaviour.get_isAnimating() : column._dropDownBehaviour.get_visible();
		if (!cancelledOrHidden)
		{
			this._columnDroppedDown = null;
			this._droppedBtn.get_element().parentNode.focus();
			this._currentSumItem = null;
		}
		return cancelledOrHidden;
	},

	_onHidingColumn: function (args)
	{
		var column = args.column;
		var displayValue = "";

		var sumCount = this._maxSumCount;

		if (!column.get_hidden())
			displayValue = "none";

		for (var i = 0; i < sumCount; i++)
		{
			var rowElement = this._grid._elements["footSumRow" + i];
			if (rowElement)
			{
				var childNodes = rowElement.childNodes;
				var childCount = childNodes.length;
				var sumsInRow = 0;
				var row = new $IG.GridRow(null, rowElement, [], this._grid, null);
				var cellElement = this._grid._gridUtil.getCellElemFromIndex(row, column.get_visibleIndex());
				var canBreak = false;
				for (var x = 0; x < childCount; ++x)
				{
					var child = childNodes[x];
					if (child.getAttribute('mkr') != null && childNodes[x].style.display != "none")
						sumsInRow++;
					if (cellElement && cellElement == child)
					{
						if (!column.get_hidden())
							sumsInRow--;
						else
							sumsInRow++;
						canBreak = true;
					}
					if (sumsInRow >= 2 || (canBreak && sumsInRow >= 1))
						break;
				}
				if (sumsInRow < 1 && cellElement && cellElement.getAttribute('mkr') != null)
				{
					rowElement.style.display = "none";
				}
				else
					rowElement.style.display = "";
				if (cellElement)
					cellElement.style.display = displayValue;
			}
		}
	},

	_onMouseDown: function (evnt)
	{
		var target = evnt.target;
		var dropDown = this._columnDroppedDown ? this._columnDroppedDown._dropDownBehaviour.get_targetContainer() : null;
		if (dropDown && !$util.isChild(dropDown, target) && target != dropDown && !((target.tagName == "IMG" && target.parentNode.getAttribute("mkr") == "sumBtn") || (target.firstChild && target.firstChild.nextSibling && target.firstChild.nextSibling.tagName == "IMG" && target.getAttribute("mkr") == "sumBtn")))
			this._onCancelBtnClick(evnt);
	},

	_onMouseUp: function (evnt)
	{
		var target = evnt.target;
		var dropDown = this._columnDroppedDown ? this._columnDroppedDown._dropDownBehaviour.get_targetContainer() : null;
		if (dropDown && !$util.isChild(dropDown, target) && target != dropDown && !((target.tagName == "IMG" && target.parentNode.getAttribute("mkr") == "sumBtn") || (target.firstChild && target.firstChild.nextSibling && target.firstChild.nextSibling.tagName == "IMG" && target.getAttribute("mkr") == "sumBtn")))
			this._onCancelBtnClick(evnt);
	},

	_onMousewheel: function (evnt)
	{
		var target = evnt.target;
		var dropDown = this._columnDroppedDown ? this._columnDroppedDown._dropDownBehaviour.get_targetContainer() : null;
		if (dropDown && !$util.isChild(dropDown, target) && target != dropDown)
			this._onCancelBtnClick(evnt);
	},

	
	_onScrollTopChange: function (evnt)
	{
		if (this._columnDroppedDown)
			this._onCancelBtnClick(evnt);
	},
	
	_onScrollLeftChange: function (args)
	{
		if (this._mouseDown)
			return true;
	},

	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the summary row behavior removes all the event handlers that it
		/// had attached.
		/// </summary>
		if (!this._grid)
			return;
		delete this._hierarchical;

		if (this._columnDroppedDown && this._columnDroppedDown._dropDownBehaviour && this._columnDroppedDown._dropDownBehaviour.get_visible())
		{
			this._closeSummaryDropdown(this._columnDroppedDown);
		}
		delete this._columnDroppedDown;

		var targetsToDelete = [];
		var animationContainerToDelete = [];
		
		for (var i = 0; i < this._dropDownBehaviorsCount; i++)
		{
			if (this._dropDownBehaviors[i])
			{
				targetsToDelete[targetsToDelete.length] = this._dropDownBehaviors[i].get_targetContainer();
				animationContainerToDelete[animationContainerToDelete.length] = this._dropDownBehaviors[i].get_animationsContainer();
				this._dropDownBehaviors[i].dispose();
			}
			this._dropDownBehaviors[i] = null;
		}
		this._dropDownBehaviors = null;
		this._dropDownBehaviorsCount = 0;
		var gridId = this._grid._id;

		if (this._onMouseDownSumItemHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL"), 'mousedown', this._onMouseDownSumItemHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'mousedown', this._onMouseDownSumItemHandler);
				} catch (e) { }
			}

			delete this._onMouseDownSumItemHandler;
		}

		if (this._onTouchStartSumItemHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL"), 'touchstart', this._onTouchStartSumItemHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'touchstart', this._onMouseDownSumItemHandler);
				} catch (e) { }
			}

			delete this._onTouchStartSumItemHandler;
		}
		if (this._onTouchEndSumItemHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL"), 'touchend', this._onTouchEndSumItemHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'touchend', this._onTouchEndSumItemHandler);
				} catch (e) { }
			}

			delete this._onTouchEndSumItemHandler;
		}

		if (this._onKeyPressSumItemHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL"), 'keypress', this._onKeyPressSumItemHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'keypress', this._onKeyPressSumItemHandler);
				} catch (e) { }
			}

			delete this._onKeyPressSumItemHandler;
		}

		if (this._onKeyDownSumItemHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL"), 'keydown', this._onKeyDownSumItemHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].firstChild, 'keydown', this._onKeyDownSumItemHandler);
				} catch (e) { }
			}

			delete this._onKeyDownSumItemHandler;
		}

		if (this._onOkBtnClickHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL").lastChild.previousSibling, 'click', this._onOkBtnClickHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].lastChild.previousSibling, 'click', this._onOkBtnClickHandler);
				} catch (e) { }
			}
			delete this._onOkBtnClickHandler;
		}

		if (this._onCancelBtnClickHandler)
		{
			try
			{
				$removeHandler($get(gridId + "_SummaryDropDown_UL").lastChild, 'click', this._onCancelBtnClickHandler);
			} catch (e) { }
			for (var i = 0; i < targetsToDelete.length; i++)
			{
				try
				{
					$removeHandler(targetsToDelete[i].lastChild, 'click', this._onCancelBtnClickHandler);
				} catch (e) { }
			}
			delete this._onCancelBtnClickHandler;
		}

		if (this._cellValueChangedListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "CellValueChanged", this._cellValueChangedListener);
			this._cellValueChangedListener = null;
		}
		if (this._rowAddedBatchListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "RowAddedBatch", this._rowAddedBatchListener);
			this._rowAddedBatchListener = null;
		}
		if (this._rowDeletedBatchListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "RowDeletedBatch", this._rowDeletedBatchListener);
			this._rowDeletedBatchListener = null;
		}
		if (this._batchUpdateUndoneListener)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "BatchUpdateUndone", this._batchUpdateUndoneListener);
			this._batchUpdateUndoneListener = null;
		}

		this._grid._gridUtil._unregisterEventListener(this._grid, "HidingColumn", this._onHidingColumnHandler);
		delete this._onHidingColumnHandler;

		if (this._onMouseDownHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousedown', this._onMouseDownHandler);
			delete this._onMouseDownHandler;
		}

		if (this._onMouseUpHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mouseup', this._onMouseUpHandler);
			delete this._onMouseUpHandler;
		}

		if (this._onMousewheelHandler)
		{
			$removeHandler(($util.IsIE8 ? document.documentElement : document), 'mousewheel', this._onMousewheelHandler);
			if ($util.IsFireFox)
				$removeHandler(window, "DOMMouseScroll", this._onMousewheelHandler);
			try	
			{
				
			} catch (e) { }

			delete this._onMousewheelHandler;
		}
		
		if (this._onScrollTopChangeHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollTopChange", this._onScrollTopChangeHandler);
			delete this._onScrollTopChangeHandler;
		}
		
		if (this._onScrollLeftChangeHandler)
		{
			this._grid._gridUtil._unregisterEventListener(this._grid, "ScrollLeftChange", this._onScrollLeftChangeHandler);
			delete this._onScrollLeftChangeHandler;
		}

		var btnCnt = this._sumButtons && this._sumButtons.length ? this._sumButtons.length : 0;
		for (var i = 0; i < btnCnt; i++)
		{
			var sumBtn = this._sumButtons[i];
			var sumImg = $util.IsIE ? sumBtn.firstChild.nextSibling : sumBtn.firstChild;
			if ($util.IsFireFox || $util.IsOpera)
			{
				if (this._onImgMouseOverHandler)
					$removeHandler(sumBtn, 'mouseover', this._onImgMouseOverHandler);
				if (this._onImgMouseOutHandler)
					$removeHandler(sumBtn, 'mouseout', this._onImgMouseOutHandler);
			}
			else
			{
				if (this._onImgMouseOverHandler)
				{
					try
					{
						$removeHandler(sumImg, 'mouseover', this._onImgMouseOverHandler);
					} catch (e) { }
				}
				if (this._onImgMouseOutHandler)
				{
					try
					{
						$removeHandler(sumImg, 'mouseout', this._onImgMouseOutHandler);
					} catch (e) { }

				}
			}
			if (this._onImgMouseDownHandler)
				try
				{
					$removeHandler(sumBtn, 'mousedown', this._onImgMouseDownHandler);
				} catch (e) { }
			if (this._onImgMouseClickHandler)
				try
				{
					$removeHandler(sumBtn, 'click', this._onImgMouseClickHandler);
				} catch (e) { }
			if (this._onBtnKeyDownHandler)
				try
				{
					$removeHandler(sumBtn, 'keydown', this._onBtnKeyDownHandler);
				} catch (e) { }

			if ($util.IsOpera && this._onBtnKeyPressHandler)
				try
				{
					$removeHandler(sumBtn, 'keypress', this._onBtnKeyPressHandler);
				} catch (e) { }
			if (this._onBtnFocusHandler)
				try
				{
					$removeHandler(sumBtn, 'focus', this._onBtnFocusHandler);
				} catch (e) { }
			this._sumButtons[i] = null;
		}
		delete this._recordCount;
		delete this._sumButtons;
		delete this._sumButtonsObjs;
		delete this._onImgMouseOverHandler;
		delete this._onImgMouseOutHandler;
		delete this._onImgMouseDownHandler;
		delete this._onImgMouseClickHandler;
		delete this._onBtnKeyDownHandler;
		delete this._onBtnFocusHandler;

		delete this._activation;

		delete this._sumDDItemCss;
		delete this._checkedUrl;
		delete this._uncheckedUrl;
		delete this._maxSumCount;

		for (var i = 0; i < this._columnSummaries.length; i++)
			this._columnSummaries[i].dispose();
		delete this._columnSummaries;

		this._columnSettings.dispose();
		delete this._columnSettings;

		$IG.SummaryRow.callBaseMethod(this, "dispose");
	}


}
$IG.SummaryRow.registerClass('Infragistics.Web.UI.SummaryRow', $IG.GridBehavior, $IG.IHeaderButton);




$IG.ColumnSummaryInfo = function(obj, element, props, control)
{
	/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo">
	/// Object that defines a column summary info for the grid column.
	/// </summary>
	/// <param name="obj" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="control" type="Infragistics.Web.UI.SummaryRow">The summary row behavior to which the column summary belongs.</param>

	var csm = new $IG.ObjectClientStateManager(props[0]);
	this._grid = control._grid;
	$IG.ColumnSummaryInfo.initializeBase(this, [obj, element, props, control, csm]); //(this, [adr, element, props, owner, csm]); 

}

$IG.ColumnSummaryInfo.prototype =
{
	get_columnKey: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.get_columnKey">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <value type="String">Summary Type</value>
		return this._get_value($IG.ColumnSummaryInfoProps.ColumnKey);
	},

	get_summary: function(index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.get_summary">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <param name="index" type="Number" integer="true">The zero based index in the summaries collection</param>
		/// <returns type="Infragistics.Web.UI.Summary"></returns>

		if (index >= 0 && index < this._summaries._items.length)
			return this._summaries._items[index];
		else
			return null;
	},

	get_summaryCount: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.get_summaryCount">
		/// Returns the number of summaries for this column.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._summaries._items.length;
	},

	get_summaryByType: function(type, name)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.get_summaryByType">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <param name="type" type="Infragistics.Web.UI.SummaryType">The type of the summary</param>
		/// <param name="name" type="String" optional="true">The name for a custom summary.  Optional.</param>
		/// <returns type="Infragistics.Web.UI.Summary"></returns>
		

		for (var i = 0; i < this._summaries._items.length; i++)
		{
			var summary = this._summaries._items[i];
			if (summary.get_summaryType() === type && (!name || (name === summary.get_customSummaryName())))
				return summary;
		}
		return null;
	},


	_createObjects: function(objectManager)
	{
		this._objectManager = objectManager;
	},

	_createCollections: function(collectionsManager)
	{
		this._summaries = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var summaryType in collectionItems)
		{
			this._summaries._addObject($IG.Summary, null, summaryType);
		}
	},

	addSummary: function(newSummary)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.addSummary">
		/// Adds the given summary to the column summary info object
		/// </summary>
		/// <param name="newSummary" type="Infragistics.Web.UI.ClientSummary">The summary to add</param>
		if (newSummary)
		{
			var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this._owner);
			var sums = [];
			sums[0] = { "val": newSummary.get_summaryType(), "name": newSummary.get_customSummaryName() }
			this._grid._actionList.add_transaction(new $IG.SummaryAction("AddSum", this._owner.get_name(), this._grid, this.get_columnKey(), sums));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},

	removeSummary: function(summary)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.removeSummary">
		/// Removes the summary from the column summary info
		/// </summary>
		/// <param name="summary" type="Infragistics.Web.UI.Summary">The summary to remove</param>
		if (summary)
		{
			var eventArgs = new $IG.SummaryAddingRemovingEventArgs(this._owner);
			var sums = [];
			sums[0] = { "val": summary.get_summaryType(), "name": summary.get_customSummaryName() }
			this._grid._actionList.add_transaction(new $IG.SummaryAction("RemoveSum", this._owner.get_name(), this._grid, this.get_columnKey(), sums));
			this._grid._raiseClientEventEnd(eventArgs);
		}
	},

	_get_sumsAsValTxtArray: function()
	{
		var sums = [];
		var sumCount = this.get_summaryCount();
		for (var x = 0; x < sumCount; ++x)
		{
			var summary = this.get_summary(x);
			var sumState = { "val": summary.get_summaryType(), "name": summary.get_customSummaryName() };
			sums[x] = sumState;
		}
		return sums;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ColumnSummaryInfo.dispose">
		/// Disposes of the object.
		/// </summary>
		this._grid = null;
		this._summaries.dispose();
		$IG.ColumnSummaryInfo.callBaseMethod(this, "dispose");
	}

}
$IG.ColumnSummaryInfo.registerClass('Infragistics.Web.UI.ColumnSummaryInfo', $IG.ObjectBase);



$IG.ClientColumnSummaryInfo = function(columnKey)
{
	/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo">
	/// Object that defines a column summary for the grid column.  Object doesn't preserve view state
	/// until added to collection.
	/// </summary>
	/// <param name="columnKey" type="String">The key of the column which to create a new column summary object</param>

	this._columnKey = columnKey;
	this._summaries = [];
}

$IG.ClientColumnSummaryInfo.prototype =
{
	get_columnKey: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.get_columnKey">
		/// Gets the key of the column that the column summary is tied to.
		/// </summary>
		/// <value type="String">Summary Type</value>
		return this._columnKey;
	},

	addSummary: function(summary)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.add_summary">
		/// Adds the specified client summary object to this column summary info object
		/// </summary>
		/// <param name="summary" type="Infragistics.Web.UI">The summary to add</param>

		this._summaries[this._summaries.length] = summary;
	},

	get_summary: function(index)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.get_summary">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <param name="index" type="Number" integer="true">The zero based index in the summaries collection</param>
		/// <returns type="Infragistics.Web.UI.Summary"></returns>
		if (index >= 0 && index < this._summaries.length)
			return this._summaries[index];
		else
			return null;
	},

	get_summaryCount: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.get_summaryCount">
		/// Returns the number of summaries for this column.
		/// </summary>
		/// <value type="Number" integer="true"></value>
		return this._summaries.length;
	},

	get_summaryByType: function(type, name)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.get_summaryByType">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <param name="type" type="Infragistics.Web.UI.SummaryType">The type of the summary</param>
		/// <param name="name" type="String" optional="true">The name for a custom summary.  Optional.</param>
		/// <returns type="Infragistics.Web.UI.Summary"></returns>
		

		for (var i = 0; i < this._summaries._items.length; i++)
		{
			var summary = this._summaries[i];
			if (summary.get_summaryType() === type && (!name || (name === summary.get_customSummaryName())))
				return summary;
		}
		return null;
	},

	_get_sumsAsValTxtArray: function()
	{
		var sums = [];
		var sumCount = this.get_summaryCount();
		for (var x = 0; x < sumCount; ++x)
		{
			var summary = this.get_summary(x);
			var sumState = { "val": summary.get_summaryType(), "name": summary.get_customSummaryName() };
			sums[x] = sumState;
		}
		return sums;
	},


	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientColumnSummaryInfo.dispose">
		/// Disposes of the object.
		/// </summary>
		for (var x = 0; x < this._summaries.length; ++x)
			this._summaries[x].dispose();
		delete this._summaries;
	}

}
$IG.ClientColumnSummaryInfo.registerClass('Infragistics.Web.UI.ClientColumnSummaryInfo');




$IG.Summary = function (adr, element, props, owner, csm)
{
	/// <summary locid="M:J#Infragistics.Web.UI.Summary">
	/// Object that defines a column summary for the grid column.
	/// </summary>
	/// <param name="adr" type="String">The object type.</param>
	/// <param name="element" domElement="true" mayBeNull="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.SummaryRow">The summary row behavior to which the column summary belongs.</param>
	/// <param name="csm" >The client state manager to use.</param>

	$IG.Summary.initializeBase(this, [adr, element, props, owner, csm]);
	this._sumValue = this._get_clientOnlyValue("sumVal");

	
	var convertDate = this._get_clientOnlyValue("sumValDtConv");
	if (convertDate && this._owner && this._owner._owner && this._owner._owner._grid)
	{
		var sumValueStr = Sys.Serialization.JavaScriptSerializer.deserialize(this._sumValue);
		this._sumValue = (sumValueStr != null ? this._owner._owner._grid._gridUtil._convertServerDateStringToClientObject(sumValueStr) : null);		
	}	
}

$IG.Summary.prototype =
{
	get_summaryType: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.get_summaryType">
		/// Gets the type of the summary.
		/// </summary>
		/// <value type="Infragistics.Web.UI.SummaryType">Summary Type</value>
		return this._get_clientOnlyValue("type");
	},

	get_customSummaryName: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.get_customSummaryName">
		/// Gets the custom summary name.	
		/// </summary>
		/// <value type="String"></value>
		return this._get_clientOnlyValue("cusName");
	},

	get_value: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.get_value">
		/// Gets the value of the summary.	
		/// </summary>
		/// <value type="Object"></value>
		return this._sumValue;
	},

	set_value: function(value)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.set_value">
		/// Sets the summary value on the object and changes the HTML to display
		/// the new value.  This setting is client-side only meant to be used to re-calculate
		/// the custom summary when a cell is edited to reflect the new value.  The value
		/// will not propagate to the server.
		/// </summary>
		/// <param name="value" optional="false" mayBeNull="false" type="Object">
		/// The summary value.
		/// </param>

		if (this._sumValue != value)
		{
			var cellElement = this._get_cellElement();
			if (cellElement)
			{
				var column = this._get_gridColumn();
				var sumType = this.get_summaryType();
				var newText = (sumType != $IG.SummaryType.Count ? column._formatValue(value) : value);
				var sumName;
				if (sumType == $IG.SummaryType.Custom || this.get_customSummaryName().length > 0)
					sumName = this.get_customSummaryName();
				else
					sumName = this._owner._owner._sumNames[sumType];
				var height = cellElement.offsetHeight;
				cellElement.innerHTML = String.format(this._get_formatString(), sumName, newText);
				
				if (height != cellElement.offsetHeight)
				{
					var grid = this._owner && this._owner._owner ? this._owner._owner._grid : null;
					if (grid && grid._element)
						grid._onResize({ clientHeight: grid._element.clientHeight });
				}
			}
			this._sumValue = value;
		}
	},
	get_columnSummaryInfo: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.get_columnSummaryInfo">
		/// Gets the Infragistics.Web.UI.ColumnSummaryInfo which the summary is for.	
		/// </summary>
		/// <value type="Infragistics.Web.UI.ColumnSummaryInfo"></value>
		return this._owner;
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.Summary.dispose">
		/// Disposes of the object.
		/// </summary>

		$IG.Summary.callBaseMethod(this, "dispose");

		delete this._sumValue;
		delete this._cellElement;
	},

	_get_formatString: function()
	{
		return this._get_clientOnlyValue("formStr");
	},
	_get_cellElement: function()
	{
		if (!this._cellElement && this._owner && this._owner._owner)
		{
			var grid = this._owner._owner._grid;
			var sumCount = this._owner._owner._maxSumCount;
			var column = this._get_gridColumn();
			var visIndex = column.get_visibleIndex();
			for (var x = 0; x < sumCount; ++x)
			{
				var rowElement = grid._elements["footSumRow" + x];
				if (rowElement)
				{
					var row = new $IG.GridRow(null, rowElement, [], grid, null);
					var cell = grid._gridUtil.getCellElemFromIndex(row, visIndex);
					if (cell.getAttribute("mkr") == this._address)
						this._cellElement = cell;
				}
			}
		}
		return this._cellElement;
	},

	_get_gridColumn: function()
	{
		if (this._owner && this._owner._owner)
		{
			var grid = this._owner._owner._grid;
			var column = grid.get_columns().get_columnFromKey(this._owner.get_columnKey());
			return column;
		}
	}

}
$IG.Summary.registerClass('Infragistics.Web.UI.Summary', $IG.ObjectBase);



$IG.ClientSummary = function(summaryType, customName)
{
	/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary">
	/// Object that defines a summary on a column summary info object. 
	/// This object does not preserve its state.
	/// </summary>
	/// <param name="summaryType" type="Infragistics.Web.UI.SummaryType"> 
	/// The type of the summary.
	/// </param>
	/// <param name="customName" type="String" optional="true">
	/// The name for a custom summary.
	/// </param>

	this._summaryType = summaryType;
	this._customName = customName ? customName : "";

}
$IG.ClientSummary.prototype =
{
	get_summaryType: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary.">
		/// Gets the type of the summary.
		/// </summary>
		/// <value type="Infragistics.Web.UI.SummaryType">Summary Type</value>
		return this._summaryType;
	},

	set_summaryType: function(summaryType)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary.set_summaryType">
		/// Sets the type of the summary.
		/// </summary>
		/// <param name="summaryType" type="Infragistics.Web.UI.SummaryType">The new type of the summary</value>
		this._summaryType = summaryType;
	},

	get_customSummaryName: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary.get_customSummaryName">
		/// Gets the custom name of the summary.
		/// </summary>
		/// <value type="String">Summary Type</value>
		return this._customName;
	},

	set_customSummaryName: function(customName)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary.set_customSummaryName">
		/// Gets the custom name of the summary.
		/// </summary>
		/// <param name="summaryType" type="String">The new custom name of the summary</value>
		this._customName = customName;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ClientSummary.dispose">
		/// Disposes of the object.
		/// </summary>

		delete this._summaryType;
		delete this._customName;
	}

}
$IG.ClientSummary.registerClass('Infragistics.Web.UI.ClientSummary');




$IG.SummaryRowSettings = function(adr, element, props, owner, csm)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings">
	/// Object that defines a column summary setting for the grid column.
	/// </summary>
	/// <param name="adr" type="Number">The index of the object in the collection.</param>
	/// <param name="element" domElement="true">The html element of the object.</param>
	/// <param name="props" type="Array">An array of objects which are the values for the internal members of the class.</param>
	/// <param name="owner" type="Infragistics.Web.UI.ObjectCollection">The collection to which the setting belongs.</param>
	/// <param name="csm" type="Infragistics.Web.UI.ObjectClientStateManager">The clientStateManager for the object.</param>


	$IG.SummaryRowSettings.initializeBase(this, [adr, element, props, owner, csm]);

	this._summarySettings = [];
	if (parseInt(this._get_clientOnlyValue("srcc")) > 0)
	{
		var vals = this._get_clientOnlyValue("srsv").split('|');
		var names = this._get_clientOnlyValue("srsn").split('|');
		var showVals = this._get_clientOnlyValue("srss").split('|');
		for (var x = 0; x < vals.length; ++x)
		{
			this._summarySettings[x] = new $IG.SummarySetting(parseInt(vals[x]), names[x]);
			if (showVals[x] == "1")
				this._summarySettings[x]._set_showOptionInDropDown(true);
		}
	}

}

$IG.SummaryRowSettings.prototype =
{
	get_enabled: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.get_enabled">
		/// Indicates whether the summary is enabled on the particular column.
		/// </summary>
		/// <value type="Boolean">True if summaries are enabled for the column, false otherwise</value>
		return this._get_clientOnlyValue("srse");
	},
	get_showSummaryButton: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.get_showSummaryButton">
		/// Indicates whether the summary button is shown for this column.
		/// </summary>
		/// <value type="Boolean"</value>
		return this._get_clientOnlyValue("srsssb");
	},
	get_enableColumnSummaryOptions: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.get_enableColumnSummaryOptions">
		/// Indicates whether default summary options are shown in the drop down.
		/// </summary>
		/// <value type="Boolean"></value>
		return this._get_clientOnlyValue("srsecso");
	},
	get_summarySettings: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.get_summarySettings">
		/// Returns an array of  SummarySetting objects
		/// </summary>
		/// <value type="Array"></value>
		return this._summarySettings;
	},

	get_summarySettingByType: function(type, name)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.get_summarySettingByType">
		/// Gets the key of the column that the column summary info is tied to.
		/// </summary>
		/// <param name="index" type="Number" integer="true">The zero based index in the summaries collection</param>
		/// <param name="name" type="String" optional="true">The name for a custom summary.  Optional.</param>
		/// <returns type="Infragistics.Web.UI.SummarySetting"></returns>
		

		for (var i = 0; i < this._summarySettings.length; i++)
		{
			var setting = this._summarySettings[i];
			if (setting.get_summaryType() === type && (!name || (name === setting.get_customSummaryName())))
				return setting;
		}
		return null;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryRowSettings.dispose">
		/// Disposes of the object.
		/// </summary>

		for (var x = 0; x < this._summarySettings.length; ++x)
			delete this._summarySettings[x];
		delete this._summarySettings;
	}
}
$IG.SummaryRowSettings.registerClass('Infragistics.Web.UI.SummaryRowSettings', $IG.ColumnSetting);



$IG.SummarySetting = function(summaryType, customName)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummarySetting">
	/// A setting object for a particular summary type per column setting
	/// </summary>
	/// <param name="summaryType" type="Infragistics.Web.UI.SummaryType">The summary type this setting refers to for a particular column</param>
	/// <param name="customName" type="String" optional="true">The name for a custom summary.  Optional.</param>

	this._summaryType = summaryType;
	this._customName = customName;
	this._showOption = false;

}
$IG.SummarySetting.prototype =
{
	get_summaryType: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummarySetting.get_summaryType">
		/// Gets the type of the summary.
		/// </summary>
		/// <value type="Infragistics.Web.UI.SummaryType">Summary Type</value>
		return this._summaryType;
	},

	get_customSummaryName: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummarySetting.get_customSummaryName">
		/// Gets the custom name of the summary.
		/// </summary>
		/// <value type="String"></value>
		return this._customName;
	},

	get_showOptionInDropDown: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummarySetting.get_showOptionInDropDown">
		/// Gets whether the summary referenced by this setting is shown in the drop down for
		/// its column.
		/// </summary>
		/// <value type="Boolean">Summary Type</value>
		return this._showOption;
	},

	_set_showOptionInDropDown: function(show)
	{
		this._showOption = show;
	},


	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummarySetting.dispose">
		/// Disposes of the object.
		/// </summary>

		delete this._summaryType;
		delete this._customName;
		delete this._showOption;
	}

}
$IG.SummarySetting.registerClass('Infragistics.Web.UI.SummarySetting');



$IG.SummaryAction = function(type, ownerName, object, value, tag)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummaryAction">
	/// Object for event arguments used in the summary row behavior to make full or partial postbacks.
	/// </summary>

	$IG.SummaryAction.initializeBase(this, [type, ownerName, object, value, tag]);
}

$IG.SummaryAction.prototype =
{

}

$IG.SummaryAction.registerClass('Infragistics.Web.UI.SummaryAction', $IG.GridAction);







$IG.SummaryType = function()
{

	/// <field name="Count" type="Number" integer="true" static="true">
	/// Number of records in the data source.
	/// </field>

	/// <field name="Min" type="Number" integer="true" static="true">
	/// Minimum value of all cells in the column. Applicable to numeric and date/time columns only.
	/// </field>

	/// <field name="Max" type="Number" integer="true" static="true">
	/// Maximum value of all cells in the column. Applicable to numeric and date/time columns only.
	/// </field>

	/// <field name="Average" type="Number" integer="true" static="true">
	/// Average value of the cells in the column. Applicable to numeric columns only.
	/// </field>

	/// <field name="Sum" type="Number" integer="true" static="true">
	/// Sum of all cell values in the column. Applicable to numeric columns only.
	/// </field>

	/// <field name="Custom" type="Number" integer="true" static="true">
	/// The summary is expected to be assigned inside of the CalculateCustomSummary event handler.
	/// </field>

}

$IG.SummaryType.prototype =
{

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Count">
	/// Number of records in the data source.
	/// </summary>

	Count: 0,

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Min">
	/// Minimum value of all cells in the column. Applicable to numeric and date/time columns only.
	/// </summary>

	Min: 1,

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Max">
	/// Maximum value of all cells in the column. Applicable to numeric and date/time columns only.
	/// </summary>

	Max: 2,

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Average">
	/// Average value of the cells in the column. Applicable to numeric columns only.
	/// </summary>

	Average: 3,

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Sum">
	/// Sum of all cell values in the column. Applicable to numeric columns only.
	/// </summary>

	Sum: 4,

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryType.Custom">
	/// The summary is expected to be assigned inside of the CalculateCustomSummary event handler.
	/// </summary>

	Custom: 5

};

$IG.SummaryType.registerEnum("Infragistics.Web.UI.SummaryType");






$IG.GridSummaryRowProps = new function()
{
	this.SummaryDropdownZIndex = [$IG.GridBehaviorProps.Count + 0, 100100];
	this.Count = $IG.GridBehaviorProps.Count + 1;
};






$IG.ColumnSummaryInfoProps = new function()
{

	this.ColumnKey = [$IG.ObjectBaseProps.Count + 0, 0];

	this.Count = $IG.ObjectBaseProps.Count + 1;

};








$IG.SummaryCalculatedArgs = function(columnSummaryInfo)
{


	/// <summary locid="M:J#Infragistics.Web.UI.SummaryCalculatedArgs">

	/// Class used as EventArgs while raising SummaryCalculated event

	/// </summary>

	/// <param name="columnSummaries" type="Array" elementType="Infragistics.Web.UI.ColumnSummaryInfo">

	/// The column summaries that were calculated for the grid. 

	/// </param>	


	$IG.SummaryCalculatedArgs.initializeBase(this);

	this._columnSummaryInfo = columnSummaryInfo;

}

$IG.SummaryCalculatedArgs.prototype =
{

	get_columnSummaryInfo: function()
	{

		/// <summary locid="M:J#Infragistics.Web.UI.SummaryCalculatedArgs.get_columnSummaryInfo">
		/// Gets the column summary info object whose summaries have been recalculated. 
		/// </summary>
		/// <value type="Infragistics.Web.UI.ColumnSummaryInfo">Column summary info </value>

		return this._columnSummaryInfo;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.SummaryCalculatedArgs.dispose">
		/// Disposes of the object.
		/// </summary>

		$IG.SummaryCalculatedArgs.callBaseMethod(this, "dispose");
		delete this._columnSummaryInfo;
	}

}


$IG.SummaryCalculatedArgs.registerClass('Infragistics.Web.UI.SummaryCalculatedArgs', $IG.EventArgs);







$IG.CalculateCustomSummaryArgs = function(summary, cell, oldCellValue, updateType)
{

	/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.">
	/// Class used as EventArgs while raising CalculateCustomSummary event
	/// </summary>
	/// <param name="summary" type="Infragistics.Web.UI.Summary">
	/// The summary that needs to be recalculated as a result of an updating operation.
	/// </param>
	/// <param name="cell" type="Infragistics.Web.UI.GridCell">
	/// The cell involved in the update operation.
	/// </param>
	/// <param name="oldCellValue" type="Object">
	/// The value of the cell before the update.
	/// </param>
	/// <param name="updateType" type="Infragistics.Web.UI.RowUpdateType">
	/// Returns the update action type (edit (0), delete (1), add (2)) that was undone
	/// </param>	
	$IG.CalculateCustomSummaryArgs.initializeBase(this);

	this._summary = summary;
	this._cell = cell;
	this._oldVal = oldCellValue;
    this._updateType = updateType;
}

$IG.CalculateCustomSummaryArgs.prototype =
{

	get_summary: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateCustomSummaryArgs.get_summary">
		/// Gets the summary object whose summary needs to be recalculated. 
		/// </summary>
		/// <value type="Infragistics.Web.UI.Summary">summary</value>

		return this._summary;
	},

	get_cell: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateCustomSummaryArgs.get_cell">
		/// Gets the cell involved in the update operation.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell">Cell involved in the update operation</value>

		return this._cell;
	},
    
	get_oldCellValue: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateCustomSummaryArgs.get_oldCellValue">
		/// Gets the value of the cell before the update.
		/// </summary>
		/// <value type="Object">Value of the cell before the update</value>

		return this._oldVal;
	},

	get_editActionType: function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.CalculateCustomSummaryArgs.editActionType">
	    /// Returns the update action type (edit (0), delete (1), add (2)) that was undone
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowUpdateType"></value>

		return this._updateType;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateCustomSummaryArgs.dispose">
		/// Disposes of the object.
		/// </summary>

		$IG.CalculateCustomSummaryArgs.callBaseMethod(this, "dispose");
		delete this._summary;
		delete this._cell;
		delete this._oldVal;
        delete this._updateType;
	}

}


$IG.CalculateCustomSummaryArgs.registerClass('Infragistics.Web.UI.CalculateCustomSummaryArgs', $IG.EventArgs);





$IG.CalculateSummaryEventArgs = function(summary, cell, oldCellValue, updateType, forcePostback)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.">
	/// Class used as EventArgs while raising CalculateSummary event
	/// </summary>
	/// <param name="summary" type="Infragistics.Web.UI.Summary">
	/// The summary that needs to be recalculated as a result of an updating operation.
	/// </param>
	/// <param name="cell" type="Infragistics.Web.UI.GridCell">
	/// The cell involved in the update operation.
	/// </param>
	/// <param name="oldCellValue" type="Object">
	/// The value of the cell before the update.
	/// </param>	
	/// <param name="updateType" type="Infragistics.Web.UI.RowUpdateType">
	/// Returns the update action type (edit (0), delete (1), add (2)) that was undone
	/// </param>
    $IG.CalculateSummaryEventArgs.initializeBase(this);

	this._summary = summary;
	this._cell = cell;
	this._oldVal = oldCellValue;
    this._updateType = updateType;
    this._forcePostback = false;
}

$IG.CalculateSummaryEventArgs.prototype =
{

	get_summary: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateSummaryArgs.get_summary">
		/// Gets the summary object whose summary needs to be recalculated. 
		/// </summary>
		/// <value type="Infragistics.Web.UI.Summary">summary</value>

		return this._summary;
	},

	get_cell: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateSummaryArgs.get_cell">
		/// Gets the cell involved in the update operation.
		/// </summary>
		/// <value type="Infragistics.Web.UI.GridCell">Cell involved in the update operation</value>

		return this._cell;
	},
    
	get_oldCellValue: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateSummaryArgs.get_oldCellValue">
		/// Gets the value of the cell before the update.
		/// </summary>
		/// <value type="Object">Value of the cell before the update</value>

		return this._oldVal;
	},
    
	get_editActionType: function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.CalculateSummaryArgs.editActionType">
	    /// Returns the update action type (edit (0), delete (1), add (2)) that was undone
		/// </summary>
		/// <value type="Infragistics.Web.UI.RowUpdateType"></value>

		return this._updateType;
	},
    
	get_forceCalculationOnServer: function()
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.CalculateSummaryArgs.forceCaluclationOnServer">
	    /// Gets/sets whether to have the grid postback to recalculate the summary
		/// </summary>
		/// <value type="Boolean"></value>

		return this._forcePostback;
	},
	set_forceCalculationOnServer: function(forcePostback)
	{
	    /// <summary locid="P:J#Infragistics.Web.UI.CalculateSummaryArgs.forceCaluclationOnServer">
	    /// Whether to have the grid postback to recalculate the summary
		/// </summary>
        /// <param name="forcePostback" type="Boolean"></param>

		this._forcePostback = forcePostback;
	},

	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.CalculateSummaryArgs.dispose">
		/// Disposes of the object.
		/// </summary>

	    $IG.CalculateSummaryEventArgs.callBaseMethod(this, "dispose");
		delete this._summary;
		delete this._cell;
		delete this._oldVal;
        delete this._updateType;
        delete this._forcePostback;
	}

}
$IG.CalculateSummaryEventArgs.registerClass('Infragistics.Web.UI.CalculateSummaryEventArgs', $IG.EventArgs);






$IG.SummaryAddingRemovingEventArgs = function(behavior)
{
	/// <summary locid="M:J#Infragistics.Web.UI.SummaryRow.SummaryAddingRemovingEventArgs">
	/// Object for event arguments used in the summary row behavior for Adding/Removing column summaries.
	/// </summary>
	/// <param name="behavior" type="Infragistics.Web.UI.SummaryRow">The summary row behavior. </param>

	$IG.SummaryAddingRemovingEventArgs.initializeBase(this, [behavior]);

	
	this._props[1] = 2;
}

$IG.SummaryAddingRemovingEventArgs.prototype =
{
}
$IG.SummaryAddingRemovingEventArgs.registerClass('Infragistics.Web.UI.SummaryAddingRemovingEventArgs', $IG.CancelBehaviorEventArgs);

